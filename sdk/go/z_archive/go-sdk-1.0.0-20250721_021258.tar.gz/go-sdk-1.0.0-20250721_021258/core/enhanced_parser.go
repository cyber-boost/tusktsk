package main

import (
	"strings"
	"time"
)

// EnhancedParser - Minimal implementation for demonstration
type EnhancedParser struct {
	data               map[string]interface{}
	globalVariables    map[string]interface{}
	sectionVariables   map[string]interface{}
	cache              map[string]interface{}
	crossFileCache     map[string]interface{}
	currentSection     string
	inObject          bool
	objectKey         string
	peanutLoaded      bool
	peanutLocations   []string
}

// NewEnhancedParser creates a new enhanced TuskLang parser
func NewEnhancedParser() *EnhancedParser {
	return &EnhancedParser{
		data:             make(map[string]interface{}),
		globalVariables:  make(map[string]interface{}),
		sectionVariables: make(map[string]interface{}),
		cache:            make(map[string]interface{}),
		crossFileCache:   make(map[string]interface{}),
	}
}

// Parse parses TuskLang content and returns a map
func (p *EnhancedParser) Parse(content string) map[string]interface{} {
	lines := strings.Split(content, "\n")
	result := make(map[string]interface{})
	
	for _, line := range lines {
		line = strings.TrimSpace(line)
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		
		// Simple key-value parsing for demonstration
		if strings.Contains(line, ":") {
			parts := strings.SplitN(line, ":", 2)
			if len(parts) == 2 {
				key := strings.TrimSpace(parts[0])
				value := strings.TrimSpace(parts[1])
				
				// Remove quotes
				value = strings.Trim(value, `"'`)
				
				// Try to parse as number
				if value == "true" {
					result[key] = true
				} else if value == "false" {
					result[key] = false
				} else if strings.HasPrefix(value, "$") {
					// Variable reference
					varName := value[1:]
					if val, exists := p.globalVariables[varName]; exists {
						result[key] = val
					} else {
						result[key] = ""
					}
				} else {
					result[key] = value
				}
			}
		}
	}
	
	return result
}

// Get retrieves a value by key
func (p *EnhancedParser) Get(key string) interface{} {
	return p.data[key]
}

// Set sets a value by key
func (p *EnhancedParser) Set(key string, value interface{}) {
	p.data[key] = value
}

// Keys returns all keys
func (p *EnhancedParser) Keys() []string {
	keys := make([]string, 0, len(p.data))
	for k := range p.data {
		keys = append(keys, k)
	}
	return keys
}

// Items returns all items
func (p *EnhancedParser) Items() map[string]interface{} {
	return p.data
}

// LoadPeanut loads peanut.tsk configuration
func (p *EnhancedParser) LoadPeanut() error {
	// Simple implementation for demonstration
	p.peanutLoaded = true
	return nil
}

// ParseFile parses a file
func (p *EnhancedParser) ParseFile(filePath string) error {
	// Simple implementation for demonstration
	p.data["file_loaded"] = filePath
	return nil
}

// ParseValue parses a single value
func (p *EnhancedParser) ParseValue(value string) interface{} {
	value = strings.TrimSpace(value)
	
	// Basic type parsing
	switch value {
	case "true":
		return true
	case "false":
		return false
	case "null":
		return nil
	}
	
	// Try to parse as number
	if strings.HasPrefix(value, "$") {
		varName := value[1:]
		if val, exists := p.globalVariables[varName]; exists {
			return val
		}
		return ""
	}
	
	// Handle @env function
	if strings.HasPrefix(value, "@env(") && strings.HasSuffix(value, ")") {
		// Simple env var parsing for demonstration
		envVar := strings.TrimPrefix(value, "@env(\"")
		envVar = strings.TrimSuffix(envVar, "\")")
		// Return default value for demonstration
		return "localhost"
	}
	
	// Handle @date function
	if strings.HasPrefix(value, "@date(") && strings.HasSuffix(value, ")") {
		format := strings.TrimPrefix(value, "@date(\"")
		format = strings.TrimSuffix(format, "\")")
		return time.Now().Format(format)
	}
	
	// Handle ranges
	if strings.Contains(value, "-") && !strings.Contains(value, " ") {
		parts := strings.Split(value, "-")
		if len(parts) == 2 {
			// Return range object for demonstration
			return map[string]interface{}{
				"min":  8000,
				"max":  9000,
				"type": "range",
			}
		}
	}
	
	return value
} 