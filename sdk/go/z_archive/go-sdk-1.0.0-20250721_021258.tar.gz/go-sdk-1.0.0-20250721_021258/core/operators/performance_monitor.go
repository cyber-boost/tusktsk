package operators

import (
	"context"
	"fmt"
	"sync"
	"time"
)

// PerformanceMonitor tracks operator execution metrics
type PerformanceMonitor struct {
	*BaseOperator
	metrics map[string]*OperatorMetrics
	mutex   sync.RWMutex
}

// OperatorMetrics tracks performance data for each operator
type OperatorMetrics struct {
	TotalExecutions int64
	TotalDuration   time.Duration
	AverageDuration time.Duration
	LastExecution   time.Time
	ErrorCount      int64
	SuccessCount    int64
}

// NewPerformanceMonitor creates a new performance monitoring operator
func NewPerformanceMonitor() *PerformanceMonitor {
	return &PerformanceMonitor{
		BaseOperator: NewBaseOperator(),
		metrics:      make(map[string]*OperatorMetrics),
	}
}

// Execute handles @performance operations
func (p *PerformanceMonitor) Execute(ctx context.Context, params map[string]interface{}) OperatorResult {
	p.Log("Executing @performance operator with params: %v", params)
	
	operation := p.GetStringParam(params, "operation", "stats")
	
	switch operation {
	case "stats":
		return p.getStats()
	case "reset":
		return p.resetMetrics()
	case "monitor":
		operatorName := p.GetStringParam(params, "operator", "")
		return p.monitorOperator(operatorName)
	default:
		return p.CreateErrorResult(fmt.Sprintf("unknown performance operation: %s", operation))
	}
}

// getStats returns performance statistics
func (p *PerformanceMonitor) getStats() OperatorResult {
	p.mutex.RLock()
	defer p.mutex.RUnlock()
	
	stats := map[string]interface{}{
		"total_operators": len(p.metrics),
		"metrics":         p.metrics,
		"summary": map[string]interface{}{
			"total_executions": p.getTotalExecutions(),
			"total_duration":   p.getTotalDuration(),
			"average_duration": p.getAverageDuration(),
		},
	}
	
	return p.CreateSuccessResult(stats)
}

// resetMetrics clears all performance metrics
func (p *PerformanceMonitor) resetMetrics() OperatorResult {
	p.mutex.Lock()
	defer p.mutex.Unlock()
	
	p.metrics = make(map[string]*OperatorMetrics)
	
	result := map[string]interface{}{
		"operation": "reset",
		"status":    "metrics_reset",
		"response":  "[Performance metrics reset successfully]",
	}
	
	return p.CreateSuccessResult(result)
}

// monitorOperator starts monitoring a specific operator
func (p *PerformanceMonitor) monitorOperator(operatorName string) OperatorResult {
	if operatorName == "" {
		return p.CreateErrorResult("operator name is required for monitoring")
	}
	
	p.mutex.Lock()
	defer p.mutex.Unlock()
	
	if _, exists := p.metrics[operatorName]; !exists {
		p.metrics[operatorName] = &OperatorMetrics{}
	}
	
	result := map[string]interface{}{
		"operation":     "monitor",
		"operator":      operatorName,
		"status":        "monitoring_started",
		"response":      fmt.Sprintf("[Performance monitoring started for: %s]", operatorName),
		"current_stats": p.metrics[operatorName],
	}
	
	return p.CreateSuccessResult(result)
}

// RecordExecution records execution metrics for an operator
func (p *PerformanceMonitor) RecordExecution(operatorName string, duration time.Duration, success bool) {
	p.mutex.Lock()
	defer p.mutex.Unlock()
	
	if _, exists := p.metrics[operatorName]; !exists {
		p.metrics[operatorName] = &OperatorMetrics{}
	}
	
	metrics := p.metrics[operatorName]
	metrics.TotalExecutions++
	metrics.TotalDuration += duration
	metrics.AverageDuration = metrics.TotalDuration / time.Duration(metrics.TotalExecutions)
	metrics.LastExecution = time.Now()
	
	if success {
		metrics.SuccessCount++
	} else {
		metrics.ErrorCount++
	}
}

// getTotalExecutions returns total executions across all operators
func (p *PerformanceMonitor) getTotalExecutions() int64 {
	var total int64
	for _, metrics := range p.metrics {
		total += metrics.TotalExecutions
	}
	return total
}

// getTotalDuration returns total duration across all operators
func (p *PerformanceMonitor) getTotalDuration() time.Duration {
	var total time.Duration
	for _, metrics := range p.metrics {
		total += metrics.TotalDuration
	}
	return total
}

// getAverageDuration returns average duration across all operators
func (p *PerformanceMonitor) getAverageDuration() time.Duration {
	totalExecutions := p.getTotalExecutions()
	if totalExecutions == 0 {
		return 0
	}
	return p.getTotalDuration() / time.Duration(totalExecutions)
} 