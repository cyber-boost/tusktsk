package operators

import (
	"context"
	"fmt"
)

// EmailOperator handles @email operations
type EmailOperator struct {
	*BaseOperator
}

func NewEmailOperator() *EmailOperator {
	return &EmailOperator{BaseOperator: NewBaseOperator()}
}

func (e *EmailOperator) Execute(ctx context.Context, params map[string]interface{}) OperatorResult {
	operation := e.GetStringParam(params, "operation", "send")
	switch operation {
	case "send":
		to := e.GetStringParam(params, "to", "")
		subject := e.GetStringParam(params, "subject", "")
		body := e.GetStringParam(params, "body", "")
		return e.send(to, subject, body)
	case "status":
		id := e.GetStringParam(params, "id", "")
		return e.status(id)
	default:
		return e.CreateErrorResult(fmt.Sprintf("unknown email operation: %s", operation))
	}
}

func (e *EmailOperator) send(to, subject, body string) OperatorResult {
	if to == "" {
		return e.CreateErrorResult("recipient is required")
	}
	return e.CreateSuccessResult(map[string]interface{}{"sent": true, "to": to, "subject": subject, "id": "email-123"})
}

func (e *EmailOperator) status(id string) OperatorResult {
	return e.CreateSuccessResult(map[string]interface{}{"id": id, "status": "delivered"})
}

// SmsOperator handles @sms operations
type SmsOperator struct {
	*BaseOperator
}

func NewSmsOperator() *SmsOperator {
	return &SmsOperator{BaseOperator: NewBaseOperator()}
}

func (s *SmsOperator) Execute(ctx context.Context, params map[string]interface{}) OperatorResult {
	operation := s.GetStringParam(params, "operation", "send")
	switch operation {
	case "send":
		to := s.GetStringParam(params, "to", "")
		message := s.GetStringParam(params, "message", "")
		return s.send(to, message)
	case "status":
		id := s.GetStringParam(params, "id", "")
		return s.status(id)
	default:
		return s.CreateErrorResult(fmt.Sprintf("unknown sms operation: %s", operation))
	}
}

func (s *SmsOperator) send(to, message string) OperatorResult {
	if to == "" {
		return s.CreateErrorResult("recipient is required")
	}
	return s.CreateSuccessResult(map[string]interface{}{"sent": true, "to": to, "id": "sms-123"})
}

func (s *SmsOperator) status(id string) OperatorResult {
	return s.CreateSuccessResult(map[string]interface{}{"id": id, "status": "delivered"})
}

// SlackOperator handles @slack operations
type SlackOperator struct {
	*BaseOperator
}

func NewSlackOperator() *SlackOperator {
	return &SlackOperator{BaseOperator: NewBaseOperator()}
}

func (s *SlackOperator) Execute(ctx context.Context, params map[string]interface{}) OperatorResult {
	operation := s.GetStringParam(params, "operation", "send")
	switch operation {
	case "send":
		channel := s.GetStringParam(params, "channel", "")
		message := s.GetStringParam(params, "message", "")
		return s.send(channel, message)
	case "list_channels":
		return s.listChannels()
	default:
		return s.CreateErrorResult(fmt.Sprintf("unknown slack operation: %s", operation))
	}
}

func (s *SlackOperator) send(channel, message string) OperatorResult {
	if channel == "" {
		return s.CreateErrorResult("channel is required")
	}
	return s.CreateSuccessResult(map[string]interface{}{"sent": true, "channel": channel})
}

func (s *SlackOperator) listChannels() OperatorResult {
	return s.CreateSuccessResult(map[string]interface{}{"channels": []string{"general", "random"}})
}

// TeamsOperator handles @teams operations
type TeamsOperator struct {
	*BaseOperator
}

func NewTeamsOperator() *TeamsOperator {
	return &TeamsOperator{BaseOperator: NewBaseOperator()}
}

func (t *TeamsOperator) Execute(ctx context.Context, params map[string]interface{}) OperatorResult {
	operation := t.GetStringParam(params, "operation", "send")
	switch operation {
	case "send":
		channel := t.GetStringParam(params, "channel", "")
		message := t.GetStringParam(params, "message", "")
		return t.send(channel, message)
	case "list_channels":
		return t.listChannels()
	default:
		return t.CreateErrorResult(fmt.Sprintf("unknown teams operation: %s", operation))
	}
}

func (t *TeamsOperator) send(channel, message string) OperatorResult {
	if channel == "" {
		return t.CreateErrorResult("channel is required")
	}
	return t.CreateSuccessResult(map[string]interface{}{"sent": true, "channel": channel})
}

func (t *TeamsOperator) listChannels() OperatorResult {
	return t.CreateSuccessResult(map[string]interface{}{"channels": []string{"team1", "team2"}})
}

// DiscordOperator handles @discord operations
type DiscordOperator struct {
	*BaseOperator
}

func NewDiscordOperator() *DiscordOperator {
	return &DiscordOperator{BaseOperator: NewBaseOperator()}
}

func (d *DiscordOperator) Execute(ctx context.Context, params map[string]interface{}) OperatorResult {
	operation := d.GetStringParam(params, "operation", "send")
	switch operation {
	case "send":
		channel := d.GetStringParam(params, "channel", "")
		message := d.GetStringParam(params, "message", "")
		return d.send(channel, message)
	case "list_channels":
		return d.listChannels()
	default:
		return d.CreateErrorResult(fmt.Sprintf("unknown discord operation: %s", operation))
	}
}

func (d *DiscordOperator) send(channel, message string) OperatorResult {
	if channel == "" {
		return d.CreateErrorResult("channel is required")
	}
	return d.CreateSuccessResult(map[string]interface{}{"sent": true, "channel": channel})
}

func (d *DiscordOperator) listChannels() OperatorResult {
	return d.CreateSuccessResult(map[string]interface{}{"channels": []string{"discord1", "discord2"}})
}

// WebhookOperator handles @webhook operations
type WebhookOperator struct {
	*BaseOperator
}

func NewWebhookOperator() *WebhookOperator {
	return &WebhookOperator{BaseOperator: NewBaseOperator()}
}

func (w *WebhookOperator) Execute(ctx context.Context, params map[string]interface{}) OperatorResult {
	operation := w.GetStringParam(params, "operation", "send")
	switch operation {
	case "send":
		url := w.GetStringParam(params, "url", "")
		payload := w.GetStringParam(params, "payload", "")
		return w.send(url, payload)
	default:
		return w.CreateErrorResult(fmt.Sprintf("unknown webhook operation: %s", operation))
	}
}

func (w *WebhookOperator) send(url, payload string) OperatorResult {
	if url == "" {
		return w.CreateErrorResult("url is required")
	}
	return w.CreateSuccessResult(map[string]interface{}{"sent": true, "url": url})
} 