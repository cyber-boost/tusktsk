package operators

import (
	"context"
	"fmt"
	"reflect"
	"strings"
)

// SwitchOperator handles @switch operations
type SwitchOperator struct {
	*BaseOperator
}

// NewSwitchOperator creates a new switch operator
func NewSwitchOperator() *SwitchOperator {
	return &SwitchOperator{
		BaseOperator: NewBaseOperator(),
	}
}

// Execute handles @switch operations
func (s *SwitchOperator) Execute(ctx context.Context, params map[string]interface{}) OperatorResult {
	s.Log("Executing @switch operator with params: %v", params)
	
	value := params["value"]
	cases := params["cases"]
	defaultCase := params["default"]
	
	if value == nil {
		return s.CreateErrorResult("switch value is required")
	}
	
	if cases == nil {
		return s.CreateErrorResult("switch cases are required")
	}
	
	// Convert cases to map if it's not already
	casesMap, ok := cases.(map[string]interface{})
	if !ok {
		return s.CreateErrorResult("switch cases must be a map")
	}
	
	// Find matching case
	valueStr := fmt.Sprintf("%v", value)
	if result, exists := casesMap[valueStr]; exists {
		return s.CreateSuccessResult(result)
	}
	
	// Return default case if provided
	if defaultCase != nil {
		return s.CreateSuccessResult(defaultCase)
	}
	
	return s.CreateSuccessResult(nil)
}

// ForOperator handles @for operations
type ForOperator struct {
	*BaseOperator
}

// NewForOperator creates a new for operator
func NewForOperator() *ForOperator {
	return &ForOperator{
		BaseOperator: NewBaseOperator(),
	}
}

// Execute handles @for operations
func (f *ForOperator) Execute(ctx context.Context, params map[string]interface{}) OperatorResult {
	f.Log("Executing @for operator with params: %v", params)
	
	operation := f.GetStringParam(params, "operation", "loop")
	
	switch operation {
	case "loop":
		start := f.GetIntParam(params, "start", 0)
		end := f.GetIntParam(params, "end", 10)
		step := f.GetIntParam(params, "step", 1)
		action := params["action"]
		return f.loop(start, end, step, action)
	case "range":
		items := params["items"]
		action := params["action"]
		return f.rangeLoop(items, action)
	case "while":
		condition := f.GetStringParam(params, "condition", "")
		action := params["action"]
		maxIterations := f.GetIntParam(params, "max_iterations", 1000)
		return f.whileLoop(condition, action, maxIterations)
	default:
		return f.CreateErrorResult(fmt.Sprintf("unknown for operation: %s", operation))
	}
}

func (f *ForOperator) loop(start, end, step int, action interface{}) OperatorResult {
	if step == 0 {
		return f.CreateErrorResult("for loop step cannot be zero")
	}
	
	var results []interface{}
	
	for i := start; (step > 0 && i < end) || (step < 0 && i > end); i += step {
		// Execute action for each iteration
		if action != nil {
			// In a real implementation, this would execute the action with the current index
			results = append(results, map[string]interface{}{
				"index":  i,
				"action": action,
			})
		}
	}
	
	result := map[string]interface{}{
		"operation": "loop",
		"start":     start,
		"end":       end,
		"step":      step,
		"action":    action,
		"results":   results,
		"iterations": len(results),
	}
	
	return f.CreateSuccessResult(result)
}

func (f *ForOperator) rangeLoop(items interface{}, action interface{}) OperatorResult {
	if items == nil {
		return f.CreateErrorResult("for range items are required")
	}
	
	var results []interface{}
	
	// Handle different types of items
	itemsValue := reflect.ValueOf(items)
	switch itemsValue.Kind() {
	case reflect.Slice, reflect.Array:
		for i := 0; i < itemsValue.Len(); i++ {
			item := itemsValue.Index(i).Interface()
			results = append(results, map[string]interface{}{
				"index": i,
				"item":  item,
				"action": action,
			})
		}
	case reflect.Map:
		iter := itemsValue.MapRange()
		for iter.Next() {
			key := iter.Key().Interface()
			value := iter.Value().Interface()
			results = append(results, map[string]interface{}{
				"key":    key,
				"value":  value,
				"action": action,
			})
		}
	default:
		return f.CreateErrorResult("for range items must be a slice, array, or map")
	}
	
	result := map[string]interface{}{
		"operation": "range",
		"items":     items,
		"action":    action,
		"results":   results,
		"iterations": len(results),
	}
	
	return f.CreateSuccessResult(result)
}

func (f *ForOperator) whileLoop(condition string, action interface{}, maxIterations int) OperatorResult {
	if condition == "" {
		return f.CreateErrorResult("while loop condition is required")
	}
	
	var results []interface{}
	iteration := 0
	
	// In a real implementation, this would evaluate the condition and execute the action
	// For now, we'll simulate a simple loop
	for iteration < maxIterations {
		// Simulate condition evaluation
		if iteration >= 5 { // Simulate condition becoming false after 5 iterations
			break
		}
		
		results = append(results, map[string]interface{}{
			"iteration": iteration,
			"condition": condition,
			"action":    action,
		})
		
		iteration++
	}
	
	result := map[string]interface{}{
		"operation": "while",
		"condition": condition,
		"action":    action,
		"results":   results,
		"iterations": len(results),
		"max_iterations": maxIterations,
	}
	
	return f.CreateSuccessResult(result)
}

// WhileOperator handles @while operations
type WhileOperator struct {
	*BaseOperator
}

// NewWhileOperator creates a new while operator
func NewWhileOperator() *WhileOperator {
	return &WhileOperator{
		BaseOperator: NewBaseOperator(),
	}
}

// Execute handles @while operations
func (w *WhileOperator) Execute(ctx context.Context, params map[string]interface{}) OperatorResult {
	w.Log("Executing @while operator with params: %v", params)
	
	condition := w.GetStringParam(params, "condition", "")
	action := params["action"]
	maxIterations := w.GetIntParam(params, "max_iterations", 1000)
	
	if condition == "" {
		return w.CreateErrorResult("while condition is required")
	}
	
	if action == nil {
		return w.CreateErrorResult("while action is required")
	}
	
	var results []interface{}
	iteration := 0
	
	// In a real implementation, this would evaluate the condition and execute the action
	// For now, we'll simulate a simple loop
	for iteration < maxIterations {
		// Simulate condition evaluation
		if iteration >= 3 { // Simulate condition becoming false after 3 iterations
			break
		}
		
		results = append(results, map[string]interface{}{
			"iteration": iteration,
			"condition": condition,
			"action":    action,
		})
		
		iteration++
	}
	
	result := map[string]interface{}{
		"condition": condition,
		"action":    action,
		"results":   results,
		"iterations": len(results),
		"max_iterations": maxIterations,
	}
	
	return w.CreateSuccessResult(result)
}

// EachOperator handles @each operations
type EachOperator struct {
	*BaseOperator
}

// NewEachOperator creates a new each operator
func NewEachOperator() *EachOperator {
	return &EachOperator{
		BaseOperator: NewBaseOperator(),
	}
}

// Execute handles @each operations
func (e *EachOperator) Execute(ctx context.Context, params map[string]interface{}) OperatorResult {
	e.Log("Executing @each operator with params: %v", params)
	
	items := params["items"]
	action := params["action"]
	
	if items == nil {
		return e.CreateErrorResult("each items are required")
	}
	
	if action == nil {
		return e.CreateErrorResult("each action is required")
	}
	
	var results []interface{}
	
	// Handle different types of items
	itemsValue := reflect.ValueOf(items)
	switch itemsValue.Kind() {
	case reflect.Slice, reflect.Array:
		for i := 0; i < itemsValue.Len(); i++ {
			item := itemsValue.Index(i).Interface()
			results = append(results, map[string]interface{}{
				"index": i,
				"item":  item,
				"action": action,
			})
		}
	case reflect.Map:
		iter := itemsValue.MapRange()
		for iter.Next() {
			key := iter.Key().Interface()
			value := iter.Value().Interface()
			results = append(results, map[string]interface{}{
				"key":    key,
				"value":  value,
				"action": action,
			})
		}
	default:
		return e.CreateErrorResult("each items must be a slice, array, or map")
	}
	
	result := map[string]interface{}{
		"items":     items,
		"action":    action,
		"results":   results,
		"iterations": len(results),
	}
	
	return e.CreateSuccessResult(result)
}

// FilterOperator handles @filter operations
type FilterOperator struct {
	*BaseOperator
}

// NewFilterOperator creates a new filter operator
func NewFilterOperator() *FilterOperator {
	return &FilterOperator{
		BaseOperator: NewBaseOperator(),
	}
}

// Execute handles @filter operations
func (f *FilterOperator) Execute(ctx context.Context, params map[string]interface{}) OperatorResult {
	f.Log("Executing @filter operator with params: %v", params)
	
	items := params["items"]
	condition := f.GetStringParam(params, "condition", "")
	predicate := params["predicate"]
	
	if items == nil {
		return f.CreateErrorResult("filter items are required")
	}
	
	var filteredResults []interface{}
	
	// Handle different types of items
	itemsValue := reflect.ValueOf(items)
	switch itemsValue.Kind() {
	case reflect.Slice, reflect.Array:
		for i := 0; i < itemsValue.Len(); i++ {
			item := itemsValue.Index(i).Interface()
			
			// Apply filter condition
			if f.shouldInclude(item, condition, predicate) {
				filteredResults = append(filteredResults, item)
			}
		}
	case reflect.Map:
		iter := itemsValue.MapRange()
		for iter.Next() {
			key := iter.Key().Interface()
			value := iter.Value().Interface()
			
			// Apply filter condition
			if f.shouldInclude(value, condition, predicate) {
				filteredResults = append(filteredResults, map[string]interface{}{
					"key":   key,
					"value": value,
				})
			}
		}
	default:
		return f.CreateErrorResult("filter items must be a slice, array, or map")
	}
	
	result := map[string]interface{}{
		"items":           items,
		"condition":       condition,
		"predicate":       predicate,
		"filtered_results": filteredResults,
		"original_count":   itemsValue.Len(),
		"filtered_count":   len(filteredResults),
	}
	
	return f.CreateSuccessResult(result)
}

// shouldInclude determines if an item should be included based on condition or predicate
func (f *FilterOperator) shouldInclude(item interface{}, condition string, predicate interface{}) bool {
	// If predicate is provided, use it
	if predicate != nil {
		// In a real implementation, this would evaluate the predicate function
		// For now, we'll simulate a simple check
		itemStr := fmt.Sprintf("%v", item)
		return strings.Contains(itemStr, "include")
	}
	
	// If condition is provided, evaluate it
	if condition != "" {
		// In a real implementation, this would evaluate the condition
		// For now, we'll simulate a simple check
		itemStr := fmt.Sprintf("%v", item)
		return strings.Contains(itemStr, condition)
	}
	
	// Default: include all items
	return true
} 