package communication

import (
	"encoding/json"
	"fmt"
	"sync"
	"time"

	"github.com/nats-io/nats.go"
)

// NATSOperator handles @nats operations
type NATSOperator struct {
	connections map[string]*nats.Conn
	subscribers map[string]*nats.Subscription
	mutex       sync.RWMutex
}

// NATSMessage represents a NATS message
type NATSMessage struct {
	Subject string                 `json:"subject"`
	Data    interface{}            `json:"data"`
	Reply   string                 `json:"reply,omitempty"`
	Headers map[string]string      `json:"headers,omitempty"`
}

// NewNATSOperator creates a new NATS operator
func NewNATSOperator() *NATSOperator {
	return &NATSOperator{
		connections: make(map[string]*nats.Conn),
		subscribers: make(map[string]*nats.Subscription),
	}
}

// Execute handles @nats operations
func (n *NATSOperator) Execute(params string) interface{} {
	// Parse parameters (format: "action", "subject", "message")
	// Example: @nats("publish", "user.created", '{"id": "123"}')
	
	return fmt.Sprintf("@nats(%s)", params)
}

// Connect establishes a NATS connection
func (n *NATSOperator) Connect(name, url string) error {
	n.mutex.Lock()
	defer n.mutex.Unlock()

	nc, err := nats.Connect(url)
	if err != nil {
		return fmt.Errorf("failed to connect to NATS %s at %s: %v", name, url, err)
	}

	n.connections[name] = nc
	return nil
}

// Disconnect closes a NATS connection
func (n *NATSOperator) Disconnect(name string) error {
	n.mutex.Lock()
	defer n.mutex.Unlock()

	if nc, exists := n.connections[name]; exists {
		nc.Close()
		delete(n.connections, name)
		return nil
	}

	return fmt.Errorf("connection %s not found", name)
}

// Publish publishes a message to a subject
func (n *NATSOperator) Publish(connectionName, subject string, data interface{}) error {
	n.mutex.RLock()
	nc, exists := n.connections[connectionName]
	n.mutex.RUnlock()

	if !exists {
		return fmt.Errorf("connection %s not found", connectionName)
	}

	messageBytes, err := json.Marshal(data)
	if err != nil {
		return fmt.Errorf("failed to marshal message: %v", err)
	}

	return nc.Publish(subject, messageBytes)
}

// Subscribe subscribes to a subject
func (n *NATSOperator) Subscribe(connectionName, subject string, handler func(*NATSMessage)) error {
	n.mutex.RLock()
	nc, exists := n.connections[connectionName]
	n.mutex.RUnlock()

	if !exists {
		return fmt.Errorf("connection %s not found", connectionName)
	}

	sub, err := nc.Subscribe(subject, func(msg *nats.Msg) {
		var data interface{}
		if err := json.Unmarshal(msg.Data, &data); err != nil {
			data = string(msg.Data)
		}

		natsMessage := &NATSMessage{
			Subject: msg.Subject,
			Data:    data,
			Reply:   msg.Reply,
		}

		handler(natsMessage)
	})

	if err != nil {
		return fmt.Errorf("failed to subscribe to %s: %v", subject, err)
	}

	subKey := fmt.Sprintf("%s:%s", connectionName, subject)
	n.mutex.Lock()
	n.subscribers[subKey] = sub
	n.mutex.Unlock()

	return nil
}

// Request sends a request and waits for a response
func (n *NATSOperator) Request(connectionName, subject string, data interface{}, timeout time.Duration) (*NATSMessage, error) {
	n.mutex.RLock()
	nc, exists := n.connections[connectionName]
	n.mutex.RUnlock()

	if !exists {
		return nil, fmt.Errorf("connection %s not found", connectionName)
	}

	messageBytes, err := json.Marshal(data)
	if err != nil {
		return nil, fmt.Errorf("failed to marshal message: %v", err)
	}

	msg, err := nc.Request(subject, messageBytes, timeout)
	if err != nil {
		return nil, fmt.Errorf("request failed: %v", err)
	}

	var responseData interface{}
	if err := json.Unmarshal(msg.Data, &responseData); err != nil {
		responseData = string(msg.Data)
	}

	return &NATSMessage{
		Subject: msg.Subject,
		Data:    responseData,
		Reply:   msg.Reply,
	}, nil
}

// QueueSubscribe subscribes to a subject with queue group
func (n *NATSOperator) QueueSubscribe(connectionName, subject, queue string, handler func(*NATSMessage)) error {
	n.mutex.RLock()
	nc, exists := n.connections[connectionName]
	n.mutex.RUnlock()

	if !exists {
		return fmt.Errorf("connection %s not found", connectionName)
	}

	sub, err := nc.QueueSubscribe(subject, queue, func(msg *nats.Msg) {
		var data interface{}
		if err := json.Unmarshal(msg.Data, &data); err != nil {
			data = string(msg.Data)
		}

		natsMessage := &NATSMessage{
			Subject: msg.Subject,
			Data:    data,
			Reply:   msg.Reply,
		}

		handler(natsMessage)
	})

	if err != nil {
		return fmt.Errorf("failed to queue subscribe to %s: %v", subject, err)
	}

	subKey := fmt.Sprintf("%s:%s:%s", connectionName, subject, queue)
	n.mutex.Lock()
	n.subscribers[subKey] = sub
	n.mutex.Unlock()

	return nil
}

// Unsubscribe unsubscribes from a subject
func (n *NATSOperator) Unsubscribe(connectionName, subject string) error {
	subKey := fmt.Sprintf("%s:%s", connectionName, subject)
	
	n.mutex.Lock()
	defer n.mutex.Unlock()

	if sub, exists := n.subscribers[subKey]; exists {
		sub.Unsubscribe()
		delete(n.subscribers, subKey)
		return nil
	}

	return fmt.Errorf("subscription %s not found", subKey)
}

// ListConnections returns a list of active connection names
func (n *NATSOperator) ListConnections() []string {
	n.mutex.RLock()
	defer n.mutex.RUnlock()

	names := make([]string, 0, len(n.connections))
	for name := range n.connections {
		names = append(names, name)
	}
	return names
}

// GetConnectionStatus returns the status of a connection
func (n *NATSOperator) GetConnectionStatus(name string) string {
	n.mutex.RLock()
	defer n.mutex.RUnlock()

	if nc, exists := n.connections[name]; exists {
		if nc.IsConnected() {
			return "connected"
		}
		return "disconnected"
	}
	return "not_found"
}

// Close closes all NATS connections
func (n *NATSOperator) Close() error {
	n.mutex.Lock()
	defer n.mutex.Unlock()

	for name, nc := range n.connections {
		nc.Close()
		delete(n.connections, name)
	}

	for _, sub := range n.subscribers {
		sub.Unsubscribe()
	}
	n.subscribers = make(map[string]*nats.Subscription)

	return nil
} 