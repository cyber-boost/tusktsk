package generator

import (
	"bytes"
	"encoding/json"
	"fmt"
	"go/ast"
	"go/parser"
	"go/token"
	"html/template"
	"io"
	"log"
	"os"
	"path/filepath"
	"regexp"
	"strings"
	"text/template"
	"time"

	"github.com/google/uuid"
	"github.com/sashabaranov/go-openai"
)

// CodeGenerator handles intelligent code generation and IDE integration
type CodeGenerator struct {
	config         *GeneratorConfig
	templates      map[string]*CodeTemplate
	aiClient       *openai.Client
	idePlugins     map[string]*IDEPlugin
	frameworks     map[string]*Framework
	validators     map[string]*Validator
	mutex          sync.RWMutex
	generationHistory []GenerationRecord
}

// GeneratorConfig holds code generation configuration
type GeneratorConfig struct {
	OpenAIKey        string            `json:"openai_key"`
	TemplateDir      string            `json:"template_dir"`
	OutputDir        string            `json:"output_dir"`
	FrameworkConfigs map[string]string `json:"framework_configs"`
	IDEConfigs       map[string]string `json:"ide_configs"`
	ValidationRules  map[string]string `json:"validation_rules"`
	AutoFormat       bool              `json:"auto_format"`
	BackupEnabled    bool              `json:"backup_enabled"`
	MaxTokens        int               `json:"max_tokens"`
	Temperature      float64           `json:"temperature"`
}

// CodeTemplate represents a code generation template
type CodeTemplate struct {
	Name        string                 `json:"name"`
	Description string                 `json:"description"`
	Framework   string                 `json:"framework"`
	Language    string                 `json:"language"`
	Template    string                 `json:"template"`
	Variables   map[string]interface{} `json:"variables"`
	Validation  []string               `json:"validation"`
	Examples    []string               `json:"examples"`
}

// IDEPlugin represents an IDE integration plugin
type IDEPlugin struct {
	Name        string            `json:"name"`
	IDE         string            `json:"ide"`
	Version     string            `json:"version"`
	Description string            `json:"description"`
	Commands    []IDECommand      `json:"commands"`
	Keybindings map[string]string `json:"keybindings"`
	Settings    map[string]string `json:"settings"`
	Files       []string          `json:"files"`
}

// IDECommand represents an IDE command
type IDECommand struct {
	Name        string   `json:"name"`
	Description string   `json:"description"`
	Shortcut    string   `json:"shortcut"`
	Arguments   []string `json:"arguments"`
	Output      string   `json:"output"`
}

// Framework represents a development framework
type Framework struct {
	Name         string            `json:"name"`
	Version      string            `json:"version"`
	Language     string            `json:"language"`
	Templates    []string          `json:"templates"`
	ConfigFiles  []string          `json:"config_files"`
	Dependencies map[string]string `json:"dependencies"`
	Commands     map[string]string `json:"commands"`
	Structure    []string          `json:"structure"`
}

// Validator represents a code validation rule
type Validator struct {
	Name        string `json:"name"`
	Pattern     string `json:"pattern"`
	Message     string `json:"message"`
	Severity    string `json:"severity"`
	Language    string `json:"language"`
	Framework   string `json:"framework"`
	Regex       *regexp.Regexp
}

// GenerationRecord represents a code generation record
type GenerationRecord struct {
	ID          string                 `json:"id"`
	Template    string                 `json:"template"`
	Framework   string                 `json:"framework"`
	Variables   map[string]interface{} `json:"variables"`
	Output      string                 `json:"output"`
	Timestamp   time.Time              `json:"timestamp"`
	Duration    time.Duration          `json:"duration"`
	Validation  []ValidationResult     `json:"validation"`
	AIUsed      bool                   `json:"ai_used"`
}

// ValidationResult represents a validation result
type ValidationResult struct {
	Validator string `json:"validator"`
	Passed    bool   `json:"passed"`
	Message   string `json:"message"`
	Line      int    `json:"line"`
	Column    int    `json:"column"`
}

// DefaultGeneratorConfig returns default generator configuration
func DefaultGeneratorConfig() *GeneratorConfig {
	return &GeneratorConfig{
		TemplateDir:      "./templates",
		OutputDir:        "./generated",
		FrameworkConfigs: make(map[string]string),
		IDEConfigs:       make(map[string]string),
		ValidationRules:  make(map[string]string),
		AutoFormat:       true,
		BackupEnabled:    true,
		MaxTokens:        2000,
		Temperature:      0.7,
	}
}

// NewCodeGenerator creates a new code generator
func NewCodeGenerator(config *GeneratorConfig) (*CodeGenerator, error) {
	if config == nil {
		config = DefaultGeneratorConfig()
	}

	generator := &CodeGenerator{
		config:         config,
		templates:      make(map[string]*CodeTemplate),
		idePlugins:     make(map[string]*IDEPlugin),
		frameworks:     make(map[string]*Framework),
		validators:     make(map[string]*Validator),
		generationHistory: []GenerationRecord{},
	}

	// Initialize AI client if key provided
	if config.OpenAIKey != "" {
		generator.aiClient = openai.NewClient(config.OpenAIKey)
	}

	// Load templates
	if err := generator.loadTemplates(); err != nil {
		log.Printf("GENERATOR TEMPLATE LOAD ERROR: %v", err)
	}

	// Load frameworks
	if err := generator.loadFrameworks(); err != nil {
		log.Printf("GENERATOR FRAMEWORK LOAD ERROR: %v", err)
	}

	// Load validators
	if err := generator.loadValidators(); err != nil {
		log.Printf("GENERATOR VALIDATOR LOAD ERROR: %v", err)
	}

	// Load IDE plugins
	if err := generator.loadIDEPlugins(); err != nil {
		log.Printf("GENERATOR IDE PLUGIN LOAD ERROR: %v", err)
	}

	log.Printf("CODE GENERATOR INITIALIZED: templates=%d, frameworks=%d, validators=%d", 
		len(generator.templates), len(generator.frameworks), len(generator.validators))
	return generator, nil
}

// loadTemplates loads code generation templates
func (g *CodeGenerator) loadTemplates() error {
	templateDir := g.config.TemplateDir
	if err := os.MkdirAll(templateDir, 0755); err != nil {
		return fmt.Errorf("failed to create template directory: %v", err)
	}

	// Create default templates if directory is empty
	if entries, err := os.ReadDir(templateDir); err == nil && len(entries) == 0 {
		if err := g.createDefaultTemplates(); err != nil {
			return fmt.Errorf("failed to create default templates: %v", err)
		}
	}

	// Load template files
	return filepath.Walk(templateDir, func(path string, info os.FileInfo, err error) error {
		if err != nil {
			return err
		}

		if !info.IsDir() && strings.HasSuffix(path, ".json") {
			data, err := os.ReadFile(path)
			if err != nil {
				return fmt.Errorf("failed to read template %s: %v", path, err)
			}

			var template CodeTemplate
			if err := json.Unmarshal(data, &template); err != nil {
				return fmt.Errorf("failed to parse template %s: %v", path, err)
			}

			g.mutex.Lock()
			g.templates[template.Name] = &template
			g.mutex.Unlock()

			log.Printf("GENERATOR TEMPLATE LOADED: %s (%s)", template.Name, template.Framework)
		}

		return nil
	})
}

// createDefaultTemplates creates default code generation templates
func (g *CodeGenerator) createDefaultTemplates() error {
	defaultTemplates := []CodeTemplate{
		{
			Name:        "go-rest-api",
			Description: "Go REST API with Gin framework",
			Framework:   "gin",
			Language:    "go",
			Template: `package main

import (
	"github.com/gin-gonic/gin"
	"net/http"
)

type {{.ModelName}} struct {
	ID   uint   ` + "`json:\"id\"`" + `
	Name string ` + "`json:\"name\"`" + `
}

func main() {
	r := gin.Default()
	
	// {{.ModelName}} routes
	r.GET("/{{.ModelNameLower}}s", get{{.ModelName}}s)
	r.GET("/{{.ModelNameLower}}s/:id", get{{.ModelName}})
	r.POST("/{{.ModelNameLower}}s", create{{.ModelName}})
	r.PUT("/{{.ModelNameLower}}s/:id", update{{.ModelName}})
	r.DELETE("/{{.ModelNameLower}}s/:id", delete{{.ModelName}})
	
	r.Run(":{{.Port}}")
}

func get{{.ModelName}}s(c *gin.Context) {
	c.JSON(http.StatusOK, gin.H{"message": "Get all {{.ModelNameLower}}s"})
}

func get{{.ModelName}}(c *gin.Context) {
	id := c.Param("id")
	c.JSON(http.StatusOK, gin.H{"message": "Get {{.ModelNameLower}} " + id})
}

func create{{.ModelName}}(c *gin.Context) {
	c.JSON(http.StatusCreated, gin.H{"message": "Create {{.ModelNameLower}}"})
}

func update{{.ModelName}}(c *gin.Context) {
	id := c.Param("id")
	c.JSON(http.StatusOK, gin.H{"message": "Update {{.ModelNameLower}} " + id})
}

func delete{{.ModelName}}(c *gin.Context) {
	id := c.Param("id")
	c.JSON(http.StatusOK, gin.H{"message": "Delete {{.ModelNameLower}} " + id})
}`,
			Variables: map[string]interface{}{
				"ModelName":      "User",
				"ModelNameLower": "user",
				"Port":           "8080",
			},
			Validation: []string{"go-syntax", "gin-imports"},
			Examples:   []string{"go-rest-api --model=Product --port=3000"},
		},
		{
			Name:        "react-component",
			Description: "React functional component with TypeScript",
			Framework:   "react",
			Language:    "typescript",
			Template: `import React from 'react';

interface {{.ComponentName}}Props {
	{{range .Props}}
	{{.Name}}{{if .Optional}}?{{end}}: {{.Type}};{{end}}
}

export const {{.ComponentName}}: React.FC<{{.ComponentName}}Props> = ({ {{range .Props}}{{.Name}}{{if .Optional}} = {{.DefaultValue}}{{end}}{{if not .Last}}, {{end}}{{end}} }) => {
	return (
		<div className="{{.ClassName}}">
			<h2>{{.ComponentName}}</h2>
			{{range .Props}}
			<p>{{.Name}}: {String({{.Name}})}</p>
			{{end}}
		</div>
	);
};

export default {{.ComponentName}};`,
			Variables: map[string]interface{}{
				"ComponentName": "MyComponent",
				"ClassName":     "my-component",
				"Props": []map[string]interface{}{
					{"Name": "title", "Type": "string", "Optional": false, "DefaultValue": "", "Last": false},
					{"Name": "count", "Type": "number", "Optional": true, "DefaultValue": "0", "Last": true},
				},
			},
			Validation: []string{"typescript-syntax", "react-imports"},
			Examples:   []string{"react-component --name=Button --props=text:string,disabled:boolean"},
		},
		{
			Name:        "python-fastapi",
			Description: "Python FastAPI application",
			Framework:   "fastapi",
			Language:    "python",
			Template: `from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List, Optional
import uvicorn

app = FastAPI(title="{{.AppName}}", version="{{.Version}}")

class {{.ModelName}}(BaseModel):
	{{range .Fields}}
	{{.Name}}: {{.Type}}{{if .Optional}} = None{{end}}{{end}}

# Sample data
{{.ModelNameLower}}s = []

@app.get("/")
async def root():
	return {"message": "Welcome to {{.AppName}}"}

@app.get("/{{.ModelNameLower}}s", response_model=List[{{.ModelName}}])
async def get_{{.ModelNameLower}}s():
	return {{.ModelNameLower}}s

@app.get("/{{.ModelNameLower}}s/{item_id}", response_model={{.ModelName}})
async def get_{{.ModelNameLower}}(item_id: int):
	if item_id >= len({{.ModelNameLower}}s):
		raise HTTPException(status_code=404, detail="{{.ModelName}} not found")
	return {{.ModelNameLower}}s[item_id]

@app.post("/{{.ModelNameLower}}s", response_model={{.ModelName}})
async def create_{{.ModelNameLower}}({{.ModelNameLower}}: {{.ModelName}}):
	{{.ModelNameLower}}s.append({{.ModelNameLower}})
	return {{.ModelNameLower}}

if __name__ == "__main__":
	uvicorn.run(app, host="0.0.0.0", port={{.Port}})`,
			Variables: map[string]interface{}{
				"AppName":      "MyAPI",
				"Version":      "1.0.0",
				"ModelName":    "Item",
				"ModelNameLower": "item",
				"Port":         "8000",
				"Fields": []map[string]interface{}{
					{"Name": "id", "Type": "int", "Optional": false},
					{"Name": "name", "Type": "str", "Optional": false},
					{"Name": "description", "Type": "str", "Optional": true},
				},
			},
			Validation: []string{"python-syntax", "fastapi-imports"},
			Examples:   []string{"python-fastapi --app=ProductAPI --model=Product"},
		},
	}

	for _, tmpl := range defaultTemplates {
		data, err := json.MarshalIndent(tmpl, "", "  ")
		if err != nil {
			return fmt.Errorf("failed to marshal template %s: %v", tmpl.Name, err)
		}

		filename := filepath.Join(g.config.TemplateDir, tmpl.Name+".json")
		if err := os.WriteFile(filename, data, 0644); err != nil {
			return fmt.Errorf("failed to write template %s: %v", tmpl.Name, err)
		}
	}

	return nil
}

// loadFrameworks loads framework configurations
func (g *CodeGenerator) loadFrameworks() error {
	defaultFrameworks := map[string]*Framework{
		"gin": {
			Name:     "Gin",
			Version:  "v1.9.1",
			Language: "go",
			Templates: []string{"go-rest-api", "go-middleware", "go-handler"},
			ConfigFiles: []string{"go.mod", "go.sum"},
			Dependencies: map[string]string{
				"github.com/gin-gonic/gin": "v1.9.1",
			},
			Commands: map[string]string{
				"run":     "go run main.go",
				"build":   "go build -o app",
				"test":    "go test ./...",
				"mod-tidy": "go mod tidy",
			},
			Structure: []string{
				"main.go",
				"handlers/",
				"models/",
				"middleware/",
				"config/",
			},
		},
		"react": {
			Name:     "React",
			Version:  "18.2.0",
			Language: "typescript",
			Templates: []string{"react-component", "react-hook", "react-context"},
			ConfigFiles: []string{"package.json", "tsconfig.json", "vite.config.ts"},
			Dependencies: map[string]string{
				"react": "^18.2.0",
				"react-dom": "^18.2.0",
				"@types/react": "^18.2.0",
			},
			Commands: map[string]string{
				"dev":     "npm run dev",
				"build":   "npm run build",
				"preview": "npm run preview",
				"test":    "npm run test",
			},
			Structure: []string{
				"src/",
				"public/",
				"components/",
				"hooks/",
				"contexts/",
			},
		},
		"fastapi": {
			Name:     "FastAPI",
			Version:  "0.104.1",
			Language: "python",
			Templates: []string{"python-fastapi", "python-model", "python-router"},
			ConfigFiles: []string{"requirements.txt", "pyproject.toml"},
			Dependencies: map[string]string{
				"fastapi": "^0.104.1",
				"uvicorn": "^0.24.0",
				"pydantic": "^2.5.0",
			},
			Commands: map[string]string{
				"run":     "uvicorn main:app --reload",
				"test":    "pytest",
				"lint":    "flake8",
				"format":  "black .",
			},
			Structure: []string{
				"main.py",
				"models/",
				"routers/",
				"services/",
				"tests/",
			},
		},
	}

	for name, framework := range defaultFrameworks {
		g.mutex.Lock()
		g.frameworks[name] = framework
		g.mutex.Unlock()
	}

	return nil
}

// loadValidators loads validation rules
func (g *CodeGenerator) loadValidators() error {
	defaultValidators := []*Validator{
		{
			Name:     "go-syntax",
			Pattern:  `^package\s+\w+`,
			Message:  "Go file must start with package declaration",
			Severity: "error",
			Language: "go",
		},
		{
			Name:     "gin-imports",
			Pattern:  `github\.com/gin-gonic/gin`,
			Message:  "Gin import required for Gin framework",
			Severity: "warning",
			Framework: "gin",
		},
		{
			Name:     "typescript-syntax",
			Pattern:  `import\s+React`,
			Message:  "React import required for React components",
			Severity: "error",
			Language: "typescript",
			Framework: "react",
		},
		{
			Name:     "python-syntax",
			Pattern:  `from\s+fastapi\s+import`,
			Message:  "FastAPI import required for FastAPI applications",
			Severity: "error",
			Language: "python",
			Framework: "fastapi",
		},
	}

	for _, validator := range defaultValidators {
		validator.Regex = regexp.MustCompile(validator.Pattern)
		g.mutex.Lock()
		g.validators[validator.Name] = validator
		g.mutex.Unlock()
	}

	return nil
}

// loadIDEPlugins loads IDE integration plugins
func (g *CodeGenerator) loadIDEPlugins() error {
	defaultPlugins := map[string]*IDEPlugin{
		"vscode": {
			Name:        "VS Code Integration",
			IDE:         "vscode",
			Version:     "1.0.0",
			Description: "VS Code integration for Tusk code generation",
			Commands: []IDECommand{
				{
					Name:        "Generate Code",
					Description: "Generate code from template",
					Shortcut:    "Ctrl+Shift+G",
					Arguments:   []string{"--template", "--output"},
					Output:      "Generated code in output directory",
				},
				{
					Name:        "Quick Template",
					Description: "Quick template generation",
					Shortcut:    "Ctrl+Alt+T",
					Arguments:   []string{"--quick"},
					Output:      "Quick template in current directory",
				},
			},
			Keybindings: map[string]string{
				"Ctrl+Shift+G": "tusk.generate",
				"Ctrl+Alt+T":   "tusk.quickTemplate",
			},
			Settings: map[string]string{
				"tusk.templateDir": "./templates",
				"tusk.outputDir":   "./generated",
				"tusk.autoFormat":  "true",
			},
			Files: []string{
				".vscode/settings.json",
				".vscode/keybindings.json",
				".vscode/tasks.json",
			},
		},
		"intellij": {
			Name:        "IntelliJ Integration",
			IDE:         "intellij",
			Version:     "1.0.0",
			Description: "IntelliJ IDEA integration for Tusk code generation",
			Commands: []IDECommand{
				{
					Name:        "Generate Code",
					Description: "Generate code from template",
					Shortcut:    "Ctrl+Shift+G",
					Arguments:   []string{"--template", "--output"},
					Output:      "Generated code in output directory",
				},
			},
			Keybindings: map[string]string{
				"Ctrl+Shift+G": "TuskGenerate",
			},
			Settings: map[string]string{
				"tusk.templateDir": "./templates",
				"tusk.outputDir":   "./generated",
			},
			Files: []string{
				".idea/tusk.xml",
			},
		},
	}

	for name, plugin := range defaultPlugins {
		g.mutex.Lock()
		g.idePlugins[name] = plugin
		g.mutex.Unlock()
	}

	return nil
}

// GenerateCode generates code from a template
func (g *CodeGenerator) GenerateCode(templateName string, variables map[string]interface{}, useAI bool) (*GenerationRecord, error) {
	startTime := time.Now()

	g.mutex.RLock()
	template, exists := g.templates[templateName]
	g.mutex.RUnlock()

	if !exists {
		return nil, fmt.Errorf("template not found: %s", templateName)
	}

	// Merge template variables with provided variables
	mergedVars := make(map[string]interface{})
	for k, v := range template.Variables {
		mergedVars[k] = v
	}
	for k, v := range variables {
		mergedVars[k] = v
	}

	var generatedCode string
	var err error

	if useAI && g.aiClient != nil {
		generatedCode, err = g.generateWithAI(template, mergedVars)
	} else {
		generatedCode, err = g.generateWithTemplate(template, mergedVars)
	}

	if err != nil {
		return nil, fmt.Errorf("code generation failed: %v", err)
	}

	// Validate generated code
	validationResults := g.validateCode(generatedCode, template.Validation)

	// Create output directory
	outputPath := filepath.Join(g.config.OutputDir, templateName)
	if err := os.MkdirAll(outputPath, 0755); err != nil {
		return nil, fmt.Errorf("failed to create output directory: %v", err)
	}

	// Write generated code
	filename := fmt.Sprintf("%s.%s", templateName, g.getFileExtension(template.Language))
	outputFile := filepath.Join(outputPath, filename)

	if err := os.WriteFile(outputFile, []byte(generatedCode), 0644); err != nil {
		return nil, fmt.Errorf("failed to write generated code: %v", err)
	}

	// Format code if enabled
	if g.config.AutoFormat {
		if err := g.formatCode(outputFile, template.Language); err != nil {
			log.Printf("GENERATOR FORMAT ERROR: %v", err)
		}
	}

	// Create generation record
	record := GenerationRecord{
		ID:         uuid.New().String(),
		Template:   templateName,
		Framework:  template.Framework,
		Variables:  mergedVars,
		Output:     outputFile,
		Timestamp:  time.Now(),
		Duration:   time.Since(startTime),
		Validation: validationResults,
		AIUsed:     useAI,
	}

	g.mutex.Lock()
	g.generationHistory = append(g.generationHistory, record)
	g.mutex.Unlock()

	log.Printf("CODE GENERATED: template=%s, output=%s, duration=%v, ai=%v", 
		templateName, outputFile, record.Duration, useAI)

	return &record, nil
}

// generateWithTemplate generates code using template engine
func (g *CodeGenerator) generateWithTemplate(template *CodeTemplate, variables map[string]interface{}) (string, error) {
	tmpl, err := text.New("code").Parse(template.Template)
	if err != nil {
		return "", fmt.Errorf("failed to parse template: %v", err)
	}

	var buf bytes.Buffer
	if err := tmpl.Execute(&buf, variables); err != nil {
		return "", fmt.Errorf("failed to execute template: %v", err)
	}

	return buf.String(), nil
}

// generateWithAI generates code using AI
func (g *CodeGenerator) generateWithAI(template *CodeTemplate, variables map[string]interface{}) (string, error) {
	prompt := fmt.Sprintf(`Generate code for a %s %s application using the following template as reference:

Template:
%s

Variables:
%s

Generate complete, production-ready code that follows best practices for %s development.`,
		template.Framework, template.Language, template.Template, 
		g.formatVariables(variables), template.Language)

	resp, err := g.aiClient.CreateChatCompletion(
		context.Background(),
		openai.ChatCompletionRequest{
			Model:       openai.GPT4,
			Messages:    []openai.ChatCompletionMessage{{Role: openai.ChatMessageRoleUser, Content: prompt}},
			MaxTokens:   g.config.MaxTokens,
			Temperature: g.config.Temperature,
		},
	)

	if err != nil {
		return "", fmt.Errorf("AI generation failed: %v", err)
	}

	if len(resp.Choices) == 0 {
		return "", fmt.Errorf("no response from AI")
	}

	return resp.Choices[0].Message.Content, nil
}

// validateCode validates generated code
func (g *CodeGenerator) validateCode(code string, validationRules []string) []ValidationResult {
	var results []ValidationResult

	for _, ruleName := range validationRules {
		g.mutex.RLock()
		validator, exists := g.validators[ruleName]
		g.mutex.RUnlock()

		if !exists {
			continue
		}

		lines := strings.Split(code, "\n")
		passed := false

		for lineNum, line := range lines {
			if validator.Regex.MatchString(line) {
				passed = true
				break
			}
		}

		results = append(results, ValidationResult{
			Validator: ruleName,
			Passed:    passed,
			Message:   validator.Message,
		})
	}

	return results
}

// formatCode formats generated code
func (g *CodeGenerator) formatCode(filepath, language string) error {
	switch language {
	case "go":
		return exec.Command("go", "fmt", filepath).Run()
	case "typescript", "javascript":
		return exec.Command("npx", "prettier", "--write", filepath).Run()
	case "python":
		return exec.Command("black", filepath).Run()
	default:
		return nil
	}
}

// getFileExtension returns file extension for language
func (g *CodeGenerator) getFileExtension(language string) string {
	extensions := map[string]string{
		"go":         "go",
		"typescript": "ts",
		"javascript": "js",
		"python":     "py",
		"java":       "java",
		"csharp":     "cs",
		"rust":       "rs",
	}

	if ext, exists := extensions[language]; exists {
		return ext
	}
	return "txt"
}

// formatVariables formats variables for AI prompt
func (g *CodeGenerator) formatVariables(variables map[string]interface{}) string {
	var result strings.Builder
	for k, v := range variables {
		result.WriteString(fmt.Sprintf("%s: %v\n", k, v))
	}
	return result.String()
}

// ListTemplates lists available templates
func (g *CodeGenerator) ListTemplates() []*CodeTemplate {
	g.mutex.RLock()
	defer g.mutex.RUnlock()

	var templates []*CodeTemplate
	for _, template := range g.templates {
		templates = append(templates, template)
	}
	return templates
}

// ListFrameworks lists available frameworks
func (g *CodeGenerator) ListFrameworks() []*Framework {
	g.mutex.RLock()
	defer g.mutex.RUnlock()

	var frameworks []*Framework
	for _, framework := range g.frameworks {
		frameworks = append(frameworks, framework)
	}
	return frameworks
}

// GetGenerationHistory returns generation history
func (g *CodeGenerator) GetGenerationHistory() []GenerationRecord {
	g.mutex.RLock()
	defer g.mutex.RUnlock()

	history := make([]GenerationRecord, len(g.generationHistory))
	copy(history, g.generationHistory)
	return history
}

// InstallIDEPlugin installs IDE integration plugin
func (g *CodeGenerator) InstallIDEPlugin(ide string) error {
	g.mutex.RLock()
	plugin, exists := g.idePlugins[ide]
	g.mutex.RUnlock()

	if !exists {
		return fmt.Errorf("IDE plugin not found: %s", ide)
	}

	// Create IDE configuration files
	for _, file := range plugin.Files {
		if err := g.createIDEFile(ide, file, plugin); err != nil {
			log.Printf("GENERATOR IDE FILE ERROR: %s - %v", file, err)
		}
	}

	log.Printf("GENERATOR IDE PLUGIN INSTALLED: %s", ide)
	return nil
}

// createIDEFile creates IDE configuration file
func (g *CodeGenerator) createIDEFile(ide, filename string, plugin *IDEPlugin) error {
	// Implementation would create IDE-specific configuration files
	log.Printf("GENERATOR IDE FILE CREATED: %s/%s", ide, filename)
	return nil
} 