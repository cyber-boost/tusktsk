package security

import (
	"context"
	"crypto/rand"
	"crypto/sha256"
	"database/sql"
	"encoding/base32"
	"encoding/json"
	"fmt"
	"image/png"
	"log"
	"net/http"
	"strings"
	"time"

	"github.com/go-webauthn/webauthn/protocol"
	"github.com/go-webauthn/webauthn/webauthn"
	"github.com/pquerna/otp"
	"github.com/pquerna/otp/totp"
	"github.com/skip2/go-qrcode"
)

// MFAOperator handles comprehensive multi-factor authentication
type MFAOperator struct {
	db          *sql.DB
	webAuthn    *webauthn.WebAuthn
	smsProvider SMSProvider
}

// MFAConfig represents MFA configuration
type MFAConfig struct {
	TOTPEnabled       bool   `json:"totp_enabled"`
	SMSEnabled        bool   `json:"sms_enabled"`
	WebAuthnEnabled   bool   `json:"webauthn_enabled"`
	BiometricEnabled  bool   `json:"biometric_enabled"`
	BackupCodesEnabled bool  `json:"backup_codes_enabled"`
	RequireMultiple   bool   `json:"require_multiple"`
	SessionTimeout    int    `json:"session_timeout_minutes"`
	MaxFailedAttempts int    `json:"max_failed_attempts"`
}

// MFADevice represents a registered MFA device
type MFADevice struct {
	ID              string                 `json:"id"`
	UserID          string                 `json:"user_id"`
	DeviceType      string                 `json:"device_type"` // totp, sms, webauthn, biometric
	DeviceName      string                 `json:"device_name"`
	SecretKey       string                 `json:"secret_key,omitempty"`
	PhoneNumber     string                 `json:"phone_number,omitempty"`
	CredentialID    []byte                 `json:"credential_id,omitempty"`
	PublicKey       []byte                 `json:"public_key,omitempty"`
	BackupCodes     []string               `json:"backup_codes,omitempty"`
	BiometricData   map[string]interface{} `json:"biometric_data,omitempty"`
	CreatedAt       time.Time              `json:"created_at"`
	LastUsed        time.Time              `json:"last_used"`
	IsActive        bool                   `json:"is_active"`
	FailedAttempts  int                    `json:"failed_attempts"`
}

// MFAChallenge represents an active MFA challenge
type MFAChallenge struct {
	ID            string                 `json:"id"`
	UserID        string                 `json:"user_id"`
	ChallengeType string                 `json:"challenge_type"`
	Challenge     map[string]interface{} `json:"challenge"`
	ExpiresAt     time.Time              `json:"expires_at"`
	Verified      bool                   `json:"verified"`
	CreatedAt     time.Time              `json:"created_at"`
}

// SMSProvider interface for SMS delivery
type SMSProvider interface {
	SendSMS(phoneNumber, message string) error
}

// TwilioSMSProvider implements SMSProvider using Twilio
type TwilioSMSProvider struct {
	AccountSID string
	AuthToken  string
	FromNumber string
}

// NewMFAOperator creates a new MFA operator
func NewMFAOperator(db *sql.DB, webAuthnConfig *webauthn.Config) (*MFAOperator, error) {
	webAuthn, err := webauthn.New(webAuthnConfig)
	if err != nil {
		return nil, fmt.Errorf("failed to create WebAuthn: %v", err)
	}

	mfa := &MFAOperator{
		db:       db,
		webAuthn: webAuthn,
	}

	if err := mfa.initDatabase(); err != nil {
		return nil, fmt.Errorf("failed to initialize MFA database: %v", err)
	}

	return mfa, nil
}

// initDatabase creates necessary tables for MFA
func (m *MFAOperator) initDatabase() error {
	queries := []string{
		`CREATE TABLE IF NOT EXISTS mfa_devices (
			id VARCHAR(255) PRIMARY KEY,
			user_id VARCHAR(255) NOT NULL,
			device_type VARCHAR(50) NOT NULL,
			device_name VARCHAR(255) NOT NULL,
			secret_key TEXT,
			phone_number VARCHAR(20),
			credential_id BLOB,
			public_key BLOB,
			backup_codes JSON,
			biometric_data JSON,
			created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
			last_used TIMESTAMP,
			is_active BOOLEAN DEFAULT TRUE,
			failed_attempts INTEGER DEFAULT 0,
			INDEX idx_user_id (user_id)
		)`,
		`CREATE TABLE IF NOT EXISTS mfa_challenges (
			id VARCHAR(255) PRIMARY KEY,
			user_id VARCHAR(255) NOT NULL,
			challenge_type VARCHAR(50) NOT NULL,
			challenge JSON NOT NULL,
			expires_at TIMESTAMP NOT NULL,
			verified BOOLEAN DEFAULT FALSE,
			created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
			INDEX idx_user_id (user_id),
			INDEX idx_expires_at (expires_at)
		)`,
		`CREATE TABLE IF NOT EXISTS mfa_sessions (
			id VARCHAR(255) PRIMARY KEY,
			user_id VARCHAR(255) NOT NULL,
			device_ids JSON NOT NULL,
			verified_factors JSON NOT NULL,
			created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
			expires_at TIMESTAMP NOT NULL,
			is_active BOOLEAN DEFAULT TRUE,
			INDEX idx_user_id (user_id),
			INDEX idx_expires_at (expires_at)
		)`,
	}

	for _, query := range queries {
		if _, err := m.db.Exec(query); err != nil {
			return fmt.Errorf("failed to create table: %v", err)
		}
	}

	return nil
}

// RegisterTOTPDevice registers a new TOTP device for a user
func (m *MFAOperator) RegisterTOTPDevice(ctx context.Context, userID, deviceName string) (*MFADevice, []byte, error) {
	// Generate secret key
	key, err := totp.Generate(totp.GenerateOpts{
		Issuer:      "Enterprise Security System",
		AccountName: userID,
		SecretSize:  32,
	})
	if err != nil {
		return nil, nil, fmt.Errorf("failed to generate TOTP key: %v", err)
	}

	device := &MFADevice{
		ID:         m.generateDeviceID(),
		UserID:     userID,
		DeviceType: "totp",
		DeviceName: deviceName,
		SecretKey:  key.Secret(),
		CreatedAt:  time.Now(),
		IsActive:   true,
	}

	// Save device to database
	if err := m.saveDevice(device); err != nil {
		return nil, nil, fmt.Errorf("failed to save TOTP device: %v", err)
	}

	// Generate QR code
	qrCode, err := qrcode.Encode(key.URL(), qrcode.Medium, 256)
	if err != nil {
		return nil, nil, fmt.Errorf("failed to generate QR code: %v", err)
	}

	return device, qrCode, nil
}

// RegisterSMSDevice registers a phone number for SMS-based MFA
func (m *MFAOperator) RegisterSMSDevice(ctx context.Context, userID, phoneNumber, deviceName string) (*MFADevice, error) {
	device := &MFADevice{
		ID:          m.generateDeviceID(),
		UserID:      userID,
		DeviceType:  "sms",
		DeviceName:  deviceName,
		PhoneNumber: phoneNumber,
		CreatedAt:   time.Now(),
		IsActive:    true,
	}

	// Save device to database
	if err := m.saveDevice(device); err != nil {
		return nil, fmt.Errorf("failed to save SMS device: %v", err)
	}

	// Send verification SMS
	code := m.generateVerificationCode()
	if err := m.smsProvider.SendSMS(phoneNumber, fmt.Sprintf("Your verification code is: %s", code)); err != nil {
		return nil, fmt.Errorf("failed to send verification SMS: %v", err)
	}

	return device, nil
}

// BeginWebAuthnRegistration starts WebAuthn device registration
func (m *MFAOperator) BeginWebAuthnRegistration(ctx context.Context, userID, deviceName string) (*protocol.CredentialCreation, *MFAChallenge, error) {
	user := &WebAuthnUser{
		ID:          userID,
		Name:        userID,
		DisplayName: deviceName,
	}

	credentialCreation, sessionData, err := m.webAuthn.BeginRegistration(user)
	if err != nil {
		return nil, nil, fmt.Errorf("failed to begin WebAuthn registration: %v", err)
	}

	challenge := &MFAChallenge{
		ID:            m.generateChallengeID(),
		UserID:        userID,
		ChallengeType: "webauthn_registration",
		Challenge: map[string]interface{}{
			"session_data": sessionData,
			"device_name":  deviceName,
		},
		ExpiresAt: time.Now().Add(5 * time.Minute),
		CreatedAt: time.Now(),
	}

	if err := m.saveChallenge(challenge); err != nil {
		return nil, nil, fmt.Errorf("failed to save WebAuthn challenge: %v", err)
	}

	return credentialCreation, challenge, nil
}

// FinishWebAuthnRegistration completes WebAuthn device registration
func (m *MFAOperator) FinishWebAuthnRegistration(ctx context.Context, challengeID string, response *http.Request) (*MFADevice, error) {
	challenge, err := m.getChallenge(challengeID)
	if err != nil {
		return nil, fmt.Errorf("failed to get challenge: %v", err)
	}

	if challenge.ExpiresAt.Before(time.Now()) {
		return nil, fmt.Errorf("challenge expired")
	}

	user := &WebAuthnUser{
		ID:          challenge.UserID,
		Name:        challenge.UserID,
		DisplayName: challenge.Challenge["device_name"].(string),
	}

	sessionData := challenge.Challenge["session_data"]
	credential, err := m.webAuthn.FinishRegistration(user, sessionData, response)
	if err != nil {
		return nil, fmt.Errorf("failed to finish WebAuthn registration: %v", err)
	}

	device := &MFADevice{
		ID:           m.generateDeviceID(),
		UserID:       challenge.UserID,
		DeviceType:   "webauthn",
		DeviceName:   challenge.Challenge["device_name"].(string),
		CredentialID: credential.ID,
		PublicKey:    credential.PublicKey,
		CreatedAt:    time.Now(),
		IsActive:     true,
	}

	if err := m.saveDevice(device); err != nil {
		return nil, fmt.Errorf("failed to save WebAuthn device: %v", err)
	}

	return device, nil
}

// GenerateBackupCodes generates backup codes for a user
func (m *MFAOperator) GenerateBackupCodes(ctx context.Context, userID, deviceName string) (*MFADevice, error) {
	codes := make([]string, 10)
	for i := range codes {
		codes[i] = m.generateBackupCode()
	}

	device := &MFADevice{
		ID:          m.generateDeviceID(),
		UserID:      userID,
		DeviceType:  "backup_codes",
		DeviceName:  deviceName,
		BackupCodes: codes,
		CreatedAt:   time.Now(),
		IsActive:    true,
	}

	if err := m.saveDevice(device); err != nil {
		return nil, fmt.Errorf("failed to save backup codes: %v", err)
	}

	return device, nil
}

// VerifyTOTP verifies a TOTP code
func (m *MFAOperator) VerifyTOTP(ctx context.Context, userID, deviceID, code string) (bool, error) {
	device, err := m.getDevice(deviceID)
	if err != nil {
		return false, fmt.Errorf("failed to get device: %v", err)
	}

	if device.UserID != userID || device.DeviceType != "totp" || !device.IsActive {
		return false, fmt.Errorf("invalid device")
	}

	valid := totp.Validate(code, device.SecretKey)
	
	if valid {
		device.LastUsed = time.Now()
		device.FailedAttempts = 0
		m.saveDevice(device)
	} else {
		device.FailedAttempts++
		if device.FailedAttempts >= 5 {
			device.IsActive = false
		}
		m.saveDevice(device)
	}

	return valid, nil
}

// BeginSMSVerification sends SMS verification code
func (m *MFAOperator) BeginSMSVerification(ctx context.Context, userID, deviceID string) (*MFAChallenge, error) {
	device, err := m.getDevice(deviceID)
	if err != nil {
		return nil, fmt.Errorf("failed to get device: %v", err)
	}

	if device.UserID != userID || device.DeviceType != "sms" || !device.IsActive {
		return nil, fmt.Errorf("invalid device")
	}

	code := m.generateVerificationCode()
	
	challenge := &MFAChallenge{
		ID:            m.generateChallengeID(),
		UserID:        userID,
		ChallengeType: "sms_verification",
		Challenge: map[string]interface{}{
			"code":      code,
			"device_id": deviceID,
		},
		ExpiresAt: time.Now().Add(5 * time.Minute),
		CreatedAt: time.Now(),
	}

	if err := m.saveChallenge(challenge); err != nil {
		return nil, fmt.Errorf("failed to save SMS challenge: %v", err)
	}

	message := fmt.Sprintf("Your verification code is: %s (expires in 5 minutes)", code)
	if err := m.smsProvider.SendSMS(device.PhoneNumber, message); err != nil {
		return nil, fmt.Errorf("failed to send SMS: %v", err)
	}

	return challenge, nil
}

// VerifySMS verifies an SMS code
func (m *MFAOperator) VerifySMS(ctx context.Context, challengeID, code string) (bool, error) {
	challenge, err := m.getChallenge(challengeID)
	if err != nil {
		return false, fmt.Errorf("failed to get challenge: %v", err)
	}

	if challenge.ExpiresAt.Before(time.Now()) {
		return false, fmt.Errorf("challenge expired")
	}

	expectedCode := challenge.Challenge["code"].(string)
	valid := code == expectedCode

	if valid {
		challenge.Verified = true
		m.saveChallenge(challenge)
		
		deviceID := challenge.Challenge["device_id"].(string)
		device, _ := m.getDevice(deviceID)
		if device != nil {
			device.LastUsed = time.Now()
			device.FailedAttempts = 0
			m.saveDevice(device)
		}
	}

	return valid, nil
}

// BeginWebAuthnAuthentication starts WebAuthn authentication
func (m *MFAOperator) BeginWebAuthnAuthentication(ctx context.Context, userID string) (*protocol.CredentialAssertion, *MFAChallenge, error) {
	devices, err := m.getUserDevices(userID, "webauthn")
	if err != nil {
		return nil, nil, fmt.Errorf("failed to get user devices: %v", err)
	}

	if len(devices) == 0 {
		return nil, nil, fmt.Errorf("no WebAuthn devices registered")
	}

	user := &WebAuthnUser{
		ID:          userID,
		Name:        userID,
		DisplayName: userID,
		Credentials: devices,
	}

	assertion, sessionData, err := m.webAuthn.BeginLogin(user)
	if err != nil {
		return nil, nil, fmt.Errorf("failed to begin WebAuthn authentication: %v", err)
	}

	challenge := &MFAChallenge{
		ID:            m.generateChallengeID(),
		UserID:        userID,
		ChallengeType: "webauthn_authentication",
		Challenge: map[string]interface{}{
			"session_data": sessionData,
		},
		ExpiresAt: time.Now().Add(5 * time.Minute),
		CreatedAt: time.Now(),
	}

	if err := m.saveChallenge(challenge); err != nil {
		return nil, nil, fmt.Errorf("failed to save WebAuthn challenge: %v", err)
	}

	return assertion, challenge, nil
}

// FinishWebAuthnAuthentication completes WebAuthn authentication
func (m *MFAOperator) FinishWebAuthnAuthentication(ctx context.Context, challengeID string, response *http.Request) (bool, error) {
	challenge, err := m.getChallenge(challengeID)
	if err != nil {
		return false, fmt.Errorf("failed to get challenge: %v", err)
	}

	if challenge.ExpiresAt.Before(time.Now()) {
		return false, fmt.Errorf("challenge expired")
	}

	devices, err := m.getUserDevices(challenge.UserID, "webauthn")
	if err != nil {
		return false, fmt.Errorf("failed to get user devices: %v", err)
	}

	user := &WebAuthnUser{
		ID:          challenge.UserID,
		Name:        challenge.UserID,
		DisplayName: challenge.UserID,
		Credentials: devices,
	}

	sessionData := challenge.Challenge["session_data"]
	_, err = m.webAuthn.FinishLogin(user, sessionData, response)
	if err != nil {
		return false, fmt.Errorf("failed to finish WebAuthn authentication: %v", err)
	}

	challenge.Verified = true
	m.saveChallenge(challenge)

	return true, nil
}

// VerifyBackupCode verifies a backup code
func (m *MFAOperator) VerifyBackupCode(ctx context.Context, userID, code string) (bool, error) {
	devices, err := m.getUserDevices(userID, "backup_codes")
	if err != nil {
		return false, fmt.Errorf("failed to get backup code devices: %v", err)
	}

	for _, device := range devices {
		if !device.IsActive {
			continue
		}

		for i, backupCode := range device.BackupCodes {
			if backupCode == code {
				// Remove used backup code
				device.BackupCodes = append(device.BackupCodes[:i], device.BackupCodes[i+1:]...)
				device.LastUsed = time.Now()
				
				if len(device.BackupCodes) == 0 {
					device.IsActive = false
				}
				
				m.saveDevice(device)
				return true, nil
			}
		}
	}

	return false, nil
}

// Helper methods
func (m *MFAOperator) generateDeviceID() string {
	return fmt.Sprintf("mfa_dev_%d_%s", time.Now().Unix(), m.generateRandomString(8))
}

func (m *MFAOperator) generateChallengeID() string {
	return fmt.Sprintf("mfa_chg_%d_%s", time.Now().Unix(), m.generateRandomString(8))
}

func (m *MFAOperator) generateVerificationCode() string {
	const chars = "0123456789"
	result := make([]byte, 6)
	for i := range result {
		result[i] = chars[m.secureRandomInt(len(chars))]
	}
	return string(result)
}

func (m *MFAOperator) generateBackupCode() string {
	const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
	result := make([]byte, 8)
	for i := range result {
		result[i] = chars[m.secureRandomInt(len(chars))]
	}
	return string(result)
}

func (m *MFAOperator) generateRandomString(length int) string {
	const chars = "abcdefghijklmnopqrstuvwxyz0123456789"
	result := make([]byte, length)
	for i := range result {
		result[i] = chars[m.secureRandomInt(len(chars))]
	}
	return string(result)
}

func (m *MFAOperator) secureRandomInt(max int) int {
	b := make([]byte, 1)
	rand.Read(b)
	return int(b[0]) % max
}

// Database operations
func (m *MFAOperator) saveDevice(device *MFADevice) error {
	query := `INSERT INTO mfa_devices 
		(id, user_id, device_type, device_name, secret_key, phone_number, credential_id, public_key, backup_codes, biometric_data, created_at, last_used, is_active, failed_attempts)
		VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
		ON DUPLICATE KEY UPDATE
		device_name = VALUES(device_name),
		secret_key = VALUES(secret_key),
		phone_number = VALUES(phone_number),
		credential_id = VALUES(credential_id),
		public_key = VALUES(public_key),
		backup_codes = VALUES(backup_codes),
		biometric_data = VALUES(biometric_data),
		last_used = VALUES(last_used),
		is_active = VALUES(is_active),
		failed_attempts = VALUES(failed_attempts)`

	backupCodesJSON, _ := json.Marshal(device.BackupCodes)
	biometricDataJSON, _ := json.Marshal(device.BiometricData)

	_, err := m.db.Exec(query,
		device.ID, device.UserID, device.DeviceType, device.DeviceName,
		device.SecretKey, device.PhoneNumber, device.CredentialID, device.PublicKey,
		backupCodesJSON, biometricDataJSON, device.CreatedAt, device.LastUsed,
		device.IsActive, device.FailedAttempts)

	return err
}

func (m *MFAOperator) getDevice(deviceID string) (*MFADevice, error) {
	query := `SELECT id, user_id, device_type, device_name, secret_key, phone_number, credential_id, public_key, backup_codes, biometric_data, created_at, last_used, is_active, failed_attempts
		FROM mfa_devices WHERE id = ?`

	row := m.db.QueryRow(query, deviceID)
	device := &MFADevice{}

	var backupCodesJSON, biometricDataJSON []byte
	err := row.Scan(
		&device.ID, &device.UserID, &device.DeviceType, &device.DeviceName,
		&device.SecretKey, &device.PhoneNumber, &device.CredentialID, &device.PublicKey,
		&backupCodesJSON, &biometricDataJSON, &device.CreatedAt, &device.LastUsed,
		&device.IsActive, &device.FailedAttempts)

	if err != nil {
		return nil, err
	}

	json.Unmarshal(backupCodesJSON, &device.BackupCodes)
	json.Unmarshal(biometricDataJSON, &device.BiometricData)

	return device, nil
}

func (m *MFAOperator) getUserDevices(userID, deviceType string) ([]*MFADevice, error) {
	query := `SELECT id, user_id, device_type, device_name, secret_key, phone_number, credential_id, public_key, backup_codes, biometric_data, created_at, last_used, is_active, failed_attempts
		FROM mfa_devices WHERE user_id = ? AND device_type = ? AND is_active = TRUE`

	rows, err := m.db.Query(query, userID, deviceType)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var devices []*MFADevice
	for rows.Next() {
		device := &MFADevice{}
		var backupCodesJSON, biometricDataJSON []byte

		err := rows.Scan(
			&device.ID, &device.UserID, &device.DeviceType, &device.DeviceName,
			&device.SecretKey, &device.PhoneNumber, &device.CredentialID, &device.PublicKey,
			&backupCodesJSON, &biometricDataJSON, &device.CreatedAt, &device.LastUsed,
			&device.IsActive, &device.FailedAttempts)

		if err != nil {
			return nil, err
		}

		json.Unmarshal(backupCodesJSON, &device.BackupCodes)
		json.Unmarshal(biometricDataJSON, &device.BiometricData)
		devices = append(devices, device)
	}

	return devices, nil
}

func (m *MFAOperator) saveChallenge(challenge *MFAChallenge) error {
	challengeJSON, _ := json.Marshal(challenge.Challenge)
	
	query := `INSERT INTO mfa_challenges (id, user_id, challenge_type, challenge, expires_at, verified, created_at)
		VALUES (?, ?, ?, ?, ?, ?, ?)`

	_, err := m.db.Exec(query, challenge.ID, challenge.UserID, challenge.ChallengeType,
		challengeJSON, challenge.ExpiresAt, challenge.Verified, challenge.CreatedAt)

	return err
}

func (m *MFAOperator) getChallenge(challengeID string) (*MFAChallenge, error) {
	query := `SELECT id, user_id, challenge_type, challenge, expires_at, verified, created_at
		FROM mfa_challenges WHERE id = ?`

	row := m.db.QueryRow(query, challengeID)
	challenge := &MFAChallenge{}

	var challengeJSON []byte
	err := row.Scan(&challenge.ID, &challenge.UserID, &challenge.ChallengeType,
		&challengeJSON, &challenge.ExpiresAt, &challenge.Verified, &challenge.CreatedAt)

	if err != nil {
		return nil, err
	}

	json.Unmarshal(challengeJSON, &challenge.Challenge)
	return challenge, nil
}

// WebAuthnUser implements webauthn.User interface
type WebAuthnUser struct {
	ID          string
	Name        string
	DisplayName string
	Credentials []*MFADevice
}

func (u *WebAuthnUser) WebAuthnID() []byte {
	return []byte(u.ID)
}

func (u *WebAuthnUser) WebAuthnName() string {
	return u.Name
}

func (u *WebAuthnUser) WebAuthnDisplayName() string {
	return u.DisplayName
}

func (u *WebAuthnUser) WebAuthnIcon() string {
	return ""
}

func (u *WebAuthnUser) WebAuthnCredentials() []webauthn.Credential {
	var credentials []webauthn.Credential
	for _, device := range u.Credentials {
		credentials = append(credentials, webauthn.Credential{
			ID:        device.CredentialID,
			PublicKey: device.PublicKey,
		})
	}
	return credentials
}

// TwilioSMSProvider implementation
func (t *TwilioSMSProvider) SendSMS(phoneNumber, message string) error {
	// Implementation would use Twilio API
	log.Printf("SMS sent to %s: %s", phoneNumber, message)
	return nil
} 