package infrastructure

import (
	"context"
	"crypto/tls"
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"strings"
	"sync"
	"time"

	"github.com/hashicorp/vault/api"
	"github.com/hashicorp/vault/api/auth/approle"
	"github.com/hashicorp/vault/api/auth/aws"
	"github.com/hashicorp/vault/api/auth/kubernetes"
	"github.com/hashicorp/vault/api/auth/ldap"
	"github.com/hashicorp/vault/api/auth/userpass"
)

// VaultOperator handles @vault secrets management and encryption operations
type VaultOperator struct {
	client      *api.Client
	config      *VaultConfig
	mutex       sync.RWMutex
	isConnected bool
	tokenRenew  chan struct{}
	auth        *AuthConfig
}

// VaultConfig holds configuration for Vault connection
type VaultConfig struct {
	Address           string            `json:"address"`
	Token             string            `json:"token"`
	Namespace         string            `json:"namespace"`
	CACert            string            `json:"ca_cert"`
	CAPath            string            `json:"ca_path"`
	ClientCert        string            `json:"client_cert"`
	ClientKey         string            `json:"client_key"`
	TLSServerName     string            `json:"tls_server_name"`
	Insecure          bool              `json:"insecure"`
	Timeout           time.Duration     `json:"timeout"`
	MaxRetries        int               `json:"max_retries"`
	Headers           map[string]string `json:"headers"`
	AgentAddress      string            `json:"agent_address"`
	DisableRedirects  bool              `json:"disable_redirects"`
	OutputCurlString  bool              `json:"output_curl_string"`
	OutputPolicy      bool              `json:"output_policy"`
	SRVLookup         bool              `json:"srv_lookup"`
	CheckRetry        func(*http.Request, *http.Response, error) (bool, error) `json:"-"`
	Logger            interface{}       `json:"-"`
	Limiter           interface{}       `json:"-"`
}

// AuthConfig holds authentication configuration
type AuthConfig struct {
	Method           string                 `json:"method"`
	AppRole          *AppRoleAuth          `json:"app_role,omitempty"`
	UserPass         *UserPassAuth         `json:"user_pass,omitempty"`
	LDAP             *LDAPAuth             `json:"ldap,omitempty"`
	Kubernetes       *KubernetesAuth       `json:"kubernetes,omitempty"`
	AWS              *AWSAuth              `json:"aws,omitempty"`
	TokenRenewal     bool                  `json:"token_renewal"`
	RenewalIncrement int                   `json:"renewal_increment"`
}

// AppRoleAuth configuration
type AppRoleAuth struct {
	RoleID   string `json:"role_id"`
	SecretID string `json:"secret_id"`
	MountPath string `json:"mount_path"`
}

// UserPassAuth configuration
type UserPassAuth struct {
	Username  string `json:"username"`
	Password  string `json:"password"`
	MountPath string `json:"mount_path"`
}

// LDAPAuth configuration
type LDAPAuth struct {
	Username  string `json:"username"`
	Password  string `json:"password"`
	MountPath string `json:"mount_path"`
}

// KubernetesAuth configuration
type KubernetesAuth struct {
	Role      string `json:"role"`
	JWT       string `json:"jwt"`
	MountPath string `json:"mount_path"`
}

// AWSAuth configuration  
type AWSAuth struct {
	Role      string `json:"role"`
	MountPath string `json:"mount_path"`
}

// SecretData represents secret key-value pairs
type SecretData map[string]interface{}

// DefaultVaultConfig returns default configuration for Vault
func DefaultVaultConfig() *VaultConfig {
	return &VaultConfig{
		Address:    "https://127.0.0.1:8200",
		Timeout:    60 * time.Second,
		MaxRetries: 3,
		Headers:    make(map[string]string),
	}
}

// NewVaultOperator creates a new Vault operator
func NewVaultOperator(config *VaultConfig, authConfig *AuthConfig) (*VaultOperator, error) {
	if config == nil {
		config = DefaultVaultConfig()
	}

	vaultConfig := &api.Config{
		Address:           config.Address,
		HttpClient:        &http.Client{Timeout: config.Timeout},
		MaxRetries:        config.MaxRetries,
		Timeout:           config.Timeout,
		Headers:           config.Headers,
		AgentAddress:      config.AgentAddress,
		DisableRedirects:  config.DisableRedirects,
		OutputCurlString:  config.OutputCurlString,
		OutputPolicy:      config.OutputPolicy,
		SRVLookup:         config.SRVLookup,
		CheckRetry:        config.CheckRetry,
		Logger:            config.Logger,
		Limiter:           config.Limiter,
	}

	// Configure TLS
	tlsConfig := &tls.Config{
		InsecureSkipVerify: config.Insecure,
		ServerName:         config.TLSServerName,
	}

	if config.CACert != "" || config.CAPath != "" {
		if err := vaultConfig.ConfigureTLS(&api.TLSConfig{
			CACert:        config.CACert,
			CAPath:        config.CAPath,
			ClientCert:    config.ClientCert,
			ClientKey:     config.ClientKey,
			TLSServerName: config.TLSServerName,
			Insecure:      config.Insecure,
		}); err != nil {
			return nil, fmt.Errorf("failed to configure TLS: %v", err)
		}
	} else if config.Insecure {
		vaultConfig.HttpClient.Transport = &http.Transport{
			TLSClientConfig: tlsConfig,
		}
	}

	client, err := api.NewClient(vaultConfig)
	if err != nil {
		return nil, fmt.Errorf("failed to create Vault client: %v", err)
	}

	// Set namespace if provided
	if config.Namespace != "" {
		client.SetNamespace(config.Namespace)
	}

	operator := &VaultOperator{
		client:      client,
		config:      config,
		auth:        authConfig,
		isConnected: false,
		tokenRenew:  make(chan struct{}, 1),
	}

	// Authenticate if auth config provided
	if authConfig != nil {
		if err := operator.authenticate(); err != nil {
			return nil, fmt.Errorf("authentication failed: %v", err)
		}
	} else if config.Token != "" {
		client.SetToken(config.Token)
	}

	// Test connection
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	_, err = client.Sys().Health()
	if err != nil {
		return nil, fmt.Errorf("failed to connect to Vault: %v", err)
	}

	operator.isConnected = true

	// Start token renewal if configured
	if authConfig != nil && authConfig.TokenRenewal {
		go operator.renewToken()
	}

	log.Printf("VAULT CONNECTED: %s", config.Address)
	return operator, nil
}

// authenticate performs authentication based on configuration
func (v *VaultOperator) authenticate() error {
	switch v.auth.Method {
	case "approle":
		return v.authenticateAppRole()
	case "userpass":
		return v.authenticateUserPass()
	case "ldap":
		return v.authenticateLDAP()
	case "kubernetes":
		return v.authenticateKubernetes()
	case "aws":
		return v.authenticateAWS()
	default:
		return fmt.Errorf("unsupported auth method: %s", v.auth.Method)
	}
}

// authenticateAppRole authenticates using AppRole
func (v *VaultOperator) authenticateAppRole() error {
	if v.auth.AppRole == nil {
		return fmt.Errorf("AppRole auth config required")
	}

	appRoleAuth, err := approle.NewAppRoleAuth(
		v.auth.AppRole.RoleID,
		&approle.SecretID{FromString: v.auth.AppRole.SecretID},
		approle.WithMountPath(v.auth.AppRole.MountPath),
	)
	if err != nil {
		return fmt.Errorf("unable to initialize AppRole auth method: %v", err)
	}

	authInfo, err := v.client.Auth().Login(context.Background(), appRoleAuth)
	if err != nil {
		return fmt.Errorf("unable to login to AppRole auth method: %v", err)
	}

	if authInfo == nil {
		return fmt.Errorf("no auth info was returned after login")
	}

	log.Printf("VAULT APPROLE AUTH SUCCESS: token_renewable=%v", authInfo.Auth.Renewable)
	return nil
}

// authenticateUserPass authenticates using username/password
func (v *VaultOperator) authenticateUserPass() error {
	if v.auth.UserPass == nil {
		return fmt.Errorf("UserPass auth config required")
	}

	userpassAuth, err := userpass.NewUserpassAuth(
		v.auth.UserPass.Username,
		&userpass.Password{FromString: v.auth.UserPass.Password},
		userpass.WithMountPath(v.auth.UserPass.MountPath),
	)
	if err != nil {
		return fmt.Errorf("unable to initialize UserPass auth method: %v", err)
	}

	authInfo, err := v.client.Auth().Login(context.Background(), userpassAuth)
	if err != nil {
		return fmt.Errorf("unable to login to UserPass auth method: %v", err)
	}

	if authInfo == nil {
		return fmt.Errorf("no auth info was returned after login")
	}

	log.Printf("VAULT USERPASS AUTH SUCCESS: token_renewable=%v", authInfo.Auth.Renewable)
	return nil
}

// authenticateLDAP authenticates using LDAP
func (v *VaultOperator) authenticateLDAP() error {
	if v.auth.LDAP == nil {
		return fmt.Errorf("LDAP auth config required")
	}

	ldapAuth, err := ldap.NewLDAPAuth(
		v.auth.LDAP.Username,
		&ldap.Password{FromString: v.auth.LDAP.Password},
		ldap.WithMountPath(v.auth.LDAP.MountPath),
	)
	if err != nil {
		return fmt.Errorf("unable to initialize LDAP auth method: %v", err)
	}

	authInfo, err := v.client.Auth().Login(context.Background(), ldapAuth)
	if err != nil {
		return fmt.Errorf("unable to login to LDAP auth method: %v", err)
	}

	if authInfo == nil {
		return fmt.Errorf("no auth info was returned after login")
	}

	log.Printf("VAULT LDAP AUTH SUCCESS: token_renewable=%v", authInfo.Auth.Renewable)
	return nil
}

// authenticateKubernetes authenticates using Kubernetes service account
func (v *VaultOperator) authenticateKubernetes() error {
	if v.auth.Kubernetes == nil {
		return fmt.Errorf("Kubernetes auth config required")
	}

	k8sAuth, err := kubernetes.NewKubernetesAuth(
		v.auth.Kubernetes.Role,
		kubernetes.WithServiceAccountToken(v.auth.Kubernetes.JWT),
		kubernetes.WithMountPath(v.auth.Kubernetes.MountPath),
	)
	if err != nil {
		return fmt.Errorf("unable to initialize Kubernetes auth method: %v", err)
	}

	authInfo, err := v.client.Auth().Login(context.Background(), k8sAuth)
	if err != nil {
		return fmt.Errorf("unable to login to Kubernetes auth method: %v", err)
	}

	if authInfo == nil {
		return fmt.Errorf("no auth info was returned after login")
	}

	log.Printf("VAULT KUBERNETES AUTH SUCCESS: token_renewable=%v", authInfo.Auth.Renewable)
	return nil
}

// authenticateAWS authenticates using AWS credentials
func (v *VaultOperator) authenticateAWS() error {
	if v.auth.AWS == nil {
		return fmt.Errorf("AWS auth config required")
	}

	awsAuth, err := aws.NewAWSAuth(
		aws.WithRole(v.auth.AWS.Role),
		aws.WithMountPath(v.auth.AWS.MountPath),
	)
	if err != nil {
		return fmt.Errorf("unable to initialize AWS auth method: %v", err)
	}

	authInfo, err := v.client.Auth().Login(context.Background(), awsAuth)
	if err != nil {
		return fmt.Errorf("unable to login to AWS auth method: %v", err)
	}

	if authInfo == nil {
		return fmt.Errorf("no auth info was returned after login")
	}

	log.Printf("VAULT AWS AUTH SUCCESS: token_renewable=%v", authInfo.Auth.Renewable)
	return nil
}

// renewToken automatically renews the token
func (v *VaultOperator) renewToken() {
	ticker := time.NewTicker(30 * time.Minute)
	defer ticker.Stop()

	for {
		select {
		case <-ticker.C:
			if err := v.performTokenRenewal(); err != nil {
				log.Printf("VAULT TOKEN RENEWAL ERROR: %v", err)
			}
		case <-v.tokenRenew:
			return
		}
	}
}

// performTokenRenewal performs the actual token renewal
func (v *VaultOperator) performTokenRenewal() error {
	if !v.isConnected {
		return fmt.Errorf("Vault client not connected")
	}

	secret, err := v.client.Auth().Token().RenewSelf(v.auth.RenewalIncrement)
	if err != nil {
		return fmt.Errorf("failed to renew token: %v", err)
	}

	log.Printf("VAULT TOKEN RENEWED: ttl=%d", secret.Auth.LeaseDuration)
	return nil
}

// Execute handles @vault operations with parameter parsing
func (v *VaultOperator) Execute(params string) interface{} {
	// Parse operation format: @vault("operation", "path", "data", "options")
	parts := strings.Split(strings.Trim(params, "()\""), "\",\"")
	if len(parts) < 2 {
		return fmt.Errorf("invalid vault operation format")
	}

	operation := strings.Trim(parts[0], "\"")
	path := strings.Trim(parts[1], "\"")

	switch operation {
	case "read":
		result, err := v.ReadSecret(path)
		if err != nil {
			return fmt.Errorf("vault read failed: %v", err)
		}
		return result
	case "write":
		if len(parts) < 3 {
			return fmt.Errorf("write operation requires path and data")
		}
		dataStr := strings.Trim(parts[2], "\"")
		
		var data map[string]interface{}
		if err := json.Unmarshal([]byte(dataStr), &data); err != nil {
			return fmt.Errorf("invalid data JSON: %v", err)
		}

		err := v.WriteSecret(path, data)
		if err != nil {
			return fmt.Errorf("vault write failed: %v", err)
		}
		return "success"
	case "delete":
		err := v.DeleteSecret(path)
		if err != nil {
			return fmt.Errorf("vault delete failed: %v", err)
		}
		return "success"
	case "encrypt":
		if len(parts) < 3 {
			return fmt.Errorf("encrypt operation requires key and plaintext")
		}
		plaintext := strings.Trim(parts[2], "\"")
		
		result, err := v.Encrypt(path, plaintext)
		if err != nil {
			return fmt.Errorf("vault encrypt failed: %v", err)
		}
		return result
	case "decrypt":
		if len(parts) < 3 {
			return fmt.Errorf("decrypt operation requires key and ciphertext")
		}
		ciphertext := strings.Trim(parts[2], "\"")
		
		result, err := v.Decrypt(path, ciphertext)
		if err != nil {
			return fmt.Errorf("vault decrypt failed: %v", err)
		}
		return result
	default:
		return fmt.Errorf("unsupported vault operation: %s", operation)
	}
}

// ReadSecret reads a secret from Vault
func (v *VaultOperator) ReadSecret(path string) (SecretData, error) {
	if !v.isConnected {
		return nil, fmt.Errorf("Vault client not connected")
	}

	secret, err := v.client.Logical().Read(path)
	if err != nil {
		log.Printf("VAULT READ ERROR: path=%s, error=%v", path, err)
		return nil, fmt.Errorf("failed to read secret at %s: %v", path, err)
	}

	if secret == nil {
		return nil, fmt.Errorf("secret not found at path: %s", path)
	}

	log.Printf("VAULT READ SUCCESS: path=%s, keys=%d", path, len(secret.Data))
	return secret.Data, nil
}

// WriteSecret writes a secret to Vault
func (v *VaultOperator) WriteSecret(path string, data SecretData) error {
	if !v.isConnected {
		return fmt.Errorf("Vault client not connected")
	}

	_, err := v.client.Logical().Write(path, data)
	if err != nil {
		log.Printf("VAULT WRITE ERROR: path=%s, error=%v", path, err)
		return fmt.Errorf("failed to write secret at %s: %v", path, err)
	}

	log.Printf("VAULT WRITE SUCCESS: path=%s, keys=%d", path, len(data))
	return nil
}

// DeleteSecret deletes a secret from Vault
func (v *VaultOperator) DeleteSecret(path string) error {
	if !v.isConnected {
		return fmt.Errorf("Vault client not connected")
	}

	_, err := v.client.Logical().Delete(path)
	if err != nil {
		log.Printf("VAULT DELETE ERROR: path=%s, error=%v", path, err)
		return fmt.Errorf("failed to delete secret at %s: %v", path, err)
	}

	log.Printf("VAULT DELETE SUCCESS: path=%s", path)
	return nil
}

// ListSecrets lists secrets at a path
func (v *VaultOperator) ListSecrets(path string) ([]interface{}, error) {
	if !v.isConnected {
		return nil, fmt.Errorf("Vault client not connected")
	}

	secret, err := v.client.Logical().List(path)
	if err != nil {
		return nil, fmt.Errorf("failed to list secrets at %s: %v", path, err)
	}

	if secret == nil || secret.Data["keys"] == nil {
		return []interface{}{}, nil
	}

	keys := secret.Data["keys"].([]interface{})
	return keys, nil
}

// Encrypt data using Vault's transit engine
func (v *VaultOperator) Encrypt(keyName, plaintext string) (string, error) {
	if !v.isConnected {
		return "", fmt.Errorf("Vault client not connected")
	}

	data := map[string]interface{}{
		"plaintext": plaintext,
	}

	secret, err := v.client.Logical().Write(fmt.Sprintf("transit/encrypt/%s", keyName), data)
	if err != nil {
		log.Printf("VAULT ENCRYPT ERROR: key=%s, error=%v", keyName, err)
		return "", fmt.Errorf("failed to encrypt with key %s: %v", keyName, err)
	}

	ciphertext := secret.Data["ciphertext"].(string)
	log.Printf("VAULT ENCRYPT SUCCESS: key=%s", keyName)
	return ciphertext, nil
}

// Decrypt data using Vault's transit engine
func (v *VaultOperator) Decrypt(keyName, ciphertext string) (string, error) {
	if !v.isConnected {
		return "", fmt.Errorf("Vault client not connected")
	}

	data := map[string]interface{}{
		"ciphertext": ciphertext,
	}

	secret, err := v.client.Logical().Write(fmt.Sprintf("transit/decrypt/%s", keyName), data)
	if err != nil {
		log.Printf("VAULT DECRYPT ERROR: key=%s, error=%v", keyName, err)
		return "", fmt.Errorf("failed to decrypt with key %s: %v", keyName, err)
	}

	plaintext := secret.Data["plaintext"].(string)
	log.Printf("VAULT DECRYPT SUCCESS: key=%s", keyName)
	return plaintext, nil
}

// GenerateDataKey generates a data key using Vault's transit engine
func (v *VaultOperator) GenerateDataKey(keyName string, keyType string) (string, string, error) {
	if !v.isConnected {
		return "", "", fmt.Errorf("Vault client not connected")
	}

	data := map[string]interface{}{
		"key_type": keyType,
	}

	secret, err := v.client.Logical().Write(fmt.Sprintf("transit/datakey/plaintext/%s", keyName), data)
	if err != nil {
		return "", "", fmt.Errorf("failed to generate data key with %s: %v", keyName, err)
	}

	ciphertext := secret.Data["ciphertext"].(string)
	plaintext := secret.Data["plaintext"].(string)

	log.Printf("VAULT DATA KEY GENERATED: key=%s, type=%s", keyName, keyType)
	return ciphertext, plaintext, nil
}

// CreateTransitKey creates a new encryption key in transit engine
func (v *VaultOperator) CreateTransitKey(keyName string, keyType string) error {
	if !v.isConnected {
		return fmt.Errorf("Vault client not connected")
	}

	data := map[string]interface{}{
		"type": keyType,
	}

	_, err := v.client.Logical().Write(fmt.Sprintf("transit/keys/%s", keyName), data)
	if err != nil {
		return fmt.Errorf("failed to create transit key %s: %v", keyName, err)
	}

	log.Printf("VAULT TRANSIT KEY CREATED: name=%s, type=%s", keyName, keyType)
	return nil
}

// RotateTransitKey rotates a transit encryption key
func (v *VaultOperator) RotateTransitKey(keyName string) error {
	if !v.isConnected {
		return fmt.Errorf("Vault client not connected")
	}

	_, err := v.client.Logical().Write(fmt.Sprintf("transit/keys/%s/rotate", keyName), nil)
	if err != nil {
		return fmt.Errorf("failed to rotate transit key %s: %v", keyName, err)
	}

	log.Printf("VAULT TRANSIT KEY ROTATED: name=%s", keyName)
	return nil
}

// GenerateDynamicDBCredentials generates dynamic database credentials
func (v *VaultOperator) GenerateDynamicDBCredentials(roleName string) (string, string, error) {
	if !v.isConnected {
		return "", "", fmt.Errorf("Vault client not connected")
	}

	secret, err := v.client.Logical().Read(fmt.Sprintf("database/creds/%s", roleName))
	if err != nil {
		return "", "", fmt.Errorf("failed to generate DB credentials for role %s: %v", roleName, err)
	}

	username := secret.Data["username"].(string)
	password := secret.Data["password"].(string)

	log.Printf("VAULT DB CREDENTIALS GENERATED: role=%s, username=%s, lease_duration=%d", 
		roleName, username, secret.LeaseDuration)
	return username, password, nil
}

// GenerateAWSCredentials generates dynamic AWS credentials
func (v *VaultOperator) GenerateAWSCredentials(roleName string) (string, string, string, error) {
	if !v.isConnected {
		return "", "", "", fmt.Errorf("Vault client not connected")
	}

	secret, err := v.client.Logical().Read(fmt.Sprintf("aws/creds/%s", roleName))
	if err != nil {
		return "", "", "", fmt.Errorf("failed to generate AWS credentials for role %s: %v", roleName, err)
	}

	accessKey := secret.Data["access_key"].(string)
	secretKey := secret.Data["secret_key"].(string)
	securityToken := ""
	
	if token, exists := secret.Data["security_token"]; exists && token != nil {
		securityToken = token.(string)
	}

	log.Printf("VAULT AWS CREDENTIALS GENERATED: role=%s, access_key=%s, lease_duration=%d", 
		roleName, accessKey, secret.LeaseDuration)
	return accessKey, secretKey, securityToken, nil
}

// RevokeLease revokes a lease
func (v *VaultOperator) RevokeLease(leaseID string) error {
	if !v.isConnected {
		return fmt.Errorf("Vault client not connected")
	}

	err := v.client.Sys().Revoke(leaseID)
	if err != nil {
		return fmt.Errorf("failed to revoke lease %s: %v", leaseID, err)
	}

	log.Printf("VAULT LEASE REVOKED: id=%s", leaseID)
	return nil
}

// RenewLease renews a lease
func (v *VaultOperator) RenewLease(leaseID string, increment int) (*api.Secret, error) {
	if !v.isConnected {
		return nil, fmt.Errorf("Vault client not connected")
	}

	secret, err := v.client.Sys().Renew(leaseID, increment)
	if err != nil {
		return nil, fmt.Errorf("failed to renew lease %s: %v", leaseID, err)
	}

	log.Printf("VAULT LEASE RENEWED: id=%s, duration=%d", leaseID, secret.LeaseDuration)
	return secret, nil
}

// GetHealth retrieves Vault cluster health
func (v *VaultOperator) GetHealth() (*api.HealthResponse, error) {
	if !v.isConnected {
		return nil, fmt.Errorf("Vault client not connected")
	}

	health, err := v.client.Sys().Health()
	if err != nil {
		return nil, fmt.Errorf("failed to get health: %v", err)
	}

	return health, nil
}

// EnableSecretEngine enables a secret engine
func (v *VaultOperator) EnableSecretEngine(mountPath, engineType string, config map[string]interface{}) error {
	if !v.isConnected {
		return fmt.Errorf("Vault client not connected")
	}

	mountInput := &api.MountInput{
		Type:    engineType,
		Config:  api.MountConfigInput(config),
	}

	err := v.client.Sys().Mount(mountPath, mountInput)
	if err != nil {
		return fmt.Errorf("failed to enable secret engine %s at %s: %v", engineType, mountPath, err)
	}

	log.Printf("VAULT SECRET ENGINE ENABLED: path=%s, type=%s", mountPath, engineType)
	return nil
}

// DisableSecretEngine disables a secret engine
func (v *VaultOperator) DisableSecretEngine(mountPath string) error {
	if !v.isConnected {
		return fmt.Errorf("Vault client not connected")
	}

	err := v.client.Sys().Unmount(mountPath)
	if err != nil {
		return fmt.Errorf("failed to disable secret engine at %s: %v", mountPath, err)
	}

	log.Printf("VAULT SECRET ENGINE DISABLED: path=%s", mountPath)
	return nil
}

// Close closes the Vault connection and cleans up resources
func (v *VaultOperator) Close() error {
	v.mutex.Lock()
	defer v.mutex.Unlock()

	if !v.isConnected {
		return nil
	}

	// Stop token renewal
	select {
	case v.tokenRenew <- struct{}{}:
	default:
	}
	close(v.tokenRenew)

	v.isConnected = false
	log.Printf("VAULT CONNECTION CLOSED")
	return nil
} 