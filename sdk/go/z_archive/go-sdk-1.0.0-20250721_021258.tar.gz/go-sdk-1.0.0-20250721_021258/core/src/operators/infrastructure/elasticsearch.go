package infrastructure

import (
	"context"
	"crypto/tls"
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"strings"
	"sync"
	"time"

	"github.com/elastic/go-elasticsearch/v8"
	"github.com/elastic/go-elasticsearch/v8/esapi"
	"github.com/elastic/go-elasticsearch/v8/esutil"
)

// ElasticsearchOperator handles @elasticsearch search and analytics operations
type ElasticsearchOperator struct {
	client      *elasticsearch.Client
	bulkIndexer esutil.BulkIndexer
	mutex       sync.RWMutex
	config      *ElasticsearchConfig
	isConnected bool
	indices     map[string]bool
}

// ElasticsearchConfig holds configuration for Elasticsearch connection
type ElasticsearchConfig struct {
	Addresses         []string      `json:"addresses"`
	Username          string        `json:"username"`
	Password          string        `json:"password"`
	APIKey            string        `json:"api_key"`
	ServiceToken      string        `json:"service_token"`
	CertificateFingerprint string   `json:"certificate_fingerprint"`
	CloudID           string        `json:"cloud_id"`
	MaxRetries        int           `json:"max_retries"`
	CompressRequestBody bool        `json:"compress_request_body"`
	DiscoverNodesOnStart bool       `json:"discover_nodes_on_start"`
	DiscoverNodesInterval time.Duration `json:"discover_nodes_interval"`
	EnableMetrics     bool          `json:"enable_metrics"`
	EnableDebugLogger bool          `json:"enable_debug_logger"`
	Transport         *http.Transport `json:"-"`
}

// DefaultElasticsearchConfig returns default configuration
func DefaultElasticsearchConfig() *ElasticsearchConfig {
	return &ElasticsearchConfig{
		Addresses:         []string{"http://localhost:9200"},
		MaxRetries:        3,
		CompressRequestBody: true,
		DiscoverNodesOnStart: false,
		DiscoverNodesInterval: 5 * time.Minute,
		EnableMetrics:     true,
		Transport: &http.Transport{
			MaxIdleConnsPerHost:   10,
			ResponseHeaderTimeout: 30 * time.Second,
			DialTimeout:          10 * time.Second,
			TLSClientConfig: &tls.Config{
				InsecureSkipVerify: false,
			},
		},
	}
}

// SearchRequest represents an Elasticsearch search request
type SearchRequest struct {
	Index    string                 `json:"index"`
	Query    map[string]interface{} `json:"query"`
	Size     *int                   `json:"size,omitempty"`
	From     *int                   `json:"from,omitempty"`
	Sort     []map[string]interface{} `json:"sort,omitempty"`
	Source   interface{}            `json:"_source,omitempty"`
	Aggregations map[string]interface{} `json:"aggs,omitempty"`
	Highlight map[string]interface{} `json:"highlight,omitempty"`
}

// IndexRequest represents a document indexing request
type IndexRequest struct {
	Index    string                 `json:"index"`
	ID       string                 `json:"id,omitempty"`
	Document map[string]interface{} `json:"document"`
	Refresh  string                 `json:"refresh,omitempty"`
}

// NewElasticsearchOperator creates a new Elasticsearch operator
func NewElasticsearchOperator(config *ElasticsearchConfig) (*ElasticsearchOperator, error) {
	if config == nil {
		config = DefaultElasticsearchConfig()
	}

	cfg := elasticsearch.Config{
		Addresses:         config.Addresses,
		Username:          config.Username,
		Password:          config.Password,
		APIKey:           config.APIKey,
		ServiceToken:     config.ServiceToken,
		CertificateFingerprint: config.CertificateFingerprint,
		CloudID:          config.CloudID,
		MaxRetries:       config.MaxRetries,
		CompressRequestBody: config.CompressRequestBody,
		DiscoverNodesOnStart: config.DiscoverNodesOnStart,
		DiscoverNodesInterval: config.DiscoverNodesInterval,
		EnableMetrics:    config.EnableMetrics,
		EnableDebugLogger: config.EnableDebugLogger,
		Transport:        config.Transport,
	}

	client, err := elasticsearch.NewClient(cfg)
	if err != nil {
		return nil, fmt.Errorf("failed to create Elasticsearch client: %v", err)
	}

	// Test connection
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	res, err := client.Info(client.Info.WithContext(ctx))
	if err != nil {
		return nil, fmt.Errorf("failed to connect to Elasticsearch: %v", err)
	}
	defer res.Body.Close()

	if res.IsError() {
		return nil, fmt.Errorf("Elasticsearch connection error: %s", res.String())
	}

	// Create bulk indexer for efficient bulk operations
	bulkIndexer, err := esutil.NewBulkIndexer(esutil.BulkIndexerConfig{
		Index:         "",
		Client:        client,
		NumWorkers:    4,
		FlushBytes:    1024 * 1024, // 1MB
		FlushInterval: 5 * time.Second,
		OnError: func(ctx context.Context, err error) {
			log.Printf("ELASTICSEARCH BULK ERROR: %v", err)
		},
		OnFlushStart: func(ctx context.Context) context.Context {
			log.Printf("ELASTICSEARCH BULK FLUSH STARTED")
			return ctx
		},
		OnFlushEnd: func(ctx context.Context) {
			log.Printf("ELASTICSEARCH BULK FLUSH COMPLETED")
		},
	})
	if err != nil {
		return nil, fmt.Errorf("failed to create bulk indexer: %v", err)
	}

	operator := &ElasticsearchOperator{
		client:      client,
		bulkIndexer: bulkIndexer,
		config:      config,
		isConnected: true,
		indices:     make(map[string]bool),
	}

	log.Printf("ELASTICSEARCH CONNECTED: %s", config.Addresses)
	return operator, nil
}

// Execute handles @elasticsearch operations with parameter parsing
func (es *ElasticsearchOperator) Execute(params string) interface{} {
	// Parse operation format: @elasticsearch("operation", "index", "query", "options")
	parts := strings.Split(strings.Trim(params, "()\""), "\",\"")
	if len(parts) < 2 {
		return fmt.Errorf("invalid elasticsearch operation format")
	}

	operation := strings.Trim(parts[0], "\"")
	index := strings.Trim(parts[1], "\"")

	switch operation {
	case "search":
		if len(parts) < 3 {
			return fmt.Errorf("search operation requires index and query")
		}
		query := strings.Trim(parts[2], "\"")
		
		// Parse JSON query
		var queryMap map[string]interface{}
		if err := json.Unmarshal([]byte(query), &queryMap); err != nil {
			queryMap = map[string]interface{}{
				"query_string": map[string]interface{}{
					"query": query,
				},
			}
		}

		searchReq := &SearchRequest{
			Index: index,
			Query: queryMap,
		}
		
		result, err := es.Search(searchReq)
		if err != nil {
			return fmt.Errorf("search failed: %v", err)
		}
		return result
	case "index":
		if len(parts) < 3 {
			return fmt.Errorf("index operation requires index and document")
		}
		docStr := strings.Trim(parts[2], "\"")
		
		var document map[string]interface{}
		if err := json.Unmarshal([]byte(docStr), &document); err != nil {
			return fmt.Errorf("invalid document JSON: %v", err)
		}

		indexReq := &IndexRequest{
			Index:    index,
			Document: document,
			Refresh:  "wait_for",
		}
		
		result, err := es.Index(indexReq)
		if err != nil {
			return fmt.Errorf("index failed: %v", err)
		}
		return result
	default:
		return fmt.Errorf("unsupported elasticsearch operation: %s", operation)
	}
}

// Search performs a search query
func (es *ElasticsearchOperator) Search(req *SearchRequest) (map[string]interface{}, error) {
	if !es.isConnected {
		return nil, fmt.Errorf("Elasticsearch client not connected")
	}

	query, err := json.Marshal(req)
	if err != nil {
		return nil, fmt.Errorf("failed to marshal search request: %v", err)
	}

	searchReq := esapi.SearchRequest{
		Index: []string{req.Index},
		Body:  strings.NewReader(string(query)),
	}

	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()

	res, err := searchReq.Do(ctx, es.client)
	if err != nil {
		log.Printf("ELASTICSEARCH SEARCH ERROR: index=%s, error=%v", req.Index, err)
		return nil, fmt.Errorf("search request failed: %v", err)
	}
	defer res.Body.Close()

	if res.IsError() {
		return nil, fmt.Errorf("search error: %s", res.String())
	}

	var result map[string]interface{}
	if err := json.NewDecoder(res.Body).Decode(&result); err != nil {
		return nil, fmt.Errorf("failed to decode search response: %v", err)
	}

	log.Printf("ELASTICSEARCH SEARCH SUCCESS: index=%s, took=%v, hits=%v", 
		req.Index, result["took"], result["hits"].(map[string]interface{})["total"])
	
	return result, nil
}

// Index adds or updates a document
func (es *ElasticsearchOperator) Index(req *IndexRequest) (map[string]interface{}, error) {
	if !es.isConnected {
		return nil, fmt.Errorf("Elasticsearch client not connected")
	}

	document, err := json.Marshal(req.Document)
	if err != nil {
		return nil, fmt.Errorf("failed to marshal document: %v", err)
	}

	indexReq := esapi.IndexRequest{
		Index:      req.Index,
		DocumentID: req.ID,
		Body:       strings.NewReader(string(document)),
		Refresh:    req.Refresh,
	}

	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()

	res, err := indexReq.Do(ctx, es.client)
	if err != nil {
		log.Printf("ELASTICSEARCH INDEX ERROR: index=%s, id=%s, error=%v", req.Index, req.ID, err)
		return nil, fmt.Errorf("index request failed: %v", err)
	}
	defer res.Body.Close()

	if res.IsError() {
		return nil, fmt.Errorf("index error: %s", res.String())
	}

	var result map[string]interface{}
	if err := json.NewDecoder(res.Body).Decode(&result); err != nil {
		return nil, fmt.Errorf("failed to decode index response: %v", err)
	}

	log.Printf("ELASTICSEARCH INDEX SUCCESS: index=%s, id=%s, result=%s", 
		req.Index, result["_id"], result["result"])
	
	return result, nil
}

// BulkIndex adds multiple documents efficiently
func (es *ElasticsearchOperator) BulkIndex(index string, documents []map[string]interface{}) error {
	if !es.isConnected {
		return fmt.Errorf("Elasticsearch client not connected")
	}

	for i, doc := range documents {
		docJSON, err := json.Marshal(doc)
		if err != nil {
			return fmt.Errorf("failed to marshal document %d: %v", i, err)
		}

		err = es.bulkIndexer.Add(
			context.Background(),
			esutil.BulkIndexerItem{
				Action: "index",
				Index:  index,
				Body:   strings.NewReader(string(docJSON)),
				OnSuccess: func(ctx context.Context, item esutil.BulkIndexerItem, res esutil.BulkIndexerResponseItem) {
					log.Printf("ELASTICSEARCH BULK INDEX SUCCESS: index=%s, id=%s", res.Index, res.DocumentID)
				},
				OnFailure: func(ctx context.Context, item esutil.BulkIndexerItem, res esutil.BulkIndexerResponseItem, err error) {
					log.Printf("ELASTICSEARCH BULK INDEX ERROR: index=%s, error=%v", res.Index, err)
				},
			},
		)
		if err != nil {
			return fmt.Errorf("failed to add document to bulk indexer: %v", err)
		}
	}

	log.Printf("ELASTICSEARCH BULK INDEX QUEUED: index=%s, documents=%d", index, len(documents))
	return nil
}

// Get retrieves a document by ID
func (es *ElasticsearchOperator) Get(index, id string) (map[string]interface{}, error) {
	if !es.isConnected {
		return nil, fmt.Errorf("Elasticsearch client not connected")
	}

	getReq := esapi.GetRequest{
		Index:      index,
		DocumentID: id,
	}

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	res, err := getReq.Do(ctx, es.client)
	if err != nil {
		return nil, fmt.Errorf("get request failed: %v", err)
	}
	defer res.Body.Close()

	if res.StatusCode == 404 {
		return nil, fmt.Errorf("document not found: %s/%s", index, id)
	}

	if res.IsError() {
		return nil, fmt.Errorf("get error: %s", res.String())
	}

	var result map[string]interface{}
	if err := json.NewDecoder(res.Body).Decode(&result); err != nil {
		return nil, fmt.Errorf("failed to decode get response: %v", err)
	}

	return result, nil
}

// Update updates a document
func (es *ElasticsearchOperator) Update(index, id string, doc map[string]interface{}) (map[string]interface{}, error) {
	if !es.isConnected {
		return nil, fmt.Errorf("Elasticsearch client not connected")
	}

	updateDoc := map[string]interface{}{
		"doc": doc,
	}

	updateJSON, err := json.Marshal(updateDoc)
	if err != nil {
		return nil, fmt.Errorf("failed to marshal update document: %v", err)
	}

	updateReq := esapi.UpdateRequest{
		Index:      index,
		DocumentID: id,
		Body:       strings.NewReader(string(updateJSON)),
		Refresh:    "wait_for",
	}

	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()

	res, err := updateReq.Do(ctx, es.client)
	if err != nil {
		return nil, fmt.Errorf("update request failed: %v", err)
	}
	defer res.Body.Close()

	if res.IsError() {
		return nil, fmt.Errorf("update error: %s", res.String())
	}

	var result map[string]interface{}
	if err := json.NewDecoder(res.Body).Decode(&result); err != nil {
		return nil, fmt.Errorf("failed to decode update response: %v", err)
	}

	return result, nil
}

// Delete removes a document
func (es *ElasticsearchOperator) Delete(index, id string) (map[string]interface{}, error) {
	if !es.isConnected {
		return nil, fmt.Errorf("Elasticsearch client not connected")
	}

	deleteReq := esapi.DeleteRequest{
		Index:      index,
		DocumentID: id,
		Refresh:    "wait_for",
	}

	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()

	res, err := deleteReq.Do(ctx, es.client)
	if err != nil {
		return nil, fmt.Errorf("delete request failed: %v", err)
	}
	defer res.Body.Close()

	if res.IsError() {
		return nil, fmt.Errorf("delete error: %s", res.String())
	}

	var result map[string]interface{}
	if err := json.NewDecoder(res.Body).Decode(&result); err != nil {
		return nil, fmt.Errorf("failed to decode delete response: %v", err)
	}

	return result, nil
}

// CreateIndex creates a new index with mappings and settings
func (es *ElasticsearchOperator) CreateIndex(index string, mappings, settings map[string]interface{}) error {
	if !es.isConnected {
		return fmt.Errorf("Elasticsearch client not connected")
	}

	indexBody := map[string]interface{}{}
	if mappings != nil {
		indexBody["mappings"] = mappings
	}
	if settings != nil {
		indexBody["settings"] = settings
	}

	bodyJSON, err := json.Marshal(indexBody)
	if err != nil {
		return fmt.Errorf("failed to marshal index body: %v", err)
	}

	createReq := esapi.IndicesCreateRequest{
		Index: index,
		Body:  strings.NewReader(string(bodyJSON)),
	}

	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()

	res, err := createReq.Do(ctx, es.client)
	if err != nil {
		return fmt.Errorf("create index failed: %v", err)
	}
	defer res.Body.Close()

	if res.IsError() {
		return fmt.Errorf("create index error: %s", res.String())
	}

	es.mutex.Lock()
	es.indices[index] = true
	es.mutex.Unlock()

	log.Printf("ELASTICSEARCH INDEX CREATED: %s", index)
	return nil
}

// DeleteIndex deletes an index
func (es *ElasticsearchOperator) DeleteIndex(index string) error {
	if !es.isConnected {
		return fmt.Errorf("Elasticsearch client not connected")
	}

	deleteReq := esapi.IndicesDeleteRequest{
		Index: []string{index},
	}

	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()

	res, err := deleteReq.Do(ctx, es.client)
	if err != nil {
		return fmt.Errorf("delete index failed: %v", err)
	}
	defer res.Body.Close()

	if res.IsError() && res.StatusCode != 404 {
		return fmt.Errorf("delete index error: %s", res.String())
	}

	es.mutex.Lock()
	delete(es.indices, index)
	es.mutex.Unlock()

	log.Printf("ELASTICSEARCH INDEX DELETED: %s", index)
	return nil
}

// IndexExists checks if an index exists
func (es *ElasticsearchOperator) IndexExists(index string) (bool, error) {
	if !es.isConnected {
		return false, fmt.Errorf("Elasticsearch client not connected")
	}

	existsReq := esapi.IndicesExistsRequest{
		Index: []string{index},
	}

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	res, err := existsReq.Do(ctx, es.client)
	if err != nil {
		return false, fmt.Errorf("index exists check failed: %v", err)
	}
	defer res.Body.Close()

	return res.StatusCode == 200, nil
}

// Refresh refreshes an index
func (es *ElasticsearchOperator) Refresh(index string) error {
	if !es.isConnected {
		return fmt.Errorf("Elasticsearch client not connected")
	}

	refreshReq := esapi.IndicesRefreshRequest{
		Index: []string{index},
	}

	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()

	res, err := refreshReq.Do(ctx, es.client)
	if err != nil {
		return fmt.Errorf("refresh failed: %v", err)
	}
	defer res.Body.Close()

	if res.IsError() {
		return fmt.Errorf("refresh error: %s", res.String())
	}

	return nil
}

// Aggregate performs aggregation queries
func (es *ElasticsearchOperator) Aggregate(index string, aggregations map[string]interface{}) (map[string]interface{}, error) {
	searchReq := &SearchRequest{
		Index:        index,
		Size:         new(int), // Set to 0
		Query:        map[string]interface{}{"match_all": map[string]interface{}{}},
		Aggregations: aggregations,
	}

	return es.Search(searchReq)
}

// ClusterHealth checks cluster health
func (es *ElasticsearchOperator) ClusterHealth() (map[string]interface{}, error) {
	if !es.isConnected {
		return nil, fmt.Errorf("Elasticsearch client not connected")
	}

	healthReq := esapi.ClusterHealthRequest{
		Level:   "cluster",
		Timeout: 10 * time.Second,
	}

	ctx, cancel := context.WithTimeout(context.Background(), 15*time.Second)
	defer cancel()

	res, err := healthReq.Do(ctx, es.client)
	if err != nil {
		return nil, fmt.Errorf("cluster health check failed: %v", err)
	}
	defer res.Body.Close()

	var health map[string]interface{}
	if err := json.NewDecoder(res.Body).Decode(&health); err != nil {
		return nil, fmt.Errorf("failed to decode health response: %v", err)
	}

	return health, nil
}

// ClusterStats retrieves cluster statistics
func (es *ElasticsearchOperator) ClusterStats() (map[string]interface{}, error) {
	if !es.isConnected {
		return nil, fmt.Errorf("Elasticsearch client not connected")
	}

	statsReq := esapi.ClusterStatsRequest{}

	ctx, cancel := context.WithTimeout(context.Background(), 15*time.Second)
	defer cancel()

	res, err := statsReq.Do(ctx, es.client)
	if err != nil {
		return nil, fmt.Errorf("cluster stats failed: %v", err)
	}
	defer res.Body.Close()

	var stats map[string]interface{}
	if err := json.NewDecoder(res.Body).Decode(&stats); err != nil {
		return nil, fmt.Errorf("failed to decode stats response: %v", err)
	}

	return stats, nil
}

// NodeStats retrieves node statistics
func (es *ElasticsearchOperator) NodeStats() (map[string]interface{}, error) {
	if !es.isConnected {
		return nil, fmt.Errorf("Elasticsearch client not connected")
	}

	statsReq := esapi.NodesStatsRequest{}

	ctx, cancel := context.WithTimeout(context.Background(), 15*time.Second)
	defer cancel()

	res, err := statsReq.Do(ctx, es.client)
	if err != nil {
		return nil, fmt.Errorf("node stats failed: %v", err)
	}
	defer res.Body.Close()

	var stats map[string]interface{}
	if err := json.NewDecoder(res.Body).Decode(&stats); err != nil {
		return nil, fmt.Errorf("failed to decode stats response: %v", err)
	}

	return stats, nil
}

// FlushBulkIndexer flushes pending bulk operations
func (es *ElasticsearchOperator) FlushBulkIndexer() error {
	if !es.isConnected {
		return fmt.Errorf("Elasticsearch client not connected")
	}

	ctx, cancel := context.WithTimeout(context.Background(), 60*time.Second)
	defer cancel()

	err := es.bulkIndexer.Close(ctx)
	if err != nil {
		return fmt.Errorf("failed to flush bulk indexer: %v", err)
	}

	// Recreate bulk indexer
	bulkIndexer, err := esutil.NewBulkIndexer(esutil.BulkIndexerConfig{
		Index:         "",
		Client:        es.client,
		NumWorkers:    4,
		FlushBytes:    1024 * 1024,
		FlushInterval: 5 * time.Second,
	})
	if err != nil {
		return fmt.Errorf("failed to recreate bulk indexer: %v", err)
	}

	es.bulkIndexer = bulkIndexer
	return nil
}

// Close closes the Elasticsearch connection and cleans up resources
func (es *ElasticsearchOperator) Close() error {
	es.mutex.Lock()
	defer es.mutex.Unlock()

	if !es.isConnected {
		return nil
	}

	// Close bulk indexer
	if es.bulkIndexer != nil {
		ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
		defer cancel()
		
		err := es.bulkIndexer.Close(ctx)
		if err != nil {
			log.Printf("ELASTICSEARCH BULK INDEXER CLOSE ERROR: %v", err)
		}
	}

	es.isConnected = false
	log.Printf("ELASTICSEARCH CONNECTION CLOSED")
	return nil
} 