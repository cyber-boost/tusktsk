package communication

import (
	"encoding/json"
	"fmt"
	"net/http"
	"sync"
	"time"

	"github.com/gorilla/websocket"
)

// WebSocketOperator handles @websocket operations
type WebSocketOperator struct {
	connections map[string]*websocket.Conn
	mutex       sync.RWMutex
	upgrader    websocket.Upgrader
}

// WebSocketMessage represents a WebSocket message
type WebSocketMessage struct {
	Type    string                 `json:"type"`
	Data    interface{}            `json:"data"`
	ID      string                 `json:"id,omitempty"`
	Channel string                 `json:"channel,omitempty"`
	Headers map[string]string      `json:"headers,omitempty"`
}

// WebSocketResponse represents a WebSocket response
type WebSocketResponse struct {
	Success bool                   `json:"success"`
	Data    interface{}            `json:"data,omitempty"`
	Error   string                 `json:"error,omitempty"`
	Headers map[string]string      `json:"headers,omitempty"`
}

// NewWebSocketOperator creates a new WebSocket operator
func NewWebSocketOperator() *WebSocketOperator {
	return &WebSocketOperator{
		connections: make(map[string]*websocket.Conn),
		upgrader: websocket.Upgrader{
			CheckOrigin: func(r *http.Request) bool {
				return true // Allow all origins for now
			},
		},
	}
}

// Execute handles @websocket operations
func (w *WebSocketOperator) Execute(params string) interface{} {
	// Parse parameters (format: "action", "url", "message")
	// Example: @websocket("connect", "ws://localhost:8080/ws", "hello")
	
	return fmt.Sprintf("@websocket(%s)", params)
}

// Connect establishes a WebSocket connection
func (w *WebSocketOperator) Connect(name, url string, headers map[string]string) error {
	w.mutex.Lock()
	defer w.mutex.Unlock()

	// Create HTTP header
	httpHeaders := http.Header{}
	for key, value := range headers {
		httpHeaders.Set(key, value)
	}

	// Establish WebSocket connection
	conn, _, err := websocket.DefaultDialer.Dial(url, httpHeaders)
	if err != nil {
		return fmt.Errorf("failed to connect to WebSocket %s at %s: %v", name, url, err)
	}

	w.connections[name] = conn
	return nil
}

// Disconnect closes a WebSocket connection
func (w *WebSocketOperator) Disconnect(name string) error {
	w.mutex.Lock()
	defer w.mutex.Unlock()

	if conn, exists := w.connections[name]; exists {
		err := conn.Close()
		delete(w.connections, name)
		return err
	}
	return fmt.Errorf("connection %s not found", name)
}

// Send sends a message through a WebSocket connection
func (w *WebSocketOperator) Send(name string, messageType string, data interface{}) error {
	w.mutex.RLock()
	conn, exists := w.connections[name]
	w.mutex.RUnlock()

	if !exists {
		return fmt.Errorf("connection %s not found", name)
	}

	// Create message
	message := WebSocketMessage{
		Type: messageType,
		Data: data,
	}

	// Marshal to JSON
	messageBytes, err := json.Marshal(message)
	if err != nil {
		return fmt.Errorf("failed to marshal message: %v", err)
	}

	// Send message
	err = conn.WriteMessage(websocket.TextMessage, messageBytes)
	if err != nil {
		return fmt.Errorf("failed to send message: %v", err)
	}

	return nil
}

// SendBinary sends binary data through a WebSocket connection
func (w *WebSocketOperator) SendBinary(name string, data []byte) error {
	w.mutex.RLock()
	conn, exists := w.connections[name]
	w.mutex.RUnlock()

	if !exists {
		return fmt.Errorf("connection %s not found", name)
	}

	err := conn.WriteMessage(websocket.BinaryMessage, data)
	if err != nil {
		return fmt.Errorf("failed to send binary message: %v", err)
	}

	return nil
}

// Receive receives a message from a WebSocket connection
func (w *WebSocketOperator) Receive(name string, timeout time.Duration) (*WebSocketMessage, error) {
	w.mutex.RLock()
	conn, exists := w.connections[name]
	w.mutex.RUnlock()

	if !exists {
		return nil, fmt.Errorf("connection %s not found", name)
	}

	// Set read deadline
	if timeout > 0 {
		err := conn.SetReadDeadline(time.Now().Add(timeout))
		if err != nil {
			return nil, fmt.Errorf("failed to set read deadline: %v", err)
		}
	}

	// Read message
	messageType, messageBytes, err := conn.ReadMessage()
	if err != nil {
		return nil, fmt.Errorf("failed to read message: %v", err)
	}

	// Parse message based on type
	if messageType == websocket.TextMessage {
		var message WebSocketMessage
		if err := json.Unmarshal(messageBytes, &message); err != nil {
			return nil, fmt.Errorf("failed to unmarshal message: %v", err)
		}
		return &message, nil
	} else if messageType == websocket.BinaryMessage {
		return &WebSocketMessage{
			Type: "binary",
			Data: messageBytes,
		}, nil
	}

	return nil, fmt.Errorf("unsupported message type: %d", messageType)
}

// Subscribe subscribes to a channel (for pub/sub systems)
func (w *WebSocketOperator) Subscribe(name, channel string) error {
	subscribeMessage := WebSocketMessage{
		Type:    "subscribe",
		Channel: channel,
	}

	return w.Send(name, "subscribe", subscribeMessage)
}

// Unsubscribe unsubscribes from a channel
func (w *WebSocketOperator) Unsubscribe(name, channel string) error {
	unsubscribeMessage := WebSocketMessage{
		Type:    "unsubscribe",
		Channel: channel,
	}

	return w.Send(name, "unsubscribe", unsubscribeMessage)
}

// Ping sends a ping message
func (w *WebSocketOperator) Ping(name string) error {
	w.mutex.RLock()
	conn, exists := w.connections[name]
	w.mutex.RUnlock()

	if !exists {
		return fmt.Errorf("connection %s not found", name)
	}

	err := conn.WriteMessage(websocket.PingMessage, nil)
	if err != nil {
		return fmt.Errorf("failed to send ping: %v", err)
	}

	return nil
}

// Pong sends a pong message
func (w *WebSocketOperator) Pong(name string) error {
	w.mutex.RLock()
	conn, exists := w.connections[name]
	w.mutex.RUnlock()

	if !exists {
		return fmt.Errorf("connection %s not found", name)
	}

	err := conn.WriteMessage(websocket.PongMessage, nil)
	if err != nil {
		return fmt.Errorf("failed to send pong: %v", err)
	}

	return nil
}

// ListConnections returns a list of active connection names
func (w *WebSocketOperator) ListConnections() []string {
	w.mutex.RLock()
	defer w.mutex.RUnlock()

	names := make([]string, 0, len(w.connections))
	for name := range w.connections {
		names = append(names, name)
	}
	return names
}

// GetConnectionStatus returns the status of a connection
func (w *WebSocketOperator) GetConnectionStatus(name string) string {
	w.mutex.RLock()
	defer w.mutex.RUnlock()

	if conn, exists := w.connections[name]; exists {
		// Try to send a ping to check if connection is alive
		err := conn.WriteControl(websocket.PingMessage, nil, time.Now().Add(5*time.Second))
		if err != nil {
			return "disconnected"
		}
		return "connected"
	}
	return "not_found"
}

// SetReadLimit sets the maximum message size for reading
func (w *WebSocketOperator) SetReadLimit(name string, limit int64) error {
	w.mutex.RLock()
	conn, exists := w.connections[name]
	w.mutex.RUnlock()

	if !exists {
		return fmt.Errorf("connection %s not found", name)
	}

	conn.SetReadLimit(limit)
	return nil
}

// SetWriteDeadline sets the write deadline for a connection
func (w *WebSocketOperator) SetWriteDeadline(name string, deadline time.Time) error {
	w.mutex.RLock()
	conn, exists := w.connections[name]
	w.mutex.RUnlock()

	if !exists {
		return fmt.Errorf("connection %s not found", name)
	}

	return conn.SetWriteDeadline(deadline)
}

// Close closes all WebSocket connections
func (w *WebSocketOperator) Close() error {
	w.mutex.Lock()
	defer w.mutex.Unlock()

	var lastError error
	for name, conn := range w.connections {
		if err := conn.Close(); err != nil {
			lastError = fmt.Errorf("failed to close connection %s: %v", name, err)
		}
	}
	w.connections = make(map[string]*websocket.Conn)
	return lastError
} 