package core

import (
	"encoding/json"
	"fmt"
	"sync"
	"time"
)

// FeatureFlag represents a feature flag configuration
type FeatureFlag struct {
	Name        string                 `json:"name"`
	Enabled     bool                   `json:"enabled"`
	Percentage  int                    `json:"percentage"`
	Users       []string               `json:"users"`
	Groups      []string               `json:"groups"`
	Conditions  map[string]interface{} `json:"conditions"`
	CreatedAt   time.Time              `json:"created_at"`
	UpdatedAt   time.Time              `json:"updated_at"`
}

// FeatureOperator handles @feature operations
type FeatureOperator struct {
	flags map[string]*FeatureFlag
	mutex sync.RWMutex
}

// NewFeatureOperator creates a new feature operator
func NewFeatureOperator() *FeatureOperator {
	return &FeatureOperator{
		flags: make(map[string]*FeatureFlag),
	}
}

// Execute handles @feature operations
func (m *FeatureOperator) Execute(params string) interface{} {
	// Parse parameters (format: "feature_name" or "feature_name", "user_id")
	// Example: @feature("new_ui")
	// Example: @feature("beta_feature", "user123")
	
	// For now, return a placeholder that matches PHP behavior
	// In a real implementation, this would check feature flags
	
	return fmt.Sprintf("@feature(%s)", params)
}

// IsEnabled checks if a feature flag is enabled
func (f *FeatureOperator) IsEnabled(featureName string) bool {
	f.mutex.RLock()
	defer f.mutex.RUnlock()
	
	if flag, exists := f.flags[featureName]; exists {
		return flag.Enabled
	}
	return false
}

// IsEnabledForUser checks if a feature flag is enabled for a specific user
func (f *FeatureOperator) IsEnabledForUser(featureName, userID string) bool {
	f.mutex.RLock()
	defer f.mutex.RUnlock()
	
	if flag, exists := f.flags[featureName]; exists {
		if !flag.Enabled {
			return false
		}
		
		// Check if user is explicitly included
		for _, user := range flag.Users {
			if user == userID {
				return true
			}
		}
		
		// Check percentage rollout
		if flag.Percentage > 0 {
			// Simple hash-based percentage check
			hash := f.hashString(userID + featureName)
			percentage := hash % 100
			return percentage < flag.Percentage
		}
		
		return flag.Enabled
	}
	return false
}

// AddFlag adds a new feature flag
func (f *FeatureOperator) AddFlag(flag *FeatureFlag) {
	f.mutex.Lock()
	defer f.mutex.Unlock()
	
	flag.CreatedAt = time.Now()
	flag.UpdatedAt = time.Now()
	f.flags[flag.Name] = flag
}

// UpdateFlag updates an existing feature flag
func (f *FeatureOperator) UpdateFlag(flag *FeatureFlag) {
	f.mutex.Lock()
	defer f.mutex.Unlock()
	
	if existing, exists := f.flags[flag.Name]; exists {
		flag.CreatedAt = existing.CreatedAt
		flag.UpdatedAt = time.Now()
		f.flags[flag.Name] = flag
	}
}

// RemoveFlag removes a feature flag
func (f *FeatureOperator) RemoveFlag(featureName string) {
	f.mutex.Lock()
	defer f.mutex.Unlock()
	
	delete(f.flags, featureName)
}

// GetFlag returns a feature flag by name
func (f *FeatureOperator) GetFlag(featureName string) (*FeatureFlag, bool) {
	f.mutex.RLock()
	defer f.mutex.RUnlock()
	
	flag, exists := f.flags[featureName]
	return flag, exists
}

// GetAllFlags returns all feature flags
func (f *FeatureOperator) GetAllFlags() map[string]*FeatureFlag {
	f.mutex.RLock()
	defer f.mutex.RUnlock()
	
	result := make(map[string]*FeatureFlag)
	for key, value := range f.flags {
		result[key] = value
	}
	return result
}

// EnableFlag enables a feature flag
func (f *FeatureOperator) EnableFlag(featureName string) {
	f.mutex.Lock()
	defer f.mutex.Unlock()
	
	if flag, exists := f.flags[featureName]; exists {
		flag.Enabled = true
		flag.UpdatedAt = time.Now()
	}
}

// DisableFlag disables a feature flag
func (f *FeatureOperator) DisableFlag(featureName string) {
	f.mutex.Lock()
	defer f.mutex.Unlock()
	
	if flag, exists := f.flags[featureName]; exists {
		flag.Enabled = false
		flag.UpdatedAt = time.Now()
	}
}

// SetPercentage sets the rollout percentage for a feature flag
func (f *FeatureOperator) SetPercentage(featureName string, percentage int) {
	f.mutex.Lock()
	defer f.mutex.Unlock()
	
	if flag, exists := f.flags[featureName]; exists {
		if percentage < 0 {
			percentage = 0
		}
		if percentage > 100 {
			percentage = 100
		}
		flag.Percentage = percentage
		flag.UpdatedAt = time.Now()
	}
}

// AddUser adds a user to a feature flag's user list
func (f *FeatureOperator) AddUser(featureName, userID string) {
	f.mutex.Lock()
	defer f.mutex.Unlock()
	
	if flag, exists := f.flags[featureName]; exists {
		// Check if user already exists
		for _, user := range flag.Users {
			if user == userID {
				return
			}
		}
		flag.Users = append(flag.Users, userID)
		flag.UpdatedAt = time.Now()
	}
}

// RemoveUser removes a user from a feature flag's user list
func (f *FeatureOperator) RemoveUser(featureName, userID string) {
	f.mutex.Lock()
	defer f.mutex.Unlock()
	
	if flag, exists := f.flags[featureName]; exists {
		for i, user := range flag.Users {
			if user == userID {
				flag.Users = append(flag.Users[:i], flag.Users[i+1:]...)
				flag.UpdatedAt = time.Now()
				break
			}
		}
	}
}

// AddGroup adds a group to a feature flag's group list
func (f *FeatureOperator) AddGroup(featureName, groupName string) {
	f.mutex.Lock()
	defer f.mutex.Unlock()
	
	if flag, exists := f.flags[featureName]; exists {
		// Check if group already exists
		for _, group := range flag.Groups {
			if group == groupName {
				return
			}
		}
		flag.Groups = append(flag.Groups, groupName)
		flag.UpdatedAt = time.Now()
	}
}

// RemoveGroup removes a group from a feature flag's group list
func (f *FeatureOperator) RemoveGroup(featureName, groupName string) {
	f.mutex.Lock()
	defer f.mutex.Unlock()
	
	if flag, exists := f.flags[featureName]; exists {
		for i, group := range flag.Groups {
			if group == groupName {
				flag.Groups = append(flag.Groups[:i], flag.Groups[i+1:]...)
				flag.UpdatedAt = time.Now()
				break
			}
		}
	}
}

// SetCondition sets a condition for a feature flag
func (f *FeatureOperator) SetCondition(featureName, conditionName string, condition interface{}) {
	f.mutex.Lock()
	defer f.mutex.Unlock()
	
	if flag, exists := f.flags[featureName]; exists {
		if flag.Conditions == nil {
			flag.Conditions = make(map[string]interface{})
		}
		flag.Conditions[conditionName] = condition
		flag.UpdatedAt = time.Now()
	}
}

// RemoveCondition removes a condition from a feature flag
func (f *FeatureOperator) RemoveCondition(featureName, conditionName string) {
	f.mutex.Lock()
	defer f.mutex.Unlock()
	
	if flag, exists := f.flags[featureName]; exists {
		if flag.Conditions != nil {
			delete(flag.Conditions, conditionName)
			flag.UpdatedAt = time.Now()
		}
	}
}

// ExportFlags exports feature flags to JSON
func (f *FeatureOperator) ExportFlags() (string, error) {
	f.mutex.RLock()
	defer f.mutex.RUnlock()
	
	data, err := json.MarshalIndent(f.flags, "", "  ")
	return string(data), err
}

// ImportFlags imports feature flags from JSON
func (f *FeatureOperator) ImportFlags(jsonData string) error {
	var flags map[string]*FeatureFlag
	err := json.Unmarshal([]byte(jsonData), &flags)
	if err != nil {
		return err
	}
	
	f.mutex.Lock()
	defer f.mutex.Unlock()
	
	f.flags = flags
	return nil
}

// hashString creates a simple hash for percentage-based rollouts
func (f *FeatureOperator) hashString(s string) int {
	hash := 0
	for _, char := range s {
		hash = ((hash << 5) - hash) + int(char)
		hash = hash & hash // Convert to 32-bit integer
	}
	if hash < 0 {
		hash = -hash
	}
	return hash
}

// Reset clears all feature flags
func (f *FeatureOperator) Reset() {
	f.mutex.Lock()
	defer f.mutex.Unlock()
	
	f.flags = make(map[string]*FeatureFlag)
} 