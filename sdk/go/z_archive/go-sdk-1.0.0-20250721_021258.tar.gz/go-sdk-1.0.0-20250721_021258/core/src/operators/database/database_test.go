package database

import (
	"fmt"
	"testing"
	"time"
)

func TestMySQLOperator(t *testing.T) {
	// Test operator creation (without actual connection)
	operator := &MySQLOperator{}
	
	// Test Execute method
	result := operator.Execute("test params")
	expected := "@mysql(test params)"
	if result != expected {
		t.Errorf("Expected %s, got %s", expected, result)
	}
}

func TestPostgreSQLOperator(t *testing.T) {
	// Test operator creation (without actual connection)
	operator := &PostgreSQLOperator{}
	
	// Test Execute method
	result := operator.Execute("test params")
	expected := "@postgresql(test params)"
	if result != expected {
		t.Errorf("Expected %s, got %s", expected, result)
	}
}

func TestMongoDBOperator(t *testing.T) {
	// Test operator creation (without actual connection)
	operator := &MongoDBOperator{}
	
	// Test Execute method
	result := operator.Execute("test params")
	expected := "@mongodb(test params)"
	if result != expected {
		t.Errorf("Expected %s, got %s", expected, result)
	}
}

func TestRedisOperator(t *testing.T) {
	// Test operator creation (without actual connection)
	operator := &RedisOperator{}
	
	// Test Execute method
	result := operator.Execute("test params")
	expected := "@redis(test params)"
	if result != expected {
		t.Errorf("Expected %s, got %s", expected, result)
	}
}

func TestDatabaseFactory(t *testing.T) {
	factory := NewDatabaseFactory()
	
	// Test factory creation
	if factory == nil {
		t.Fatal("Failed to create database factory")
	}
	
	// Test listing connections (should be empty initially)
	connections := factory.ListConnections()
	if len(connections) != 0 {
		t.Errorf("Expected 0 connections, got %d", len(connections))
	}
	
	// Test closing all connections (should not panic)
	factory.CloseAllConnections()
}

func TestDatabaseFactoryGlobal(t *testing.T) {
	// Test global factory creation
	factory := GetGlobalFactory()
	if factory == nil {
		t.Fatal("Failed to create global database factory")
	}
	
	// Test that it's the same instance
	factory2 := GetGlobalFactory()
	if factory != factory2 {
		t.Error("Global factory should return the same instance")
	}
}

func TestOperatorRegistryDatabase(t *testing.T) {
	registry := NewOperatorRegistry()
	
	// Test database operator registration
	mockOperator := &MockDatabaseOperator{}
	registry.RegisterDatabase("test", mockOperator)
	
	// Test retrieval
	operator, exists := registry.GetDatabase("test")
	if !exists {
		t.Error("Database operator should exist after registration")
	}
	
	if operator != mockOperator {
		t.Error("Retrieved operator should match registered operator")
	}
	
	// Test listing database operators
	dbOperators := registry.ListDatabaseOperators()
	if len(dbOperators) != 1 {
		t.Errorf("Expected 1 database operator, got %d", len(dbOperators))
	}
	
	if dbOperators[0] != "test" {
		t.Errorf("Expected 'test' operator, got %s", dbOperators[0])
	}
	
	// Test closing database operators
	registry.CloseDatabaseOperators()
}

// MockDatabaseOperator for testing
type MockDatabaseOperator struct{}

func (m *MockDatabaseOperator) Execute(params string) interface{} {
	return fmt.Sprintf("@mock(%s)", params)
}

func (m *MockDatabaseOperator) Close() error {
	return nil
}

func TestRedisOperatorMethods(t *testing.T) {
	// Test Redis operator method signatures (without actual connection)
	operator := &RedisOperator{}
	
	// Test that methods exist and don't panic
	_ = operator.Set
	_ = operator.Get
	_ = operator.Del
	_ = operator.Exists
	_ = operator.Expire
	_ = operator.TTL
	_ = operator.Incr
	_ = operator.IncrBy
	_ = operator.Decr
	_ = operator.DecrBy
	_ = operator.HSet
	_ = operator.HGet
	_ = operator.HGetAll
	_ = operator.HDel
	_ = operator.LPush
	_ = operator.RPush
	_ = operator.LPop
	_ = operator.RPop
	_ = operator.LRange
	_ = operator.SAdd
	_ = operator.SMembers
	_ = operator.SRem
	_ = operator.ZAdd
	_ = operator.ZRange
	_ = operator.ZRangeWithScores
	_ = operator.Publish
	_ = operator.Subscribe
	_ = operator.PSubscribe
	_ = operator.SetJSON
	_ = operator.GetJSON
	_ = operator.Keys
	_ = operator.Scan
	_ = operator.FlushDB
	_ = operator.FlushAll
	_ = operator.Info
	_ = operator.Close
}

func TestMySQLOperatorMethods(t *testing.T) {
	// Test MySQL operator method signatures (without actual connection)
	operator := &MySQLOperator{}
	
	// Test that methods exist and don't panic
	_ = operator.Query
	_ = operator.QueryRow
	_ = operator.Exec
	_ = operator.Insert
	_ = operator.Update
	_ = operator.Delete
	_ = operator.Transaction
	_ = operator.CreateTable
	_ = operator.DropTable
	_ = operator.ListTables
	_ = operator.DescribeTable
	_ = operator.CreateIndex
	_ = operator.DropIndex
	_ = operator.Close
}

func TestPostgreSQLOperatorMethods(t *testing.T) {
	// Test PostgreSQL operator method signatures (without actual connection)
	operator := &PostgreSQLOperator{}
	
	// Test that methods exist and don't panic
	_ = operator.Query
	_ = operator.QueryRow
	_ = operator.Exec
	_ = operator.Insert
	_ = operator.Update
	_ = operator.Delete
	_ = operator.Transaction
	_ = operator.CreateTable
	_ = operator.DropTable
	_ = operator.ListTables
	_ = operator.DescribeTable
	_ = operator.CreateIndex
	_ = operator.DropIndex
	_ = operator.Close
}

func TestMongoDBOperatorMethods(t *testing.T) {
	// Test MongoDB operator method signatures (without actual connection)
	operator := &MongoDBOperator{}
	
	// Test that methods exist and don't panic
	_ = operator.Find
	_ = operator.FindOne
	_ = operator.InsertOne
	_ = operator.InsertMany
	_ = operator.UpdateOne
	_ = operator.UpdateMany
	_ = operator.DeleteOne
	_ = operator.DeleteMany
	_ = operator.Aggregate
	_ = operator.CreateCollection
	_ = operator.DropCollection
	_ = operator.ListCollections
	_ = operator.CreateIndex
	_ = operator.DropIndex
	_ = operator.ListIndexes
	_ = operator.Close
}

func TestDatabaseOperatorInterface(t *testing.T) {
	// Test that all database operators implement the DatabaseOperator interface
	var _ DatabaseOperator = &MySQLOperator{}
	var _ DatabaseOperator = &PostgreSQLOperator{}
	var _ DatabaseOperator = &MongoDBOperator{}
	var _ DatabaseOperator = &RedisOperator{}
}

func TestOperatorRegistryGlobal(t *testing.T) {
	// Test global registry functions
	registry := GetGlobalRegistry()
	if registry == nil {
		t.Fatal("Failed to get global registry")
	}
	
	// Test that it's the same instance
	registry2 := GetGlobalRegistry()
	if registry != registry2 {
		t.Error("Global registry should return the same instance")
	}
	
	// Test global registration
	mockOperator := &MockDatabaseOperator{}
	RegisterDatabaseGlobal("global_test", mockOperator)
	
	// Test global execution
	result := ExecuteGlobal("global_test", "test params")
	expected := "@mock(test params)"
	if result != expected {
		t.Errorf("Expected %s, got %s", expected, result)
	}
	
	// Test closing global database operators
	CloseGlobalDatabaseOperators()
}

func TestDatabaseFactoryMethods(t *testing.T) {
	factory := NewDatabaseFactory()
	
	// Test factory methods (without actual connections)
	_, err := factory.CreateMySQLOperator("test", "invalid_connection")
	if err == nil {
		t.Error("Should fail with invalid connection string")
	}
	
	_, err = factory.CreatePostgreSQLOperator("test", "invalid_connection")
	if err == nil {
		t.Error("Should fail with invalid connection string")
	}
	
	_, err = factory.CreateMongoDBOperator("test", "invalid_connection")
	if err == nil {
		t.Error("Should fail with invalid connection string")
	}
	
	_, err = factory.CreateRedisOperator("test", "invalid_addr", "", 0)
	if err == nil {
		t.Error("Should fail with invalid Redis address")
	}
	
	// Test getter methods
	_, exists := factory.GetMySQLOperator("nonexistent")
	if exists {
		t.Error("Should not find nonexistent operator")
	}
	
	_, exists = factory.GetPostgreSQLOperator("nonexistent")
	if exists {
		t.Error("Should not find nonexistent operator")
	}
	
	_, exists = factory.GetMongoDBOperator("nonexistent")
	if exists {
		t.Error("Should not find nonexistent operator")
	}
	
	_, exists = factory.GetRedisOperator("nonexistent")
	if exists {
		t.Error("Should not find nonexistent operator")
	}
	
	// Test connection management
	err = factory.CloseConnection("nonexistent")
	if err != nil {
		t.Errorf("Should not error when closing nonexistent connection: %v", err)
	}
} 