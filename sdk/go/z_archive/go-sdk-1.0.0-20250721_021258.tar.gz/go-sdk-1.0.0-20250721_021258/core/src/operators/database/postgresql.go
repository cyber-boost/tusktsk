package database

import (
	"context"
	"database/sql"
	"fmt"
	"time"

	_ "github.com/lib/pq"
)

// PostgreSQLOperator handles @postgresql operations
type PostgreSQLOperator struct {
	db *sql.DB
}

// NewPostgreSQLOperator creates a new PostgreSQL operator
func NewPostgreSQLOperator(connectionString string) (*PostgreSQLOperator, error) {
	db, err := sql.Open("postgres", connectionString)
	if err != nil {
		return nil, fmt.Errorf("failed to open PostgreSQL connection: %v", err)
	}

	// Test connection
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	
	if err := db.PingContext(ctx); err != nil {
		return nil, fmt.Errorf("failed to ping PostgreSQL: %v", err)
	}

	// Set connection pool settings
	db.SetMaxOpenConns(25)
	db.SetMaxIdleConns(5)
	db.SetConnMaxLifetime(5 * time.Minute)

	return &PostgreSQLOperator{db: db}, nil
}

// Execute handles @postgresql operations
func (p *PostgreSQLOperator) Execute(params string) interface{} {
	// Parse parameters (format: "operation", "query", "params")
	// Example: @postgresql("query", "SELECT * FROM users WHERE status = $1", ["active"])
	
	return fmt.Sprintf("@postgresql(%s)", params)
}

// Query executes a SELECT query
func (p *PostgreSQLOperator) Query(query string, args ...interface{}) ([]map[string]interface{}, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()

	rows, err := p.db.QueryContext(ctx, query, args...)
	if err != nil {
		return nil, fmt.Errorf("query execution failed: %v", err)
	}
	defer rows.Close()

	columns, err := rows.Columns()
	if err != nil {
		return nil, fmt.Errorf("failed to get columns: %v", err)
	}

	var results []map[string]interface{}
	for rows.Next() {
		values := make([]interface{}, len(columns))
		valuePtrs := make([]interface{}, len(columns))
		for i := range values {
			valuePtrs[i] = &values[i]
		}

		if err := rows.Scan(valuePtrs...); err != nil {
			return nil, fmt.Errorf("failed to scan row: %v", err)
		}

		row := make(map[string]interface{})
		for i, col := range columns {
			val := values[i]
			switch v := val.(type) {
			case []byte:
				row[col] = string(v)
			case time.Time:
				row[col] = v.Format("2006-01-02 15:04:05")
			default:
				row[col] = v
			}
		}
		results = append(results, row)
	}

	if err = rows.Err(); err != nil {
		return nil, fmt.Errorf("error iterating rows: %v", err)
	}

	return results, nil
}

// QueryRow executes a SELECT query returning a single row
func (p *PostgreSQLOperator) QueryRow(query string, args ...interface{}) (map[string]interface{}, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()

	rows, err := p.db.QueryContext(ctx, query, args...)
	if err != nil {
		return nil, fmt.Errorf("query execution failed: %v", err)
	}
	defer rows.Close()

	columns, err := rows.Columns()
	if err != nil {
		return nil, fmt.Errorf("failed to get columns: %v", err)
	}

	if !rows.Next() {
		return nil, nil // No rows found
	}

	values := make([]interface{}, len(columns))
	valuePtrs := make([]interface{}, len(columns))
	for i := range values {
		valuePtrs[i] = &values[i]
	}

	if err := rows.Scan(valuePtrs...); err != nil {
		return nil, fmt.Errorf("failed to scan row: %v", err)
	}

	row := make(map[string]interface{})
	for i, col := range columns {
		val := values[i]
		switch v := val.(type) {
		case []byte:
			row[col] = string(v)
		case time.Time:
			row[col] = v.Format("2006-01-02 15:04:05")
		default:
			row[col] = v
		}
	}

	return row, nil
}

// Exec executes an INSERT, UPDATE, or DELETE query
func (p *PostgreSQLOperator) Exec(query string, args ...interface{}) (int64, int64, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()

	result, err := p.db.ExecContext(ctx, query, args...)
	if err != nil {
		return 0, 0, fmt.Errorf("execution failed: %v", err)
	}

	rowsAffected, err := result.RowsAffected()
	if err != nil {
		return 0, 0, fmt.Errorf("failed to get rows affected: %v", err)
	}

	lastInsertID := int64(0)
	// PostgreSQL doesn't have a direct LastInsertId, but we can get it from RETURNING clause
	// This is a simplified implementation

	return lastInsertID, rowsAffected, nil
}

// Insert executes an INSERT query and returns the last insert ID
func (p *PostgreSQLOperator) Insert(query string, args ...interface{}) (int64, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()

	var lastInsertID int64
	err := p.db.QueryRowContext(ctx, query+" RETURNING id", args...).Scan(&lastInsertID)
	if err != nil {
		return 0, fmt.Errorf("insert failed: %v", err)
	}

	return lastInsertID, nil
}

// Update executes an UPDATE query
func (p *PostgreSQLOperator) Update(query string, args ...interface{}) (int64, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()

	result, err := p.db.ExecContext(ctx, query, args...)
	if err != nil {
		return 0, fmt.Errorf("update failed: %v", err)
	}

	rowsAffected, err := result.RowsAffected()
	if err != nil {
		return 0, fmt.Errorf("failed to get rows affected: %v", err)
	}

	return rowsAffected, nil
}

// Delete executes a DELETE query
func (p *PostgreSQLOperator) Delete(query string, args ...interface{}) (int64, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()

	result, err := p.db.ExecContext(ctx, query, args...)
	if err != nil {
		return 0, fmt.Errorf("delete failed: %v", err)
	}

	rowsAffected, err := result.RowsAffected()
	if err != nil {
		return 0, fmt.Errorf("failed to get rows affected: %v", err)
	}

	return rowsAffected, nil
}

// Transaction executes multiple queries in a transaction
func (p *PostgreSQLOperator) Transaction(queries []string, args [][]interface{}) error {
	ctx, cancel := context.WithTimeout(context.Background(), 60*time.Second)
	defer cancel()

	tx, err := p.db.BeginTx(ctx, nil)
	if err != nil {
		return fmt.Errorf("failed to begin transaction: %v", err)
	}

	for i, query := range queries {
		var queryArgs []interface{}
		if i < len(args) {
			queryArgs = args[i]
		}

		_, err := tx.ExecContext(ctx, query, queryArgs...)
		if err != nil {
			tx.Rollback()
			return fmt.Errorf("query %d failed: %v", i+1, err)
		}
	}

	return tx.Commit()
}

// CreateTable creates a new table
func (p *PostgreSQLOperator) CreateTable(tableName, schema string) error {
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()

	query := fmt.Sprintf("CREATE TABLE IF NOT EXISTS %s (%s)", tableName, schema)
	_, err := p.db.ExecContext(ctx, query)
	if err != nil {
		return fmt.Errorf("create table failed: %v", err)
	}

	return nil
}

// DropTable drops a table
func (p *PostgreSQLOperator) DropTable(tableName string) error {
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()

	query := fmt.Sprintf("DROP TABLE IF EXISTS %s", tableName)
	_, err := p.db.ExecContext(ctx, query)
	if err != nil {
		return fmt.Errorf("drop table failed: %v", err)
	}

	return nil
}

// ListTables lists all tables in the database
func (p *PostgreSQLOperator) ListTables() ([]string, error) {
	query := `
		SELECT table_name 
		FROM information_schema.tables 
		WHERE table_schema = 'public'
		ORDER BY table_name
	`

	rows, err := p.Query(query)
	if err != nil {
		return nil, fmt.Errorf("list tables failed: %v", err)
	}

	var tables []string
	for _, row := range rows {
		if tableName, ok := row["table_name"].(string); ok {
			tables = append(tables, tableName)
		}
	}

	return tables, nil
}

// DescribeTable describes the structure of a table
func (p *PostgreSQLOperator) DescribeTable(tableName string) ([]map[string]interface{}, error) {
	query := `
		SELECT 
			column_name,
			data_type,
			is_nullable,
			column_default
		FROM information_schema.columns 
		WHERE table_name = $1 AND table_schema = 'public'
		ORDER BY ordinal_position
	`

	return p.Query(query, tableName)
}

// CreateIndex creates an index on a table
func (p *PostgreSQLOperator) CreateIndex(indexName, tableName, columns string) error {
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()

	query := fmt.Sprintf("CREATE INDEX IF NOT EXISTS %s ON %s (%s)", indexName, tableName, columns)
	_, err := p.db.ExecContext(ctx, query)
	if err != nil {
		return fmt.Errorf("create index failed: %v", err)
	}

	return nil
}

// DropIndex drops an index
func (p *PostgreSQLOperator) DropIndex(indexName string) error {
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()

	query := fmt.Sprintf("DROP INDEX IF EXISTS %s", indexName)
	_, err := p.db.ExecContext(ctx, query)
	if err != nil {
		return fmt.Errorf("drop index failed: %v", err)
	}

	return nil
}

// Close closes the PostgreSQL connection
func (p *PostgreSQLOperator) Close() error {
	return p.db.Close()
} 