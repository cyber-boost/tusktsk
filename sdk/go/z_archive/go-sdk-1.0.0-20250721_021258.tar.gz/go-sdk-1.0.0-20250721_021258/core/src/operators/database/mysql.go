package database

import (
	"context"
	"database/sql"
	"fmt"
	"time"

	_ "github.com/go-sql-driver/mysql"
)

// MySQLOperator handles @mysql operations
type MySQLOperator struct {
	db *sql.DB
}

// NewMySQLOperator creates a new MySQL operator
func NewMySQLOperator(connectionString string) (*MySQLOperator, error) {
	db, err := sql.Open("mysql", connectionString)
	if err != nil {
		return nil, fmt.Errorf("failed to open MySQL connection: %v", err)
	}

	// Test connection
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	
	if err := db.PingContext(ctx); err != nil {
		return nil, fmt.Errorf("failed to ping MySQL: %v", err)
	}

	// Set connection pool settings
	db.SetMaxOpenConns(25)
	db.SetMaxIdleConns(5)
	db.SetConnMaxLifetime(5 * time.Minute)

	return &MySQLOperator{db: db}, nil
}

// Execute handles @mysql operations
func (m *MySQLOperator) Execute(params string) interface{} {
	// Parse parameters (format: "operation", "query", "params")
	// Example: @mysql("query", "SELECT * FROM users WHERE status = ?", ["active"])
	
	return fmt.Sprintf("@mysql(%s)", params)
}

// Query executes a SELECT query
func (m *MySQLOperator) Query(query string, args ...interface{}) ([]map[string]interface{}, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()

	rows, err := m.db.QueryContext(ctx, query, args...)
	if err != nil {
		return nil, fmt.Errorf("query execution failed: %v", err)
	}
	defer rows.Close()

	columns, err := rows.Columns()
	if err != nil {
		return nil, fmt.Errorf("failed to get columns: %v", err)
	}

	var results []map[string]interface{}
	for rows.Next() {
		values := make([]interface{}, len(columns))
		valuePtrs := make([]interface{}, len(columns))
		for i := range values {
			valuePtrs[i] = &values[i]
		}

		if err := rows.Scan(valuePtrs...); err != nil {
			return nil, fmt.Errorf("failed to scan row: %v", err)
		}

		row := make(map[string]interface{})
		for i, col := range columns {
			val := values[i]
			switch v := val.(type) {
			case []byte:
				row[col] = string(v)
			case time.Time:
				row[col] = v.Format("2006-01-02 15:04:05")
			default:
				row[col] = v
			}
		}
		results = append(results, row)
	}

	if err = rows.Err(); err != nil {
		return nil, fmt.Errorf("error iterating rows: %v", err)
	}

	return results, nil
}

// QueryRow executes a SELECT query returning a single row
func (m *MySQLOperator) QueryRow(query string, args ...interface{}) (map[string]interface{}, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()

	rows, err := m.db.QueryContext(ctx, query, args...)
	if err != nil {
		return nil, fmt.Errorf("query execution failed: %v", err)
	}
	defer rows.Close()

	columns, err := rows.Columns()
	if err != nil {
		return nil, fmt.Errorf("failed to get columns: %v", err)
	}

	if !rows.Next() {
		return nil, nil // No rows found
	}

	values := make([]interface{}, len(columns))
	valuePtrs := make([]interface{}, len(columns))
	for i := range values {
		valuePtrs[i] = &values[i]
	}

	if err := rows.Scan(valuePtrs...); err != nil {
		return nil, fmt.Errorf("failed to scan row: %v", err)
	}

	row := make(map[string]interface{})
	for i, col := range columns {
		val := values[i]
		switch v := val.(type) {
		case []byte:
			row[col] = string(v)
		case time.Time:
			row[col] = v.Format("2006-01-02 15:04:05")
		default:
			row[col] = v
		}
	}

	return row, nil
}

// Exec executes an INSERT, UPDATE, or DELETE query
func (m *MySQLOperator) Exec(query string, args ...interface{}) (int64, int64, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()

	result, err := m.db.ExecContext(ctx, query, args...)
	if err != nil {
		return 0, 0, fmt.Errorf("execution failed: %v", err)
	}

	lastInsertID, err := result.LastInsertId()
	if err != nil {
		return 0, 0, fmt.Errorf("failed to get last insert ID: %v", err)
	}

	rowsAffected, err := result.RowsAffected()
	if err != nil {
		return 0, 0, fmt.Errorf("failed to get rows affected: %v", err)
	}

	return lastInsertID, rowsAffected, nil
}

// Insert executes an INSERT query and returns the last insert ID
func (m *MySQLOperator) Insert(query string, args ...interface{}) (int64, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()

	result, err := m.db.ExecContext(ctx, query, args...)
	if err != nil {
		return 0, fmt.Errorf("insert failed: %v", err)
	}

	lastInsertID, err := result.LastInsertId()
	if err != nil {
		return 0, fmt.Errorf("failed to get last insert ID: %v", err)
	}

	return lastInsertID, nil
}

// Update executes an UPDATE query
func (m *MySQLOperator) Update(query string, args ...interface{}) (int64, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()

	result, err := m.db.ExecContext(ctx, query, args...)
	if err != nil {
		return 0, fmt.Errorf("update failed: %v", err)
	}

	rowsAffected, err := result.RowsAffected()
	if err != nil {
		return 0, fmt.Errorf("failed to get rows affected: %v", err)
	}

	return rowsAffected, nil
}

// Delete executes a DELETE query
func (m *MySQLOperator) Delete(query string, args ...interface{}) (int64, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()

	result, err := m.db.ExecContext(ctx, query, args...)
	if err != nil {
		return 0, fmt.Errorf("delete failed: %v", err)
	}

	rowsAffected, err := result.RowsAffected()
	if err != nil {
		return 0, fmt.Errorf("failed to get rows affected: %v", err)
	}

	return rowsAffected, nil
}

// Transaction executes multiple queries in a transaction
func (m *MySQLOperator) Transaction(queries []string, args [][]interface{}) error {
	ctx, cancel := context.WithTimeout(context.Background(), 60*time.Second)
	defer cancel()

	tx, err := m.db.BeginTx(ctx, nil)
	if err != nil {
		return fmt.Errorf("failed to begin transaction: %v", err)
	}

	for i, query := range queries {
		var queryArgs []interface{}
		if i < len(args) {
			queryArgs = args[i]
		}

		_, err := tx.ExecContext(ctx, query, queryArgs...)
		if err != nil {
			tx.Rollback()
			return fmt.Errorf("query %d failed: %v", i+1, err)
		}
	}

	return tx.Commit()
}

// CreateTable creates a new table
func (m *MySQLOperator) CreateTable(tableName, schema string) error {
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()

	query := fmt.Sprintf("CREATE TABLE IF NOT EXISTS %s (%s)", tableName, schema)
	_, err := m.db.ExecContext(ctx, query)
	if err != nil {
		return fmt.Errorf("create table failed: %v", err)
	}

	return nil
}

// DropTable drops a table
func (m *MySQLOperator) DropTable(tableName string) error {
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()

	query := fmt.Sprintf("DROP TABLE IF EXISTS %s", tableName)
	_, err := m.db.ExecContext(ctx, query)
	if err != nil {
		return fmt.Errorf("drop table failed: %v", err)
	}

	return nil
}

// ListTables lists all tables in the database
func (m *MySQLOperator) ListTables() ([]string, error) {
	query := "SHOW TABLES"

	rows, err := m.Query(query)
	if err != nil {
		return nil, fmt.Errorf("list tables failed: %v", err)
	}

	var tables []string
	for _, row := range rows {
		// MySQL SHOW TABLES returns a single column with table names
		for _, value := range row {
			if tableName, ok := value.(string); ok {
				tables = append(tables, tableName)
			}
		}
	}

	return tables, nil
}

// DescribeTable describes the structure of a table
func (m *MySQLOperator) DescribeTable(tableName string) ([]map[string]interface{}, error) {
	query := fmt.Sprintf("DESCRIBE %s", tableName)

	return m.Query(query)
}

// CreateIndex creates an index on a table
func (m *MySQLOperator) CreateIndex(indexName, tableName, columns string) error {
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()

	query := fmt.Sprintf("CREATE INDEX %s ON %s (%s)", indexName, tableName, columns)
	_, err := m.db.ExecContext(ctx, query)
	if err != nil {
		return fmt.Errorf("create index failed: %v", err)
	}

	return nil
}

// DropIndex drops an index
func (m *MySQLOperator) DropIndex(indexName, tableName string) error {
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()

	query := fmt.Sprintf("DROP INDEX %s ON %s", indexName, tableName)
	_, err := m.db.ExecContext(ctx, query)
	if err != nil {
		return fmt.Errorf("drop index failed: %v", err)
	}

	return nil
}

// Close closes the MySQL connection
func (m *MySQLOperator) Close() error {
	return m.db.Close()
} 