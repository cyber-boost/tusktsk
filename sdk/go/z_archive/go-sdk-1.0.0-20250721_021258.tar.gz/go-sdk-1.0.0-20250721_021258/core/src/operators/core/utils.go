package core

// splitParams splits parameters by comma, respecting quotes
func splitParams(params string) []string {
	var result []string
	var current string
	var inQuotes bool
	var quoteChar byte
	
	for i := 0; i < len(params); i++ {
		char := params[i]
		
		if (char == '"' || char == '\'') && !inQuotes {
			inQuotes = true
			quoteChar = char
			continue
		}
		
		if char == quoteChar && inQuotes {
			inQuotes = false
			continue
		}
		
		if char == ',' && !inQuotes {
			result = append(result, current)
			current = ""
			continue
		}
		
		current += string(char)
	}
	
	if current != "" {
		result = append(result, current)
	}
	
	return result
} 