package core

import (
	"database/sql"
	"fmt"
	"strings"
)

// QueryOperator handles @query operations
type QueryOperator struct {
	db *sql.DB
}

// NewQueryOperator creates a new query operator
func NewQueryOperator() *QueryOperator {
	return &QueryOperator{}
}

// SetDatabase sets the database connection
func (q *QueryOperator) SetDatabase(db *sql.DB) {
	q.db = db
}

// Execute handles @query operations
func (q *QueryOperator) Execute(params string) interface{} {
	// Parse parameters (format: "sql_query")
	// Example: @query("SELECT * FROM users WHERE id = 1")
	
	if params == "" {
		return fmt.Sprintf("@query(%s)", params)
	}
	
	// Remove quotes if present
	query := params
	if len(query) >= 2 && (query[0] == '"' || query[0] == '\'') {
		query = query[1 : len(query)-1]
	}
	
	if q.db == nil {
		return fmt.Sprintf("@query(%s) - No database connection", query)
	}
	
	result, err := q.ExecuteQuery(query)
	if err != nil {
		return fmt.Sprintf("@query(%s) - Error: %v", query, err)
	}
	
	return result
}

// ExecuteQuery executes a SQL query and returns results
func (q *QueryOperator) ExecuteQuery(query string) (interface{}, error) {
	if q.db == nil {
		return nil, fmt.Errorf("no database connection")
	}
	
	query = strings.TrimSpace(query)
	queryUpper := strings.ToUpper(query)
	
	// Determine if it's a SELECT query
	if strings.HasPrefix(queryUpper, "SELECT") {
		return q.executeSelect(query)
	}
	
	// For non-SELECT queries (INSERT, UPDATE, DELETE)
	return q.executeNonSelect(query)
}

// executeSelect executes a SELECT query
func (q *QueryOperator) executeSelect(query string) (interface{}, error) {
	rows, err := q.db.Query(query)
	if err != nil {
		return nil, fmt.Errorf("query execution failed: %v", err)
	}
	defer rows.Close()
	
	columns, err := rows.Columns()
	if err != nil {
		return nil, fmt.Errorf("failed to get columns: %v", err)
	}
	
	var results []map[string]interface{}
	
	for rows.Next() {
		// Create a slice of interface{} to hold the values
		values := make([]interface{}, len(columns))
		valuePtrs := make([]interface{}, len(columns))
		for i := range values {
			valuePtrs[i] = &values[i]
		}
		
		// Scan the result into the value pointers
		if err := rows.Scan(valuePtrs...); err != nil {
			return nil, fmt.Errorf("failed to scan row: %v", err)
		}
		
		// Create a map for this row
		row := make(map[string]interface{})
		for i, col := range columns {
			val := values[i]
			row[col] = val
		}
		
		results = append(results, row)
	}
	
	if err = rows.Err(); err != nil {
		return nil, fmt.Errorf("error iterating rows: %v", err)
	}
	
	return results, nil
}

// executeNonSelect executes non-SELECT queries
func (q *QueryOperator) executeNonSelect(query string) (interface{}, error) {
	result, err := q.db.Exec(query)
	if err != nil {
		return nil, fmt.Errorf("query execution failed: %v", err)
	}
	
	lastInsertID, _ := result.LastInsertId()
	rowsAffected, _ := result.RowsAffected()
	
	return map[string]interface{}{
		"last_insert_id": lastInsertID,
		"rows_affected":  rowsAffected,
		"success":        true,
	}, nil
}

// ExecuteWithParams executes a query with parameters
func (q *QueryOperator) ExecuteWithParams(query string, params ...interface{}) (interface{}, error) {
	if q.db == nil {
		return nil, fmt.Errorf("no database connection")
	}
	
	query = strings.TrimSpace(query)
	queryUpper := strings.ToUpper(query)
	
	if strings.HasPrefix(queryUpper, "SELECT") {
		return q.executeSelectWithParams(query, params...)
	}
	
	return q.executeNonSelectWithParams(query, params...)
}

// executeSelectWithParams executes a SELECT query with parameters
func (q *QueryOperator) executeSelectWithParams(query string, params ...interface{}) (interface{}, error) {
	rows, err := q.db.Query(query, params...)
	if err != nil {
		return nil, fmt.Errorf("query execution failed: %v", err)
	}
	defer rows.Close()
	
	columns, err := rows.Columns()
	if err != nil {
		return nil, fmt.Errorf("failed to get columns: %v", err)
	}
	
	var results []map[string]interface{}
	
	for rows.Next() {
		values := make([]interface{}, len(columns))
		valuePtrs := make([]interface{}, len(columns))
		for i := range values {
			valuePtrs[i] = &values[i]
		}
		
		if err := rows.Scan(valuePtrs...); err != nil {
			return nil, fmt.Errorf("failed to scan row: %v", err)
		}
		
		row := make(map[string]interface{})
		for i, col := range columns {
			val := values[i]
			row[col] = val
		}
		
		results = append(results, row)
	}
	
	if err = rows.Err(); err != nil {
		return nil, fmt.Errorf("error iterating rows: %v", err)
	}
	
	return results, nil
}

// executeNonSelectWithParams executes non-SELECT queries with parameters
func (q *QueryOperator) executeNonSelectWithParams(query string, params ...interface{}) (interface{}, error) {
	result, err := q.db.Exec(query, params...)
	if err != nil {
		return nil, fmt.Errorf("query execution failed: %v", err)
	}
	
	lastInsertID, _ := result.LastInsertId()
	rowsAffected, _ := result.RowsAffected()
	
	return map[string]interface{}{
		"last_insert_id": lastInsertID,
		"rows_affected":  rowsAffected,
		"success":        true,
	}, nil
}

// GetSingleRow executes a query and returns a single row
func (q *QueryOperator) GetSingleRow(query string, params ...interface{}) (map[string]interface{}, error) {
	if q.db == nil {
		return nil, fmt.Errorf("no database connection")
	}
	
	row := q.db.QueryRow(query, params...)
	
	columns, err := q.getColumnsFromQuery(query)
	if err != nil {
		return nil, fmt.Errorf("failed to get columns: %v", err)
	}
	
	values := make([]interface{}, len(columns))
	valuePtrs := make([]interface{}, len(columns))
	for i := range values {
		valuePtrs[i] = &values[i]
	}
	
	if err := row.Scan(valuePtrs...); err != nil {
		return nil, fmt.Errorf("failed to scan row: %v", err)
	}
	
	result := make(map[string]interface{})
	for i, col := range columns {
		result[col] = values[i]
	}
	
	return result, nil
}

// getColumnsFromQuery extracts column names from a SELECT query
func (q *QueryOperator) getColumnsFromQuery(query string) ([]string, error) {
	// This is a simplified implementation
	// In a real implementation, you might want to parse the SQL properly
	
	// For now, we'll execute the query once to get columns
	rows, err := q.db.Query(query)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	
	return rows.Columns()
}

// Close closes the database connection
func (q *QueryOperator) Close() error {
	if q.db != nil {
		return q.db.Close()
	}
	return nil
} 