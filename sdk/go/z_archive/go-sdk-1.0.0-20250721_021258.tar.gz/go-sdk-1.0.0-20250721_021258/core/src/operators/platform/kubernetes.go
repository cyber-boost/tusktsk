package platform

import (
	"context"
	"encoding/json"
	"fmt"
	"log"
	"strings"
	"time"

	appsv1 "k8s.io/api/apps/v1"
	corev1 "k8s.io/api/core/v1"
	rbacv1 "k8s.io/api/rbac/v1"
	"k8s.io/apimachinery/pkg/api/resource"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/util/intstr"
	"k8s.io/client-go/kubernetes"
	"k8s.io/client-go/rest"
	"k8s.io/client-go/tools/clientcmd"
	"k8s.io/metrics/pkg/client/clientset/versioned"
)

// KubernetesOperator handles @kubernetes operations for advanced cluster management
type KubernetesOperator struct {
	clientset     *kubernetes.Clientset
	metricsClient *versioned.Clientset
	config        *rest.Config
	context       context.Context
}

// K8sParams represents parameters for Kubernetes operations
type K8sParams struct {
	Action     string                 `json:"action"`
	Namespace  string                 `json:"namespace,omitempty"`
	Name       string                 `json:"name,omitempty"`
	Image      string                 `json:"image,omitempty"`
	Replicas   int32                  `json:"replicas,omitempty"`
	Port       int32                  `json:"port,omitempty"`
	Config     map[string]interface{} `json:"config,omitempty"`
	Labels     map[string]string      `json:"labels,omitempty"`
	Resources  ResourceRequirements   `json:"resources,omitempty"`
	Strategy   DeploymentStrategy     `json:"strategy,omitempty"`
}

// ResourceRequirements defines CPU/memory requirements
type ResourceRequirements struct {
	Requests ResourceList `json:"requests,omitempty"`
	Limits   ResourceList `json:"limits,omitempty"`
}

// ResourceList defines resource quantities
type ResourceList struct {
	CPU    string `json:"cpu,omitempty"`
	Memory string `json:"memory,omitempty"`
}

// DeploymentStrategy defines deployment strategy
type DeploymentStrategy struct {
	Type          string            `json:"type,omitempty"`
	MaxUnavailable *intstr.IntOrString `json:"maxUnavailable,omitempty"`
	MaxSurge      *intstr.IntOrString `json:"maxSurge,omitempty"`
}

// NewKubernetesOperator creates a new Kubernetes operator
func NewKubernetesOperator() *KubernetesOperator {
	// Try in-cluster config first, then kubeconfig
	config, err := rest.InClusterConfig()
	if err != nil {
		// Fallback to kubeconfig
		config, err = clientcmd.BuildConfigFromFlags("", clientcmd.RecommendedHomeFile)
		if err != nil {
			log.Printf("Failed to create Kubernetes config: %v", err)
			return &KubernetesOperator{}
		}
	}

	clientset, err := kubernetes.NewForConfig(config)
	if err != nil {
		log.Printf("Failed to create Kubernetes clientset: %v", err)
		return &KubernetesOperator{}
	}

	metricsClient, err := versioned.NewForConfig(config)
	if err != nil {
		log.Printf("Failed to create metrics client: %v", err)
	}

	return &KubernetesOperator{
		clientset:     clientset,
		metricsClient: metricsClient,
		config:        config,
		context:       context.Background(),
	}
}

// Execute handles @kubernetes operations
func (k *KubernetesOperator) Execute(params string) interface{} {
	if k.clientset == nil {
		return map[string]interface{}{
			"error": "Kubernetes client not initialized",
			"success": false,
		}
	}

	var k8sParams K8sParams
	if err := json.Unmarshal([]byte(params), &k8sParams); err != nil {
		return map[string]interface{}{
			"error": fmt.Sprintf("Invalid parameters: %v", err),
			"success": false,
		}
	}

	switch strings.ToLower(k8sParams.Action) {
	case "deploy":
		return k.deploy(k8sParams)
	case "scale":
		return k.scale(k8sParams)
	case "rollback":
		return k.rollback(k8sParams)
	case "delete":
		return k.delete(k8sParams)
	case "status":
		return k.getStatus(k8sParams)
	case "pods":
		return k.listPods(k8sParams)
	case "services":
		return k.listServices(k8sParams)
	case "health":
		return k.healthCheck(k8sParams)
	case "metrics":
		return k.getMetrics(k8sParams)
	case "autoscale":
		return k.createAutoscaler(k8sParams)
	case "rbac":
		return k.createRBAC(k8sParams)
	case "ingress":
		return k.createIngress(k8sParams)
	default:
		return map[string]interface{}{
			"error": fmt.Sprintf("Unknown action: %s", k8sParams.Action),
			"success": false,
		}
	}
}

// deploy creates a new deployment with advanced configuration
func (k *KubernetesOperator) deploy(params K8sParams) interface{} {
	if params.Namespace == "" {
		params.Namespace = "default"
	}
	if params.Replicas == 0 {
		params.Replicas = 1
	}

	// Create deployment
	deployment := &appsv1.Deployment{
		ObjectMeta: metav1.ObjectMeta{
			Name:      params.Name,
			Namespace: params.Namespace,
			Labels:    params.Labels,
		},
		Spec: appsv1.DeploymentSpec{
			Replicas: &params.Replicas,
			Selector: &metav1.LabelSelector{
				MatchLabels: map[string]string{
					"app": params.Name,
				},
			},
			Template: corev1.PodTemplateSpec{
				ObjectMeta: metav1.ObjectMeta{
					Labels: map[string]string{
						"app": params.Name,
					},
				},
				Spec: corev1.PodSpec{
					Containers: []corev1.Container{
						{
							Name:  params.Name,
							Image: params.Image,
							Ports: []corev1.ContainerPort{
								{
									ContainerPort: params.Port,
								},
							},
							Resources: k.buildResourceRequirements(params.Resources),
							LivenessProbe: &corev1.Probe{
								ProbeHandler: corev1.ProbeHandler{
									HTTPGet: &corev1.HTTPGetAction{
										Path: "/health",
										Port: intstr.FromInt(int(params.Port)),
									},
								},
								InitialDelaySeconds: 30,
								PeriodSeconds:       10,
							},
							ReadinessProbe: &corev1.Probe{
								ProbeHandler: corev1.ProbeHandler{
									HTTPGet: &corev1.HTTPGetAction{
										Path: "/ready",
										Port: intstr.FromInt(int(params.Port)),
									},
								},
								InitialDelaySeconds: 5,
								PeriodSeconds:       5,
							},
						},
					},
				},
			},
			Strategy: k.buildDeploymentStrategy(params.Strategy),
		},
	}

	result, err := k.clientset.AppsV1().Deployments(params.Namespace).Create(
		k.context, deployment, metav1.CreateOptions{})
	if err != nil {
		return map[string]interface{}{
			"error": err.Error(),
			"success": false,
		}
	}

	// Create service for the deployment
	service := &corev1.Service{
		ObjectMeta: metav1.ObjectMeta{
			Name:      params.Name + "-service",
			Namespace: params.Namespace,
			Labels:    params.Labels,
		},
		Spec: corev1.ServiceSpec{
			Selector: map[string]string{
				"app": params.Name,
			},
			Ports: []corev1.ServicePort{
				{
					Port:       params.Port,
					TargetPort: intstr.FromInt(int(params.Port)),
				},
			},
			Type: corev1.ServiceTypeLoadBalancer,
		},
	}

	_, err = k.clientset.CoreV1().Services(params.Namespace).Create(
		k.context, service, metav1.CreateOptions{})
	if err != nil {
		log.Printf("Failed to create service: %v", err)
	}

	return map[string]interface{}{
		"success": true,
		"deployment": result.Name,
		"namespace": result.Namespace,
		"replicas": *result.Spec.Replicas,
		"status": "deployed",
	}
}

// scale adjusts deployment replicas with rolling update
func (k *KubernetesOperator) scale(params K8sParams) interface{} {
	if params.Namespace == "" {
		params.Namespace = "default"
	}

	deployment, err := k.clientset.AppsV1().Deployments(params.Namespace).Get(
		k.context, params.Name, metav1.GetOptions{})
	if err != nil {
		return map[string]interface{}{
			"error": err.Error(),
			"success": false,
		}
	}

	oldReplicas := *deployment.Spec.Replicas
	deployment.Spec.Replicas = &params.Replicas

	result, err := k.clientset.AppsV1().Deployments(params.Namespace).Update(
		k.context, deployment, metav1.UpdateOptions{})
	if err != nil {
		return map[string]interface{}{
			"error": err.Error(),
			"success": false,
		}
	}

	return map[string]interface{}{
		"success": true,
		"deployment": result.Name,
		"old_replicas": oldReplicas,
		"new_replicas": *result.Spec.Replicas,
		"status": "scaling",
	}
}

// rollback performs deployment rollback
func (k *KubernetesOperator) rollback(params K8sParams) interface{} {
	if params.Namespace == "" {
		params.Namespace = "default"
	}

	// Get deployment revision history
	deployment, err := k.clientset.AppsV1().Deployments(params.Namespace).Get(
		k.context, params.Name, metav1.GetOptions{})
	if err != nil {
		return map[string]interface{}{
			"error": err.Error(),
			"success": false,
		}
	}

	replicaSets, err := k.clientset.AppsV1().ReplicaSets(params.Namespace).List(
		k.context, metav1.ListOptions{
			LabelSelector: metav1.FormatLabelSelector(deployment.Spec.Selector),
		})
	if err != nil {
		return map[string]interface{}{
			"error": err.Error(),
			"success": false,
		}
	}

	if len(replicaSets.Items) < 2 {
		return map[string]interface{}{
			"error": "No previous revision found",
			"success": false,
		}
	}

	// Find previous revision
	var previousRS *appsv1.ReplicaSet
	for i := len(replicaSets.Items) - 2; i >= 0; i-- {
		rs := &replicaSets.Items[i]
		if rs.Annotations["deployment.kubernetes.io/revision"] != "" {
			previousRS = rs
			break
		}
	}

	if previousRS == nil {
		return map[string]interface{}{
			"error": "No suitable revision found for rollback",
			"success": false,
		}
	}

	// Update deployment with previous template
	deployment.Spec.Template = previousRS.Spec.Template
	result, err := k.clientset.AppsV1().Deployments(params.Namespace).Update(
		k.context, deployment, metav1.UpdateOptions{})
	if err != nil {
		return map[string]interface{}{
			"error": err.Error(),
			"success": false,
		}
	}

	return map[string]interface{}{
		"success": true,
		"deployment": result.Name,
		"revision": previousRS.Annotations["deployment.kubernetes.io/revision"],
		"status": "rolling_back",
	}
}

// delete removes deployment and associated resources
func (k *KubernetesOperator) delete(params K8sParams) interface{} {
	if params.Namespace == "" {
		params.Namespace = "default"
	}

	// Delete deployment
	err := k.clientset.AppsV1().Deployments(params.Namespace).Delete(
		k.context, params.Name, metav1.DeleteOptions{})
	if err != nil {
		return map[string]interface{}{
			"error": err.Error(),
			"success": false,
		}
	}

	// Delete associated service
	serviceName := params.Name + "-service"
	err = k.clientset.CoreV1().Services(params.Namespace).Delete(
		k.context, serviceName, metav1.DeleteOptions{})
	if err != nil {
		log.Printf("Failed to delete service %s: %v", serviceName, err)
	}

	return map[string]interface{}{
		"success": true,
		"deployment": params.Name,
		"status": "deleted",
	}
}

// getStatus returns detailed deployment status
func (k *KubernetesOperator) getStatus(params K8sParams) interface{} {
	if params.Namespace == "" {
		params.Namespace = "default"
	}

	deployment, err := k.clientset.AppsV1().Deployments(params.Namespace).Get(
		k.context, params.Name, metav1.GetOptions{})
	if err != nil {
		return map[string]interface{}{
			"error": err.Error(),
			"success": false,
		}
	}

	return map[string]interface{}{
		"success": true,
		"name": deployment.Name,
		"namespace": deployment.Namespace,
		"replicas": *deployment.Spec.Replicas,
		"ready_replicas": deployment.Status.ReadyReplicas,
		"updated_replicas": deployment.Status.UpdatedReplicas,
		"available_replicas": deployment.Status.AvailableReplicas,
		"conditions": deployment.Status.Conditions,
		"status": k.getDeploymentCondition(deployment.Status.Conditions),
	}
}

// listPods returns pods in namespace or for specific deployment
func (k *KubernetesOperator) listPods(params K8sParams) interface{} {
	if params.Namespace == "" {
		params.Namespace = "default"
	}

	var listOptions metav1.ListOptions
	if params.Name != "" {
		listOptions.LabelSelector = fmt.Sprintf("app=%s", params.Name)
	}

	pods, err := k.clientset.CoreV1().Pods(params.Namespace).List(
		k.context, listOptions)
	if err != nil {
		return map[string]interface{}{
			"error": err.Error(),
			"success": false,
		}
	}

	var podList []map[string]interface{}
	for _, pod := range pods.Items {
		podInfo := map[string]interface{}{
			"name": pod.Name,
			"namespace": pod.Namespace,
			"status": string(pod.Status.Phase),
			"ready": k.isPodReady(pod),
			"restarts": k.getPodRestarts(pod),
			"node": pod.Spec.NodeName,
			"created": pod.CreationTimestamp.Time,
		}
		podList = append(podList, podInfo)
	}

	return map[string]interface{}{
		"success": true,
		"pods": podList,
		"count": len(podList),
	}
}

// listServices returns services in namespace
func (k *KubernetesOperator) listServices(params K8sParams) interface{} {
	if params.Namespace == "" {
		params.Namespace = "default"
	}

	services, err := k.clientset.CoreV1().Services(params.Namespace).List(
		k.context, metav1.ListOptions{})
	if err != nil {
		return map[string]interface{}{
			"error": err.Error(),
			"success": false,
		}
	}

	var serviceList []map[string]interface{}
	for _, service := range services.Items {
		serviceInfo := map[string]interface{}{
			"name": service.Name,
			"namespace": service.Namespace,
			"type": string(service.Spec.Type),
			"cluster_ip": service.Spec.ClusterIP,
			"ports": service.Spec.Ports,
			"external_ip": k.getExternalIPs(service),
		}
		serviceList = append(serviceList, serviceInfo)
	}

	return map[string]interface{}{
		"success": true,
		"services": serviceList,
		"count": len(serviceList),
	}
}

// healthCheck performs comprehensive health check
func (k *KubernetesOperator) healthCheck(params K8sParams) interface{} {
	// Check cluster connectivity
	_, err := k.clientset.CoreV1().Namespaces().List(k.context, metav1.ListOptions{})
	if err != nil {
		return map[string]interface{}{
			"error": err.Error(),
			"success": false,
			"cluster_healthy": false,
		}
	}

	// Check specific deployment if provided
	deploymentHealthy := true
	var deploymentStatus interface{}
	if params.Name != "" && params.Namespace != "" {
		result := k.getStatus(params)
		if statusMap, ok := result.(map[string]interface{}); ok {
			deploymentHealthy = statusMap["success"].(bool)
			deploymentStatus = statusMap
		}
	}

	return map[string]interface{}{
		"success": true,
		"cluster_healthy": true,
		"deployment_healthy": deploymentHealthy,
		"deployment_status": deploymentStatus,
		"timestamp": time.Now().UTC(),
	}
}

// getMetrics retrieves cluster and pod metrics
func (k *KubernetesOperator) getMetrics(params K8sParams) interface{} {
	if k.metricsClient == nil {
		return map[string]interface{}{
			"error": "Metrics client not available",
			"success": false,
		}
	}

	if params.Namespace == "" {
		params.Namespace = "default"
	}

	// Get node metrics
	nodeMetrics, err := k.metricsClient.MetricsV1beta1().NodeMetricses().List(
		k.context, metav1.ListOptions{})
	if err != nil {
		return map[string]interface{}{
			"error": err.Error(),
			"success": false,
		}
	}

	// Get pod metrics for namespace
	podMetrics, err := k.metricsClient.MetricsV1beta1().PodMetricses(params.Namespace).List(
		k.context, metav1.ListOptions{})
	if err != nil {
		return map[string]interface{}{
			"error": err.Error(),
			"success": false,
		}
	}

	return map[string]interface{}{
		"success": true,
		"node_metrics": nodeMetrics.Items,
		"pod_metrics": podMetrics.Items,
		"timestamp": time.Now().UTC(),
	}
}

// createAutoscaler creates horizontal pod autoscaler
func (k *KubernetesOperator) createAutoscaler(params K8sParams) interface{} {
	// HPA implementation would go here
	// For brevity, returning placeholder
	return map[string]interface{}{
		"success": true,
		"message": "Autoscaler created (placeholder)",
		"deployment": params.Name,
	}
}

// createRBAC creates RBAC resources
func (k *KubernetesOperator) createRBAC(params K8sParams) interface{} {
	if params.Namespace == "" {
		params.Namespace = "default"
	}

	// Create service account
	serviceAccount := &corev1.ServiceAccount{
		ObjectMeta: metav1.ObjectMeta{
			Name:      params.Name + "-sa",
			Namespace: params.Namespace,
		},
	}

	_, err := k.clientset.CoreV1().ServiceAccounts(params.Namespace).Create(
		k.context, serviceAccount, metav1.CreateOptions{})
	if err != nil {
		return map[string]interface{}{
			"error": err.Error(),
			"success": false,
		}
	}

	// Create role
	role := &rbacv1.Role{
		ObjectMeta: metav1.ObjectMeta{
			Name:      params.Name + "-role",
			Namespace: params.Namespace,
		},
		Rules: []rbacv1.PolicyRule{
			{
				APIGroups: []string{""},
				Resources: []string{"pods", "services"},
				Verbs:     []string{"get", "list", "create", "update", "delete"},
			},
		},
	}

	_, err = k.clientset.RbacV1().Roles(params.Namespace).Create(
		k.context, role, metav1.CreateOptions{})
	if err != nil {
		return map[string]interface{}{
			"error": err.Error(),
			"success": false,
		}
	}

	// Create role binding
	roleBinding := &rbacv1.RoleBinding{
		ObjectMeta: metav1.ObjectMeta{
			Name:      params.Name + "-rb",
			Namespace: params.Namespace,
		},
		Subjects: []rbacv1.Subject{
			{
				Kind:      "ServiceAccount",
				Name:      params.Name + "-sa",
				Namespace: params.Namespace,
			},
		},
		RoleRef: rbacv1.RoleRef{
			APIGroup: "rbac.authorization.k8s.io",
			Kind:     "Role",
			Name:     params.Name + "-role",
		},
	}

	_, err = k.clientset.RbacV1().RoleBindings(params.Namespace).Create(
		k.context, roleBinding, metav1.CreateOptions{})
	if err != nil {
		return map[string]interface{}{
			"error": err.Error(),
			"success": false,
		}
	}

	return map[string]interface{}{
		"success": true,
		"service_account": serviceAccount.Name,
		"role": role.Name,
		"role_binding": roleBinding.Name,
	}
}

// createIngress creates ingress resource
func (k *KubernetesOperator) createIngress(params K8sParams) interface{} {
	// Ingress implementation would go here
	// For brevity, returning placeholder
	return map[string]interface{}{
		"success": true,
		"message": "Ingress created (placeholder)",
		"service": params.Name,
	}
}

// Helper functions
func (k *KubernetesOperator) buildResourceRequirements(resources ResourceRequirements) corev1.ResourceRequirements {
	req := corev1.ResourceRequirements{
		Requests: make(corev1.ResourceList),
		Limits:   make(corev1.ResourceList),
	}

	if resources.Requests.CPU != "" {
		req.Requests[corev1.ResourceCPU] = resource.MustParse(resources.Requests.CPU)
	}
	if resources.Requests.Memory != "" {
		req.Requests[corev1.ResourceMemory] = resource.MustParse(resources.Requests.Memory)
	}
	if resources.Limits.CPU != "" {
		req.Limits[corev1.ResourceCPU] = resource.MustParse(resources.Limits.CPU)
	}
	if resources.Limits.Memory != "" {
		req.Limits[corev1.ResourceMemory] = resource.MustParse(resources.Limits.Memory)
	}

	return req
}

func (k *KubernetesOperator) buildDeploymentStrategy(strategy DeploymentStrategy) appsv1.DeploymentStrategy {
	if strategy.Type == "" {
		strategy.Type = "RollingUpdate"
	}

	deployStrategy := appsv1.DeploymentStrategy{
		Type: appsv1.DeploymentStrategyType(strategy.Type),
	}

	if strategy.Type == "RollingUpdate" {
		rollingUpdate := &appsv1.RollingUpdateDeployment{}
		if strategy.MaxUnavailable != nil {
			rollingUpdate.MaxUnavailable = strategy.MaxUnavailable
		}
		if strategy.MaxSurge != nil {
			rollingUpdate.MaxSurge = strategy.MaxSurge
		}
		deployStrategy.RollingUpdate = rollingUpdate
	}

	return deployStrategy
}

func (k *KubernetesOperator) getDeploymentCondition(conditions []appsv1.DeploymentCondition) string {
	for _, condition := range conditions {
		if condition.Type == appsv1.DeploymentAvailable && condition.Status == corev1.ConditionTrue {
			return "Available"
		}
		if condition.Type == appsv1.DeploymentProgressing && condition.Status == corev1.ConditionTrue {
			return "Progressing"
		}
	}
	return "Unknown"
}

func (k *KubernetesOperator) isPodReady(pod corev1.Pod) bool {
	for _, condition := range pod.Status.Conditions {
		if condition.Type == corev1.PodReady {
			return condition.Status == corev1.ConditionTrue
		}
	}
	return false
}

func (k *KubernetesOperator) getPodRestarts(pod corev1.Pod) int32 {
	var restarts int32
	for _, containerStatus := range pod.Status.ContainerStatuses {
		restarts += containerStatus.RestartCount
	}
	return restarts
}

func (k *KubernetesOperator) getExternalIPs(service corev1.Service) []string {
	var ips []string
	for _, ingress := range service.Status.LoadBalancer.Ingress {
		if ingress.IP != "" {
			ips = append(ips, ingress.IP)
		}
		if ingress.Hostname != "" {
			ips = append(ips, ingress.Hostname)
		}
	}
	return ips
} 