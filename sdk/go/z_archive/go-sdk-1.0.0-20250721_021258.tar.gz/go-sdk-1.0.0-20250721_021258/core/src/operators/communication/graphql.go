package communication

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"time"
)

// GraphQLOperator handles @graphql operations
type GraphQLOperator struct {
	client  *http.Client
	baseURL string
	headers map[string]string
}

// GraphQLRequest represents a GraphQL request
type GraphQLRequest struct {
	Query         string                 `json:"query"`
	Variables     map[string]interface{} `json:"variables,omitempty"`
	OperationName string                 `json:"operationName,omitempty"`
}

// GraphQLResponse represents a GraphQL response
type GraphQLResponse struct {
	Data   interface{}            `json:"data"`
	Errors []GraphQLError         `json:"errors,omitempty"`
	Extensions map[string]interface{} `json:"extensions,omitempty"`
}

// GraphQLError represents a GraphQL error
type GraphQLError struct {
	Message    string                 `json:"message"`
	Locations  []GraphQLLocation      `json:"locations,omitempty"`
	Path       []interface{}          `json:"path,omitempty"`
	Extensions map[string]interface{} `json:"extensions,omitempty"`
}

// GraphQLLocation represents a GraphQL error location
type GraphQLLocation struct {
	Line   int `json:"line"`
	Column int `json:"column"`
}

// NewGraphQLOperator creates a new GraphQL operator
func NewGraphQLOperator(baseURL string) *GraphQLOperator {
	return &GraphQLOperator{
		client: &http.Client{
			Timeout: 30 * time.Second,
		},
		baseURL: baseURL,
		headers: map[string]string{
			"Content-Type": "application/json",
		},
	}
}

// Execute handles @graphql operations
func (g *GraphQLOperator) Execute(params string) interface{} {
	// Parse parameters (format: "query", "variables", "operationName")
	// Example: @graphql("query { users { id name } }", "{}", "")
	
	return fmt.Sprintf("@graphql(%s)", params)
}

// Query executes a GraphQL query
func (g *GraphQLOperator) Query(query string, variables map[string]interface{}, operationName string) (*GraphQLResponse, error) {
	request := GraphQLRequest{
		Query:         query,
		Variables:     variables,
		OperationName: operationName,
	}

	return g.executeRequest(request)
}

// Mutation executes a GraphQL mutation
func (g *GraphQLOperator) Mutation(mutation string, variables map[string]interface{}, operationName string) (*GraphQLResponse, error) {
	request := GraphQLRequest{
		Query:         mutation,
		Variables:     variables,
		OperationName: operationName,
	}

	return g.executeRequest(request)
}

// Subscription executes a GraphQL subscription (placeholder for WebSocket implementation)
func (g *GraphQLOperator) Subscription(subscription string, variables map[string]interface{}, operationName string) (*GraphQLResponse, error) {
	// This would typically use WebSocket connection
	// For now, return a placeholder response
	return &GraphQLResponse{
		Data: map[string]interface{}{
			"subscription": "WebSocket subscription not implemented yet",
		},
	}, nil
}

// SetHeader sets a custom header for GraphQL requests
func (g *GraphQLOperator) SetHeader(key, value string) {
	g.headers[key] = value
}

// SetAuthToken sets the Authorization header with a Bearer token
func (g *GraphQLOperator) SetAuthToken(token string) {
	g.headers["Authorization"] = "Bearer " + token
}

// SetAPIKey sets the X-API-Key header
func (g *GraphQLOperator) SetAPIKey(key string) {
	g.headers["X-API-Key"] = key
}

// executeRequest executes a GraphQL request
func (g *GraphQLOperator) executeRequest(request GraphQLRequest) (*GraphQLResponse, error) {
	// Marshal request to JSON
	requestBody, err := json.Marshal(request)
	if err != nil {
		return nil, fmt.Errorf("failed to marshal GraphQL request: %v", err)
	}

	// Create HTTP request
	req, err := http.NewRequest("POST", g.baseURL, bytes.NewBuffer(requestBody))
	if err != nil {
		return nil, fmt.Errorf("failed to create HTTP request: %v", err)
	}

	// Set headers
	for key, value := range g.headers {
		req.Header.Set(key, value)
	}

	// Execute request
	resp, err := g.client.Do(req)
	if err != nil {
		return nil, fmt.Errorf("failed to execute GraphQL request: %v", err)
	}
	defer resp.Body.Close()

	// Read response body
	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, fmt.Errorf("failed to read response body: %v", err)
	}

	// Check HTTP status
	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("GraphQL request failed with status %d: %s", resp.StatusCode, string(body))
	}

	// Parse response
	var response GraphQLResponse
	if err := json.Unmarshal(body, &response); err != nil {
		return nil, fmt.Errorf("failed to unmarshal GraphQL response: %v", err)
	}

	// Check for GraphQL errors
	if len(response.Errors) > 0 {
		return &response, fmt.Errorf("GraphQL errors: %v", response.Errors)
	}

	return &response, nil
}

// Introspect performs GraphQL introspection query
func (g *GraphQLOperator) Introspect() (*GraphQLResponse, error) {
	introspectionQuery := `
		query IntrospectionQuery {
			__schema {
				queryType { name }
				mutationType { name }
				subscriptionType { name }
				types {
					...FullType
				}
				directives {
					name
					description
					locations
					args {
						...InputValue
					}
				}
			}
		}

		fragment FullType on __Type {
			kind
			name
			description
			fields(includeDeprecated: true) {
				name
				description
				args {
					...InputValue
				}
				type {
					...TypeRef
				}
				isDeprecated
				deprecationReason
			}
			inputFields {
				...InputValue
			}
			interfaces {
				...TypeRef
			}
			enumValues(includeDeprecated: true) {
				name
				description
				isDeprecated
				deprecationReason
			}
			possibleTypes {
				...TypeRef
			}
		}

		fragment InputValue on __InputValue {
			name
			description
			type { ...TypeRef }
			defaultValue
		}

		fragment TypeRef on __Type {
			kind
			name
			ofType {
				kind
				name
				ofType {
					kind
					name
					ofType {
						kind
						name
						ofType {
							kind
							name
							ofType {
								kind
								name
								ofType {
									kind
									name
									ofType {
										kind
										name
									}
								}
							}
						}
					}
				}
			}
		}
	`

	return g.Query(introspectionQuery, nil, "IntrospectionQuery")
}

// ValidateQuery validates a GraphQL query syntax
func (g *GraphQLOperator) ValidateQuery(query string) (*GraphQLResponse, error) {
	validationQuery := `
		query ValidateQuery($query: String!) {
			__validateQuery(query: $query) {
				valid
				errors {
					message
					locations {
						line
						column
					}
				}
			}
		}
	`

	variables := map[string]interface{}{
		"query": query,
	}

	return g.Query(validationQuery, variables, "ValidateQuery")
}

// Close closes the GraphQL operator (no cleanup needed for HTTP client)
func (g *GraphQLOperator) Close() error {
	return nil
} 