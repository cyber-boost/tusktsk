package core

import (
	"bytes"
	"context"
	"crypto/tls"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strings"
	"time"
)

// RequestConfig holds HTTP request configuration
type RequestConfig struct {
	Method      string            `json:"method"`
	URL         string            `json:"url"`
	Headers     map[string]string `json:"headers"`
	Body        interface{}       `json:"body"`
	Timeout     time.Duration     `json:"timeout"`
	FollowRedirects bool          `json:"follow_redirects"`
	VerifySSL   bool              `json:"verify_ssl"`
}

// RequestResponse holds HTTP response data
type RequestResponse struct {
	StatusCode  int               `json:"status_code"`
	Headers     map[string]string `json:"headers"`
	Body        string            `json:"body"`
	Error       string            `json:"error,omitempty"`
	Duration    time.Duration     `json:"duration"`
	URL         string            `json:"url"`
}

// RequestOperator handles @request operations
type RequestOperator struct {
	client *http.Client
}

// NewRequestOperator creates a new request operator
func NewRequestOperator() *RequestOperator {
	return &RequestOperator{
		client: &http.Client{
			Timeout: 30 * time.Second,
			Transport: &http.Transport{
				TLSClientConfig: &tls.Config{
					InsecureSkipVerify: false,
				},
			},
		},
	}
}

// Execute handles @request operations
func (r *RequestOperator) Execute(params string) interface{} {
	// Parse parameters (format: "method", "url", "headers", "body")
	// Example: @request("GET", "https://api.example.com/data")
	// Example: @request("POST", "https://api.example.com/submit", {"Content-Type": "application/json"}, {"key": "value"})
	
	// For now, return a placeholder that matches PHP behavior
	// In a real implementation, this would make HTTP requests
	
	return fmt.Sprintf("@request(%s)", params)
}

// MakeRequest makes an HTTP request with the given configuration
func (r *RequestOperator) MakeRequest(config *RequestConfig) (*RequestResponse, error) {
	startTime := time.Now()
	
	// Set default values
	if config.Method == "" {
		config.Method = "GET"
	}
	if config.Timeout == 0 {
		config.Timeout = 30 * time.Second
	}
	
	// Create request context with timeout
	ctx, cancel := context.WithTimeout(context.Background(), config.Timeout)
	defer cancel()
	
	// Prepare request body
	var body io.Reader
	if config.Body != nil {
		switch v := config.Body.(type) {
		case string:
			body = strings.NewReader(v)
		case []byte:
			body = bytes.NewReader(v)
		case map[string]interface{}:
			jsonData, err := json.Marshal(v)
			if err != nil {
				return nil, fmt.Errorf("failed to marshal JSON body: %v", err)
			}
			body = bytes.NewReader(jsonData)
		default:
			jsonData, err := json.Marshal(v)
			if err != nil {
				return nil, fmt.Errorf("failed to marshal body: %v", err)
			}
			body = bytes.NewReader(jsonData)
		}
	}
	
	// Create HTTP request
	req, err := http.NewRequestWithContext(ctx, config.Method, config.URL, body)
	if err != nil {
		return nil, fmt.Errorf("failed to create request: %v", err)
	}
	
	// Set headers
	if config.Headers != nil {
		for key, value := range config.Headers {
			req.Header.Set(key, value)
		}
	}
	
	// Set default headers if not provided
	if req.Header.Get("User-Agent") == "" {
		req.Header.Set("User-Agent", "TuskLang-Go-SDK/1.0.0")
	}
	if req.Header.Get("Accept") == "" {
		req.Header.Set("Accept", "*/*")
	}
	
	// Configure client based on settings
	client := r.client
	if !config.VerifySSL {
		client = &http.Client{
			Timeout: config.Timeout,
			Transport: &http.Transport{
				TLSClientConfig: &tls.Config{
					InsecureSkipVerify: true,
				},
			},
		}
	}
	
	if !config.FollowRedirects {
		client.CheckRedirect = func(req *http.Request, via []*http.Request) error {
			return http.ErrUseLastResponse
		}
	}
	
	// Make the request
	resp, err := client.Do(req)
	if err != nil {
		return &RequestResponse{
			Error:    err.Error(),
			Duration: time.Since(startTime),
			URL:      config.URL,
		}, nil
	}
	defer resp.Body.Close()
	
	// Read response body
	bodyBytes, err := io.ReadAll(resp.Body)
	if err != nil {
		return &RequestResponse{
			StatusCode: resp.StatusCode,
			Error:      fmt.Sprintf("failed to read response body: %v", err),
			Duration:   time.Since(startTime),
			URL:        config.URL,
		}, nil
	}
	
	// Convert headers to map
	headers := make(map[string]string)
	for key, values := range resp.Header {
		if len(values) > 0 {
			headers[key] = values[0]
		}
	}
	
	return &RequestResponse{
		StatusCode: resp.StatusCode,
		Headers:    headers,
		Body:       string(bodyBytes),
		Duration:   time.Since(startTime),
		URL:        resp.Request.URL.String(),
	}, nil
}

// Get makes a GET request
func (r *RequestOperator) Get(url string, headers map[string]string) (*RequestResponse, error) {
	config := &RequestConfig{
		Method:  "GET",
		URL:     url,
		Headers: headers,
	}
	return r.MakeRequest(config)
}

// Post makes a POST request
func (r *RequestOperator) Post(url string, body interface{}, headers map[string]string) (*RequestResponse, error) {
	config := &RequestConfig{
		Method:  "POST",
		URL:     url,
		Body:    body,
		Headers: headers,
	}
	return r.MakeRequest(config)
}

// Put makes a PUT request
func (r *RequestOperator) Put(url string, body interface{}, headers map[string]string) (*RequestResponse, error) {
	config := &RequestConfig{
		Method:  "PUT",
		URL:     url,
		Body:    body,
		Headers: headers,
	}
	return r.MakeRequest(config)
}

// Delete makes a DELETE request
func (r *RequestOperator) Delete(url string, headers map[string]string) (*RequestResponse, error) {
	config := &RequestConfig{
		Method:  "DELETE",
		URL:     url,
		Headers: headers,
	}
	return r.MakeRequest(config)
}

// Patch makes a PATCH request
func (r *RequestOperator) Patch(url string, body interface{}, headers map[string]string) (*RequestResponse, error) {
	config := &RequestConfig{
		Method:  "PATCH",
		URL:     url,
		Body:    body,
		Headers: headers,
	}
	return r.MakeRequest(config)
}

// Head makes a HEAD request
func (r *RequestOperator) Head(url string, headers map[string]string) (*RequestResponse, error) {
	config := &RequestConfig{
		Method:  "HEAD",
		URL:     url,
		Headers: headers,
	}
	return r.MakeRequest(config)
}

// Options makes an OPTIONS request
func (r *RequestOperator) Options(url string, headers map[string]string) (*RequestResponse, error) {
	config := &RequestConfig{
		Method:  "OPTIONS",
		URL:     url,
		Headers: headers,
	}
	return r.MakeRequest(config)
}

// PostForm makes a POST request with form data
func (r *RequestOperator) PostForm(url string, formData map[string]string, headers map[string]string) (*RequestResponse, error) {
	// Convert form data to URL-encoded string
	values := make([]string, 0, len(formData)*2)
	for key, value := range formData {
		values = append(values, key+"="+value)
	}
	formString := strings.Join(values, "&")
	
	config := &RequestConfig{
		Method:  "POST",
		URL:     url,
		Body:    formString,
		Headers: headers,
	}
	
	// Set content type if not provided
	if config.Headers == nil {
		config.Headers = make(map[string]string)
	}
	if config.Headers["Content-Type"] == "" {
		config.Headers["Content-Type"] = "application/x-www-form-urlencoded"
	}
	
	return r.MakeRequest(config)
}

// PostJSON makes a POST request with JSON data
func (r *RequestOperator) PostJSON(url string, jsonData interface{}, headers map[string]string) (*RequestResponse, error) {
	config := &RequestConfig{
		Method:  "POST",
		URL:     url,
		Body:    jsonData,
		Headers: headers,
	}
	
	// Set content type if not provided
	if config.Headers == nil {
		config.Headers = make(map[string]string)
	}
	if config.Headers["Content-Type"] == "" {
		config.Headers["Content-Type"] = "application/json"
	}
	
	return r.MakeRequest(config)
}

// SetTimeout sets the default timeout for requests
func (r *RequestOperator) SetTimeout(timeout time.Duration) {
	r.client.Timeout = timeout
}

// SetVerifySSL sets whether to verify SSL certificates
func (r *RequestOperator) SetVerifySSL(verify bool) {
	transport := r.client.Transport.(*http.Transport)
	transport.TLSClientConfig.InsecureSkipVerify = !verify
}

// SetFollowRedirects sets whether to follow redirects
func (r *RequestOperator) SetFollowRedirects(follow bool) {
	if follow {
		r.client.CheckRedirect = nil
	} else {
		r.client.CheckRedirect = func(req *http.Request, via []*http.Request) error {
			return http.ErrUseLastResponse
		}
	}
}

// ParseURL parses a URL and returns its components
func (r *RequestOperator) ParseURL(urlStr string) (map[string]interface{}, error) {
	parsedURL, err := url.Parse(urlStr)
	if err != nil {
		return nil, err
	}
	
	return map[string]interface{}{
		"scheme":   parsedURL.Scheme,
		"host":     parsedURL.Host,
		"path":     parsedURL.Path,
		"query":    parsedURL.RawQuery,
		"fragment": parsedURL.Fragment,
		"port":     parsedURL.Port(),
	}, nil
}

// BuildURL builds a URL from components
func (r *RequestOperator) BuildURL(scheme, host, path string, query map[string]string) string {
	u := &url.URL{
		Scheme: scheme,
		Host:   host,
		Path:   path,
	}
	
	if query != nil {
		values := make([]string, 0, len(query)*2)
		for key, value := range query {
			values = append(values, key+"="+value)
		}
		u.RawQuery = strings.Join(values, "&")
	}
	
	return u.String()
} 