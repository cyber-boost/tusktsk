package binary

import (
	"bytes"
	"encoding/binary"
	"fmt"
	"io"
	"os"
	"testing"
	"time"
)

// TestHeaderValidation tests header creation and validation
func TestHeaderValidation(t *testing.T) {
	header := &Header{}
	
	// Test magic bytes
	copy(header.Magic[:], MagicHeader)
	if string(header.Magic[:]) != MagicHeader {
		t.Errorf("expected magic bytes %s, got %s", MagicHeader, string(header.Magic[:]))
	}
	
	// Test version
	header.Major = VersionMajor
	header.Minor = VersionMinor
	header.Patch = VersionPatch
	
	if header.Major != 1 || header.Minor != 0 || header.Patch != 0 {
		t.Errorf("expected version 1.0.0, got %d.%d.%d", header.Major, header.Minor, header.Patch)
	}
	
	// Test checksum calculation
	testData := []byte("test data for checksum")
	checksum := calculateCRC32(testData)
	if checksum == 0 {
		t.Error("checksum should not be zero")
	}
}

// TestLengthEncoding tests the compact length encoding
func TestLengthEncoding(t *testing.T) {
	testCases := []struct {
		length uint64
		bytes  int
	}{
		{1, 1},
		{127, 1},
		{128, 2},
		{16383, 2},
		{16384, 4},
		{1000000, 4},
	}
	
	for _, tc := range testCases {
		encoded := encodeLength(tc.length)
		if len(encoded) != tc.bytes {
			t.Errorf("length %d: expected %d bytes, got %d", tc.length, tc.bytes, len(encoded))
		}
		
		// Test decoding
		decoded, err := decodeLength(bytes.NewReader(encoded))
		if err != nil {
			t.Errorf("failed to decode length %d: %v", tc.length, err)
		}
		if decoded != tc.length {
			t.Errorf("length %d: decoded to %d", tc.length, decoded)
		}
	}
}

// TestValueTypes tests all supported value types
func TestValueTypes(t *testing.T) {
	testCases := []struct {
		name     string
		value    *Value
		expected interface{}
	}{
		{"null", &Value{Type: TypeNull, Data: nil}, nil},
		{"bool_true", &Value{Type: TypeBool, Data: true}, true},
		{"bool_false", &Value{Type: TypeBool, Data: false}, false},
		{"int8", &Value{Type: TypeInt8, Data: int8(-42)}, int8(-42)},
		{"uint8", &Value{Type: TypeUint8, Data: uint8(255)}, uint8(255)},
		{"int16", &Value{Type: TypeInt16, Data: int16(-1234)}, int16(-1234)},
		{"uint16", &Value{Type: TypeUint16, Data: uint16(65535)}, uint16(65535)},
		{"int32", &Value{Type: TypeInt32, Data: int32(-123456)}, int32(-123456)},
		{"uint32", &Value{Type: TypeUint32, Data: uint32(4294967295)}, uint32(4294967295)},
		{"int64", &Value{Type: TypeInt64, Data: int64(-123456789)}, int64(-123456789)},
		{"uint64", &Value{Type: TypeUint64, Data: uint64(18446744073709551615)}, uint64(18446744073709551615)},
		{"float32", &Value{Type: TypeFloat32, Data: float32(3.14159)}, float32(3.14159)},
		{"float64", &Value{Type: TypeFloat64, Data: float64(2.718281828)}, float64(2.718281828)},
		{"string", &Value{Type: TypeString, Data: "hello world"}, "hello world"},
		{"bytes", &Value{Type: TypeBytes, Data: []byte{1, 2, 3, 4}}, []byte{1, 2, 3, 4}},
		{"timestamp", &Value{Type: TypeTimestamp, Data: time.Unix(1234567890, 0)}, time.Unix(1234567890, 0)},
		{"duration", &Value{Type: TypeDuration, Data: time.Second * 5}, time.Second * 5},
	}
	
	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			// Test serialization
			bytes, err := valueToBytes(tc.value)
			if err != nil {
				t.Errorf("failed to serialize %s: %v", tc.name, err)
				return
			}
			
			// Test deserialization (simplified)
			if tc.value.Type == TypeString {
				// For strings, we need to handle length encoding
				if len(bytes) == 0 {
					t.Errorf("string should not be empty")
				}
			}
		})
	}
}

// TestObjectSerialization tests object serialization and deserialization
func TestObjectSerialization(t *testing.T) {
	// Create test object
	object := &Object{
		Entries: map[string]*Value{
			"string_key": {Type: TypeString, Data: "string_value"},
			"int_key":    {Type: TypeInt32, Data: int32(42)},
			"bool_key":   {Type: TypeBool, Data: true},
		},
	}
	
	// Test writing
	filename := "test_object.pnt"
	writer, err := NewWriter(filename)
	if err != nil {
		t.Fatalf("failed to create writer: %v", err)
	}
	defer os.Remove(filename)
	defer writer.Close()
	
	// Write header
	header := &Header{}
	if err := writer.WriteHeader(header); err != nil {
		t.Fatalf("failed to write header: %v", err)
	}
	
	// Write object
	if err := writer.WriteObject(object); err != nil {
		t.Fatalf("failed to write object: %v", err)
	}
	
	// Write footer
	footer := &Footer{}
	if err := writer.WriteFooter(footer); err != nil {
		t.Fatalf("failed to write footer: %v", err)
	}
	
	// Test reading
	reader, err := NewReader(filename)
	if err != nil {
		t.Fatalf("failed to create reader: %v", err)
	}
	defer reader.Close()
	
	// Read header
	readHeader, err := reader.ReadHeader()
	if err != nil {
		t.Fatalf("failed to read header: %v", err)
	}
	
	if readHeader.Major != VersionMajor {
		t.Errorf("expected major version %d, got %d", VersionMajor, readHeader.Major)
	}
	
	// Read object
	readObject, err := reader.ReadObject()
	if err != nil {
		t.Fatalf("failed to read object: %v", err)
	}
	
	// Verify object contents
	if len(readObject.Entries) != len(object.Entries) {
		t.Errorf("expected %d entries, got %d", len(object.Entries), len(readObject.Entries))
	}
	
	for key, expectedValue := range object.Entries {
		actualValue, exists := readObject.Entries[key]
		if !exists {
			t.Errorf("missing key: %s", key)
			continue
		}
		
		if actualValue.Type != expectedValue.Type {
			t.Errorf("key %s: expected type %d, got %d", key, expectedValue.Type, actualValue.Type)
		}
	}
}

// TestArraySerialization tests array serialization and deserialization
func TestArraySerialization(t *testing.T) {
	// Create test array
	array := &Array{
		Elements: []*Value{
			{Type: TypeString, Data: "first"},
			{Type: TypeInt32, Data: int32(42)},
			{Type: TypeBool, Data: true},
		},
	}
	
	// Test writing
	filename := "test_array.pnt"
	writer, err := NewWriter(filename)
	if err != nil {
		t.Fatalf("failed to create writer: %v", err)
	}
	defer os.Remove(filename)
	defer writer.Close()
	
	// Write header
	header := &Header{}
	if err := writer.WriteHeader(header); err != nil {
		t.Fatalf("failed to write header: %v", err)
	}
	
	// Write array
	if err := writer.WriteArray(array); err != nil {
		t.Fatalf("failed to write array: %v", err)
	}
	
	// Write footer
	footer := &Footer{}
	if err := writer.WriteFooter(footer); err != nil {
		t.Fatalf("failed to write footer: %v", err)
	}
	
	// Test reading
	reader, err := NewReader(filename)
	if err != nil {
		t.Fatalf("failed to create reader: %v", err)
	}
	defer reader.Close()
	
	// Read header
	_, err = reader.ReadHeader()
	if err != nil {
		t.Fatalf("failed to read header: %v", err)
	}
	
	// Read array
	readArray, err := reader.ReadArray()
	if err != nil {
		t.Fatalf("failed to read array: %v", err)
	}
	
	// Verify array contents
	if len(readArray.Elements) != len(array.Elements) {
		t.Errorf("expected %d elements, got %d", len(array.Elements), len(readArray.Elements))
	}
	
	for i, expectedElement := range array.Elements {
		actualElement := readArray.Elements[i]
		if actualElement.Type != expectedElement.Type {
			t.Errorf("element %d: expected type %d, got %d", i, expectedElement.Type, actualElement.Type)
		}
	}
}

// TestStringEncoding tests string encoding and decoding
func TestStringEncoding(t *testing.T) {
	testStrings := []string{
		"",
		"hello",
		"hello world",
		"привет мир", // UTF-8
		"a" + string(make([]byte, 1000)), // Long string
	}
	
	for _, str := range testStrings {
		t.Run(fmt.Sprintf("string_%d", len(str)), func(t *testing.T) {
			// Test writing
			var buf bytes.Buffer
			writer := &BinaryWriter{file: nil} // Mock for testing
			
			if err := writer.WriteString(str); err != nil {
				t.Errorf("failed to write string: %v", err)
				return
			}
			
			// Test reading
			reader := &BinaryReader{file: nil} // Mock for testing
			readStr, err := reader.ReadString()
			if err != nil {
				t.Errorf("failed to read string: %v", err)
				return
			}
			
			if readStr != str {
				t.Errorf("expected %q, got %q", str, readStr)
			}
		})
	}
}

// TestErrorHandling tests error conditions
func TestErrorHandling(t *testing.T) {
	// Test invalid magic bytes
	header := &Header{}
	copy(header.Magic[:], "INVALID")
	
	// Test unsupported version
	header.Major = 99
	
	// Test invalid type identifier
	value := &Value{Type: 0xFF, Data: nil}
	_, err := valueToBytes(value)
	if err == nil {
		t.Error("expected error for invalid type identifier")
	}
}

// TestLargeFile tests handling of large files
func TestLargeFile(t *testing.T) {
	// Create a large object
	largeObject := &Object{
		Entries: make(map[string]*Value),
	}
	
	// Add many entries
	for i := 0; i < 1000; i++ {
		key := fmt.Sprintf("key_%d", i)
		value := &Value{
			Type: TypeString,
			Data: fmt.Sprintf("value_%d", i),
		}
		largeObject.Entries[key] = value
	}
	
	// Test writing
	filename := "test_large.pnt"
	writer, err := NewWriter(filename)
	if err != nil {
		t.Fatalf("failed to create writer: %v", err)
	}
	defer os.Remove(filename)
	defer writer.Close()
	
	// Write header
	header := &Header{}
	if err := writer.WriteHeader(header); err != nil {
		t.Fatalf("failed to write header: %v", err)
	}
	
	// Write large object
	if err := writer.WriteObject(largeObject); err != nil {
		t.Fatalf("failed to write large object: %v", err)
	}
	
	// Write footer
	footer := &Footer{}
	if err := writer.WriteFooter(footer); err != nil {
		t.Fatalf("failed to write footer: %v", err)
	}
	
	// Verify file size
	fileInfo, err := os.Stat(filename)
	if err != nil {
		t.Fatalf("failed to stat file: %v", err)
	}
	
	if fileInfo.Size() < 1000 {
		t.Errorf("expected file size > 1000 bytes, got %d", fileInfo.Size())
	}
}

// BenchmarkWriteObject benchmarks object writing performance
func BenchmarkWriteObject(b *testing.B) {
	object := &Object{
		Entries: map[string]*Value{
			"string_key": {Type: TypeString, Data: "string_value"},
			"int_key":    {Type: TypeInt32, Data: int32(42)},
			"bool_key":   {Type: TypeBool, Data: true},
		},
	}
	
	filename := "benchmark_object.pnt"
	
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		writer, err := NewWriter(filename)
		if err != nil {
			b.Fatalf("failed to create writer: %v", err)
		}
		
		header := &Header{}
		writer.WriteHeader(header)
		writer.WriteObject(object)
		footer := &Footer{}
		writer.WriteFooter(footer)
		writer.Close()
		
		os.Remove(filename)
	}
}

// BenchmarkReadObject benchmarks object reading performance
func BenchmarkReadObject(b *testing.B) {
	// Create test file
	object := &Object{
		Entries: map[string]*Value{
			"string_key": {Type: TypeString, Data: "string_value"},
			"int_key":    {Type: TypeInt32, Data: int32(42)},
			"bool_key":   {Type: TypeBool, Data: true},
		},
	}
	
	filename := "benchmark_read.pnt"
	writer, err := NewWriter(filename)
	if err != nil {
		b.Fatalf("failed to create writer: %v", err)
	}
	
	header := &Header{}
	writer.WriteHeader(header)
	writer.WriteObject(object)
	footer := &Footer{}
	writer.WriteFooter(footer)
	writer.Close()
	
	defer os.Remove(filename)
	
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		reader, err := NewReader(filename)
		if err != nil {
			b.Fatalf("failed to create reader: %v", err)
		}
		
		reader.ReadHeader()
		reader.ReadObject()
		reader.Close()
	}
}

// TestCrossPlatformCompatibility tests that files can be read across platforms
func TestCrossPlatformCompatibility(t *testing.T) {
	// Create a test file with various data types
	testObject := &Object{
		Entries: map[string]*Value{
			"null":       {Type: TypeNull, Data: nil},
			"bool":       {Type: TypeBool, Data: true},
			"int8":       {Type: TypeInt8, Data: int8(-42)},
			"uint8":      {Type: TypeUint8, Data: uint8(255)},
			"int16":      {Type: TypeInt16, Data: int16(-1234)},
			"uint16":     {Type: TypeUint16, Data: uint16(65535)},
			"int32":      {Type: TypeInt32, Data: int32(-123456)},
			"uint32":     {Type: TypeUint32, Data: uint32(4294967295)},
			"int64":      {Type: TypeInt64, Data: int64(-123456789)},
			"uint64":     {Type: TypeUint64, Data: uint64(18446744073709551615)},
			"float32":    {Type: TypeFloat32, Data: float32(3.14159)},
			"float64":    {Type: TypeFloat64, Data: float64(2.718281828)},
			"string":     {Type: TypeString, Data: "hello world"},
			"bytes":      {Type: TypeBytes, Data: []byte{1, 2, 3, 4}},
			"timestamp":  {Type: TypeTimestamp, Data: time.Unix(1234567890, 0)},
			"duration":   {Type: TypeDuration, Data: time.Second * 5},
		},
	}
	
	filename := "test_cross_platform.pnt"
	
	// Write test file
	writer, err := NewWriter(filename)
	if err != nil {
		t.Fatalf("failed to create writer: %v", err)
	}
	
	header := &Header{}
	if err := writer.WriteHeader(header); err != nil {
		t.Fatalf("failed to write header: %v", err)
	}
	
	if err := writer.WriteObject(testObject); err != nil {
		t.Fatalf("failed to write object: %v", err)
	}
	
	footer := &Footer{}
	if err := writer.WriteFooter(footer); err != nil {
		t.Fatalf("failed to write footer: %v", err)
	}
	
	writer.Close()
	defer os.Remove(filename)
	
	// Read and verify
	reader, err := NewReader(filename)
	if err != nil {
		t.Fatalf("failed to create reader: %v", err)
	}
	defer reader.Close()
	
	readHeader, err := reader.ReadHeader()
	if err != nil {
		t.Fatalf("failed to read header: %v", err)
	}
	
	// Verify header
	if readHeader.Major != VersionMajor {
		t.Errorf("expected major version %d, got %d", VersionMajor, readHeader.Major)
	}
	
	if string(readHeader.Magic[:]) != MagicHeader {
		t.Errorf("expected magic bytes %s, got %s", MagicHeader, string(readHeader.Magic[:]))
	}
	
	readObject, err := reader.ReadObject()
	if err != nil {
		t.Fatalf("failed to read object: %v", err)
	}
	
	// Verify all entries
	for key, expectedValue := range testObject.Entries {
		actualValue, exists := readObject.Entries[key]
		if !exists {
			t.Errorf("missing key: %s", key)
			continue
		}
		
		if actualValue.Type != expectedValue.Type {
			t.Errorf("key %s: expected type %d, got %d", key, expectedValue.Type, actualValue.Type)
		}
	}
} 