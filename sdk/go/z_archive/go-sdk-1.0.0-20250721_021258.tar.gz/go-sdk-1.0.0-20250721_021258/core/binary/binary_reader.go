package binary

import (
	"encoding/binary"
	"fmt"
	"io"
	"os"
	"time"
)

// BinaryReader implements the Reader interface for .pnt files
type BinaryReader struct {
	file   *os.File
	offset int64
	buffer []byte
}

// NewReader creates a new binary reader for the given file
func NewReader(filename string) (*BinaryReader, error) {
	file, err := os.Open(filename)
	if err != nil {
		return nil, err
	}

	return &BinaryReader{
		file:   file,
		offset: 0,
		buffer: make([]byte, 4096), // 4KB buffer
	}, nil
}

// ReadHeader reads and validates the file header
func (r *BinaryReader) ReadHeader() (*Header, error) {
	header := &Header{}
	
	// Read header bytes
	if err := binary.Read(r.file, binary.LittleEndian, header); err != nil {
		return nil, &BinaryFormatError{
			Message: fmt.Sprintf("failed to read header: %v", err),
			Offset:  r.offset,
			Type:    "header_read",
		}
	}

	// Validate magic bytes
	if string(header.Magic[:]) != MagicHeader {
		return nil, &BinaryFormatError{
			Message: fmt.Sprintf("invalid magic bytes: expected %s, got %s", 
				MagicHeader, string(header.Magic[:])),
			Offset: r.offset,
			Type:   "magic_validation",
		}
	}

	// Validate version
	if header.Major != VersionMajor {
		return nil, &BinaryFormatError{
			Message: fmt.Sprintf("unsupported major version: %d", header.Major),
			Offset:  r.offset,
			Type:    "version_validation",
		}
	}

	// Validate checksum
	headerData := make([]byte, 64)
	r.file.Seek(0, io.SeekStart)
	if _, err := io.ReadFull(r.file, headerData); err != nil {
		return nil, &BinaryFormatError{
			Message: fmt.Sprintf("failed to read header for checksum: %v", err),
			Offset:  r.offset,
			Type:    "checksum_read",
		}
	}
	
	// Exclude checksum field from calculation
	checksumData := append(headerData[:28], headerData[32:]...)
	calculatedChecksum := calculateCRC32(checksumData)
	
	if header.Checksum != calculatedChecksum {
		return nil, &BinaryFormatError{
			Message: fmt.Sprintf("header checksum mismatch: expected %08x, got %08x", 
				calculatedChecksum, header.Checksum),
			Offset: r.offset,
			Type:   "checksum_validation",
		}
	}

	r.offset = 64
	return header, nil
}

// ReadValue reads a single value from the current position
func (r *BinaryReader) ReadValue() (*Value, error) {
	// Read type identifier
	var typeID [1]byte
	if _, err := io.ReadFull(r.file, typeID[:]); err != nil {
		return nil, &BinaryFormatError{
			Message: fmt.Sprintf("failed to read type identifier: %v", err),
			Offset:  r.offset,
			Type:    "type_read",
		}
	}
	r.offset++

	value := &Value{
		Type:   typeID[0],
		Offset: uint64(r.offset),
	}

	// Read value data based on type
	switch typeID[0] {
	case TypeNull:
		value.Data = nil
		value.Size = 0

	case TypeBool:
		var boolVal [1]byte
		if _, err := io.ReadFull(r.file, boolVal[:]); err != nil {
			return nil, &BinaryFormatError{
				Message: fmt.Sprintf("failed to read bool value: %v", err),
				Offset:  r.offset,
				Type:    "bool_read",
			}
		}
		value.Data = boolVal[0] != 0
		value.Size = 1
		r.offset++

	case TypeInt8:
		var intVal [1]byte
		if _, err := io.ReadFull(r.file, intVal[:]); err != nil {
			return nil, &BinaryFormatError{
				Message: fmt.Sprintf("failed to read int8 value: %v", err),
				Offset:  r.offset,
				Type:    "int8_read",
			}
		}
		value.Data = int8(intVal[0])
		value.Size = 1
		r.offset++

	case TypeUint8:
		var uintVal [1]byte
		if _, err := io.ReadFull(r.file, uintVal[:]); err != nil {
			return nil, &BinaryFormatError{
				Message: fmt.Sprintf("failed to read uint8 value: %v", err),
				Offset:  r.offset,
				Type:    "uint8_read",
			}
		}
		value.Data = uintVal[0]
		value.Size = 1
		r.offset++

	case TypeInt16:
		var intVal [2]byte
		if _, err := io.ReadFull(r.file, intVal[:]); err != nil {
			return nil, &BinaryFormatError{
				Message: fmt.Sprintf("failed to read int16 value: %v", err),
				Offset:  r.offset,
				Type:    "int16_read",
			}
		}
		value.Data = int16(binary.LittleEndian.Uint16(intVal[:]))
		value.Size = 2
		r.offset += 2

	case TypeUint16:
		var uintVal [2]byte
		if _, err := io.ReadFull(r.file, uintVal[:]); err != nil {
			return nil, &BinaryFormatError{
				Message: fmt.Sprintf("failed to read uint16 value: %v", err),
				Offset:  r.offset,
				Type:    "uint16_read",
			}
		}
		value.Data = binary.LittleEndian.Uint16(uintVal[:])
		value.Size = 2
		r.offset += 2

	case TypeInt32:
		var intVal [4]byte
		if _, err := io.ReadFull(r.file, intVal[:]); err != nil {
			return nil, &BinaryFormatError{
				Message: fmt.Sprintf("failed to read int32 value: %v", err),
				Offset:  r.offset,
				Type:    "int32_read",
			}
		}
		value.Data = int32(binary.LittleEndian.Uint32(intVal[:]))
		value.Size = 4
		r.offset += 4

	case TypeUint32:
		var uintVal [4]byte
		if _, err := io.ReadFull(r.file, uintVal[:]); err != nil {
			return nil, &BinaryFormatError{
				Message: fmt.Sprintf("failed to read uint32 value: %v", err),
				Offset:  r.offset,
				Type:    "uint32_read",
			}
		}
		value.Data = binary.LittleEndian.Uint32(uintVal[:])
		value.Size = 4
		r.offset += 4

	case TypeInt64:
		var intVal [8]byte
		if _, err := io.ReadFull(r.file, intVal[:]); err != nil {
			return nil, &BinaryFormatError{
				Message: fmt.Sprintf("failed to read int64 value: %v", err),
				Offset:  r.offset,
				Type:    "int64_read",
			}
		}
		value.Data = int64(binary.LittleEndian.Uint64(intVal[:]))
		value.Size = 8
		r.offset += 8

	case TypeUint64:
		var uintVal [8]byte
		if _, err := io.ReadFull(r.file, uintVal[:]); err != nil {
			return nil, &BinaryFormatError{
				Message: fmt.Sprintf("failed to read uint64 value: %v", err),
				Offset:  r.offset,
				Type:    "uint64_read",
			}
		}
		value.Data = binary.LittleEndian.Uint64(uintVal[:])
		value.Size = 8
		r.offset += 8

	case TypeFloat32:
		var floatVal [4]byte
		if _, err := io.ReadFull(r.file, floatVal[:]); err != nil {
			return nil, &BinaryFormatError{
				Message: fmt.Sprintf("failed to read float32 value: %v", err),
				Offset:  r.offset,
				Type:    "float32_read",
			}
		}
		value.Data = float32(binary.LittleEndian.Uint32(floatVal[:]))
		value.Size = 4
		r.offset += 4

	case TypeFloat64:
		var floatVal [8]byte
		if _, err := io.ReadFull(r.file, floatVal[:]); err != nil {
			return nil, &BinaryFormatError{
				Message: fmt.Sprintf("failed to read float64 value: %v", err),
				Offset:  r.offset,
				Type:    "float64_read",
			}
		}
		value.Data = float64(binary.LittleEndian.Uint64(floatVal[:]))
		value.Size = 8
		r.offset += 8

	case TypeString:
		str, err := r.ReadString()
		if err != nil {
			return nil, err
		}
		value.Data = str
		value.Size = uint64(len(str))

	case TypeBytes:
		bytes, err := r.ReadBytes()
		if err != nil {
			return nil, err
		}
		value.Data = bytes
		value.Size = uint64(len(bytes))

	case TypeTimestamp:
		var timestamp [8]byte
		if _, err := io.ReadFull(r.file, timestamp[:]); err != nil {
			return nil, &BinaryFormatError{
				Message: fmt.Sprintf("failed to read timestamp value: %v", err),
				Offset:  r.offset,
				Type:    "timestamp_read",
			}
		}
		unixTime := int64(binary.LittleEndian.Uint64(timestamp[:]))
		value.Data = time.Unix(unixTime, 0)
		value.Size = 8
		r.offset += 8

	case TypeDuration:
		var duration [8]byte
		if _, err := io.ReadFull(r.file, duration[:]); err != nil {
			return nil, &BinaryFormatError{
				Message: fmt.Sprintf("failed to read duration value: %v", err),
				Offset:  r.offset,
				Type:    "duration_read",
			}
		}
		nanoseconds := int64(binary.LittleEndian.Uint64(duration[:]))
		value.Data = time.Duration(nanoseconds)
		value.Size = 8
		r.offset += 8

	case TypeArray:
		array, err := r.ReadArray()
		if err != nil {
			return nil, err
		}
		value.Data = array
		value.Size = array.Size

	case TypeObject:
		object, err := r.ReadObject()
		if err != nil {
			return nil, err
		}
		value.Data = object
		value.Size = object.Size

	case TypeReference:
		var refOffset [8]byte
		if _, err := io.ReadFull(r.file, refOffset[:]); err != nil {
			return nil, &BinaryFormatError{
				Message: fmt.Sprintf("failed to read reference offset: %v", err),
				Offset:  r.offset,
				Type:    "reference_read",
			}
		}
		value.Data = binary.LittleEndian.Uint64(refOffset[:])
		value.Size = 8
		r.offset += 8

	default:
		return nil, &BinaryFormatError{
			Message: fmt.Sprintf("unknown type identifier: %d", typeID[0]),
			Offset:  r.offset,
			Type:    "unknown_type",
		}
	}

	return value, nil
}

// ReadString reads a string value with length prefix
func (r *BinaryReader) ReadString() (string, error) {
	length, err := decodeLength(r.file)
	if err != nil {
		return "", &BinaryFormatError{
			Message: fmt.Sprintf("failed to read string length: %v", err),
			Offset:  r.offset,
			Type:    "string_length",
		}
	}

	if length > 0 {
		// Update offset for length bytes
		if length <= 127 {
			r.offset++
		} else if length <= 16383 {
			r.offset += 2
		} else {
			r.offset += 4
		}

		// Read string data
		strBytes := make([]byte, length)
		if _, err := io.ReadFull(r.file, strBytes); err != nil {
			return "", &BinaryFormatError{
				Message: fmt.Sprintf("failed to read string data: %v", err),
				Offset:  r.offset,
				Type:    "string_data",
			}
		}
		r.offset += int64(length)

		return string(strBytes), nil
	}

	return "", nil
}

// ReadBytes reads a byte array with length prefix
func (r *BinaryReader) ReadBytes() ([]byte, error) {
	length, err := decodeLength(r.file)
	if err != nil {
		return nil, &BinaryFormatError{
			Message: fmt.Sprintf("failed to read bytes length: %v", err),
			Offset:  r.offset,
			Type:    "bytes_length",
		}
	}

	if length > 0 {
		// Update offset for length bytes
		if length <= 127 {
			r.offset++
		} else if length <= 16383 {
			r.offset += 2
		} else {
			r.offset += 4
		}

		// Read byte data
		bytes := make([]byte, length)
		if _, err := io.ReadFull(r.file, bytes); err != nil {
			return nil, &BinaryFormatError{
				Message: fmt.Sprintf("failed to read bytes data: %v", err),
				Offset:  r.offset,
				Type:    "bytes_data",
			}
		}
		r.offset += int64(length)

		return bytes, nil
	}

	return []byte{}, nil
}

// ReadArray reads an array value
func (r *BinaryReader) ReadArray() (*Array, error) {
	length, err := decodeLength(r.file)
	if err != nil {
		return nil, &BinaryFormatError{
			Message: fmt.Sprintf("failed to read array length: %v", err),
			Offset:  r.offset,
			Type:    "array_length",
		}
	}

	// Update offset for length bytes
	if length <= 127 {
		r.offset++
	} else if length <= 16383 {
		r.offset += 2
	} else {
		r.offset += 4
	}

	array := &Array{
		Elements: make([]*Value, length),
		Offset:   uint64(r.offset),
	}

	// Read array elements
	for i := uint64(0); i < length; i++ {
		element, err := r.ReadValue()
		if err != nil {
			return nil, err
		}
		array.Elements[i] = element
	}

	// Calculate total size
	array.Size = uint64(r.offset) - array.Offset
	return array, nil
}

// ReadObject reads an object value
func (r *BinaryReader) ReadObject() (*Object, error) {
	length, err := decodeLength(r.file)
	if err != nil {
		return nil, &BinaryFormatError{
			Message: fmt.Sprintf("failed to read object length: %v", err),
			Offset:  r.offset,
			Type:    "object_length",
		}
	}

	// Update offset for length bytes
	if length <= 127 {
		r.offset++
	} else if length <= 16383 {
		r.offset += 2
	} else {
		r.offset += 4
	}

	object := &Object{
		Entries: make(map[string]*Value),
		Offset:  uint64(r.offset),
	}

	// Read object entries
	for i := uint64(0); i < length; i++ {
		// Read key
		key, err := r.ReadString()
		if err != nil {
			return nil, err
		}

		// Read value
		value, err := r.ReadValue()
		if err != nil {
			return nil, err
		}

		object.Entries[key] = value
	}

	// Calculate total size
	object.Size = uint64(r.offset) - object.Offset
	return object, nil
}

// ReadIndex reads the index table
func (r *BinaryReader) ReadIndex() ([]*IndexEntry, error) {
	// Seek to index offset (assuming we have header info)
	// This would need to be called after reading the header
	// For now, we'll read from current position
	
	var length [2]byte
	if _, err := io.ReadFull(r.file, length[:]); err != nil {
		return nil, &BinaryFormatError{
			Message: fmt.Sprintf("failed to read index length: %v", err),
			Offset:  r.offset,
			Type:    "index_length",
		}
	}
	r.offset += 2

	indexLength := binary.LittleEndian.Uint16(length[:])
	entries := make([]*IndexEntry, indexLength)

	for i := uint16(0); i < indexLength; i++ {
		entry := &IndexEntry{}

		// Read key length
		if err := binary.Read(r.file, binary.LittleEndian, &entry.KeyLength); err != nil {
			return nil, &BinaryFormatError{
				Message: fmt.Sprintf("failed to read index key length: %v", err),
				Offset:  r.offset,
				Type:    "index_key_length",
			}
		}
		r.offset += 2

		// Read key
		keyBytes := make([]byte, entry.KeyLength)
		if _, err := io.ReadFull(r.file, keyBytes); err != nil {
			return nil, &BinaryFormatError{
				Message: fmt.Sprintf("failed to read index key: %v", err),
				Offset:  r.offset,
				Type:    "index_key",
			}
		}
		entry.Key = string(keyBytes)
		r.offset += int64(entry.KeyLength)

		// Read value offset
		if err := binary.Read(r.file, binary.LittleEndian, &entry.ValueOffset); err != nil {
			return nil, &BinaryFormatError{
				Message: fmt.Sprintf("failed to read index value offset: %v", err),
				Offset:  r.offset,
				Type:    "index_value_offset",
			}
		}
		r.offset += 8

		// Read value type
		if err := binary.Read(r.file, binary.LittleEndian, &entry.ValueType); err != nil {
			return nil, &BinaryFormatError{
				Message: fmt.Sprintf("failed to read index value type: %v", err),
				Offset:  r.offset,
				Type:    "index_value_type",
			}
		}
		r.offset++

		// Read value size
		if err := binary.Read(r.file, binary.LittleEndian, &entry.ValueSize); err != nil {
			return nil, &BinaryFormatError{
				Message: fmt.Sprintf("failed to read index value size: %v", err),
				Offset:  r.offset,
				Type:    "index_value_size",
			}
		}
		r.offset += 4

		entries[i] = entry
	}

	return entries, nil
}

// ReadFooter reads and validates the file footer
func (r *BinaryReader) ReadFooter() (*Footer, error) {
	footer := &Footer{}
	
	if err := binary.Read(r.file, binary.LittleEndian, footer); err != nil {
		return nil, &BinaryFormatError{
			Message: fmt.Sprintf("failed to read footer: %v", err),
			Offset:  r.offset,
			Type:    "footer_read",
		}
	}

	// Validate magic bytes
	if string(footer.Magic[:]) != MagicFooter {
		return nil, &BinaryFormatError{
			Message: fmt.Sprintf("invalid footer magic bytes: expected %s, got %s", 
				MagicFooter, string(footer.Magic[:])),
			Offset: r.offset,
			Type:   "footer_magic",
		}
	}

	return footer, nil
}

// Seek moves to the specified offset
func (r *BinaryReader) Seek(offset int64) error {
	if _, err := r.file.Seek(offset, io.SeekStart); err != nil {
		return &BinaryFormatError{
			Message: fmt.Sprintf("failed to seek to offset %d: %v", offset, err),
			Offset:  r.offset,
			Type:    "seek",
		}
	}
	r.offset = offset
	return nil
}

// Close closes the underlying file
func (r *BinaryReader) Close() error {
	return r.file.Close()
} 