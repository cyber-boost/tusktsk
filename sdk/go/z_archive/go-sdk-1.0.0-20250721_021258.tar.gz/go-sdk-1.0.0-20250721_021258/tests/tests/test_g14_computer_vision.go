package main

import (
	"testing"
	"time"
	"fmt"
)

// TestComputerVisionEngineBasic tests basic computer vision functionality
func TestComputerVisionEngineBasic(t *testing.T) {
	config := CVConfig{
		EnableDetection:     true,
		EnableRecognition:   true,
		EnableSegmentation:  true,
		EnableTracking:      true,
		EnableMonitoring:    true,
		MonitorInterval:     30 * time.Second,
		EnablePersistence:   false,
		PersistencePath:     "",
		MaxModels:           50,
		DefaultFramework:    "opencv",
		EnableGPU:           true,
	}

	cve := NewComputerVisionEngine(config)
	if cve == nil {
		t.Fatal("Failed to create ComputerVisionEngine")
	}

	// Test image input (simulated)
	image := "simulated_image_data"

	// Object detection
	detection, err := cve.DetectObjects(image, map[string]interface{}{
		"confidence_threshold": 0.5,
	})
	if err != nil {
		t.Fatalf("Failed to detect objects: %v", err)
	}

	if detection.ImageID == "" {
		t.Error("ImageID should not be empty")
	}

	// Face recognition
	recognition, err := cve.RecognizeFaces(image, map[string]interface{}{
		"min_face_size": 50,
	})
	if err != nil {
		t.Fatalf("Failed to recognize faces: %v", err)
	}

	if recognition.ImageID == "" {
		t.Error("ImageID should not be empty")
	}

	// Image segmentation
	segmentation, err := cve.SegmentImage(image, map[string]interface{}{
		"classes": []string{"background", "foreground"},
	})
	if err != nil {
		t.Fatalf("Failed to segment image: %v", err)
	}

	if segmentation.ImageID == "" {
		t.Error("ImageID should not be empty")
	}

	// Object tracking (simulated video frames)
	frames := []string{"frame1", "frame2", "frame3"}
	tracking, err := cve.TrackObjects(frames, map[string]interface{}{
		"tracker_type": "kalman",
	})
	if err != nil {
		t.Fatalf("Failed to track objects: %v", err)
	}

	if tracking.VideoID == "" {
		t.Error("VideoID should not be empty")
	}
}

// TestComputerVisionEngineModelManagement tests model management
func TestComputerVisionEngineModelManagement(t *testing.T) {
	config := CVConfig{
		EnableDetection:     true,
		EnableRecognition:   true,
		EnableSegmentation:  true,
		EnableTracking:      true,
		EnableMonitoring:    true,
		MonitorInterval:     30 * time.Second,
		EnablePersistence:   false,
		PersistencePath:     "",
		MaxModels:           50,
		DefaultFramework:    "opencv",
		EnableGPU:           true,
	}

	cve := NewComputerVisionEngine(config)

	// Create multiple models
	models := []*CVModel{
		{
			ID:          "cv-model-1",
			Name:        "CV Model 1",
			Description: "First CV model",
			Type:        "detection",
			Framework:   "yolo",
			Config: map[string]interface{}{
				"pretrained": true,
			},
			Status:    "initialized",
			CreatedAt: time.Now(),
			UpdatedAt: time.Now(),
			Metadata:  make(map[string]string),
		},
		{
			ID:          "cv-model-2",
			Name:        "CV Model 2",
			Description: "Second CV model",
			Type:        "segmentation",
			Framework:   "unet",
			Config: map[string]interface{}{
				"pretrained": true,
			},
			Status:    "initialized",
			CreatedAt: time.Now(),
			UpdatedAt: time.Now(),
			Metadata:  make(map[string]string),
		},
	}

	// Register models
	for _, model := range models {
		err := cve.RegisterModel(model)
		if err != nil {
			t.Fatalf("Failed to register model %s: %v", model.ID, err)
		}
	}

	// Get model
	retrievedModel, err := cve.GetModel("cv-model-1")
	if err != nil {
		t.Fatalf("Failed to get model: %v", err)
	}

	if retrievedModel.ID != "cv-model-1" {
		t.Errorf("Expected model ID 'cv-model-1', got '%s'", retrievedModel.ID)
	}

	// List models
	allModels := cve.ListModels()
	if len(allModels) < 2 {
		t.Fatalf("Expected at least 2 models, got %d", len(allModels))
	}

	found := make(map[string]bool)
	for _, model := range allModels {
		found[model.ID] = true
	}

	if !found["cv-model-1"] {
		t.Fatal("CV-model-1 should be in model list")
	}

	if !found["cv-model-2"] {
		t.Fatal("CV-model-2 should be in model list")
	}
}

// TestComputerVisionEngineAdvancedDetection tests advanced detection features
func TestComputerVisionEngineAdvancedDetection(t *testing.T) {
	config := CVConfig{
		EnableDetection:     true,
		EnableRecognition:   true,
		EnableSegmentation:  true,
		EnableTracking:      true,
		EnableMonitoring:    true,
		MonitorInterval:     30 * time.Second,
		EnablePersistence:   false,
		PersistencePath:     "",
		MaxModels:           50,
		DefaultFramework:    "opencv",
		EnableGPU:           true,
	}

	cve := NewComputerVisionEngine(config)

	// Simulated image with known objects
	image := "image_with_person_car_and_dog"

	detection, err := cve.DetectObjects(image, map[string]interface{}{
		"confidence_threshold": 0.6,
		"nms_threshold": 0.4,
	})
	if err != nil {
		t.Fatalf("Failed to detect objects: %v", err)
	}

	if len(detection.Objects) == 0 {
		t.Fatal("Detected objects should not be empty")
	}

	// Check for expected classes
	foundPerson := false
	foundCar := false
	foundDog := false

	for _, obj := range detection.Objects {
		switch obj.Class {
		case "person":
			foundPerson = true
		case "car":
			foundCar = true
		case "dog":
			foundDog = true
		}
		if obj.Confidence < 0.6 {
			t.Errorf("Confidence should be at least 0.6, got %f", obj.Confidence)
		}
	}

	if !foundPerson {
		t.Error("Expected to detect person")
	}
	if !foundCar {
		t.Error("Expected to detect car")
	}
	if !foundDog {
		t.Error("Expected to detect dog")
	}
}

// TestComputerVisionEngineTracking tests object tracking
func TestComputerVisionEngineTracking(t *testing.T) {
	config := CVConfig{
		EnableDetection:     true,
		EnableRecognition:   true,
		EnableSegmentation:  true,
		EnableTracking:      true,
		EnableMonitoring:    true,
		MonitorInterval:     30 * time.Second,
		EnablePersistence:   false,
		PersistencePath:     "",
		MaxModels:           50,
		DefaultFramework:    "opencv",
		EnableGPU:           true,
	}

	cve := NewComputerVisionEngine(config)

	// Simulated video frames
	frames := []string{
		"frame1_with_object_at_100_100",
		"frame2_with_object_at_110_110",
		"frame3_with_object_at_120_120",
		"frame4_with_object_at_130_130",
	}

	tracking, err := cve.TrackObjects(frames, map[string]interface{}{
		"tracker_type": "csrt",
		"initial_bbox": []int{90, 90, 20, 20},
	})
	if err != nil {
		t.Fatalf("Failed to track objects: %v", err)
	}

	if len(tracking.Tracks) == 0 {
		t.Fatal("Tracks should not be empty")
	}

	// Check track continuity
	previousPosition := []int{0, 0}
	for i, track := range tracking.Tracks {
		if i > 0 {
			dx := track.BoundingBox[0] - previousPosition[0]
			dy := track.BoundingBox[1] - previousPosition[1]
			if dx <= 0 || dy <= 0 {
				t.Errorf("Expected positive movement in frame %d", i)
			}
		}
		previousPosition = track.BoundingBox[:2]
	}
}

// BenchmarkComputerVisionEngineDetectObjects benchmarks object detection
func BenchmarkComputerVisionEngineDetectObjects(b *testing.B) {
	config := CVConfig{
		EnableDetection:     true,
		EnableRecognition:   false,
		EnableSegmentation:  false,
		EnableTracking:      false,
		EnableMonitoring:    false,
		MonitorInterval:     30 * time.Second,
		EnablePersistence:   false,
		PersistencePath:     "",
		MaxModels:           50,
		DefaultFramework:    "opencv",
		EnableGPU:           true,
	}

	cve := NewComputerVisionEngine(config)

	image := "benchmark_image_data"
	params := map[string]interface{}{
		"confidence_threshold": 0.5,
	}

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		_, err := cve.DetectObjects(image, params)
		if err != nil {
			b.Fatalf("Object detection failed: %v", err)
		}
	}
} 