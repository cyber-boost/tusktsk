package main

import (
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"time"
	"encoding/json"
	"reflect"
	"math/rand"
)

// TestCase represents a single test case
type TestCase struct {
	Name        string                 `json:"name"`
	Description string                 `json:"description"`
	Input       string                 `json:"input"`
	Expected    interface{}            `json:"expected"`
	Setup       func() error           `json:"-"`
	Teardown    func() error           `json:"-"`
	Timeout     time.Duration          `json:"timeout"`
	Tags        []string               `json:"tags"`
	Priority    string                 `json:"priority"` // low, medium, high, critical
	Category    string                 `json:"category"`
	Metadata    map[string]interface{} `json:"metadata"`
}

// TestResult represents the result of a test execution
type TestResult struct {
	TestCase   *TestCase  `json:"test_case"`
	Status     string     `json:"status"` // pass, fail, skip, error
	Duration   time.Duration `json:"duration"`
	Error      error      `json:"error,omitempty"`
	Output     interface{} `json:"output,omitempty"`
	Timestamp  time.Time  `json:"timestamp"`
	MemoryUsage uint64    `json:"memory_usage"`
	Assertions  int       `json:"assertions"`
}

// TestSuite represents a collection of related tests
type TestSuite struct {
	Name        string      `json:"name"`
	Description string      `json:"description"`
	TestCases   []*TestCase `json:"test_cases"`
	Setup       func() error `json:"-"`
	Teardown    func() error `json:"-"`
	Timeout     time.Duration `json:"timeout"`
	Parallel    bool        `json:"parallel"`
	Category    string      `json:"category"`
}

// TestRunner manages test execution and reporting
type TestRunner struct {
	suites       []*TestSuite
	results      []*TestResult
	config       *TestConfig
	reporter     TestReporter
	performance  *PerformanceOptimizer
}

// TestConfig holds testing configuration
type TestConfig struct {
	Parallel     bool          `json:"parallel"`
	Timeout      time.Duration `json:"timeout"`
	Verbose      bool          `json:"verbose"`
	StopOnError  bool          `json:"stop_on_error"`
	Categories   []string      `json:"categories"`
	Tags         []string      `json:"tags"`
	OutputDir    string        `json:"output_dir"`
	ReportFormat string        `json:"report_format"` // json, html, junit
	Seed         int64         `json:"seed"`
}

// TestReporter interface for different report formats
type TestReporter interface {
	Report(results []*TestResult, config *TestConfig) error
}

// JSONReporter generates JSON test reports
type JSONReporter struct{}

// HTMLReporter generates HTML test reports
type HTMLReporter struct{}

// JUnitReporter generates JUnit XML reports
type JUnitReporter struct{}

// NewTestRunner creates a new test runner
func NewTestRunner(config *TestConfig) *TestRunner {
	if config == nil {
		config = &TestConfig{
			Parallel:     false,
			Timeout:      30 * time.Second,
			Verbose:      false,
			StopOnError:  false,
			OutputDir:    "./test-reports",
			ReportFormat: "json",
			Seed:         time.Now().UnixNano(),
		}
	}
	
	// Set random seed for reproducible tests
	rand.Seed(config.Seed)
	
	return &TestRunner{
		suites:      make([]*TestSuite, 0),
		results:     make([]*TestResult, 0),
		config:      config,
		performance: NewPerformanceOptimizer(nil),
	}
}

// AddSuite adds a test suite to the runner
func (tr *TestRunner) AddSuite(suite *TestSuite) {
	tr.suites = append(tr.suites, suite)
}

// Run executes all test suites
func (tr *TestRunner) Run() error {
	startTime := time.Now()
	
	// Create output directory
	if err := os.MkdirAll(tr.config.OutputDir, 0755); err != nil {
		return fmt.Errorf("failed to create output directory: %w", err)
	}
	
	// Run test suites
	for _, suite := range tr.suites {
		if err := tr.runSuite(suite); err != nil {
			if tr.config.StopOnError {
				return err
			}
		}
	}
	
	// Generate report
	if err := tr.generateReport(); err != nil {
		return fmt.Errorf("failed to generate report: %w", err)
	}
	
	totalDuration := time.Since(startTime)
	fmt.Printf("Test execution completed in %v\n", totalDuration)
	
	return nil
}

// runSuite executes a single test suite
func (tr *TestRunner) runSuite(suite *TestSuite) error {
	fmt.Printf("Running test suite: %s\n", suite.Name)
	
	// Run suite setup
	if suite.Setup != nil {
		if err := suite.Setup(); err != nil {
			return fmt.Errorf("suite setup failed: %w", err)
		}
	}
	
	// Run test cases
	if suite.Parallel && tr.config.Parallel {
		tr.runSuiteParallel(suite)
	} else {
		tr.runSuiteSequential(suite)
	}
	
	// Run suite teardown
	if suite.Teardown != nil {
		if err := suite.Teardown(); err != nil {
			return fmt.Errorf("suite teardown failed: %w", err)
		}
	}
	
	return nil
}

// runSuiteSequential runs test cases sequentially
func (tr *TestRunner) runSuiteSequential(suite *TestSuite) {
	for _, testCase := range suite.TestCases {
		result := tr.runTestCase(testCase)
		tr.results = append(tr.results, result)
		
		if tr.config.Verbose {
			tr.printTestResult(result)
		}
		
		if result.Status == "fail" && tr.config.StopOnError {
			break
		}
	}
}

// runSuiteParallel runs test cases in parallel
func (tr *TestRunner) runSuiteParallel(suite *TestSuite) {
	results := make(chan *TestResult, len(suite.TestCases))
	
	for _, testCase := range suite.TestCases {
		go func(tc *TestCase) {
			result := tr.runTestCase(tc)
			results <- result
		}(testCase)
	}
	
	// Collect results
	for i := 0; i < len(suite.TestCases); i++ {
		result := <-results
		tr.results = append(tr.results, result)
		
		if tr.config.Verbose {
			tr.printTestResult(result)
		}
	}
}

// runTestCase executes a single test case
func (tr *TestRunner) runTestCase(testCase *TestCase) *TestResult {
	result := &TestResult{
		TestCase:  testCase,
		Status:    "pass",
		Timestamp: time.Now(),
	}
	
	startTime := time.Now()
	
	// Run test case setup
	if testCase.Setup != nil {
		if err := testCase.Setup(); err != nil {
			result.Status = "error"
			result.Error = fmt.Errorf("test setup failed: %w", err)
			result.Duration = time.Since(startTime)
			return result
		}
	}
	
	// Execute test
	done := make(chan bool, 1)
	go func() {
		defer func() {
			if r := recover(); r != nil {
				result.Status = "error"
				result.Error = fmt.Errorf("test panicked: %v", r)
			}
			done <- true
		}()
		
		// Parse input and compare with expected
		parser := NewEnhancedParser()
		parsed := parser.Parse(testCase.Input)
		
		if !reflect.DeepEqual(parsed, testCase.Expected) {
			result.Status = "fail"
			result.Error = fmt.Errorf("expected %v, got %v", testCase.Expected, parsed)
			result.Output = parsed
		} else {
			result.Output = parsed
		}
	}()
	
	// Wait for test completion or timeout
	timeout := testCase.Timeout
	if timeout == 0 {
		timeout = tr.config.Timeout
	}
	
	select {
	case <-done:
		// Test completed
	case <-time.After(timeout):
		result.Status = "error"
		result.Error = fmt.Errorf("test timed out after %v", timeout)
	}
	
	result.Duration = time.Since(startTime)
	
	// Run test case teardown
	if testCase.Teardown != nil {
		if err := testCase.Teardown(); err != nil {
			// Log teardown error but don't fail the test
			fmt.Printf("Warning: test teardown failed: %v\n", err)
		}
	}
	
	return result
}

// printTestResult prints a test result to console
func (tr *TestRunner) printTestResult(result *TestResult) {
	status := "✅"
	if result.Status == "fail" {
		status = "❌"
	} else if result.Status == "error" {
		status = "💥"
	} else if result.Status == "skip" {
		status = "⏭️"
	}
	
	fmt.Printf("%s %s (%v) - %s\n", 
		status, 
		result.TestCase.Name, 
		result.Duration,
		result.TestCase.Description)
	
	if result.Error != nil {
		fmt.Printf("  Error: %v\n", result.Error)
	}
}

// generateReport creates test reports
func (tr *TestRunner) generateReport() error {
	// Create appropriate reporter
	var reporter TestReporter
	switch tr.config.ReportFormat {
	case "json":
		reporter = &JSONReporter{}
	case "html":
		reporter = &HTMLReporter{}
	case "junit":
		reporter = &JUnitReporter{}
	default:
		reporter = &JSONReporter{}
	}
	
	// Generate report
	return reporter.Report(tr.results, tr.config)
}

// Report implements TestReporter for JSON format
func (jr *JSONReporter) Report(results []*TestResult, config *TestConfig) error {
	report := map[string]interface{}{
		"timestamp":    time.Now(),
		"config":       config,
		"results":      results,
		"summary":      jr.generateSummary(results),
		"performance":  jr.generatePerformanceSummary(results),
	}
	
	filename := filepath.Join(config.OutputDir, "test-report.json")
	file, err := os.Create(filename)
	if err != nil {
		return err
	}
	defer file.Close()
	
	encoder := json.NewEncoder(file)
	encoder.SetIndent("", "  ")
	return encoder.Encode(report)
}

// generateSummary creates a test summary
func (jr *JSONReporter) generateSummary(results []*TestResult) map[string]interface{} {
	total := len(results)
	passed := 0
	failed := 0
	skipped := 0
	errors := 0
	
	for _, result := range results {
		switch result.Status {
		case "pass":
			passed++
		case "fail":
			failed++
		case "skip":
			skipped++
		case "error":
			errors++
		}
	}
	
	return map[string]interface{}{
		"total":    total,
		"passed":   passed,
		"failed":   failed,
		"skipped":  skipped,
		"errors":   errors,
		"success_rate": float64(passed) / float64(total) * 100,
	}
}

// generatePerformanceSummary creates performance metrics
func (jr *JSONReporter) generatePerformanceSummary(results []*TestResult) map[string]interface{} {
	if len(results) == 0 {
		return map[string]interface{}{}
	}
	
	totalDuration := time.Duration(0)
	totalMemory := uint64(0)
	minDuration := results[0].Duration
	maxDuration := results[0].Duration
	
	for _, result := range results {
		totalDuration += result.Duration
		totalMemory += result.MemoryUsage
		
		if result.Duration < minDuration {
			minDuration = result.Duration
		}
		if result.Duration > maxDuration {
			maxDuration = result.Duration
		}
	}
	
	avgDuration := totalDuration / time.Duration(len(results))
	avgMemory := totalMemory / uint64(len(results))
	
	return map[string]interface{}{
		"total_duration":   totalDuration.String(),
		"average_duration": avgDuration.String(),
		"min_duration":     minDuration.String(),
		"max_duration":     maxDuration.String(),
		"total_memory":     totalMemory,
		"average_memory":   avgMemory,
	}
}

// Report implements TestReporter for HTML format
func (hr *HTMLReporter) Report(results []*TestResult, config *TestConfig) error {
	// Generate HTML report
	html := hr.generateHTML(results, config)
	
	filename := filepath.Join(config.OutputDir, "test-report.html")
	return os.WriteFile(filename, []byte(html), 0644)
}

// generateHTML creates HTML report content
func (hr *HTMLReporter) generateHTML(results []*TestResult, config *TestConfig) string {
	var sb strings.Builder
	
	sb.WriteString(`<!DOCTYPE html>
<html>
<head>
    <title>TuskLang Test Report</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        .header { background: #f0f0f0; padding: 20px; border-radius: 5px; }
        .summary { display: flex; gap: 20px; margin: 20px 0; }
        .metric { background: #e8f4fd; padding: 15px; border-radius: 5px; text-align: center; }
        .test-result { margin: 10px 0; padding: 10px; border-radius: 3px; }
        .pass { background: #d4edda; border-left: 4px solid #28a745; }
        .fail { background: #f8d7da; border-left: 4px solid #dc3545; }
        .error { background: #fff3cd; border-left: 4px solid #ffc107; }
        .skip { background: #e2e3e5; border-left: 4px solid #6c757d; }
    </style>
</head>
<body>
    <div class="header">
        <h1>TuskLang Test Report</h1>
        <p>Generated: ` + time.Now().Format("2006-01-02 15:04:05") + `</p>
    </div>`)
	
	// Add summary
	jsonReporter := &JSONReporter{}
	summary := jsonReporter.generateSummary(results)
	sb.WriteString(`
    <div class="summary">
        <div class="metric">
            <h3>Total</h3>
            <p>` + fmt.Sprintf("%d", summary["total"]) + `</p>
        </div>
        <div class="metric">
            <h3>Passed</h3>
            <p style="color: #28a745;">` + fmt.Sprintf("%d", summary["passed"]) + `</p>
        </div>
        <div class="metric">
            <h3>Failed</h3>
            <p style="color: #dc3545;">` + fmt.Sprintf("%d", summary["failed"]) + `</p>
        </div>
        <div class="metric">
            <h3>Success Rate</h3>
            <p>` + fmt.Sprintf("%.1f%%", summary["success_rate"]) + `</p>
        </div>
    </div>`)
	
	// Add test results
	sb.WriteString(`
    <h2>Test Results</h2>`)
	
	for _, result := range results {
		statusClass := result.Status
		statusIcon := "✅"
		if result.Status == "fail" {
			statusIcon = "❌"
		} else if result.Status == "error" {
			statusIcon = "💥"
		} else if result.Status == "skip" {
			statusIcon = "⏭️"
		}
		
		sb.WriteString(fmt.Sprintf(`
    <div class="test-result %s">
        <h3>%s %s</h3>
        <p><strong>Duration:</strong> %v</p>
        <p><strong>Description:</strong> %s</p>`, 
			statusClass, statusIcon, result.TestCase.Name, 
			result.Duration, result.TestCase.Description))
		
		if result.Error != nil {
			sb.WriteString(fmt.Sprintf(`
        <p><strong>Error:</strong> %v</p>`, result.Error))
		}
		
		sb.WriteString(`
    </div>`)
	}
	
	sb.WriteString(`
</body>
</html>`)
	
	return sb.String()
}

// Report implements TestReporter for JUnit format
func (jur *JUnitReporter) Report(results []*TestResult, config *TestConfig) error {
	// Generate JUnit XML report
	xml := jur.generateJUnitXML(results, config)
	
	filename := filepath.Join(config.OutputDir, "test-report.xml")
	return os.WriteFile(filename, []byte(xml), 0644)
}

// generateJUnitXML creates JUnit XML report
func (jur *JUnitReporter) generateJUnitXML(results []*TestResult, config *TestConfig) string {
	var sb strings.Builder
	
	sb.WriteString(`<?xml version="1.0" encoding="UTF-8"?>
<testsuites name="TuskLang Tests" time="0" tests="0" failures="0" errors="0" skipped="0">
    <testsuite name="TuskLang Parser Tests" time="0" tests="0" failures="0" errors="0" skipped="0">`)
	
	totalTests := 0
	totalFailures := 0
	totalErrors := 0
	totalSkipped := 0
	totalTime := time.Duration(0)
	
	for _, result := range results {
		totalTests++
		totalTime += result.Duration
		
		status := "passed"
		if result.Status == "fail" {
			totalFailures++
			status = "failed"
		} else if result.Status == "error" {
			totalErrors++
			status = "error"
		} else if result.Status == "skip" {
			totalSkipped++
			status = "skipped"
		}
		
		sb.WriteString(fmt.Sprintf(`
        <testcase name="%s" time="%.3f" status="%s">`, 
			result.TestCase.Name, result.Duration.Seconds(), status))
		
		if result.Error != nil {
			sb.WriteString(fmt.Sprintf(`
            <failure message="%s" type="%s">%v</failure>`, 
				result.Error.Error(), result.Status, result.Error))
		}
		
		sb.WriteString(`
        </testcase>`)
	}
	
	sb.WriteString(fmt.Sprintf(`
    </testsuite>
</testsuites>`, totalTime.Seconds(), totalTests, totalFailures, totalErrors, totalSkipped))
	
	return sb.String()
}

// CreateTestSuite creates a test suite with common TuskLang test cases
func CreateTestSuite(name string) *TestSuite {
	return &TestSuite{
		Name:        name,
		Description: "TuskLang parser test suite",
		TestCases:   make([]*TestCase, 0),
		Timeout:     30 * time.Second,
		Parallel:    false,
		Category:    "parser",
	}
}

// AddBasicTests adds basic syntax tests to a test suite
func (ts *TestSuite) AddBasicTests() {
	basicTests := []*TestCase{
		{
			Name:        "Simple Key-Value",
			Description: "Test basic key-value parsing",
			Input:       "name: \"John\"",
			Expected:    map[string]interface{}{"name": "John"},
			Category:    "syntax",
			Priority:    "high",
		},
		{
			Name:        "Numeric Values",
			Description: "Test numeric value parsing",
			Input:       "port: 8080\ncount: 42",
			Expected:    map[string]interface{}{"port": 8080, "count": 42},
			Category:    "syntax",
			Priority:    "high",
		},
		{
			Name:        "Boolean Values",
			Description: "Test boolean value parsing",
			Input:       "enabled: true\ndebug: false",
			Expected:    map[string]interface{}{"enabled": true, "debug": false},
			Category:    "syntax",
			Priority:    "high",
		},
		{
			Name:        "Array Values",
			Description: "Test array value parsing",
			Input:       "items: [\"a\", \"b\", \"c\"]",
			Expected:    map[string]interface{}{"items": []interface{}{"a", "b", "c"}},
			Category:    "syntax",
			Priority:    "medium",
		},
		{
			Name:        "Nested Objects",
			Description: "Test nested object parsing",
			Input:       "database {\n  host: \"localhost\"\n  port: 5432\n}",
			Expected:    map[string]interface{}{"database": map[string]interface{}{"host": "localhost", "port": 5432}},
			Category:    "syntax",
			Priority:    "medium",
		},
	}
	
	ts.TestCases = append(ts.TestCases, basicTests...)
}

// AddAdvancedTests adds advanced feature tests
func (ts *TestSuite) AddAdvancedTests() {
	advancedTests := []*TestCase{
		{
			Name:        "Global Variables",
			Description: "Test global variable interpolation",
			Input:       "$app_name: \"MyApp\"\nname: $app_name",
			Expected:    map[string]interface{}{"$app_name": "MyApp", "name": "MyApp"},
			Category:    "variables",
			Priority:    "medium",
		},
		{
			Name:        "Environment Variables",
			Description: "Test environment variable parsing",
			Input:       "host: @env(\"DB_HOST\", \"localhost\")",
			Expected:    map[string]interface{}{"host": "localhost"}, // Assuming env var not set
			Category:    "environment",
			Priority:    "medium",
		},
		{
			Name:        "Date Functions",
			Description: "Test date function parsing",
			Input:       "timestamp: @date(\"2006-01-02\")",
			Expected:    map[string]interface{}{"timestamp": time.Now().Format("2006-01-02")},
			Category:    "functions",
			Priority:    "low",
		},
		{
			Name:        "Range Syntax",
			Description: "Test range syntax parsing",
			Input:       "ports: 8000-9000",
			Expected:    map[string]interface{}{"ports": map[string]interface{}{"min": 8000, "max": 9000, "type": "range"}},
			Category:    "syntax",
			Priority:    "low",
		},
	}
	
	ts.TestCases = append(ts.TestCases, advancedTests...)
} 