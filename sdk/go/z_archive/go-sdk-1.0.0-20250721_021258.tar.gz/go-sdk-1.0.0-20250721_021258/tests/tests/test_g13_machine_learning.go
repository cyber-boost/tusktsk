package main

import (
	"fmt"
	"testing"
	"time"
)

// TestMachineLearningEngineBasic tests basic machine learning functionality
func TestMachineLearningEngineBasic(t *testing.T) {
	config := MLConfig{
		EnableTraining:      true,
		EnableInference:     true,
		EnableAutoML:        true,
		EnableMonitoring:    true,
		MonitorInterval:     30 * time.Second,
		EnablePersistence:   false,
		PersistencePath:     "",
		MaxModels:           100,
		RetentionPeriod:     365 * 24 * time.Hour, // 1 year
		DefaultAlgorithm:    "random_forest",
		EnableHyperparameterTuning: true,
	}

	mle := NewMachineLearningEngine(config)
	if mle == nil {
		t.Fatal("Failed to create MachineLearningEngine")
	}

	// Create a dataset
	dataset := &Dataset{
		ID:          "test-dataset",
		Name:        "Test Dataset",
		Description: "A test dataset for machine learning",
		Type:        "tabular",
		Features: []*Feature{
			{
				Name:     "feature1",
				Type:     "numeric",
				Required: true,
			},
			{
				Name:     "feature2",
				Type:     "numeric",
				Required: true,
			},
			{
				Name:     "feature3",
				Type:     "categorical",
				Required: true,
			},
		},
		Target: &Feature{
			Name:     "target",
			Type:     "numeric",
			Required: true,
		},
		Data: [][]interface{}{
			{1.0, 2.0, "A", 10.0},
			{2.0, 3.0, "B", 15.0},
			{3.0, 4.0, "A", 20.0},
			{4.0, 5.0, "B", 25.0},
			{5.0, 6.0, "A", 30.0},
		},
		CreatedAt: time.Now(),
		UpdatedAt: time.Now(),
		Metadata:  make(map[string]string),
	}

	// Register dataset
	err := mle.RegisterDataset(dataset)
	if err != nil {
		t.Fatalf("Failed to register dataset: %v", err)
	}

	// Create a model
	model := &Model{
		ID:          "test-model",
		Name:        "Test Model",
		Description: "A test machine learning model",
		Algorithm:   "random_forest",
		DatasetID:   "test-dataset",
		Type:        "regression",
		Config: map[string]interface{}{
			"n_estimators": 100,
			"max_depth":    10,
		},
		Status:    "untrained",
		CreatedAt: time.Now(),
		UpdatedAt: time.Now(),
		Metadata:  make(map[string]string),
	}

	// Register model
	err = mle.RegisterModel(model)
	if err != nil {
		t.Fatalf("Failed to register model: %v", err)
	}

	// Train model
	result, err := mle.TrainModel("test-model", map[string]interface{}{
		"test_size": 0.2,
		"random_state": 42,
	})
	if err != nil {
		t.Fatalf("Failed to train model: %v", err)
	}

	if result.ModelID != "test-model" {
		t.Errorf("Expected model ID 'test-model', got '%s'", result.ModelID)
	}

	if result.Status != "completed" {
		t.Errorf("Expected status 'completed', got '%s'", result.Status)
	}

	if result.Accuracy <= 0 {
		t.Errorf("Expected positive accuracy, got %f", result.Accuracy)
	}

	// Make prediction
	prediction, err := mle.Predict("test-model", map[string]interface{}{
		"feature1": 6.0,
		"feature2": 7.0,
		"feature3": "A",
	})
	if err != nil {
		t.Fatalf("Failed to make prediction: %v", err)
	}

	if prediction.ModelID != "test-model" {
		t.Errorf("Expected model ID 'test-model', got '%s'", prediction.ModelID)
	}

	if prediction.Prediction == nil {
		t.Fatal("Prediction should not be nil")
	}
}

// TestMachineLearningEngineAlgorithmManagement tests algorithm management
func TestMachineLearningEngineAlgorithmManagement(t *testing.T) {
	config := MLConfig{
		EnableTraining:      true,
		EnableInference:     true,
		EnableAutoML:        true,
		EnableMonitoring:    true,
		MonitorInterval:     30 * time.Second,
		EnablePersistence:   false,
		PersistencePath:     "",
		MaxModels:           100,
		RetentionPeriod:     365 * 24 * time.Hour,
		DefaultAlgorithm:    "random_forest",
		EnableHyperparameterTuning: true,
	}

	mle := NewMachineLearningEngine(config)

	// Create multiple models with different algorithms
	algorithms := []string{"random_forest", "linear_regression", "decision_tree", "svm"}

	for i, algorithm := range algorithms {
		model := &Model{
			ID:          fmt.Sprintf("model-%d", i),
			Name:        fmt.Sprintf("Model %d", i),
			Description: fmt.Sprintf("A test model with %s", algorithm),
			Algorithm:   algorithm,
			DatasetID:   "test-dataset",
			Type:        "regression",
			Config: map[string]interface{}{
				"random_state": 42,
			},
			Status:    "untrained",
			CreatedAt: time.Now(),
			UpdatedAt: time.Now(),
			Metadata:  make(map[string]string),
		}

		err := mle.RegisterModel(model)
		if err != nil {
			t.Fatalf("Failed to register model %d: %v", i, err)
		}
	}

	// Get model
	retrievedModel, err := mle.GetModel("model-0")
	if err != nil {
		t.Fatalf("Failed to get model: %v", err)
	}

	if retrievedModel.ID != "model-0" {
		t.Errorf("Expected model ID 'model-0', got '%s'", retrievedModel.ID)
	}

	// List models
	allModels := mle.ListModels()
	if len(allModels) < 4 {
		t.Fatalf("Expected at least 4 models, got %d", len(allModels))
	}

	found := make(map[string]bool)
	for _, model := range allModels {
		found[model.ID] = true
	}

	for i := 0; i < 4; i++ {
		modelID := fmt.Sprintf("model-%d", i)
		if !found[modelID] {
			t.Fatalf("Model %s should be in model list", modelID)
		}
	}
}

// TestMachineLearningEngineTrainingAndEvaluation tests training and evaluation
func TestMachineLearningEngineTrainingAndEvaluation(t *testing.T) {
	config := MLConfig{
		EnableTraining:      true,
		EnableInference:     true,
		EnableAutoML:        true,
		EnableMonitoring:    true,
		MonitorInterval:     30 * time.Second,
		EnablePersistence:   false,
		PersistencePath:     "",
		MaxModels:           100,
		RetentionPeriod:     365 * 24 * time.Hour,
		DefaultAlgorithm:    "random_forest",
		EnableHyperparameterTuning: true,
	}

	mle := NewMachineLearningEngine(config)

	// Create a larger dataset for training
	dataset := &Dataset{
		ID:          "training-dataset",
		Name:        "Training Dataset",
		Description: "A dataset for training tests",
		Type:        "tabular",
		Features: []*Feature{
			{
				Name:     "feature1",
				Type:     "numeric",
				Required: true,
			},
			{
				Name:     "feature2",
				Type:     "numeric",
				Required: true,
			},
		},
		Target: &Feature{
			Name:     "target",
			Type:     "numeric",
			Required: true,
		},
		Data: [][]interface{}{
			{1.0, 2.0, 10.0},
			{2.0, 3.0, 15.0},
			{3.0, 4.0, 20.0},
			{4.0, 5.0, 25.0},
			{5.0, 6.0, 30.0},
			{6.0, 7.0, 35.0},
			{7.0, 8.0, 40.0},
			{8.0, 9.0, 45.0},
			{9.0, 10.0, 50.0},
			{10.0, 11.0, 55.0},
		},
		CreatedAt: time.Now(),
		UpdatedAt: time.Now(),
		Metadata:  make(map[string]string),
	}

	// Register dataset
	err := mle.RegisterDataset(dataset)
	if err != nil {
		t.Fatalf("Failed to register dataset: %v", err)
	}

	// Create and train multiple models
	models := []*Model{
		{
			ID:          "train-model-1",
			Name:        "Training Model 1",
			Description: "First training model",
			Algorithm:   "linear_regression",
			DatasetID:   "training-dataset",
			Type:        "regression",
			Config:      make(map[string]interface{}),
			Status:      "untrained",
			CreatedAt:   time.Now(),
			UpdatedAt:   time.Now(),
			Metadata:    make(map[string]string),
		},
		{
			ID:          "train-model-2",
			Name:        "Training Model 2",
			Description: "Second training model",
			Algorithm:   "random_forest",
			DatasetID:   "training-dataset",
			Type:        "regression",
			Config: map[string]interface{}{
				"n_estimators": 50,
				"max_depth":    5,
			},
			Status:    "untrained",
			CreatedAt: time.Now(),
			UpdatedAt: time.Now(),
			Metadata:  make(map[string]string),
		},
	}

	// Register and train models
	for _, model := range models {
		err := mle.RegisterModel(model)
		if err != nil {
			t.Fatalf("Failed to register model %s: %v", model.ID, err)
		}

		result, err := mle.TrainModel(model.ID, map[string]interface{}{
			"test_size":    0.3,
			"random_state": 42,
		})
		if err != nil {
			t.Fatalf("Failed to train model %s: %v", model.ID, err)
		}

		if result.Status != "completed" {
			t.Errorf("Expected status 'completed' for model %s, got '%s'", model.ID, result.Status)
		}

		if result.Accuracy <= 0 {
			t.Errorf("Expected positive accuracy for model %s, got %f", model.ID, result.Accuracy)
		}
	}

	// Evaluate models
	for _, model := range models {
		evaluation, err := mle.EvaluateModel(model.ID, map[string]interface{}{
			"test_size": 0.3,
		})
		if err != nil {
			t.Fatalf("Failed to evaluate model %s: %v", model.ID, err)
		}

		if evaluation.ModelID != model.ID {
			t.Errorf("Expected model ID %s, got %s", model.ID, evaluation.ModelID)
		}

		if evaluation.Metrics == nil {
			t.Errorf("Evaluation metrics should not be nil for model %s", model.ID)
		}
	}
}

// TestMachineLearningEngineAutoML tests AutoML functionality
func TestMachineLearningEngineAutoML(t *testing.T) {
	config := MLConfig{
		EnableTraining:      true,
		EnableInference:     true,
		EnableAutoML:        true,
		EnableMonitoring:    true,
		MonitorInterval:     30 * time.Second,
		EnablePersistence:   false,
		PersistencePath:     "",
		MaxModels:           100,
		RetentionPeriod:     365 * 24 * time.Hour,
		DefaultAlgorithm:    "random_forest",
		EnableHyperparameterTuning: true,
	}

	mle := NewMachineLearningEngine(config)

	// Create AutoML experiment
	experiment := &AutoMLExperiment{
		ID:          "automl-experiment",
		Name:        "AutoML Experiment",
		Description: "An AutoML experiment for testing",
		DatasetID:   "test-dataset",
		Type:        "regression",
		Config: map[string]interface{}{
			"max_models":          10,
			"time_limit":          300, // 5 minutes
			"algorithms":          []string{"random_forest", "linear_regression", "decision_tree"},
			"hyperparameter_tuning": true,
		},
		Status:    "pending",
		CreatedAt: time.Now(),
		UpdatedAt: time.Now(),
		Metadata:  make(map[string]string),
	}

	// Register experiment
	err := mle.RegisterAutoMLExperiment(experiment)
	if err != nil {
		t.Fatalf("Failed to register AutoML experiment: %v", err)
	}

	// Start AutoML experiment
	result, err := mle.StartAutoMLExperiment("automl-experiment")
	if err != nil {
		t.Fatalf("Failed to start AutoML experiment: %v", err)
	}

	if result.ExperimentID != "automl-experiment" {
		t.Errorf("Expected experiment ID 'automl-experiment', got '%s'", result.ExperimentID)
	}

	// Wait for AutoML to complete (or timeout)
	time.Sleep(1 * time.Minute)

	// Get experiment results
	experimentResults := mle.GetAutoMLResults("automl-experiment")
	if experimentResults == nil {
		t.Fatal("AutoML results should not be nil")
	}

	// Verify that models were created
	models := mle.ListModels()
	automlModels := 0
	for _, model := range models {
		if model.Metadata["automl_experiment"] == "automl-experiment" {
			automlModels++
		}
	}

	if automlModels == 0 {
		t.Log("No AutoML models were created (this might be expected for short experiments)")
	}
}

// TestMachineLearningEngineHyperparameterTuning tests hyperparameter tuning
func TestMachineLearningEngineHyperparameterTuning(t *testing.T) {
	config := MLConfig{
		EnableTraining:      true,
		EnableInference:     true,
		EnableAutoML:        true,
		EnableMonitoring:    true,
		MonitorInterval:     30 * time.Second,
		EnablePersistence:   false,
		PersistencePath:     "",
		MaxModels:           100,
		RetentionPeriod:     365 * 24 * time.Hour,
		DefaultAlgorithm:    "random_forest",
		EnableHyperparameterTuning: true,
	}

	mle := NewMachineLearningEngine(config)

	// Create hyperparameter tuning experiment
	tuningExperiment := &HyperparameterTuningExperiment{
		ID:          "tuning-experiment",
		Name:        "Hyperparameter Tuning Experiment",
		Description: "A hyperparameter tuning experiment",
		ModelID:     "test-model",
		Algorithm:   "random_forest",
		Type:        "regression",
		Config: map[string]interface{}{
			"n_trials":          10,
			"timeout":           300, // 5 minutes
			"hyperparameters": map[string]interface{}{
				"n_estimators": []int{50, 100, 200},
				"max_depth":    []int{5, 10, 15},
				"min_samples_split": []int{2, 5, 10},
			},
		},
		Status:    "pending",
		CreatedAt: time.Now(),
		UpdatedAt: time.Now(),
		Metadata:  make(map[string]string),
	}

	// Register tuning experiment
	err := mle.RegisterHyperparameterTuningExperiment(tuningExperiment)
	if err != nil {
		t.Fatalf("Failed to register tuning experiment: %v", err)
	}

	// Start tuning experiment
	result, err := mle.StartHyperparameterTuning("tuning-experiment")
	if err != nil {
		t.Fatalf("Failed to start tuning experiment: %v", err)
	}

	if result.ExperimentID != "tuning-experiment" {
		t.Errorf("Expected experiment ID 'tuning-experiment', got '%s'", result.ExperimentID)
	}

	// Wait for tuning to complete (or timeout)
	time.Sleep(1 * time.Minute)

	// Get tuning results
	tuningResults := mle.GetHyperparameterTuningResults("tuning-experiment")
	if tuningResults == nil {
		t.Fatal("Tuning results should not be nil")
	}

	// Verify that best parameters were found
	if tuningResults.BestParameters == nil {
		t.Log("No best parameters found (this might be expected for short experiments)")
	}
}

// TestMachineLearningEngineModelManagement tests model management
func TestMachineLearningEngineModelManagement(t *testing.T) {
	config := MLConfig{
		EnableTraining:      true,
		EnableInference:     true,
		EnableAutoML:        true,
		EnableMonitoring:    true,
		MonitorInterval:     30 * time.Second,
		EnablePersistence:   false,
		PersistencePath:     "",
		MaxModels:           100,
		RetentionPeriod:     365 * 24 * time.Hour,
		DefaultAlgorithm:    "random_forest",
		EnableHyperparameterTuning: true,
	}

	mle := NewMachineLearningEngine(config)

	// Create multiple models
	models := []*Model{
		{
			ID:          "manage-model-1",
			Name:        "Management Model 1",
			Description: "First management model",
			Algorithm:   "linear_regression",
			DatasetID:   "test-dataset",
			Type:        "regression",
			Config:      make(map[string]interface{}),
			Status:      "untrained",
			CreatedAt:   time.Now(),
			UpdatedAt:   time.Now(),
			Metadata:    make(map[string]string),
		},
		{
			ID:          "manage-model-2",
			Name:        "Management Model 2",
			Description: "Second management model",
			Algorithm:   "decision_tree",
			DatasetID:   "test-dataset",
			Type:        "regression",
			Config:      make(map[string]interface{}),
			Status:      "untrained",
			CreatedAt:   time.Now(),
			UpdatedAt:   time.Now(),
			Metadata:    make(map[string]string),
		},
	}

	// Register models
	for _, model := range models {
		err := mle.RegisterModel(model)
		if err != nil {
			t.Fatalf("Failed to register model %s: %v", model.ID, err)
		}
	}

	// Get model
	retrievedModel, err := mle.GetModel("manage-model-1")
	if err != nil {
		t.Fatalf("Failed to get model: %v", err)
	}

	if retrievedModel.ID != "manage-model-1" {
		t.Errorf("Expected model ID 'manage-model-1', got '%s'", retrievedModel.ID)
	}

	// List models
	allModels := mle.ListModels()
	if len(allModels) < 2 {
		t.Fatalf("Expected at least 2 models, got %d", len(allModels))
	}

	found := make(map[string]bool)
	for _, model := range allModels {
		found[model.ID] = true
	}

	if !found["manage-model-1"] {
		t.Fatal("Manage-model-1 should be in model list")
	}

	if !found["manage-model-2"] {
		t.Fatal("Manage-model-2 should be in model list")
	}

	// Update model
	retrievedModel.Description = "Updated description"
	err = mle.UpdateModel(retrievedModel)
	if err != nil {
		t.Fatalf("Failed to update model: %v", err)
	}

	// Verify update
	updatedModel, err := mle.GetModel("manage-model-1")
	if err != nil {
		t.Fatalf("Failed to get updated model: %v", err)
	}

	if updatedModel.Description != "Updated description" {
		t.Errorf("Expected updated description, got '%s'", updatedModel.Description)
	}
}

// TestMachineLearningEngineMonitoring tests monitoring functionality
func TestMachineLearningEngineMonitoring(t *testing.T) {
	config := MLConfig{
		EnableTraining:      true,
		EnableInference:     true,
		EnableAutoML:        true,
		EnableMonitoring:    true,
		MonitorInterval:     30 * time.Second,
		EnablePersistence:   false,
		PersistencePath:     "",
		MaxModels:           100,
		RetentionPeriod:     365 * 24 * time.Hour,
		DefaultAlgorithm:    "random_forest",
		EnableHyperparameterTuning: true,
	}

	mle := NewMachineLearningEngine(config)

	// Create and train multiple models to generate metrics
	for i := 0; i < 3; i++ {
		model := &Model{
			ID:          fmt.Sprintf("monitor-model-%d", i),
			Name:        fmt.Sprintf("Monitor Model %d", i),
			Description: fmt.Sprintf("A model for monitoring tests %d", i),
			Algorithm:   "linear_regression",
			DatasetID:   "test-dataset",
			Type:        "regression",
			Config:      make(map[string]interface{}),
			Status:      "untrained",
			CreatedAt:   time.Now(),
			UpdatedAt:   time.Now(),
			Metadata:    make(map[string]string),
		}

		err := mle.RegisterModel(model)
		if err != nil {
			t.Fatalf("Failed to register model %d: %v", i, err)
		}

		_, err = mle.TrainModel(model.ID, map[string]interface{}{
			"test_size":    0.2,
			"random_state": 42,
		})
		if err != nil {
			t.Fatalf("Failed to train model %d: %v", i, err)
		}
	}

	// Wait for monitoring to collect metrics
	time.Sleep(1 * time.Minute)

	// Get statistics
	stats := mle.GetStats()
	if stats == nil {
		t.Fatal("Statistics should not be nil")
	}

	// Verify statistics contain expected data
	if stats["total_models"] == nil {
		t.Error("Statistics should contain total_models")
	}

	if stats["trained_models"] == nil {
		t.Error("Statistics should contain trained_models")
	}

	if stats["total_datasets"] == nil {
		t.Error("Statistics should contain total_datasets")
	}

	if stats["total_predictions"] == nil {
		t.Error("Statistics should contain total_predictions")
	}
}

// BenchmarkMachineLearningEngineTrainModel benchmarks model training
func BenchmarkMachineLearningEngineTrainModel(b *testing.B) {
	config := MLConfig{
		EnableTraining:      true,
		EnableInference:     true,
		EnableAutoML:        false,
		EnableMonitoring:    false,
		MonitorInterval:     30 * time.Second,
		EnablePersistence:   false,
		PersistencePath:     "",
		MaxModels:           100,
		RetentionPeriod:     365 * 24 * time.Hour,
		DefaultAlgorithm:    "random_forest",
		EnableHyperparameterTuning: false,
	}

	mle := NewMachineLearningEngine(config)

	// Create model
	model := &Model{
		ID:          "benchmark-model",
		Name:        "Benchmark Model",
		Description: "A model for benchmarking",
		Algorithm:   "linear_regression",
		DatasetID:   "test-dataset",
		Type:        "regression",
		Config:      make(map[string]interface{}),
		Status:      "untrained",
		CreatedAt:   time.Now(),
		UpdatedAt:   time.Now(),
		Metadata:    make(map[string]string),
	}

	err := mle.RegisterModel(model)
	if err != nil {
		b.Fatalf("Failed to register model: %v", err)
	}

	params := map[string]interface{}{
		"test_size":    0.2,
		"random_state": 42,
	}

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		_, err := mle.TrainModel("benchmark-model", params)
		if err != nil {
			b.Fatalf("Model training failed: %v", err)
		}
	}
}

// BenchmarkMachineLearningEnginePredict benchmarks prediction
func BenchmarkMachineLearningEnginePredict(b *testing.B) {
	config := MLConfig{
		EnableTraining:      true,
		EnableInference:     true,
		EnableAutoML:        false,
		EnableMonitoring:    false,
		MonitorInterval:     30 * time.Second,
		EnablePersistence:   false,
		PersistencePath:     "",
		MaxModels:           100,
		RetentionPeriod:     365 * 24 * time.Hour,
		DefaultAlgorithm:    "random_forest",
		EnableHyperparameterTuning: false,
	}

	mle := NewMachineLearningEngine(config)

	// Create and train model
	model := &Model{
		ID:          "predict-benchmark-model",
		Name:        "Predict Benchmark Model",
		Description: "A model for prediction benchmarking",
		Algorithm:   "linear_regression",
		DatasetID:   "test-dataset",
		Type:        "regression",
		Config:      make(map[string]interface{}),
		Status:      "untrained",
		CreatedAt:   time.Now(),
		UpdatedAt:   time.Now(),
		Metadata:    make(map[string]string),
	}

	err := mle.RegisterModel(model)
	if err != nil {
		b.Fatalf("Failed to register model: %v", err)
	}

	_, err = mle.TrainModel("predict-benchmark-model", map[string]interface{}{
		"test_size":    0.2,
		"random_state": 42,
	})
	if err != nil {
		b.Fatalf("Failed to train model: %v", err)
	}

	input := map[string]interface{}{
		"feature1": 5.0,
		"feature2": 6.0,
		"feature3": "A",
	}

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		_, err := mle.Predict("predict-benchmark-model", input)
		if err != nil {
			b.Fatalf("Prediction failed: %v", err)
		}
	}
} 