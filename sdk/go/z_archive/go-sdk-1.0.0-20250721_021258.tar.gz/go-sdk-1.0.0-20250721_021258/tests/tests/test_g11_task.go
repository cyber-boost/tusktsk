package main

import (
	"fmt"
	"testing"
	"time"
)

// TestTaskManagerBasic tests basic task management functionality
func TestTaskManagerBasic(t *testing.T) {
	config := TaskConfig{
		MaxConcurrentTasks: 10,
		DefaultTimeout:     5 * time.Minute,
		EnableRetry:        true,
		MaxRetries:         3,
		EnableMonitoring:   true,
		MonitorInterval:    30 * time.Second,
		EnablePersistence:  false,
		PersistencePath:    "",
	}

	tm := NewTaskManager(config)
	if tm == nil {
		t.Fatal("Failed to create TaskManager")
	}

	// Create a simple task
	task := &Task{
		ID:          "test-task",
		Name:        "Test Task",
		Description: "A simple test task",
		Handler:     "test_handler",
		Input:       map[string]string{"message": "Hello, World!"},
		Output:      map[string]string{"result": "success"},
		Timeout:     30 * time.Second,
		Priority:    1,
		Tags:        []string{"test", "simple"},
		CreatedAt:   time.Now(),
		UpdatedAt:   time.Now(),
		Metadata:    make(map[string]string),
	}

	// Register task
	err := tm.RegisterTask(task)
	if err != nil {
		t.Fatalf("Failed to register task: %v", err)
	}

	// Execute task
	input := map[string]interface{}{
		"user": "testuser",
		"data": "testdata",
	}

	execution, err := tm.ExecuteTask("test-task", input)
	if err != nil {
		t.Fatalf("Failed to execute task: %v", err)
	}

	if execution.TaskID != "test-task" {
		t.Errorf("Expected task ID 'test-task', got '%s'", execution.TaskID)
	}

	if execution.Status != "completed" {
		t.Errorf("Expected status 'completed', got '%s'", execution.Status)
	}

	// Verify execution details
	if execution.StartedAt == nil {
		t.Fatal("Execution should have start time")
	}

	if execution.CompletedAt == nil {
		t.Fatal("Execution should have completion time")
	}

	if execution.Duration <= 0 {
		t.Fatal("Execution should have positive duration")
	}
}

// TestTaskManagerTaskManagement tests task management operations
func TestTaskManagerTaskManagement(t *testing.T) {
	config := TaskConfig{
		MaxConcurrentTasks: 10,
		DefaultTimeout:     5 * time.Minute,
		EnableRetry:        true,
		MaxRetries:         3,
		EnableMonitoring:   true,
		MonitorInterval:    30 * time.Second,
		EnablePersistence:  false,
		PersistencePath:    "",
	}

	tm := NewTaskManager(config)

	// Create multiple tasks
	tasks := []*Task{
		{
			ID:          "task1",
			Name:        "Task 1",
			Description: "First test task",
			Handler:     "handler1",
			Input:       map[string]string{"data": "task1_data"},
			Output:      map[string]string{"result": "task1_result"},
			Timeout:     30 * time.Second,
			Priority:    1,
			Tags:        []string{"test", "task1"},
			CreatedAt:   time.Now(),
			UpdatedAt:   time.Now(),
			Metadata:    make(map[string]string),
		},
		{
			ID:          "task2",
			Name:        "Task 2",
			Description: "Second test task",
			Handler:     "handler2",
			Input:       map[string]string{"data": "task2_data"},
			Output:      map[string]string{"result": "task2_result"},
			Timeout:     30 * time.Second,
			Priority:    2,
			Tags:        []string{"test", "task2"},
			CreatedAt:   time.Now(),
			UpdatedAt:   time.Now(),
			Metadata:    make(map[string]string),
		},
	}

	// Register tasks
	for _, task := range tasks {
		err := tm.RegisterTask(task)
		if err != nil {
			t.Fatalf("Failed to register task %s: %v", task.ID, err)
		}
	}

	// Get task
	retrievedTask, err := tm.GetTask("task1")
	if err != nil {
		t.Fatalf("Failed to get task: %v", err)
	}

	if retrievedTask.ID != "task1" {
		t.Errorf("Expected task ID 'task1', got '%s'", retrievedTask.ID)
	}

	// List tasks
	allTasks := tm.ListTasks()
	if len(allTasks) < 2 {
		t.Fatalf("Expected at least 2 tasks, got %d", len(allTasks))
	}

	found := make(map[string]bool)
	for _, task := range allTasks {
		found[task.ID] = true
	}

	if !found["task1"] {
		t.Fatal("Task1 should be in task list")
	}

	if !found["task2"] {
		t.Fatal("Task2 should be in task list")
	}
}

// TestTaskManagerTaskScheduling tests task scheduling functionality
func TestTaskManagerTaskScheduling(t *testing.T) {
	config := TaskConfig{
		MaxConcurrentTasks: 10,
		DefaultTimeout:     5 * time.Minute,
		EnableRetry:        true,
		MaxRetries:         3,
		EnableMonitoring:   true,
		MonitorInterval:    30 * time.Second,
		EnablePersistence:  false,
		PersistencePath:    "",
	}

	tm := NewTaskManager(config)

	// Create task
	task := &Task{
		ID:          "scheduled-task",
		Name:        "Scheduled Task",
		Description: "A task for scheduling tests",
		Handler:     "scheduled_handler",
		Input:       map[string]string{"data": "scheduled_data"},
		Output:      map[string]string{"result": "scheduled_result"},
		Timeout:     30 * time.Second,
		Priority:    1,
		Tags:        []string{"test", "scheduled"},
		CreatedAt:   time.Now(),
		UpdatedAt:   time.Now(),
		Metadata:    make(map[string]string),
	}

	// Register task
	err := tm.RegisterTask(task)
	if err != nil {
		t.Fatalf("Failed to register task: %v", err)
	}

	// Schedule task
	schedule, err := tm.ScheduleTask("scheduled-task", "*/1 * * * *") // Every minute
	if err != nil {
		t.Fatalf("Failed to schedule task: %v", err)
	}

	if schedule.TaskID != "scheduled-task" {
		t.Errorf("Expected task ID 'scheduled-task', got '%s'", schedule.TaskID)
	}

	if !schedule.Enabled {
		t.Fatal("Schedule should be enabled")
	}

	// Get schedule
	retrievedSchedule, err := tm.GetSchedule(schedule.ID)
	if err != nil {
		t.Fatalf("Failed to get schedule: %v", err)
	}

	if retrievedSchedule.ID != schedule.ID {
		t.Errorf("Expected schedule ID %s, got %s", schedule.ID, retrievedSchedule.ID)
	}

	// List schedules
	schedules := tm.ListSchedules()
	if len(schedules) == 0 {
		t.Fatal("Should have at least one schedule")
	}

	found := false
	for _, s := range schedules {
		if s.ID == schedule.ID {
			found = true
			break
		}
	}

	if !found {
		t.Fatal("Created schedule should be in schedule list")
	}

	// Disable schedule
	err = tm.DisableSchedule(schedule.ID)
	if err != nil {
		t.Fatalf("Failed to disable schedule: %v", err)
	}

	// Enable schedule
	err = tm.EnableSchedule(schedule.ID)
	if err != nil {
		t.Fatalf("Failed to enable schedule: %v", err)
	}

	// Wait for scheduled execution
	time.Sleep(2 * time.Minute)

	// Check that task was executed
	executions := tm.ListExecutions()
	found = false
	for _, execution := range executions {
		if execution.TaskID == "scheduled-task" {
			found = true
			break
		}
	}

	if !found {
		t.Fatal("Scheduled task should have been executed")
	}
}

// TestTaskManagerTaskExecution tests task execution management
func TestTaskManagerTaskExecution(t *testing.T) {
	config := TaskConfig{
		MaxConcurrentTasks: 10,
		DefaultTimeout:     5 * time.Minute,
		EnableRetry:        true,
		MaxRetries:         3,
		EnableMonitoring:   true,
		MonitorInterval:    30 * time.Second,
		EnablePersistence:  false,
		PersistencePath:    "",
	}

	tm := NewTaskManager(config)

	// Create task
	task := &Task{
		ID:          "execution-task",
		Name:        "Execution Task",
		Description: "A task for execution tests",
		Handler:     "execution_handler",
		Input:       map[string]string{"data": "execution_data"},
		Output:      map[string]string{"result": "execution_result"},
		Timeout:     30 * time.Second,
		Priority:    1,
		Tags:        []string{"test", "execution"},
		CreatedAt:   time.Now(),
		UpdatedAt:   time.Now(),
		Metadata:    make(map[string]string),
	}

	// Register task
	err := tm.RegisterTask(task)
	if err != nil {
		t.Fatalf("Failed to register task: %v", err)
	}

	// Execute task multiple times
	executions := make([]*TaskExecution, 3)
	for i := 0; i < 3; i++ {
		input := map[string]interface{}{
			"index": i,
			"data":  "execution test data",
		}

		execution, err := tm.ExecuteTask("execution-task", input)
		if err != nil {
			t.Fatalf("Failed to execute task %d: %v", i, err)
		}

		executions[i] = execution
	}

	// Get execution
	retrievedExecution, err := tm.GetExecution(executions[0].ID)
	if err != nil {
		t.Fatalf("Failed to get execution: %v", err)
	}

	if retrievedExecution.ID != executions[0].ID {
		t.Errorf("Expected execution ID %s, got %s", executions[0].ID, retrievedExecution.ID)
	}

	// List executions
	allExecutions := tm.ListExecutions()
	if len(allExecutions) < 3 {
		t.Fatalf("Expected at least 3 executions, got %d", len(allExecutions))
	}

	// Cancel execution (if still running)
	err = tm.CancelExecution(executions[0].ID)
	if err != nil {
		// It's okay if the execution is already completed
		t.Logf("Could not cancel execution (likely already completed): %v", err)
	}
}

// TestTaskManagerRetryPolicy tests task retry functionality
func TestTaskManagerRetryPolicy(t *testing.T) {
	config := TaskConfig{
		MaxConcurrentTasks: 10,
		DefaultTimeout:     5 * time.Minute,
		EnableRetry:        true,
		MaxRetries:         3,
		EnableMonitoring:   true,
		MonitorInterval:    30 * time.Second,
		EnablePersistence:  false,
		PersistencePath:    "",
	}

	tm := NewTaskManager(config)

	// Create task with retry policy
	task := &Task{
		ID:          "retry-task",
		Name:        "Retry Task",
		Description: "A task with retry policy",
		Handler:     "failing_handler",
		Input:       map[string]string{"attempt": "retry_count"},
		Output:      map[string]string{"result": "success"},
		Timeout:     30 * time.Second,
		RetryPolicy: &RetryPolicy{
			MaxRetries: 3,
			Delay:      1 * time.Second,
			Backoff:    "exponential",
			MaxDelay:   10 * time.Second,
		},
		Priority:  1,
		Tags:      []string{"test", "retry"},
		CreatedAt: time.Now(),
		UpdatedAt: time.Now(),
		Metadata:  make(map[string]string),
	}

	// Register task
	err := tm.RegisterTask(task)
	if err != nil {
		t.Fatalf("Failed to register task: %v", err)
	}

	// Execute task
	input := map[string]interface{}{
		"data": "retry test data",
	}

	execution, err := tm.ExecuteTask("retry-task", input)
	if err != nil {
		t.Fatalf("Failed to execute task: %v", err)
	}

	// Check retry behavior
	if execution.RetryCount < 1 {
		t.Errorf("Expected retry count >= 1, got %d", execution.RetryCount)
	}

	// Check that the task eventually completed or failed
	if execution.Status != "completed" && execution.Status != "failed" {
		t.Errorf("Expected status 'completed' or 'failed', got '%s'", execution.Status)
	}
}

// TestTaskManagerConcurrentExecution tests concurrent task execution
func TestTaskManagerConcurrentExecution(t *testing.T) {
	config := TaskConfig{
		MaxConcurrentTasks: 5,
		DefaultTimeout:     5 * time.Minute,
		EnableRetry:        false,
		MaxRetries:         0,
		EnableMonitoring:   true,
		MonitorInterval:    30 * time.Second,
		EnablePersistence:  false,
		PersistencePath:    "",
	}

	tm := NewTaskManager(config)

	// Create task
	task := &Task{
		ID:          "concurrent-task",
		Name:        "Concurrent Task",
		Description: "A task for concurrent execution tests",
		Handler:     "concurrent_handler",
		Input:       map[string]string{"data": "concurrent_data"},
		Output:      map[string]string{"result": "concurrent_result"},
		Timeout:     30 * time.Second,
		Priority:    1,
		Tags:        []string{"test", "concurrent"},
		CreatedAt:   time.Now(),
		UpdatedAt:   time.Now(),
		Metadata:    make(map[string]string),
	}

	// Register task
	err := tm.RegisterTask(task)
	if err != nil {
		t.Fatalf("Failed to register task: %v", err)
	}

	// Execute multiple tasks concurrently
	executions := make([]*TaskExecution, 10)
	for i := 0; i < 10; i++ {
		input := map[string]interface{}{
			"index": i,
			"data":  "concurrent test data",
		}

		execution, err := tm.ExecuteTask("concurrent-task", input)
		if err != nil {
			t.Fatalf("Failed to execute task %d: %v", i, err)
		}

		executions[i] = execution
	}

	// Wait for all executions to complete
	time.Sleep(2 * time.Second)

	// Check that all executions completed
	completedCount := 0
	for _, execution := range executions {
		if execution.Status == "completed" {
			completedCount++
		}
	}

	if completedCount < 5 {
		t.Errorf("Expected at least 5 completed executions, got %d", completedCount)
	}
}

// TestTaskManagerMonitoring tests task monitoring functionality
func TestTaskManagerMonitoring(t *testing.T) {
	config := TaskConfig{
		MaxConcurrentTasks: 10,
		DefaultTimeout:     5 * time.Minute,
		EnableRetry:        false,
		MaxRetries:         0,
		EnableMonitoring:   true,
		MonitorInterval:    30 * time.Second,
		EnablePersistence:  false,
		PersistencePath:    "",
	}

	tm := NewTaskManager(config)

	// Create and execute multiple tasks to generate metrics
	for i := 0; i < 5; i++ {
		task := &Task{
			ID:          fmt.Sprintf("monitor-task-%d", i),
			Name:        fmt.Sprintf("Monitor Task %d", i),
			Description: "A task for monitoring tests",
			Handler:     "monitor_handler",
			Input:       map[string]string{"index": fmt.Sprintf("%d", i)},
			Output:      map[string]string{"result": "monitor_result"},
			Timeout:     30 * time.Second,
			Priority:    1,
			Tags:        []string{"test", "monitor"},
			CreatedAt:   time.Now(),
			UpdatedAt:   time.Now(),
			Metadata:    make(map[string]string),
		}

		err := tm.RegisterTask(task)
		if err != nil {
			t.Fatalf("Failed to register task %d: %v", i, err)
		}

		input := map[string]interface{}{
			"index": i,
		}

		_, err = tm.ExecuteTask(task.ID, input)
		if err != nil {
			t.Fatalf("Failed to execute task %d: %v", i, err)
		}
	}

	// Wait for monitoring to collect metrics
	time.Sleep(1 * time.Minute)

	// Get statistics
	stats := tm.GetStats()
	if stats == nil {
		t.Fatal("Statistics should not be nil")
	}

	// Verify statistics contain expected data
	if stats["total_tasks"] == nil {
		t.Error("Statistics should contain total_tasks")
	}

	if stats["total_executions"] == nil {
		t.Error("Statistics should contain total_executions")
	}

	if stats["successful_executions"] == nil {
		t.Error("Statistics should contain successful_executions")
	}

	if stats["failed_executions"] == nil {
		t.Error("Statistics should contain failed_executions")
	}
}

// BenchmarkTaskManagerExecuteTask benchmarks task execution
func BenchmarkTaskManagerExecuteTask(b *testing.B) {
	config := TaskConfig{
		MaxConcurrentTasks: 10,
		DefaultTimeout:     5 * time.Minute,
		EnableRetry:        false,
		MaxRetries:         0,
		EnableMonitoring:   false,
		MonitorInterval:    30 * time.Second,
		EnablePersistence:  false,
		PersistencePath:    "",
	}

	tm := NewTaskManager(config)

	// Create task
	task := &Task{
		ID:          "benchmark-task",
		Name:        "Benchmark Task",
		Description: "A task for benchmarking",
		Handler:     "benchmark_handler",
		Input:       map[string]string{"data": "benchmark_data"},
		Output:      map[string]string{"result": "benchmark_result"},
		Timeout:     30 * time.Second,
		Priority:    1,
		Tags:        []string{"test", "benchmark"},
		CreatedAt:   time.Now(),
		UpdatedAt:   time.Now(),
		Metadata:    make(map[string]string),
	}

	err := tm.RegisterTask(task)
	if err != nil {
		b.Fatalf("Failed to register task: %v", err)
	}

	input := map[string]interface{}{
		"data": "benchmark test data",
	}

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		_, err := tm.ExecuteTask("benchmark-task", input)
		if err != nil {
			b.Fatalf("Task execution failed: %v", err)
		}
	}
} 