package main

import (
	"context"
	"fmt"
	"sync"
	"testing"
	"time"
)

// TestMessageQueueBasic tests basic message queue functionality
func TestMessageQueueBasic(t *testing.T) {
	config := QueueConfig{
		DefaultBackend:    "memory",
		Backends:          map[string]string{"memory": "memory"},
		EnableRetry:       true,
		MaxRetries:        3,
		RetryDelay:        1 * time.Second,
		EnableDeadLetter:  true,
		DeadLetterQueue:   "dead-letter",
		EnableMonitoring:  true,
		MonitorInterval:   5 * time.Second,
		EnableCompression: false,
		EnableEncryption:  false,
	}

	mq := NewMessageQueue(config)
	defer mq.Disconnect()

	// Test connection
	err := mq.Connect()
	if err != nil {
		t.Fatalf("Failed to connect: %v", err)
	}

	// Test message publishing
	testData := []byte("test message")
	testHeaders := map[string]string{"test": "header"}

	err = mq.Publish("test-queue", testData, testHeaders)
	if err != nil {
		t.Fatalf("Failed to publish message: %v", err)
	}

	// Test message subscription
	receivedMessages := make(chan *Message, 1)
	handler := func(msg *Message) error {
		receivedMessages <- msg
		return nil
	}

	err = mq.Subscribe("test-queue", handler)
	if err != nil {
		t.Fatalf("Failed to subscribe: %v", err)
	}

	// Start consumer
	err = mq.StartConsumer()
	if err != nil {
		t.Fatalf("Failed to start consumer: %v", err)
	}

	// Wait for message
	select {
	case msg := <-receivedMessages:
		if string(msg.Data) != "test message" {
			t.Errorf("Expected 'test message', got '%s'", string(msg.Data))
		}
		if msg.Headers["test"] != "header" {
			t.Errorf("Expected header 'test'='header', got '%s'", msg.Headers["test"])
		}
	case <-time.After(5 * time.Second):
		t.Fatal("Timeout waiting for message")
	}

	// Test stats
	stats := mq.GetStats()
	if stats == nil {
		t.Fatal("Stats should not be nil")
	}

	// Test unsubscribe
	err = mq.Unsubscribe("test-queue")
	if err != nil {
		t.Fatalf("Failed to unsubscribe: %v", err)
	}

	// Test stop consumer
	err = mq.StopConsumer()
	if err != nil {
		t.Fatalf("Failed to stop consumer: %v", err)
	}
}

// TestMessageQueueRetry tests retry functionality
func TestMessageQueueRetry(t *testing.T) {
	config := QueueConfig{
		DefaultBackend:    "memory",
		Backends:          map[string]string{"memory": "memory"},
		EnableRetry:       true,
		MaxRetries:        3,
		RetryDelay:        100 * time.Millisecond,
		EnableDeadLetter:  true,
		DeadLetterQueue:   "dead-letter",
		EnableMonitoring:  false,
		EnableCompression: false,
		EnableEncryption:  false,
	}

	mq := NewMessageQueue(config)
	defer mq.Disconnect()

	err := mq.Connect()
	if err != nil {
		t.Fatalf("Failed to connect: %v", err)
	}

	// Test retry with failing handler
	retryCount := 0
	handler := func(msg *Message) error {
		retryCount++
		if retryCount < 3 {
			return fmt.Errorf("temporary error")
		}
		return nil
	}

	err = mq.Subscribe("retry-queue", handler)
	if err != nil {
		t.Fatalf("Failed to subscribe: %v", err)
	}

	err = mq.StartConsumer()
	if err != nil {
		t.Fatalf("Failed to start consumer: %v", err)
	}

	// Publish message
	err = mq.Publish("retry-queue", []byte("retry test"), nil)
	if err != nil {
		t.Fatalf("Failed to publish message: %v", err)
	}

	// Wait for retries
	time.Sleep(1 * time.Second)

	if retryCount != 3 {
		t.Errorf("Expected 3 retries, got %d", retryCount)
	}

	mq.StopConsumer()
}

// TestMessageQueueDeadLetter tests dead letter queue functionality
func TestMessageQueueDeadLetter(t *testing.T) {
	config := QueueConfig{
		DefaultBackend:    "memory",
		Backends:          map[string]string{"memory": "memory"},
		EnableRetry:       true,
		MaxRetries:        1,
		RetryDelay:        100 * time.Millisecond,
		EnableDeadLetter:  true,
		DeadLetterQueue:   "dead-letter",
		EnableMonitoring:  false,
		EnableCompression: false,
		EnableEncryption:  false,
	}

	mq := NewMessageQueue(config)
	defer mq.Disconnect()

	err := mq.Connect()
	if err != nil {
		t.Fatalf("Failed to connect: %v", err)
	}

	// Handler that always fails
	handler := func(msg *Message) error {
		return fmt.Errorf("permanent error")
	}

	err = mq.Subscribe("test-queue", handler)
	if err != nil {
		t.Fatalf("Failed to subscribe: %v", err)
	}

	// Dead letter handler
	deadLetterMessages := make(chan *Message, 1)
	deadLetterHandler := func(msg *Message) error {
		deadLetterMessages <- msg
		return nil
	}

	err = mq.Subscribe("dead-letter", deadLetterHandler)
	if err != nil {
		t.Fatalf("Failed to subscribe to dead letter: %v", err)
	}

	err = mq.StartConsumer()
	if err != nil {
		t.Fatalf("Failed to start consumer: %v", err)
	}

	// Publish message
	err = mq.Publish("test-queue", []byte("dead letter test"), nil)
	if err != nil {
		t.Fatalf("Failed to publish message: %v", err)
	}

	// Wait for dead letter
	select {
	case msg := <-deadLetterMessages:
		if string(msg.Data) != "dead letter test" {
			t.Errorf("Expected 'dead letter test', got '%s'", string(msg.Data))
		}
	case <-time.After(2 * time.Second):
		t.Fatal("Timeout waiting for dead letter message")
	}

	mq.StopConsumer()
}

// TestMessageQueueConcurrency tests concurrent message processing
func TestMessageQueueConcurrency(t *testing.T) {
	config := QueueConfig{
		DefaultBackend:    "memory",
		Backends:          map[string]string{"memory": "memory"},
		EnableRetry:       false,
		EnableDeadLetter:  false,
		EnableMonitoring:  false,
		EnableCompression: false,
		EnableEncryption:  false,
	}

	mq := NewMessageQueue(config)
	defer mq.Disconnect()

	err := mq.Connect()
	if err != nil {
		t.Fatalf("Failed to connect: %v", err)
	}

	// Concurrent message processing
	var wg sync.WaitGroup
	messageCount := 100
	processedMessages := make(chan int, messageCount)

	handler := func(msg *Message) error {
		processedMessages <- 1
		wg.Done()
		return nil
	}

	err = mq.Subscribe("concurrent-queue", handler)
	if err != nil {
		t.Fatalf("Failed to subscribe: %v", err)
	}

	err = mq.StartConsumer()
	if err != nil {
		t.Fatalf("Failed to start consumer: %v", err)
	}

	// Publish messages concurrently
	for i := 0; i < messageCount; i++ {
		wg.Add(1)
		go func(id int) {
			data := fmt.Sprintf("message %d", id)
			err := mq.Publish("concurrent-queue", []byte(data), nil)
			if err != nil {
				t.Errorf("Failed to publish message %d: %v", id, err)
			}
		}(i)
	}

	// Wait for all messages to be processed
	wg.Wait()

	// Count processed messages
	processed := 0
	for i := 0; i < messageCount; i++ {
		select {
		case <-processedMessages:
			processed++
		case <-time.After(1 * time.Second):
			break
		}
	}

	if processed != messageCount {
		t.Errorf("Expected %d processed messages, got %d", messageCount, processed)
	}

	mq.StopConsumer()
}

// TestMessageQueueBackends tests different backend types
func TestMessageQueueBackends(t *testing.T) {
	config := QueueConfig{
		DefaultBackend:    "memory",
		Backends:          map[string]string{"memory": "memory", "redis": "redis", "rabbitmq": "rabbitmq", "kafka": "kafka"},
		EnableRetry:       false,
		EnableDeadLetter:  false,
		EnableMonitoring:  false,
		EnableCompression: false,
		EnableEncryption:  false,
	}

	mq := NewMessageQueue(config)
	defer mq.Disconnect()

	// Test that backends are initialized
	if len(mq.backends) != 4 {
		t.Errorf("Expected 4 backends, got %d", len(mq.backends))
	}

	// Test backend names
	expectedBackends := []string{"memory", "redis", "rabbitmq", "kafka"}
	for _, expected := range expectedBackends {
		if mq.backends[expected] == nil {
			t.Errorf("Backend %s not initialized", expected)
		}
	}
}

// TestMessageQueueMonitoring tests monitoring functionality
func TestMessageQueueMonitoring(t *testing.T) {
	config := QueueConfig{
		DefaultBackend:    "memory",
		Backends:          map[string]string{"memory": "memory"},
		EnableRetry:       false,
		EnableDeadLetter:  false,
		EnableMonitoring:  true,
		MonitorInterval:   100 * time.Millisecond,
		EnableCompression: false,
		EnableEncryption:  false,
	}

	mq := NewMessageQueue(config)
	defer mq.Disconnect()

	err := mq.Connect()
	if err != nil {
		t.Fatalf("Failed to connect: %v", err)
	}

	// Wait for monitoring to start
	time.Sleep(200 * time.Millisecond)

	// Test stats collection
	stats := mq.GetStats()
	if stats == nil {
		t.Fatal("Stats should not be nil")
	}

	// Check that monitoring data is present
	if stats["monitoring"] == nil {
		t.Error("Monitoring data should be present in stats")
	}
}

// TestMessageQueueMessageProperties tests message properties
func TestMessageQueueMessageProperties(t *testing.T) {
	config := QueueConfig{
		DefaultBackend:    "memory",
		Backends:          map[string]string{"memory": "memory"},
		EnableRetry:       false,
		EnableDeadLetter:  false,
		EnableMonitoring:  false,
		EnableCompression: false,
		EnableEncryption:  false,
	}

	mq := NewMessageQueue(config)
	defer mq.Disconnect()

	err := mq.Connect()
	if err != nil {
		t.Fatalf("Failed to connect: %v", err)
	}

	// Test message with properties
	testData := []byte("test message")
	testHeaders := map[string]string{"priority": "high", "type": "test"}
	expiresAt := time.Now().Add(1 * time.Hour)

	// Create message manually to test properties
	message := &Message{
		ID:        "test-id",
		Queue:     "test-queue",
		Data:      testData,
		Headers:   testHeaders,
		Priority:  10,
		Timestamp: time.Now(),
		ExpiresAt: &expiresAt,
		RetryCount: 0,
		MaxRetries: 3,
		Status:    "pending",
		Metadata:  map[string]string{"test": "metadata"},
	}

	// Test message properties
	if message.ID != "test-id" {
		t.Errorf("Expected ID 'test-id', got '%s'", message.ID)
	}

	if message.Priority != 10 {
		t.Errorf("Expected priority 10, got %d", message.Priority)
	}

	if message.Status != "pending" {
		t.Errorf("Expected status 'pending', got '%s'", message.Status)
	}

	if message.Headers["priority"] != "high" {
		t.Errorf("Expected header 'priority'='high', got '%s'", message.Headers["priority"])
	}
}

// BenchmarkMessageQueuePublish benchmarks message publishing
func BenchmarkMessageQueuePublish(b *testing.B) {
	config := QueueConfig{
		DefaultBackend:    "memory",
		Backends:          map[string]string{"memory": "memory"},
		EnableRetry:       false,
		EnableDeadLetter:  false,
		EnableMonitoring:  false,
		EnableCompression: false,
		EnableEncryption:  false,
	}

	mq := NewMessageQueue(config)
	defer mq.Disconnect()

	err := mq.Connect()
	if err != nil {
		b.Fatalf("Failed to connect: %v", err)
	}

	testData := []byte("benchmark message")
	testHeaders := map[string]string{"benchmark": "true"}

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		err := mq.Publish("benchmark-queue", testData, testHeaders)
		if err != nil {
			b.Fatalf("Failed to publish message: %v", err)
		}
	}
}

// BenchmarkMessageQueueSubscribe benchmarks message subscription
func BenchmarkMessageQueueSubscribe(b *testing.B) {
	config := QueueConfig{
		DefaultBackend:    "memory",
		Backends:          map[string]string{"memory": "memory"},
		EnableRetry:       false,
		EnableDeadLetter:  false,
		EnableMonitoring:  false,
		EnableCompression: false,
		EnableEncryption:  false,
	}

	mq := NewMessageQueue(config)
	defer mq.Disconnect()

	err := mq.Connect()
	if err != nil {
		b.Fatalf("Failed to connect: %v", err)
	}

	handler := func(msg *Message) error {
		return nil
	}

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		queueName := fmt.Sprintf("benchmark-queue-%d", i)
		err := mq.Subscribe(queueName, handler)
		if err != nil {
			b.Fatalf("Failed to subscribe: %v", err)
		}
	}
} 