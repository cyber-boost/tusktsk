package main

import (
	"testing"
	"time"
)

// TestAuthorizationManagerBasic tests basic authorization functionality
func TestAuthorizationManagerBasic(t *testing.T) {
	config := AuthzConfig{
		DefaultPolicy:     "deny",
		EnableAudit:       true,
		EnableCache:       true,
		CacheTTL:          5 * time.Minute,
		EnableHierarchy:   true,
		EnableInheritance: true,
		MaxPolicyDepth:    10,
	}

	am := NewAuthorizationManager(config)
	if am == nil {
		t.Fatal("Failed to create AuthorizationManager")
	}

	// Test role creation
	role := &Role{
		ID:          "test-role",
		Name:        "Test Role",
		Description: "A test role",
		Permissions: []string{"read", "write"},
		Users:       []string{"user1", "user2"},
		CreatedAt:   time.Now(),
		UpdatedAt:   time.Now(),
		Metadata:    make(map[string]string),
	}

	err := am.CreateRole(role)
	if err != nil {
		t.Fatalf("Failed to create role: %v", err)
	}

	// Test policy creation
	policy := &Policy{
		ID:          "test-policy",
		Name:        "Test Policy",
		Description: "A test policy",
		Type:        "allow",
		Resource:    "test-resource",
		Action:      "read",
		Roles:       []string{"test-role"},
		Priority:    1,
		Enabled:     true,
		CreatedAt:   time.Now(),
		UpdatedAt:   time.Now(),
		Metadata:    make(map[string]string),
	}

	err = am.CreatePolicy(policy)
	if err != nil {
		t.Fatalf("Failed to create policy: %v", err)
	}

	// Test authorization request
	request := &AuthorizationRequest{
		UserID:   "user1",
		Resource: "test-resource",
		Action:   "read",
		Context:  make(map[string]string),
		Metadata: make(map[string]string),
	}

	result, err := am.Authorize(request)
	if err != nil {
		t.Fatalf("Failed to authorize: %v", err)
	}

	if !result.Allowed {
		t.Fatal("Authorization should be allowed")
	}

	if result.Policy.ID != "test-policy" {
		t.Errorf("Expected policy ID 'test-policy', got '%s'", result.Policy.ID)
	}
}

// TestAuthorizationManagerRoleManagement tests role management functionality
func TestAuthorizationManagerRoleManagement(t *testing.T) {
	config := AuthzConfig{
		DefaultPolicy: "deny",
		EnableAudit:   true,
	}

	am := NewAuthorizationManager(config)

	// Test role creation
	role := &Role{
		ID:          "admin-role",
		Name:        "Administrator",
		Description: "Administrator role with full access",
		Permissions: []string{"read", "write", "delete", "admin"},
		Users:       []string{"admin1"},
		CreatedAt:   time.Now(),
		UpdatedAt:   time.Now(),
		Metadata:    make(map[string]string),
	}

	err := am.CreateRole(role)
	if err != nil {
		t.Fatalf("Failed to create role: %v", err)
	}

	// Test role retrieval
	retrievedRole, err := am.GetRole("admin-role")
	if err != nil {
		t.Fatalf("Failed to get role: %v", err)
	}

	if retrievedRole.Name != "Administrator" {
		t.Errorf("Expected role name 'Administrator', got '%s'", retrievedRole.Name)
	}

	// Test role update
	retrievedRole.Description = "Updated administrator role"
	retrievedRole.Permissions = []string{"read", "write", "delete", "admin", "audit"}

	err = am.UpdateRole(retrievedRole)
	if err != nil {
		t.Fatalf("Failed to update role: %v", err)
	}

	// Verify update
	updatedRole, err := am.GetRole("admin-role")
	if err != nil {
		t.Fatalf("Failed to get updated role: %v", err)
	}

	if updatedRole.Description != "Updated administrator role" {
		t.Errorf("Expected description 'Updated administrator role', got '%s'", updatedRole.Description)
	}

	if len(updatedRole.Permissions) != 5 {
		t.Errorf("Expected 5 permissions, got %d", len(updatedRole.Permissions))
	}

	// Test role listing
	roles := am.ListRoles()
	if len(roles) == 0 {
		t.Fatal("Should have at least one role")
	}

	found := false
	for _, r := range roles {
		if r.ID == "admin-role" {
			found = true
			break
		}
	}

	if !found {
		t.Fatal("Created role should be in role list")
	}

	// Test role assignment
	err = am.AssignRole("user1", "admin-role")
	if err != nil {
		t.Fatalf("Failed to assign role: %v", err)
	}

	// Test role removal
	err = am.RemoveRole("user1", "admin-role")
	if err != nil {
		t.Fatalf("Failed to remove role: %v", err)
	}

	// Test role deletion
	err = am.DeleteRole("admin-role")
	if err != nil {
		t.Fatalf("Failed to delete role: %v", err)
	}

	// Verify deletion
	_, err = am.GetRole("admin-role")
	if err == nil {
		t.Fatal("Role should not exist after deletion")
	}
}

// TestAuthorizationManagerPolicyManagement tests policy management functionality
func TestAuthorizationManagerPolicyManagement(t *testing.T) {
	config := AuthzConfig{
		DefaultPolicy: "deny",
		EnableAudit:   true,
	}

	am := NewAuthorizationManager(config)

	// Test policy creation
	policy := &Policy{
		ID:          "read-policy",
		Name:        "Read Policy",
		Description: "Allow read access to documents",
		Type:        "allow",
		Resource:    "documents",
		Action:      "read",
		Roles:       []string{"user"},
		Priority:    1,
		Enabled:     true,
		CreatedAt:   time.Now(),
		UpdatedAt:   time.Now(),
		Metadata:    make(map[string]string),
	}

	err := am.CreatePolicy(policy)
	if err != nil {
		t.Fatalf("Failed to create policy: %v", err)
	}

	// Test policy retrieval
	retrievedPolicy, err := am.GetPolicy("read-policy")
	if err != nil {
		t.Fatalf("Failed to get policy: %v", err)
	}

	if retrievedPolicy.Name != "Read Policy" {
		t.Errorf("Expected policy name 'Read Policy', got '%s'", retrievedPolicy.Name)
	}

	// Test policy update
	retrievedPolicy.Description = "Updated read policy"
	retrievedPolicy.Resource = "documents/*"

	err = am.UpdatePolicy(retrievedPolicy)
	if err != nil {
		t.Fatalf("Failed to update policy: %v", err)
	}

	// Verify update
	updatedPolicy, err := am.GetPolicy("read-policy")
	if err != nil {
		t.Fatalf("Failed to get updated policy: %v", err)
	}

	if updatedPolicy.Description != "Updated read policy" {
		t.Errorf("Expected description 'Updated read policy', got '%s'", updatedPolicy.Description)
	}

	if updatedPolicy.Resource != "documents/*" {
		t.Errorf("Expected resource 'documents/*', got '%s'", updatedPolicy.Resource)
	}

	// Test policy listing
	policies := am.ListPolicies()
	if len(policies) == 0 {
		t.Fatal("Should have at least one policy")
	}

	found := false
	for _, p := range policies {
		if p.ID == "read-policy" {
			found = true
			break
		}
	}

	if !found {
		t.Fatal("Created policy should be in policy list")
	}

	// Test policy deletion
	err = am.DeletePolicy("read-policy")
	if err != nil {
		t.Fatalf("Failed to delete policy: %v", err)
	}

	// Verify deletion
	_, err = am.GetPolicy("read-policy")
	if err == nil {
		t.Fatal("Policy should not exist after deletion")
	}
}

// TestAuthorizationManagerConditionalPolicies tests conditional policies
func TestAuthorizationManagerConditionalPolicies(t *testing.T) {
	config := AuthzConfig{
		DefaultPolicy: "deny",
		EnableAudit:   true,
	}

	am := NewAuthorizationManager(config)

	// Create role
	role := &Role{
		ID:          "manager-role",
		Name:        "Manager",
		Permissions: []string{"read", "write"},
		CreatedAt:   time.Now(),
		UpdatedAt:   time.Now(),
		Metadata:    make(map[string]string),
	}

	err := am.CreateRole(role)
	if err != nil {
		t.Fatalf("Failed to create role: %v", err)
	}

	// Create conditional policy
	policy := &Policy{
		ID:          "conditional-policy",
		Name:        "Conditional Policy",
		Description: "Allow access based on conditions",
		Type:        "allow",
		Resource:    "documents",
		Action:      "read",
		Roles:       []string{"manager-role"},
		Conditions: []*Condition{
			{
				Field:    "department",
				Operator: "eq",
				Value:    "engineering",
			},
			{
				Field:    "time",
				Operator: "gte",
				Value:    "09:00",
			},
		},
		Priority: 1,
		Enabled:  true,
		CreatedAt: time.Now(),
		UpdatedAt: time.Now(),
		Metadata:  make(map[string]string),
	}

	err = am.CreatePolicy(policy)
	if err != nil {
		t.Fatalf("Failed to create conditional policy: %v", err)
	}

	// Test authorization with matching conditions
	request := &AuthorizationRequest{
		UserID:   "manager1",
		Resource: "documents",
		Action:   "read",
		Context: map[string]string{
			"department": "engineering",
			"time":       "10:00",
		},
		Metadata: make(map[string]string),
	}

	result, err := am.Authorize(request)
	if err != nil {
		t.Fatalf("Failed to authorize with matching conditions: %v", err)
	}

	if !result.Allowed {
		t.Fatal("Authorization should be allowed with matching conditions")
	}

	// Test authorization with non-matching conditions
	request.Context["department"] = "marketing"
	result, err = am.Authorize(request)
	if err != nil {
		t.Fatalf("Failed to authorize with non-matching conditions: %v", err)
	}

	if result.Allowed {
		t.Fatal("Authorization should be denied with non-matching conditions")
	}
}

// TestAuthorizationManagerPolicyPriority tests policy priority handling
func TestAuthorizationManagerPolicyPriority(t *testing.T) {
	config := AuthzConfig{
		DefaultPolicy: "deny",
		EnableAudit:   true,
	}

	am := NewAuthorizationManager(config)

	// Create role
	role := &Role{
		ID:          "user-role",
		Name:        "User",
		Permissions: []string{"read"},
		CreatedAt:   time.Now(),
		UpdatedAt:   time.Now(),
		Metadata:    make(map[string]string),
	}

	err := am.CreateRole(role)
	if err != nil {
		t.Fatalf("Failed to create role: %v", err)
	}

	// Create allow policy with lower priority
	allowPolicy := &Policy{
		ID:          "allow-policy",
		Name:        "Allow Policy",
		Type:        "allow",
		Resource:    "documents",
		Action:      "read",
		Roles:       []string{"user-role"},
		Priority:    2,
		Enabled:     true,
		CreatedAt:   time.Now(),
		UpdatedAt:   time.Now(),
		Metadata:    make(map[string]string),
	}

	err = am.CreatePolicy(allowPolicy)
	if err != nil {
		t.Fatalf("Failed to create allow policy: %v", err)
	}

	// Create deny policy with higher priority
	denyPolicy := &Policy{
		ID:          "deny-policy",
		Name:        "Deny Policy",
		Type:        "deny",
		Resource:    "documents",
		Action:      "read",
		Roles:       []string{"user-role"},
		Priority:    1,
		Enabled:     true,
		CreatedAt:   time.Now(),
		UpdatedAt:   time.Now(),
		Metadata:    make(map[string]string),
	}

	err = am.CreatePolicy(denyPolicy)
	if err != nil {
		t.Fatalf("Failed to create deny policy: %v", err)
	}

	// Test authorization - deny policy should take precedence
	request := &AuthorizationRequest{
		UserID:   "user1",
		Resource: "documents",
		Action:   "read",
		Context:  make(map[string]string),
		Metadata: make(map[string]string),
	}

	result, err := am.Authorize(request)
	if err != nil {
		t.Fatalf("Failed to authorize: %v", err)
	}

	if result.Allowed {
		t.Fatal("Authorization should be denied due to higher priority deny policy")
	}

	if result.Policy.ID != "deny-policy" {
		t.Errorf("Expected deny policy to be applied, got '%s'", result.Policy.ID)
	}
}

// TestAuthorizationManagerCache tests authorization caching
func TestAuthorizationManagerCache(t *testing.T) {
	config := AuthzConfig{
		DefaultPolicy: "deny",
		EnableAudit:   true,
		EnableCache:   true,
		CacheTTL:      1 * time.Minute,
	}

	am := NewAuthorizationManager(config)

	// Create role and policy
	role := &Role{
		ID:          "cache-role",
		Name:        "Cache Role",
		Permissions: []string{"read"},
		CreatedAt:   time.Now(),
		UpdatedAt:   time.Now(),
		Metadata:    make(map[string]string),
	}

	err := am.CreateRole(role)
	if err != nil {
		t.Fatalf("Failed to create role: %v", err)
	}

	policy := &Policy{
		ID:          "cache-policy",
		Name:        "Cache Policy",
		Type:        "allow",
		Resource:    "cache-resource",
		Action:      "read",
		Roles:       []string{"cache-role"},
		Priority:    1,
		Enabled:     true,
		CreatedAt:   time.Now(),
		UpdatedAt:   time.Now(),
		Metadata:    make(map[string]string),
	}

	err = am.CreatePolicy(policy)
	if err != nil {
		t.Fatalf("Failed to create policy: %v", err)
	}

	// Test multiple authorization requests - should use cache
	request := &AuthorizationRequest{
		UserID:   "cache-user",
		Resource: "cache-resource",
		Action:   "read",
		Context:  make(map[string]string),
		Metadata: make(map[string]string),
	}

	// First request
	result1, err := am.Authorize(request)
	if err != nil {
		t.Fatalf("Failed first authorization: %v", err)
	}

	if !result1.Allowed {
		t.Fatal("First authorization should be allowed")
	}

	// Second request - should use cache
	result2, err := am.Authorize(request)
	if err != nil {
		t.Fatalf("Failed second authorization: %v", err)
	}

	if !result2.Allowed {
		t.Fatal("Second authorization should be allowed")
	}

	// Both results should be identical
	if result1.Timestamp != result2.Timestamp {
		t.Fatal("Cached result should have same timestamp")
	}
}

// TestAuthorizationManagerAuditLogging tests audit logging functionality
func TestAuthorizationManagerAuditLogging(t *testing.T) {
	config := AuthzConfig{
		DefaultPolicy: "deny",
		EnableAudit:   true,
	}

	am := NewAuthorizationManager(config)

	// Create role and policy
	role := &Role{
		ID:          "audit-role",
		Name:        "Audit Role",
		Permissions: []string{"read"},
		CreatedAt:   time.Now(),
		UpdatedAt:   time.Now(),
		Metadata:    make(map[string]string),
	}

	err := am.CreateRole(role)
	if err != nil {
		t.Fatalf("Failed to create role: %v", err)
	}

	policy := &Policy{
		ID:          "audit-policy",
		Name:        "Audit Policy",
		Type:        "allow",
		Resource:    "audit-resource",
		Action:      "read",
		Roles:       []string{"audit-role"},
		Priority:    1,
		Enabled:     true,
		CreatedAt:   time.Now(),
		UpdatedAt:   time.Now(),
		Metadata:    make(map[string]string),
	}

	err = am.CreatePolicy(policy)
	if err != nil {
		t.Fatalf("Failed to create policy: %v", err)
	}

	// Test authorization requests to generate audit events
	request := &AuthorizationRequest{
		UserID:   "audit-user",
		Resource: "audit-resource",
		Action:   "read",
		Context:  make(map[string]string),
		Metadata: make(map[string]string),
	}

	// Successful authorization
	result, err := am.Authorize(request)
	if err != nil {
		t.Fatalf("Failed to authorize: %v", err)
	}

	if !result.Allowed {
		t.Fatal("Authorization should be allowed")
	}

	// Failed authorization
	request.Resource = "denied-resource"
	result, err = am.Authorize(request)
	if err != nil {
		t.Fatalf("Failed to authorize: %v", err)
	}

	if result.Allowed {
		t.Fatal("Authorization should be denied")
	}

	// Get audit events
	events := am.auditor.GetEvents()
	if len(events) == 0 {
		t.Fatal("Should have audit events")
	}

	// Verify audit events
	foundSuccess := false
	foundFailure := false

	for _, event := range events {
		if event.Result == "success" {
			foundSuccess = true
		}
		if event.Result == "failure" {
			foundFailure = true
		}
	}

	if !foundSuccess {
		t.Fatal("Should have success audit event")
	}

	if !foundFailure {
		t.Fatal("Should have failure audit event")
	}
}

// BenchmarkAuthorizationManagerAuthorize benchmarks authorization
func BenchmarkAuthorizationManagerAuthorize(b *testing.B) {
	config := AuthzConfig{
		DefaultPolicy: "deny",
		EnableCache:   true,
	}

	am := NewAuthorizationManager(config)

	// Create role and policy
	role := &Role{
		ID:          "benchmark-role",
		Name:        "Benchmark Role",
		Permissions: []string{"read"},
		CreatedAt:   time.Now(),
		UpdatedAt:   time.Now(),
		Metadata:    make(map[string]string),
	}

	err := am.CreateRole(role)
	if err != nil {
		b.Fatalf("Failed to create role: %v", err)
	}

	policy := &Policy{
		ID:          "benchmark-policy",
		Name:        "Benchmark Policy",
		Type:        "allow",
		Resource:    "benchmark-resource",
		Action:      "read",
		Roles:       []string{"benchmark-role"},
		Priority:    1,
		Enabled:     true,
		CreatedAt:   time.Now(),
		UpdatedAt:   time.Now(),
		Metadata:    make(map[string]string),
	}

	err = am.CreatePolicy(policy)
	if err != nil {
		b.Fatalf("Failed to create policy: %v", err)
	}

	request := &AuthorizationRequest{
		UserID:   "benchmark-user",
		Resource: "benchmark-resource",
		Action:   "read",
		Context:  make(map[string]string),
		Metadata: make(map[string]string),
	}

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		_, err := am.Authorize(request)
		if err != nil {
			b.Fatalf("Authorization failed: %v", err)
		}
	}
} 