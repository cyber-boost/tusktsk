package main

import (
	"context"
	"fmt"
	"sync"
	"time"
)

// TaskManager provides task management capabilities
type TaskManager struct {
	tasks       map[string]*Task
	schedules   map[string]*TaskSchedule
	executions  map[string]*TaskExecution
	config      TaskConfig
	scheduler   *TaskScheduler
	executor    *TaskExecutor
	monitor     *TaskMonitor
	mutex       sync.RWMutex
}

// Task represents a task definition
type Task struct {
	ID          string            `json:"id"`
	Name        string            `json:"name"`
	Description string            `json:"description"`
	Handler     string            `json:"handler"`
	Input       map[string]string `json:"input"`
	Output      map[string]string `json:"output"`
	Timeout     time.Duration     `json:"timeout"`
	RetryPolicy *RetryPolicy      `json:"retry_policy"`
	Priority    int               `json:"priority"`
	Tags        []string          `json:"tags"`
	CreatedAt   time.Time         `json:"created_at"`
	UpdatedAt   time.Time         `json:"updated_at"`
	Metadata    map[string]string `json:"metadata"`
}

// TaskSchedule represents a task schedule
type TaskSchedule struct {
	ID         string            `json:"id"`
	TaskID     string            `json:"task_id"`
	CronExpr   string            `json:"cron_expr"`
	Enabled    bool              `json:"enabled"`
	LastRun    *time.Time        `json:"last_run"`
	NextRun    *time.Time        `json:"next_run"`
	RunCount   int64             `json:"run_count"`
	Metadata   map[string]string `json:"metadata"`
}

// TaskExecution represents a task execution
type TaskExecution struct {
	ID         string                 `json:"id"`
	TaskID     string                 `json:"task_id"`
	Status     string                 `json:"status"` // pending, running, completed, failed, cancelled
	Input      map[string]interface{} `json:"input"`
	Output     map[string]interface{} `json:"output"`
	StartedAt  *time.Time             `json:"started_at"`
	CompletedAt *time.Time            `json:"completed_at"`
	Duration   time.Duration          `json:"duration"`
	Error      string                 `json:"error"`
	RetryCount int                    `json:"retry_count"`
	WorkerID   string                 `json:"worker_id"`
	Metadata   map[string]string      `json:"metadata"`
}

// TaskConfig represents task configuration
type TaskConfig struct {
	MaxConcurrentTasks int           `json:"max_concurrent_tasks"`
	DefaultTimeout     time.Duration `json:"default_timeout"`
	EnableRetry        bool          `json:"enable_retry"`
	MaxRetries         int           `json:"max_retries"`
	EnableMonitoring   bool          `json:"enable_monitoring"`
	MonitorInterval    time.Duration `json:"monitor_interval"`
	EnablePersistence  bool          `json:"enable_persistence"`
	PersistencePath    string        `json:"persistence_path"`
}

// TaskScheduler manages task scheduling
type TaskScheduler struct {
	taskManager *TaskManager
	schedules   map[string]*TaskSchedule
	config      SchedulerConfig
	mutex       sync.RWMutex
}

// SchedulerConfig represents scheduler configuration
type SchedulerConfig struct {
	EnableScheduling bool          `json:"enable_scheduling"`
	CheckInterval    time.Duration `json:"check_interval"`
	MaxSchedules     int           `json:"max_schedules"`
}

// TaskExecutor manages task execution
type TaskExecutor struct {
	taskManager *TaskManager
	workers     chan struct{}
	queue       chan *TaskExecution
	config      ExecutorConfig
	mutex       sync.RWMutex
}

// ExecutorConfig represents executor configuration
type ExecutorConfig struct {
	WorkerPoolSize int           `json:"worker_pool_size"`
	QueueSize      int           `json:"queue_size"`
	Timeout        time.Duration `json:"timeout"`
	EnableMetrics  bool          `json:"enable_metrics"`
}

// TaskMonitor monitors task execution
type TaskMonitor struct {
	taskManager *TaskManager
	metrics     map[string]*TaskMetric
	alerts      []TaskAlert
	config      MonitorConfig
	mutex       sync.RWMutex
}

// TaskMetric represents a task metric
type TaskMetric struct {
	TaskID      string                 `json:"task_id"`
	Name        string                 `json:"name"`
	Value       float64                `json:"value"`
	Unit        string                 `json:"unit"`
	Timestamp   time.Time              `json:"timestamp"`
	History     []MetricPoint          `json:"history"`
	Thresholds  map[string]float64     `json:"thresholds"`
	Metadata    map[string]interface{} `json:"metadata"`
}

// TaskAlert represents a task alert
type TaskAlert struct {
	TaskID    string    `json:"task_id"`
	Type      string    `json:"type"`
	Message   string    `json:"message"`
	Severity  string    `json:"severity"`
	Timestamp time.Time `json:"timestamp"`
	Value     float64   `json:"value"`
	Threshold float64   `json:"threshold"`
}

// MonitorConfig represents monitor configuration
type MonitorConfig struct {
	EnableLatencyMonitoring bool          `json:"enable_latency_monitoring"`
	EnableThroughputMonitoring bool       `json:"enable_throughput_monitoring"`
	EnableErrorMonitoring   bool          `json:"enable_error_monitoring"`
	AlertThreshold          float64       `json:"alert_threshold"`
	CheckInterval           time.Duration `json:"check_interval"`
}

// TaskHandler represents a task handler function
type TaskHandler func(input map[string]interface{}) (map[string]interface{}, error)

// TaskManager creates a new task manager
func NewTaskManager(config TaskConfig) *TaskManager {
	tm := &TaskManager{
		tasks:      make(map[string]*Task),
		schedules:  make(map[string]*TaskSchedule),
		executions: make(map[string]*TaskExecution),
		config:     config,
		scheduler: &TaskScheduler{
			schedules: make(map[string]*TaskSchedule),
			config: SchedulerConfig{
				EnableScheduling: true,
				CheckInterval:    1 * time.Minute,
				MaxSchedules:     100,
			},
		},
		executor: &TaskExecutor{
			workers: make(chan struct{}, config.MaxConcurrentTasks),
			queue:   make(chan *TaskExecution, 1000),
			config: ExecutorConfig{
				WorkerPoolSize: config.MaxConcurrentTasks,
				QueueSize:      1000,
				Timeout:        config.DefaultTimeout,
				EnableMetrics:  true,
			},
		},
		monitor: &TaskMonitor{
			metrics: make(map[string]*TaskMetric),
			alerts:  make([]TaskAlert, 0),
			config: MonitorConfig{
				EnableLatencyMonitoring: true,
				EnableThroughputMonitoring: true,
				EnableErrorMonitoring:   true,
				AlertThreshold:          0.8,
				CheckInterval:           30 * time.Second,
			},
		},
	}

	tm.scheduler.taskManager = tm
	tm.executor.taskManager = tm
	tm.monitor.taskManager = tm

	// Start monitoring if enabled
	if config.EnableMonitoring {
		go tm.startMonitoring()
	}

	// Start scheduler if enabled
	if tm.scheduler.config.EnableScheduling {
		go tm.startScheduler()
	}

	// Start executor workers
	go tm.startWorkers()

	return tm
}

// RegisterTask registers a task
func (tm *TaskManager) RegisterTask(task *Task) error {
	tm.mutex.Lock()
	defer tm.mutex.Unlock()

	if _, exists := tm.tasks[task.ID]; exists {
		return fmt.Errorf("task %s already exists", task.ID)
	}

	task.CreatedAt = time.Now()
	task.UpdatedAt = time.Now()
	if task.Metadata == nil {
		task.Metadata = make(map[string]string)
	}

	tm.tasks[task.ID] = task
	return nil
}

// GetTask returns a task by ID
func (tm *TaskManager) GetTask(taskID string) (*Task, error) {
	tm.mutex.RLock()
	defer tm.mutex.RUnlock()

	task, exists := tm.tasks[taskID]
	if !exists {
		return nil, fmt.Errorf("task %s not found", taskID)
	}

	return task, nil
}

// ListTasks lists all tasks
func (tm *TaskManager) ListTasks() []*Task {
	tm.mutex.RLock()
	defer tm.mutex.RUnlock()

	tasks := make([]*Task, 0, len(tm.tasks))
	for _, task := range tm.tasks {
		tasks = append(tasks, task)
	}

	return tasks
}

// ExecuteTask executes a task
func (tm *TaskManager) ExecuteTask(taskID string, input map[string]interface{}) (*TaskExecution, error) {
	tm.mutex.RLock()
	task, exists := tm.tasks[taskID]
	tm.mutex.RUnlock()

	if !exists {
		return nil, fmt.Errorf("task %s not found", taskID)
	}

	// Create execution
	execution := &TaskExecution{
		ID:       generateExecutionID(),
		TaskID:   taskID,
		Status:   "pending",
		Input:    input,
		Output:   make(map[string]interface{}),
		Metadata: make(map[string]string),
	}

	// Store execution
	tm.mutex.Lock()
	tm.executions[execution.ID] = execution
	tm.mutex.Unlock()

	// Queue execution
	select {
	case tm.executor.queue <- execution:
	default:
		execution.Status = "failed"
		execution.Error = "queue full"
		now := time.Now()
		execution.CompletedAt = &now
	}

	return execution, nil
}

// GetExecution returns an execution by ID
func (tm *TaskManager) GetExecution(executionID string) (*TaskExecution, error) {
	tm.mutex.RLock()
	defer tm.mutex.RUnlock()

	execution, exists := tm.executions[executionID]
	if !exists {
		return nil, fmt.Errorf("execution %s not found", executionID)
	}

	return execution, nil
}

// ListExecutions lists all executions
func (tm *TaskManager) ListExecutions() []*TaskExecution {
	tm.mutex.RLock()
	defer tm.mutex.RUnlock()

	executions := make([]*TaskExecution, 0, len(tm.executions))
	for _, execution := range tm.executions {
		executions = append(executions, execution)
	}

	return executions
}

// CancelExecution cancels an execution
func (tm *TaskManager) CancelExecution(executionID string) error {
	tm.mutex.Lock()
	defer tm.mutex.Unlock()

	execution, exists := tm.executions[executionID]
	if !exists {
		return fmt.Errorf("execution %s not found", executionID)
	}

	if execution.Status == "completed" || execution.Status == "failed" || execution.Status == "cancelled" {
		return fmt.Errorf("execution %s cannot be cancelled", executionID)
	}

	execution.Status = "cancelled"
	now := time.Now()
	execution.CompletedAt = &now

	return nil
}

// ScheduleTask schedules a task
func (tm *TaskManager) ScheduleTask(taskID, cronExpr string) (*TaskSchedule, error) {
	tm.mutex.RLock()
	_, exists := tm.tasks[taskID]
	tm.mutex.RUnlock()

	if !exists {
		return nil, fmt.Errorf("task %s not found", taskID)
	}

	schedule := &TaskSchedule{
		ID:       generateScheduleID(),
		TaskID:   taskID,
		CronExpr: cronExpr,
		Enabled:  true,
		Metadata: make(map[string]string),
	}

	// Calculate next run time
	nextRun, err := tm.calculateNextRun(cronExpr)
	if err != nil {
		return nil, err
	}
	schedule.NextRun = &nextRun

	// Register schedule
	tm.scheduler.RegisterSchedule(schedule)

	return schedule, nil
}

// calculateNextRun calculates next run time from cron expression
func (tm *TaskManager) calculateNextRun(cronExpr string) (time.Time, error) {
	// This would parse cron expression and calculate next run
	// For now, just return current time + 1 hour
	return time.Now().Add(1 * time.Hour), nil
}

// GetSchedule returns a schedule by ID
func (tm *TaskManager) GetSchedule(scheduleID string) (*TaskSchedule, error) {
	return tm.scheduler.GetSchedule(scheduleID)
}

// ListSchedules lists all schedules
func (tm *TaskManager) ListSchedules() []*TaskSchedule {
	return tm.scheduler.ListSchedules()
}

// EnableSchedule enables a schedule
func (tm *TaskManager) EnableSchedule(scheduleID string) error {
	return tm.scheduler.EnableSchedule(scheduleID)
}

// DisableSchedule disables a schedule
func (tm *TaskManager) DisableSchedule(scheduleID string) error {
	return tm.scheduler.DisableSchedule(scheduleID)
}

// startMonitoring starts task monitoring
func (tm *TaskManager) startMonitoring() {
	ticker := time.NewTicker(tm.config.MonitorInterval)
	defer ticker.Stop()

	for {
		select {
		case <-ticker.C:
			tm.collectMetrics()
			tm.checkAlerts()
		}
	}
}

// startScheduler starts task scheduler
func (tm *TaskManager) startScheduler() {
	ticker := time.NewTicker(tm.scheduler.config.CheckInterval)
	defer ticker.Stop()

	for {
		select {
		case <-ticker.C:
			tm.scheduler.checkSchedules()
		}
	}
}

// startWorkers starts task executor workers
func (tm *TaskManager) startWorkers() {
	for i := 0; i < tm.executor.config.WorkerPoolSize; i++ {
		go tm.worker(fmt.Sprintf("worker-%d", i))
	}
}

// worker represents a task worker
func (tm *TaskManager) worker(workerID string) {
	for execution := range tm.executor.queue {
		// Acquire worker
		tm.executor.workers <- struct{}{}

		// Execute task
		tm.executeTask(execution, workerID)

		// Release worker
		<-tm.executor.workers
	}
}

// executeTask executes a task
func (tm *TaskManager) executeTask(execution *TaskExecution, workerID string) {
	// Get task
	tm.mutex.RLock()
	task, exists := tm.tasks[execution.TaskID]
	tm.mutex.RUnlock()

	if !exists {
		execution.Status = "failed"
		execution.Error = "task not found"
		now := time.Now()
		execution.CompletedAt = &now
		return
	}

	// Start execution
	execution.Status = "running"
	execution.WorkerID = workerID
	now := time.Now()
	execution.StartedAt = &now

	// Execute task with timeout
	ctx, cancel := context.WithTimeout(context.Background(), task.Timeout)
	defer cancel()

	// Create channel for result
	resultChan := make(chan map[string]interface{}, 1)
	errorChan := make(chan error, 1)

	go func() {
		// This would execute the actual task handler
		// For now, just a placeholder
		result := map[string]interface{}{
			"result": "task completed successfully",
		}
		resultChan <- result
	}()

	// Wait for result or timeout
	select {
	case result := <-resultChan:
		execution.Status = "completed"
		execution.Output = result
	case err := <-errorChan:
		execution.Status = "failed"
		execution.Error = err.Error()
	case <-ctx.Done():
		execution.Status = "failed"
		execution.Error = "timeout"
	}

	// Complete execution
	now = time.Now()
	execution.CompletedAt = &now
	execution.Duration = now.Sub(*execution.StartedAt)
}

// collectMetrics collects task metrics
func (tm *TaskManager) collectMetrics() {
	tm.mutex.RLock()
	defer tm.mutex.RUnlock()

	// Calculate execution statistics
	totalExecutions := len(tm.executions)
	completedExecutions := 0
	failedExecutions := 0
	runningExecutions := 0
	var totalDuration time.Duration

	for _, execution := range tm.executions {
		switch execution.Status {
		case "completed":
			completedExecutions++
			totalDuration += execution.Duration
		case "failed":
			failedExecutions++
		case "running":
			runningExecutions++
		}
	}

	// Update metrics
	if tm.monitor.config.EnableThroughputMonitoring {
		tm.updateTaskMetric("execution_throughput", float64(completedExecutions), "tasks/hour")
	}

	if tm.monitor.config.EnableLatencyMonitoring && completedExecutions > 0 {
		avgDuration := totalDuration.Seconds() / float64(completedExecutions)
		tm.updateTaskMetric("average_duration", avgDuration, "seconds")
	}

	if tm.monitor.config.EnableErrorMonitoring && totalExecutions > 0 {
		errorRate := float64(failedExecutions) / float64(totalExecutions)
		tm.updateTaskMetric("error_rate", errorRate, "percentage")
	}
}

// updateTaskMetric updates a task metric
func (tm *TaskManager) updateTaskMetric(name string, value float64, unit string) {
	metricKey := fmt.Sprintf("task_%s", name)
	
	tm.monitor.mutex.Lock()
	defer tm.monitor.mutex.Unlock()

	metric, exists := tm.monitor.metrics[metricKey]
	if !exists {
		metric = &TaskMetric{
			Name:       name,
			Unit:       unit,
			History:    make([]MetricPoint, 0),
			Thresholds: make(map[string]float64),
			Metadata:   make(map[string]interface{}),
		}
		tm.monitor.metrics[metricKey] = metric
	}

	metric.Value = value
	metric.Timestamp = time.Now()

	// Add to history (keep last 100 points)
	metric.History = append(metric.History, MetricPoint{
		Value:     value,
		Timestamp: time.Now(),
	})

	if len(metric.History) > 100 {
		metric.History = metric.History[1:]
	}
}

// checkAlerts checks for task alerts
func (tm *TaskManager) checkAlerts() {
	tm.monitor.mutex.RLock()
	defer tm.monitor.mutex.RUnlock()

	for _, metric := range tm.monitor.metrics {
		// Check error rate threshold
		if metric.Name == "error_rate" && metric.Value > tm.monitor.config.AlertThreshold {
			alert := TaskAlert{
				Type:      "high_error_rate",
				Message:   fmt.Sprintf("Task error rate is high: %.2f%%", metric.Value*100),
				Severity:  "warning",
				Timestamp: time.Now(),
				Value:     metric.Value,
				Threshold: tm.monitor.config.AlertThreshold,
			}

			tm.monitor.alerts = append(tm.monitor.alerts, alert)
		}
	}
}

// generateExecutionID generates a unique execution ID
func generateExecutionID() string {
	return fmt.Sprintf("exec_%d", time.Now().UnixNano())
}

// generateScheduleID generates a unique schedule ID
func generateScheduleID() string {
	return fmt.Sprintf("sched_%d", time.Now().UnixNano())
}

// TaskScheduler implementation
func (ts *TaskScheduler) RegisterSchedule(schedule *TaskSchedule) error {
	ts.mutex.Lock()
	defer ts.mutex.Unlock()

	if _, exists := ts.schedules[schedule.ID]; exists {
		return fmt.Errorf("schedule %s already exists", schedule.ID)
	}

	ts.schedules[schedule.ID] = schedule
	return nil
}

func (ts *TaskScheduler) GetSchedule(scheduleID string) (*TaskSchedule, error) {
	ts.mutex.RLock()
	defer ts.mutex.RUnlock()

	schedule, exists := ts.schedules[scheduleID]
	if !exists {
		return nil, fmt.Errorf("schedule %s not found", scheduleID)
	}

	return schedule, nil
}

func (ts *TaskScheduler) ListSchedules() []*TaskSchedule {
	ts.mutex.RLock()
	defer ts.mutex.RUnlock()

	schedules := make([]*TaskSchedule, 0, len(ts.schedules))
	for _, schedule := range ts.schedules {
		schedules = append(schedules, schedule)
	}

	return schedules
}

func (ts *TaskScheduler) EnableSchedule(scheduleID string) error {
	ts.mutex.Lock()
	defer ts.mutex.Unlock()

	schedule, exists := ts.schedules[scheduleID]
	if !exists {
		return fmt.Errorf("schedule %s not found", scheduleID)
	}

	schedule.Enabled = true
	return nil
}

func (ts *TaskScheduler) DisableSchedule(scheduleID string) error {
	ts.mutex.Lock()
	defer ts.mutex.Unlock()

	schedule, exists := ts.schedules[scheduleID]
	if !exists {
		return fmt.Errorf("schedule %s not found", scheduleID)
	}

	schedule.Enabled = false
	return nil
}

func (ts *TaskScheduler) checkSchedules() {
	ts.mutex.RLock()
	defer ts.mutex.RUnlock()

	now := time.Now()
	for _, schedule := range ts.schedules {
		if !schedule.Enabled {
			continue
		}

		if schedule.NextRun != nil && now.After(*schedule.NextRun) {
			// Execute task
			go ts.executeScheduledTask(schedule)

			// Update schedule
			schedule.LastRun = &now
			schedule.RunCount++

			// Calculate next run time
			nextRun, err := ts.taskManager.calculateNextRun(schedule.CronExpr)
			if err == nil {
				schedule.NextRun = &nextRun
			}
		}
	}
}

func (ts *TaskScheduler) executeScheduledTask(schedule *TaskSchedule) {
	// Execute the task
	_, err := ts.taskManager.ExecuteTask(schedule.TaskID, make(map[string]interface{}))
	if err != nil {
		// Log error
		// In practice, this would log to a proper logging system
	}
}

// GetStats returns task manager statistics
func (tm *TaskManager) GetStats() map[string]interface{} {
	tm.mutex.RLock()
	defer tm.mutex.RUnlock()

	stats := map[string]interface{}{
		"tasks":     len(tm.tasks),
		"schedules": len(tm.schedules),
		"executions": len(tm.executions),
		"config":    tm.config,
	}

	// Calculate execution statistics
	totalExecutions := len(tm.executions)
	completedExecutions := 0
	failedExecutions := 0
	runningExecutions := 0

	for _, execution := range tm.executions {
		switch execution.Status {
		case "completed":
			completedExecutions++
		case "failed":
			failedExecutions++
		case "running":
			runningExecutions++
		}
	}

	stats["total_executions"] = totalExecutions
	stats["completed_executions"] = completedExecutions
	stats["failed_executions"] = failedExecutions
	stats["running_executions"] = runningExecutions

	if totalExecutions > 0 {
		stats["success_rate"] = float64(completedExecutions) / float64(totalExecutions)
	}

	return stats
} 