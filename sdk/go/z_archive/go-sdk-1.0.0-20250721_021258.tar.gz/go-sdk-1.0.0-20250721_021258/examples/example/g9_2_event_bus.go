package main

import (
	"context"
	"fmt"
	"sync"
	"time"
)

// EventBus provides event-driven communication capabilities
type EventBus struct {
	subscribers map[string][]*Subscriber
	config      EventBusConfig
	dispatcher  *EventDispatcher
	registry    *EventRegistry
	mutex       sync.RWMutex
}

// Event represents an event
type Event struct {
	ID        string            `json:"id"`
	Type      string            `json:"type"`
	Source    string            `json:"source"`
	Data      interface{}       `json:"data"`
	Headers   map[string]string `json:"headers"`
	Timestamp time.Time         `json:"timestamp"`
	Priority  int               `json:"priority"`
	TTL       time.Duration     `json:"ttl"`
	Metadata  map[string]string `json:"metadata"`
}

// Subscriber represents an event subscriber
type Subscriber struct {
	ID          string            `json:"id"`
	Pattern     string            `json:"pattern"`
	Handler     EventHandler      `json:"-"`
	Priority    int               `json:"priority"`
	Active      bool              `json:"active"`
	CreatedAt   time.Time         `json:"created_at"`
	LastEvent   *time.Time        `json:"last_event"`
	Stats       *SubscriberStats  `json:"stats"`
	Metadata    map[string]string `json:"metadata"`
}

// EventHandler represents an event handler function
type EventHandler func(*Event) error

// EventBusConfig represents event bus configuration
type EventBusConfig struct {
	EnableAsync       bool          `json:"enable_async"`
	AsyncWorkers      int           `json:"async_workers"`
	EnableRetry       bool          `json:"enable_retry"`
	MaxRetries        int           `json:"max_retries"`
	RetryDelay        time.Duration `json:"retry_delay"`
	EnableDeadLetter  bool          `json:"enable_dead_letter"`
	DeadLetterTopic   string        `json:"dead_letter_topic"`
	EnableMonitoring  bool          `json:"enable_monitoring"`
	MonitorInterval   time.Duration `json:"monitor_interval"`
	EnablePersistence bool          `json:"enable_persistence"`
	PersistencePath   string        `json:"persistence_path"`
}

// EventDispatcher manages event dispatching
type EventDispatcher struct {
	eventBus *EventBus
	workers  chan struct{}
	config   DispatcherConfig
	mutex    sync.RWMutex
}

// DispatcherConfig represents dispatcher configuration
type DispatcherConfig struct {
	WorkerPoolSize int           `json:"worker_pool_size"`
	QueueSize      int           `json:"queue_size"`
	Timeout        time.Duration `json:"timeout"`
	EnableMetrics  bool          `json:"enable_metrics"`
}

// EventRegistry manages event registration
type EventRegistry struct {
	events map[string]*EventType
	mutex  sync.RWMutex
}

// EventType represents an event type
type EventType struct {
	Name        string            `json:"name"`
	Description string            `json:"description"`
	Schema      map[string]string `json:"schema"`
	Version     string            `json:"version"`
	Deprecated  bool              `json:"deprecated"`
	Metadata    map[string]string `json:"metadata"`
}

// SubscriberStats represents subscriber statistics
type SubscriberStats struct {
	TotalEvents    int64         `json:"total_events"`
	SuccessfulEvents int64       `json:"successful_events"`
	FailedEvents   int64         `json:"failed_events"`
	TotalDuration  time.Duration `json:"total_duration"`
	AverageDuration time.Duration `json:"average_duration"`
	LastEventAt    *time.Time    `json:"last_event_at"`
	mutex          sync.RWMutex
}

// EventBus creates a new event bus
func NewEventBus(config EventBusConfig) *EventBus {
	eb := &EventBus{
		subscribers: make(map[string][]*Subscriber),
		config:      config,
		dispatcher: &EventDispatcher{
			workers: make(chan struct{}, config.AsyncWorkers),
			config: DispatcherConfig{
				WorkerPoolSize: config.AsyncWorkers,
				QueueSize:      1000,
				Timeout:        30 * time.Second,
				EnableMetrics:  true,
			},
		},
		registry: &EventRegistry{
			events: make(map[string]*EventType),
		},
	}

	eb.dispatcher.eventBus = eb

	// Start monitoring if enabled
	if config.EnableMonitoring {
		go eb.startMonitoring()
	}

	return eb
}

// Subscribe subscribes to an event pattern
func (eb *EventBus) Subscribe(pattern string, handler EventHandler) (*Subscriber, error) {
	eb.mutex.Lock()
	defer eb.mutex.Unlock()

	subscriber := &Subscriber{
		ID:        generateSubscriberID(),
		Pattern:   pattern,
		Handler:   handler,
		Priority:  0,
		Active:    true,
		CreatedAt: time.Now(),
		Stats:     &SubscriberStats{},
		Metadata:  make(map[string]string),
	}

	// Add subscriber to pattern
	if eb.subscribers[pattern] == nil {
		eb.subscribers[pattern] = make([]*Subscriber, 0)
	}
	eb.subscribers[pattern] = append(eb.subscribers[pattern], subscriber)

	return subscriber, nil
}

// Unsubscribe unsubscribes from an event pattern
func (eb *EventBus) Unsubscribe(subscriber *Subscriber) error {
	eb.mutex.Lock()
	defer eb.mutex.Unlock()

	subscribers, exists := eb.subscribers[subscriber.Pattern]
	if !exists {
		return fmt.Errorf("pattern %s not found", subscriber.Pattern)
	}

	// Remove subscriber
	for i, sub := range subscribers {
		if sub.ID == subscriber.ID {
			eb.subscribers[subscriber.Pattern] = append(subscribers[:i], subscribers[i+1:]...)
			subscriber.Active = false
			return nil
		}
	}

	return fmt.Errorf("subscriber %s not found", subscriber.ID)
}

// Publish publishes an event
func (eb *EventBus) Publish(eventType string, data interface{}, headers map[string]string) error {
	event := &Event{
		ID:        generateEventID(),
		Type:      eventType,
		Source:    "system",
		Data:      data,
		Headers:   headers,
		Timestamp: time.Now(),
		Priority:  0,
		Metadata:  make(map[string]string),
	}

	return eb.dispatchEvent(event)
}

// PublishEvent publishes a complete event
func (eb *EventBus) PublishEvent(event *Event) error {
	if event.ID == "" {
		event.ID = generateEventID()
	}
	if event.Timestamp.IsZero() {
		event.Timestamp = time.Now()
	}
	if event.Headers == nil {
		event.Headers = make(map[string]string)
	}
	if event.Metadata == nil {
		event.Metadata = make(map[string]string)
	}

	return eb.dispatchEvent(event)
}

// dispatchEvent dispatches an event to subscribers
func (eb *EventBus) dispatchEvent(event *Event) error {
	eb.mutex.RLock()
	defer eb.mutex.RUnlock()

	// Find matching subscribers
	var matchingSubscribers []*Subscriber
	for pattern, subscribers := range eb.subscribers {
		if eb.matchesPattern(event.Type, pattern) {
			for _, subscriber := range subscribers {
				if subscriber.Active {
					matchingSubscribers = append(matchingSubscribers, subscriber)
				}
			}
		}
	}

	// Sort subscribers by priority
	eb.sortSubscribersByPriority(matchingSubscribers)

	// Dispatch to subscribers
	if eb.config.EnableAsync {
		return eb.dispatchAsync(event, matchingSubscribers)
	} else {
		return eb.dispatchSync(event, matchingSubscribers)
	}
}

// matchesPattern checks if event type matches pattern
func (eb *EventBus) matchesPattern(eventType, pattern string) bool {
	// Simple pattern matching - in practice, use regex or more sophisticated matching
	return eventType == pattern || pattern == "*"
}

// sortSubscribersByPriority sorts subscribers by priority
func (eb *EventBus) sortSubscribersByPriority(subscribers []*Subscriber) {
	// Sort in descending order (higher priority first)
	for i := 0; i < len(subscribers)-1; i++ {
		for j := i + 1; j < len(subscribers); j++ {
			if subscribers[i].Priority < subscribers[j].Priority {
				subscribers[i], subscribers[j] = subscribers[j], subscribers[i]
			}
		}
	}
}

// dispatchSync dispatches events synchronously
func (eb *EventBus) dispatchSync(event *Event, subscribers []*Subscriber) error {
	var lastError error

	for _, subscriber := range subscribers {
		if err := eb.handleEvent(subscriber, event); err != nil {
			lastError = err
		}
	}

	return lastError
}

// dispatchAsync dispatches events asynchronously
func (eb *EventBus) dispatchAsync(event *Event, subscribers []*Subscriber) error {
	for _, subscriber := range subscribers {
		go func(sub *Subscriber, evt *Event) {
			eb.dispatcher.workers <- struct{}{} // Acquire worker
			defer func() {
				<-eb.dispatcher.workers // Release worker
			}()

			eb.handleEvent(sub, evt)
		}(subscriber, event)
	}

	return nil
}

// handleEvent handles an event for a subscriber
func (eb *EventBus) handleEvent(subscriber *Subscriber, event *Event) error {
	start := time.Now()

	// Update subscriber stats
	subscriber.Stats.mutex.Lock()
	subscriber.Stats.TotalEvents++
	subscriber.Stats.LastEventAt = &start
	subscriber.Stats.mutex.Unlock()

	// Execute handler with retry logic
	var err error
	for attempt := 0; attempt <= eb.config.MaxRetries; attempt++ {
		err = subscriber.Handler(event)
		if err == nil {
			break
		}

		if attempt < eb.config.MaxRetries && eb.config.EnableRetry {
			time.Sleep(eb.config.RetryDelay)
		}
	}

	duration := time.Since(start)

	// Update stats
	subscriber.Stats.mutex.Lock()
	subscriber.Stats.TotalDuration += duration
	if err == nil {
		subscriber.Stats.SuccessfulEvents++
	} else {
		subscriber.Stats.FailedEvents++
	}
	if subscriber.Stats.TotalEvents > 0 {
		subscriber.Stats.AverageDuration = subscriber.Stats.TotalDuration / time.Duration(subscriber.Stats.TotalEvents)
	}
	subscriber.Stats.mutex.Unlock()

	// Send to dead letter if failed and enabled
	if err != nil && eb.config.EnableDeadLetter {
		eb.sendToDeadLetter(event, err)
	}

	return err
}

// sendToDeadLetter sends failed events to dead letter topic
func (eb *EventBus) sendToDeadLetter(event *Event, err error) {
	deadLetterEvent := &Event{
		ID:        generateEventID(),
		Type:      eb.config.DeadLetterTopic,
		Source:    "dead_letter",
		Data:      event,
		Headers:   map[string]string{"original_error": err.Error()},
		Timestamp: time.Now(),
		Metadata:  make(map[string]string),
	}

	// Publish to dead letter topic
	eb.dispatchEvent(deadLetterEvent)
}

// RegisterEventType registers an event type
func (eb *EventBus) RegisterEventType(eventType *EventType) error {
	eb.registry.mutex.Lock()
	defer eb.registry.mutex.Unlock()

	if _, exists := eb.registry.events[eventType.Name]; exists {
		return fmt.Errorf("event type %s already registered", eventType.Name)
	}

	if eventType.Metadata == nil {
		eventType.Metadata = make(map[string]string)
	}

	eb.registry.events[eventType.Name] = eventType
	return nil
}

// GetEventType returns an event type by name
func (eb *EventBus) GetEventType(name string) (*EventType, error) {
	eb.registry.mutex.RLock()
	defer eb.registry.mutex.RUnlock()

	eventType, exists := eb.registry.events[name]
	if !exists {
		return nil, fmt.Errorf("event type %s not found", name)
	}

	return eventType, nil
}

// ListEventTypes lists all registered event types
func (eb *EventBus) ListEventTypes() []*EventType {
	eb.registry.mutex.RLock()
	defer eb.registry.mutex.RUnlock()

	eventTypes := make([]*EventType, 0, len(eb.registry.events))
	for _, eventType := range eb.registry.events {
		eventTypes = append(eventTypes, eventType)
	}

	return eventTypes
}

// GetSubscribers returns subscribers for a pattern
func (eb *EventBus) GetSubscribers(pattern string) []*Subscriber {
	eb.mutex.RLock()
	defer eb.mutex.RUnlock()

	subscribers, exists := eb.subscribers[pattern]
	if !exists {
		return make([]*Subscriber, 0)
	}

	// Return a copy
	result := make([]*Subscriber, len(subscribers))
	copy(result, subscribers)
	return result
}

// GetAllSubscribers returns all subscribers
func (eb *EventBus) GetAllSubscribers() map[string][]*Subscriber {
	eb.mutex.RLock()
	defer eb.mutex.RUnlock()

	result := make(map[string][]*Subscriber)
	for pattern, subscribers := range eb.subscribers {
		result[pattern] = make([]*Subscriber, len(subscribers))
		copy(result[pattern], subscribers)
	}

	return result
}

// GetStats returns event bus statistics
func (eb *EventBus) GetStats() map[string]interface{} {
	eb.mutex.RLock()
	defer eb.mutex.RUnlock()

	stats := map[string]interface{}{
		"patterns":    len(eb.subscribers),
		"event_types": len(eb.registry.events),
		"config":      eb.config,
	}

	// Calculate total subscribers
	totalSubscribers := 0
	activeSubscribers := 0
	for _, subscribers := range eb.subscribers {
		totalSubscribers += len(subscribers)
		for _, subscriber := range subscribers {
			if subscriber.Active {
				activeSubscribers++
			}
		}
	}

	stats["total_subscribers"] = totalSubscribers
	stats["active_subscribers"] = activeSubscribers

	return stats
}

// startMonitoring starts event bus monitoring
func (eb *EventBus) startMonitoring() {
	ticker := time.NewTicker(eb.config.MonitorInterval)
	defer ticker.Stop()

	for {
		select {
		case <-ticker.C:
			eb.collectMetrics()
		}
	}
}

// collectMetrics collects event bus metrics
func (eb *EventBus) collectMetrics() {
	// This would collect and store metrics
	// For now, just a placeholder
}

// generateEventID generates a unique event ID
func generateEventID() string {
	return fmt.Sprintf("evt_%d", time.Now().UnixNano())
}

// generateSubscriberID generates a unique subscriber ID
func generateSubscriberID() string {
	return fmt.Sprintf("sub_%d", time.Now().UnixNano())
}

// Close closes the event bus
func (eb *EventBus) Close() error {
	eb.mutex.Lock()
	defer eb.mutex.Unlock()

	// Close all subscribers
	for pattern, subscribers := range eb.subscribers {
		for _, subscriber := range subscribers {
			subscriber.Active = false
		}
		eb.subscribers[pattern] = nil
	}

	return nil
} 