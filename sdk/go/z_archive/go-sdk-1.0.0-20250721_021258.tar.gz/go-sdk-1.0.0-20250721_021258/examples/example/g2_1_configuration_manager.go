package main

import (
	"context"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"os"
	"path/filepath"
	"reflect"
	"strconv"
	"strings"
	"sync"
	"time"

	"gopkg.in/yaml.v3"
)

// ConfigurationManager provides comprehensive configuration management
type ConfigurationManager struct {
	configs     map[string]interface{}
	watchers    map[string][]ConfigWatcher
	mutex       sync.RWMutex
	configPath  string
	autoReload  bool
	encryption  bool
	encryptKey  []byte
}

// ConfigWatcher interface for configuration change notifications
type ConfigWatcher interface {
	OnConfigChanged(key string, oldValue, newValue interface{})
}

// ConfigValidator interface for configuration validation
type ConfigValidator interface {
	Validate(config map[string]interface{}) error
}

// ConfigSource represents different configuration sources
type ConfigSource struct {
	Type     string `json:"type"`     // file, env, database, api
	Path     string `json:"path"`     // file path, env prefix, etc.
	Priority int    `json:"priority"` // higher number = higher priority
	Required bool   `json:"required"` // whether this source is required
}

// ConfigurationManager creates a new configuration manager
func NewConfigurationManager(configPath string) *ConfigurationManager {
	return &ConfigurationManager{
		configs:    make(map[string]interface{}),
		watchers:   make(map[string][]ConfigWatcher),
		configPath: configPath,
		autoReload: true,
		encryption: false,
	}
}

// LoadConfiguration loads configuration from multiple sources
func (cm *ConfigurationManager) LoadConfiguration(sources []ConfigSource) error {
	cm.mutex.Lock()
	defer cm.mutex.Unlock()

	// Sort sources by priority
	sortedSources := make([]ConfigSource, len(sources))
	copy(sortedSources, sources)
	
	// Load from each source
	for _, source := range sortedSources {
		switch source.Type {
		case "file":
			if err := cm.loadFromFile(source.Path); err != nil {
				if source.Required {
					return fmt.Errorf("required config file %s failed to load: %v", source.Path, err)
				}
				// Log warning for non-required sources
				fmt.Printf("Warning: Config file %s failed to load: %v\n", source.Path, err)
			}
		case "env":
			cm.loadFromEnvironment(source.Path)
		case "database":
			if err := cm.loadFromDatabase(source.Path); err != nil {
				if source.Required {
					return fmt.Errorf("required database config failed to load: %v", err)
				}
			}
		case "api":
			if err := cm.loadFromAPI(source.Path); err != nil {
				if source.Required {
					return fmt.Errorf("required API config failed to load: %v", err)
				}
			}
		}
	}

	return nil
}

// loadFromFile loads configuration from a file
func (cm *ConfigurationManager) loadFromFile(filePath string) error {
	data, err := ioutil.ReadFile(filePath)
	if err != nil {
		return err
	}

	var config map[string]interface{}
	ext := strings.ToLower(filepath.Ext(filePath))

	switch ext {
	case ".json":
		if err := json.Unmarshal(data, &config); err != nil {
			return err
		}
	case ".yaml", ".yml":
		if err := yaml.Unmarshal(data, &config); err != nil {
			return err
		}
	case ".env":
		config = cm.parseEnvFile(string(data))
	default:
		return fmt.Errorf("unsupported file format: %s", ext)
	}

	// Merge with existing config
	cm.mergeConfig(config)
	return nil
}

// loadFromEnvironment loads configuration from environment variables
func (cm *ConfigurationManager) loadFromEnvironment(prefix string) {
	config := make(map[string]interface{})
	
	for _, env := range os.Environ() {
		pair := strings.SplitN(env, "=", 2)
		if len(pair) != 2 {
			continue
		}
		
		key, value := pair[0], pair[1]
		if strings.HasPrefix(key, prefix) {
			configKey := strings.TrimPrefix(key, prefix+"_")
			config[configKey] = cm.parseValue(value)
		}
	}
	
	cm.mergeConfig(config)
}

// loadFromDatabase loads configuration from database (placeholder)
func (cm *ConfigurationManager) loadFromDatabase(connectionString string) error {
	// Implementation would connect to database and load config
	// For now, return nil as placeholder
	return nil
}

// loadFromAPI loads configuration from API (placeholder)
func (cm *ConfigurationManager) loadFromAPI(endpoint string) error {
	// Implementation would make HTTP request to API
	// For now, return nil as placeholder
	return nil
}

// parseEnvFile parses .env file format
func (cm *ConfigurationManager) parseEnvFile(content string) map[string]interface{} {
	config := make(map[string]interface{})
	lines := strings.Split(content, "\n")
	
	for _, line := range lines {
		line = strings.TrimSpace(line)
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		
		if idx := strings.Index(line, "="); idx != -1 {
			key := strings.TrimSpace(line[:idx])
			value := strings.TrimSpace(line[idx+1:])
			config[key] = cm.parseValue(value)
		}
	}
	
	return config
}

// parseValue attempts to parse string value into appropriate type
func (cm *ConfigurationManager) parseValue(value string) interface{} {
	// Try boolean
	if value == "true" || value == "false" {
		return value == "true"
	}
	
	// Try integer
	if intVal, err := strconv.Atoi(value); err == nil {
		return intVal
	}
	
	// Try float
	if floatVal, err := strconv.ParseFloat(value, 64); err == nil {
		return floatVal
	}
	
	// Return as string
	return value
}

// mergeConfig merges new configuration with existing
func (cm *ConfigurationManager) mergeConfig(newConfig map[string]interface{}) {
	for key, value := range newConfig {
		cm.configs[key] = value
	}
}

// Get retrieves a configuration value
func (cm *ConfigurationManager) Get(key string) interface{} {
	cm.mutex.RLock()
	defer cm.mutex.RUnlock()
	
	keys := strings.Split(key, ".")
	current := cm.configs
	
	for _, k := range keys {
		if val, ok := current[k]; ok {
			if reflect.TypeOf(val).Kind() == reflect.Map {
				if mapVal, ok := val.(map[string]interface{}); ok {
					current = mapVal
					continue
				}
			}
			return val
		}
		return nil
	}
	
	return current
}

// GetString retrieves a configuration value as string
func (cm *ConfigurationManager) GetString(key string, defaultValue string) string {
	value := cm.Get(key)
	if value == nil {
		return defaultValue
	}
	return fmt.Sprintf("%v", value)
}

// GetInt retrieves a configuration value as int
func (cm *ConfigurationManager) GetInt(key string, defaultValue int) int {
	value := cm.Get(key)
	if value == nil {
		return defaultValue
	}
	
	switch v := value.(type) {
	case int:
		return v
	case float64:
		return int(v)
	case string:
		if intVal, err := strconv.Atoi(v); err == nil {
			return intVal
		}
	}
	
	return defaultValue
}

// GetBool retrieves a configuration value as bool
func (cm *ConfigurationManager) GetBool(key string, defaultValue bool) bool {
	value := cm.Get(key)
	if value == nil {
		return defaultValue
	}
	
	switch v := value.(type) {
	case bool:
		return v
	case string:
		return v == "true"
	case int:
		return v != 0
	}
	
	return defaultValue
}

// Set sets a configuration value
func (cm *ConfigurationManager) Set(key string, value interface{}) {
	cm.mutex.Lock()
	defer cm.mutex.Unlock()
	
	oldValue := cm.Get(key)
	cm.configs[key] = value
	
	// Notify watchers
	if watchers, ok := cm.watchers[key]; ok {
		for _, watcher := range watchers {
			watcher.OnConfigChanged(key, oldValue, value)
		}
	}
}

// Watch registers a watcher for configuration changes
func (cm *ConfigurationManager) Watch(key string, watcher ConfigWatcher) {
	cm.mutex.Lock()
	defer cm.mutex.Unlock()
	
	cm.watchers[key] = append(cm.watchers[key], watcher)
}

// Unwatch removes a watcher
func (cm *ConfigurationManager) Unwatch(key string, watcher ConfigWatcher) {
	cm.mutex.Lock()
	defer cm.mutex.Unlock()
	
	if watchers, ok := cm.watchers[key]; ok {
		for i, w := range watchers {
			if w == watcher {
				cm.watchers[key] = append(watchers[:i], watchers[i+1:]...)
				break
			}
		}
	}
}

// Validate validates configuration using provided validators
func (cm *ConfigurationManager) Validate(validators []ConfigValidator) error {
	cm.mutex.RLock()
	defer cm.mutex.RUnlock()
	
	for _, validator := range validators {
		if err := validator.Validate(cm.configs); err != nil {
			return err
		}
	}
	
	return nil
}

// Save saves configuration to file
func (cm *ConfigurationManager) Save(filePath string) error {
	cm.mutex.RLock()
	defer cm.mutex.RUnlock()
	
	data, err := json.MarshalIndent(cm.configs, "", "  ")
	if err != nil {
		return err
	}
	
	return ioutil.WriteFile(filePath, data, 0644)
}

// Export exports configuration in specified format
func (cm *ConfigurationManager) Export(format string) ([]byte, error) {
	cm.mutex.RLock()
	defer cm.mutex.RUnlock()
	
	switch format {
	case "json":
		return json.MarshalIndent(cm.configs, "", "  ")
	case "yaml":
		return yaml.Marshal(cm.configs)
	default:
		return nil, fmt.Errorf("unsupported format: %s", format)
	}
}

// Reload reloads configuration from sources
func (cm *ConfigurationManager) Reload(sources []ConfigSource) error {
	cm.mutex.Lock()
	cm.configs = make(map[string]interface{})
	cm.mutex.Unlock()
	
	return cm.LoadConfiguration(sources)
}

// GetStats returns configuration statistics
func (cm *ConfigurationManager) GetStats() map[string]interface{} {
	cm.mutex.RLock()
	defer cm.mutex.RUnlock()
	
	return map[string]interface{}{
		"total_keys":     len(cm.configs),
		"total_watchers": len(cm.watchers),
		"auto_reload":    cm.autoReload,
		"encryption":     cm.encryption,
	}
} 