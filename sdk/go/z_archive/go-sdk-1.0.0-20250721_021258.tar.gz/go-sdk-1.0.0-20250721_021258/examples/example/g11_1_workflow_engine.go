package main

import (
	"context"
	"fmt"
	"sync"
	"time"
)

// WorkflowEngine provides workflow orchestration capabilities
type WorkflowEngine struct {
	workflows   map[string]*Workflow
	executions  map[string]*WorkflowExecution
	config      WorkflowConfig
	executor    *WorkflowExecutor
	scheduler   *WorkflowScheduler
	monitor     *WorkflowMonitor
	mutex       sync.RWMutex
}

// Workflow represents a workflow definition
type Workflow struct {
	ID          string            `json:"id"`
	Name        string            `json:"name"`
	Description string            `json:"description"`
	Version     string            `json:"version"`
	Steps       []*WorkflowStep   `json:"steps"`
	Triggers    []*WorkflowTrigger `json:"triggers"`
	Variables   map[string]string `json:"variables"`
	CreatedAt   time.Time         `json:"created_at"`
	UpdatedAt   time.Time         `json:"updated_at"`
	Metadata    map[string]string `json:"metadata"`
}

// WorkflowStep represents a workflow step
type WorkflowStep struct {
	ID          string            `json:"id"`
	Name        string            `json:"name"`
	Type        string            `json:"type"` // task, condition, loop, parallel
	Action      string            `json:"action"`
	Input       map[string]string `json:"input"`
	Output      map[string]string `json:"output"`
	Condition   string            `json:"condition"`
	RetryPolicy *RetryPolicy      `json:"retry_policy"`
	Timeout     time.Duration     `json:"timeout"`
	DependsOn   []string          `json:"depends_on"`
	Metadata    map[string]string `json:"metadata"`
}

// WorkflowTrigger represents a workflow trigger
type WorkflowTrigger struct {
	ID       string            `json:"id"`
	Type     string            `json:"type"` // schedule, event, manual
	Schedule string            `json:"schedule"`
	Event    string            `json:"event"`
	Enabled  bool              `json:"enabled"`
	Metadata map[string]string `json:"metadata"`
}

// WorkflowExecution represents a workflow execution
type WorkflowExecution struct {
	ID           string                    `json:"id"`
	WorkflowID   string                    `json:"workflow_id"`
	Status       string                    `json:"status"` // pending, running, completed, failed, cancelled
	Input        map[string]interface{}    `json:"input"`
	Output       map[string]interface{}    `json:"output"`
	Variables    map[string]interface{}    `json:"variables"`
	StepResults  map[string]*StepResult    `json:"step_results"`
	StartedAt    *time.Time                `json:"started_at"`
	CompletedAt  *time.Time                `json:"completed_at"`
	Error        string                    `json:"error"`
	Context      map[string]interface{}    `json:"context"`
	Metadata     map[string]string         `json:"metadata"`
}

// StepResult represents a step execution result
type StepResult struct {
	StepID      string                 `json:"step_id"`
	Status      string                 `json:"status"` // pending, running, completed, failed, skipped
	Input       map[string]interface{} `json:"input"`
	Output      map[string]interface{} `json:"output"`
	StartedAt   *time.Time             `json:"started_at"`
	CompletedAt *time.Time             `json:"completed_at"`
	Error       string                 `json:"error"`
	RetryCount  int                    `json:"retry_count"`
	Metadata    map[string]string      `json:"metadata"`
}

// RetryPolicy represents a retry policy
type RetryPolicy struct {
	MaxRetries  int           `json:"max_retries"`
	Delay       time.Duration `json:"delay"`
	Backoff     string        `json:"backoff"` // fixed, exponential
	MaxDelay    time.Duration `json:"max_delay"`
}

// WorkflowConfig represents workflow configuration
type WorkflowConfig struct {
	MaxConcurrentExecutions int           `json:"max_concurrent_executions"`
	DefaultTimeout          time.Duration `json:"default_timeout"`
	EnableRetry             bool          `json:"enable_retry"`
	MaxRetries              int           `json:"max_retries"`
	EnableMonitoring        bool          `json:"enable_monitoring"`
	MonitorInterval         time.Duration `json:"monitor_interval"`
	EnablePersistence       bool          `json:"enable_persistence"`
	PersistencePath         string        `json:"persistence_path"`
}

// WorkflowExecutor manages workflow execution
type WorkflowExecutor struct {
	workflowEngine *WorkflowEngine
	workers        chan struct{}
	config         ExecutorConfig
	mutex          sync.RWMutex
}

// ExecutorConfig represents executor configuration
type ExecutorConfig struct {
	WorkerPoolSize int           `json:"worker_pool_size"`
	QueueSize      int           `json:"queue_size"`
	Timeout        time.Duration `json:"timeout"`
	EnableMetrics  bool          `json:"enable_metrics"`
}

// WorkflowScheduler manages workflow scheduling
type WorkflowScheduler struct {
	workflowEngine *WorkflowEngine
	schedules      map[string]*Schedule
	config         SchedulerConfig
	mutex          sync.RWMutex
}

// Schedule represents a workflow schedule
type Schedule struct {
	ID         string            `json:"id"`
	WorkflowID string            `json:"workflow_id"`
	CronExpr   string            `json:"cron_expr"`
	Enabled    bool              `json:"enabled"`
	LastRun    *time.Time        `json:"last_run"`
	NextRun    *time.Time        `json:"next_run"`
	Metadata   map[string]string `json:"metadata"`
}

// SchedulerConfig represents scheduler configuration
type SchedulerConfig struct {
	EnableScheduling bool          `json:"enable_scheduling"`
	CheckInterval    time.Duration `json:"check_interval"`
	MaxSchedules     int           `json:"max_schedules"`
}

// WorkflowMonitor monitors workflow execution
type WorkflowMonitor struct {
	workflowEngine *WorkflowEngine
	metrics        map[string]*WorkflowMetric
	alerts         []WorkflowAlert
	config         MonitorConfig
	mutex          sync.RWMutex
}

// WorkflowMetric represents a workflow metric
type WorkflowMetric struct {
	WorkflowID     string                 `json:"workflow_id"`
	Name           string                 `json:"name"`
	Value          float64                `json:"value"`
	Unit           string                 `json:"unit"`
	Timestamp      time.Time              `json:"timestamp"`
	History        []MetricPoint          `json:"history"`
	Thresholds     map[string]float64     `json:"thresholds"`
	Metadata       map[string]interface{} `json:"metadata"`
}

// WorkflowAlert represents a workflow alert
type WorkflowAlert struct {
	WorkflowID string    `json:"workflow_id"`
	Type       string    `json:"type"`
	Message    string    `json:"message"`
	Severity   string    `json:"severity"`
	Timestamp  time.Time `json:"timestamp"`
	Value      float64   `json:"value"`
	Threshold  float64   `json:"threshold"`
}

// MonitorConfig represents monitor configuration
type MonitorConfig struct {
	EnableLatencyMonitoring bool          `json:"enable_latency_monitoring"`
	EnableThroughputMonitoring bool       `json:"enable_throughput_monitoring"`
	EnableErrorMonitoring   bool          `json:"enable_error_monitoring"`
	AlertThreshold          float64       `json:"alert_threshold"`
	CheckInterval           time.Duration `json:"check_interval"`
}

// WorkflowEngine creates a new workflow engine
func NewWorkflowEngine(config WorkflowConfig) *WorkflowEngine {
	we := &WorkflowEngine{
		workflows:  make(map[string]*Workflow),
		executions: make(map[string]*WorkflowExecution),
		config:     config,
		executor: &WorkflowExecutor{
			workers: make(chan struct{}, config.MaxConcurrentExecutions),
			config: ExecutorConfig{
				WorkerPoolSize: config.MaxConcurrentExecutions,
				QueueSize:      1000,
				Timeout:        config.DefaultTimeout,
				EnableMetrics:  true,
			},
		},
		scheduler: &WorkflowScheduler{
			schedules: make(map[string]*Schedule),
			config: SchedulerConfig{
				EnableScheduling: true,
				CheckInterval:    1 * time.Minute,
				MaxSchedules:     100,
			},
		},
		monitor: &WorkflowMonitor{
			metrics: make(map[string]*WorkflowMetric),
			alerts:  make([]WorkflowAlert, 0),
			config: MonitorConfig{
				EnableLatencyMonitoring: true,
				EnableThroughputMonitoring: true,
				EnableErrorMonitoring:   true,
				AlertThreshold:          0.8,
				CheckInterval:           30 * time.Second,
			},
		},
	}

	we.executor.workflowEngine = we
	we.scheduler.workflowEngine = we
	we.monitor.workflowEngine = we

	// Start monitoring if enabled
	if config.EnableMonitoring {
		go we.startMonitoring()
	}

	// Start scheduler if enabled
	if we.scheduler.config.EnableScheduling {
		go we.startScheduler()
	}

	return we
}

// RegisterWorkflow registers a workflow
func (we *WorkflowEngine) RegisterWorkflow(workflow *Workflow) error {
	we.mutex.Lock()
	defer we.mutex.Unlock()

	if _, exists := we.workflows[workflow.ID]; exists {
		return fmt.Errorf("workflow %s already exists", workflow.ID)
	}

	workflow.CreatedAt = time.Now()
	workflow.UpdatedAt = time.Now()
	if workflow.Metadata == nil {
		workflow.Metadata = make(map[string]string)
	}

	// Validate workflow
	if err := we.validateWorkflow(workflow); err != nil {
		return err
	}

	we.workflows[workflow.ID] = workflow

	// Register triggers
	for _, trigger := range workflow.Triggers {
		if trigger.Type == "schedule" && trigger.Enabled {
			we.scheduler.RegisterSchedule(workflow.ID, trigger)
		}
	}

	return nil
}

// validateWorkflow validates a workflow
func (we *WorkflowEngine) validateWorkflow(workflow *Workflow) error {
	if len(workflow.Steps) == 0 {
		return fmt.Errorf("workflow must have at least one step")
	}

	// Check for circular dependencies
	if err := we.checkCircularDependencies(workflow); err != nil {
		return err
	}

	return nil
}

// checkCircularDependencies checks for circular dependencies
func (we *WorkflowEngine) checkCircularDependencies(workflow *Workflow) error {
	// Simple cycle detection
	// In practice, this would use a more sophisticated algorithm
	visited := make(map[string]bool)
	recStack := make(map[string]bool)

	for _, step := range workflow.Steps {
		if !visited[step.ID] {
			if we.isCyclic(step.ID, workflow, visited, recStack) {
				return fmt.Errorf("circular dependency detected in workflow")
			}
		}
	}

	return nil
}

// isCyclic checks if there's a cycle in the dependency graph
func (we *WorkflowEngine) isCyclic(stepID string, workflow *Workflow, visited, recStack map[string]bool) bool {
	visited[stepID] = true
	recStack[stepID] = true

	// Find step
	var step *WorkflowStep
	for _, s := range workflow.Steps {
		if s.ID == stepID {
			step = s
			break
		}
	}

	if step == nil {
		return false
	}

	// Check dependencies
	for _, depID := range step.DependsOn {
		if !visited[depID] {
			if we.isCyclic(depID, workflow, visited, recStack) {
				return true
			}
		} else if recStack[depID] {
			return true
		}
	}

	recStack[stepID] = false
	return false
}

// ExecuteWorkflow executes a workflow
func (we *WorkflowEngine) ExecuteWorkflow(workflowID string, input map[string]interface{}) (*WorkflowExecution, error) {
	we.mutex.RLock()
	workflow, exists := we.workflows[workflowID]
	we.mutex.RUnlock()

	if !exists {
		return nil, fmt.Errorf("workflow %s not found", workflowID)
	}

	// Create execution
	execution := &WorkflowExecution{
		ID:         generateExecutionID(),
		WorkflowID: workflowID,
		Status:     "pending",
		Input:      input,
		Output:     make(map[string]interface{}),
		Variables:  make(map[string]interface{}),
		StepResults: make(map[string]*StepResult),
		Context:    make(map[string]interface{}),
		Metadata:   make(map[string]string),
	}

	// Store execution
	we.mutex.Lock()
	we.executions[execution.ID] = execution
	we.mutex.Unlock()

	// Execute workflow
	go we.executor.executeWorkflow(execution)

	return execution, nil
}

// GetExecution returns an execution by ID
func (we *WorkflowEngine) GetExecution(executionID string) (*WorkflowExecution, error) {
	we.mutex.RLock()
	defer we.mutex.RUnlock()

	execution, exists := we.executions[executionID]
	if !exists {
		return nil, fmt.Errorf("execution %s not found", executionID)
	}

	return execution, nil
}

// ListExecutions lists all executions
func (we *WorkflowEngine) ListExecutions() []*WorkflowExecution {
	we.mutex.RLock()
	defer we.mutex.RUnlock()

	executions := make([]*WorkflowExecution, 0, len(we.executions))
	for _, execution := range we.executions {
		executions = append(executions, execution)
	}

	return executions
}

// CancelExecution cancels an execution
func (we *WorkflowEngine) CancelExecution(executionID string) error {
	we.mutex.Lock()
	defer we.mutex.Unlock()

	execution, exists := we.executions[executionID]
	if !exists {
		return fmt.Errorf("execution %s not found", executionID)
	}

	if execution.Status == "completed" || execution.Status == "failed" || execution.Status == "cancelled" {
		return fmt.Errorf("execution %s cannot be cancelled", executionID)
	}

	execution.Status = "cancelled"
	now := time.Now()
	execution.CompletedAt = &now

	return nil
}

// GetWorkflow returns a workflow by ID
func (we *WorkflowEngine) GetWorkflow(workflowID string) (*Workflow, error) {
	we.mutex.RLock()
	defer we.mutex.RUnlock()

	workflow, exists := we.workflows[workflowID]
	if !exists {
		return nil, fmt.Errorf("workflow %s not found", workflowID)
	}

	return workflow, nil
}

// ListWorkflows lists all workflows
func (we *WorkflowEngine) ListWorkflows() []*Workflow {
	we.mutex.RLock()
	defer we.mutex.RUnlock()

	workflows := make([]*Workflow, 0, len(we.workflows))
	for _, workflow := range we.workflows {
		workflows = append(workflows, workflow)
	}

	return workflows
}

// startMonitoring starts workflow monitoring
func (we *WorkflowEngine) startMonitoring() {
	ticker := time.NewTicker(we.config.MonitorInterval)
	defer ticker.Stop()

	for {
		select {
		case <-ticker.C:
			we.collectMetrics()
			we.checkAlerts()
		}
	}
}

// startScheduler starts workflow scheduler
func (we *WorkflowEngine) startScheduler() {
	ticker := time.NewTicker(we.scheduler.config.CheckInterval)
	defer ticker.Stop()

	for {
		select {
		case <-ticker.C:
			we.scheduler.checkSchedules()
		}
	}
}

// collectMetrics collects workflow metrics
func (we *WorkflowEngine) collectMetrics() {
	we.mutex.RLock()
	defer we.mutex.RUnlock()

	// Calculate execution statistics
	totalExecutions := len(we.executions)
	completedExecutions := 0
	failedExecutions := 0
	runningExecutions := 0

	for _, execution := range we.executions {
		switch execution.Status {
		case "completed":
			completedExecutions++
		case "failed":
			failedExecutions++
		case "running":
			runningExecutions++
		}
	}

	// Update metrics
	if we.monitor.config.EnableThroughputMonitoring {
		we.updateWorkflowMetric("execution_throughput", float64(completedExecutions), "executions/hour")
	}

	if we.monitor.config.EnableErrorMonitoring && totalExecutions > 0 {
		errorRate := float64(failedExecutions) / float64(totalExecutions)
		we.updateWorkflowMetric("error_rate", errorRate, "percentage")
	}
}

// updateWorkflowMetric updates a workflow metric
func (we *WorkflowEngine) updateWorkflowMetric(name string, value float64, unit string) {
	metricKey := fmt.Sprintf("workflow_%s", name)
	
	we.monitor.mutex.Lock()
	defer we.monitor.mutex.Unlock()

	metric, exists := we.monitor.metrics[metricKey]
	if !exists {
		metric = &WorkflowMetric{
			Name:       name,
			Unit:       unit,
			History:    make([]MetricPoint, 0),
			Thresholds: make(map[string]float64),
			Metadata:   make(map[string]interface{}),
		}
		we.monitor.metrics[metricKey] = metric
	}

	metric.Value = value
	metric.Timestamp = time.Now()

	// Add to history (keep last 100 points)
	metric.History = append(metric.History, MetricPoint{
		Value:     value,
		Timestamp: time.Now(),
	})

	if len(metric.History) > 100 {
		metric.History = metric.History[1:]
	}
}

// checkAlerts checks for workflow alerts
func (we *WorkflowEngine) checkAlerts() {
	we.monitor.mutex.RLock()
	defer we.monitor.mutex.RUnlock()

	for _, metric := range we.monitor.metrics {
		// Check error rate threshold
		if metric.Name == "error_rate" && metric.Value > we.monitor.config.AlertThreshold {
			alert := WorkflowAlert{
				Type:      "high_error_rate",
				Message:   fmt.Sprintf("Workflow error rate is high: %.2f%%", metric.Value*100),
				Severity:  "warning",
				Timestamp: time.Now(),
				Value:     metric.Value,
				Threshold: we.monitor.config.AlertThreshold,
			}

			we.monitor.alerts = append(we.monitor.alerts, alert)
		}
	}
}

// generateExecutionID generates a unique execution ID
func generateExecutionID() string {
	return fmt.Sprintf("exec_%d", time.Now().UnixNano())
}

// WorkflowExecutor implementation
func (we *WorkflowExecutor) executeWorkflow(execution *WorkflowExecution) {
	// Acquire worker
	we.workers <- struct{}{}
	defer func() {
		<-we.workers // Release worker
	}()

	// Get workflow
	we.workflowEngine.mutex.RLock()
	workflow, exists := we.workflowEngine.workflows[execution.WorkflowID]
	we.workflowEngine.mutex.RUnlock()

	if !exists {
		execution.Status = "failed"
		execution.Error = "workflow not found"
		now := time.Now()
		execution.CompletedAt = &now
		return
	}

	// Start execution
	execution.Status = "running"
	now := time.Now()
	execution.StartedAt = &now

	// Execute steps
	if err := we.executeSteps(execution, workflow); err != nil {
		execution.Status = "failed"
		execution.Error = err.Error()
		now := time.Now()
		execution.CompletedAt = &now
		return
	}

	// Complete execution
	execution.Status = "completed"
	now = time.Now()
	execution.CompletedAt = &now
}

// executeSteps executes workflow steps
func (we *WorkflowExecutor) executeSteps(execution *WorkflowExecution, workflow *Workflow) error {
	// Create step execution order
	executionOrder := we.createExecutionOrder(workflow.Steps)

	// Execute steps in order
	for _, stepID := range executionOrder {
		// Find step
		var step *WorkflowStep
		for _, s := range workflow.Steps {
			if s.ID == stepID {
				step = s
				break
			}
		}

		if step == nil {
			continue
		}

		// Execute step
		if err := we.executeStep(execution, step); err != nil {
			return err
		}

		// Check if execution was cancelled
		if execution.Status == "cancelled" {
			return fmt.Errorf("execution cancelled")
		}
	}

	return nil
}

// createExecutionOrder creates step execution order
func (we *WorkflowExecutor) createExecutionOrder(steps []*WorkflowStep) []string {
	// Simple topological sort
	// In practice, this would be more sophisticated
	var order []string
	visited := make(map[string]bool)

	for _, step := range steps {
		if !visited[step.ID] {
			we.dfs(step.ID, steps, visited, &order)
		}
	}

	return order
}

// dfs performs depth-first search for topological sort
func (we *WorkflowExecutor) dfs(stepID string, steps []*WorkflowStep, visited map[string]bool, order *[]string) {
	visited[stepID] = true

	// Find step
	var step *WorkflowStep
	for _, s := range steps {
		if s.ID == stepID {
			step = s
			break
		}
	}

	if step == nil {
		return
	}

	// Visit dependencies first
	for _, depID := range step.DependsOn {
		if !visited[depID] {
			we.dfs(depID, steps, visited, order)
		}
	}

	*order = append(*order, stepID)
}

// executeStep executes a single step
func (we *WorkflowExecutor) executeStep(execution *WorkflowExecution, step *WorkflowStep) error {
	// Create step result
	stepResult := &StepResult{
		StepID:   step.ID,
		Status:   "running",
		Input:    make(map[string]interface{}),
		Output:   make(map[string]interface{}),
		Metadata: make(map[string]string),
	}

	now := time.Now()
	stepResult.StartedAt = &now

	// Store step result
	execution.StepResults[step.ID] = stepResult

	// Execute step based on type
	var err error
	switch step.Type {
	case "task":
		err = we.executeTask(execution, step, stepResult)
	case "condition":
		err = we.executeCondition(execution, step, stepResult)
	case "loop":
		err = we.executeLoop(execution, step, stepResult)
	case "parallel":
		err = we.executeParallel(execution, step, stepResult)
	default:
		err = fmt.Errorf("unknown step type: %s", step.Type)
	}

	// Update step result
	now = time.Now()
	stepResult.CompletedAt = &now

	if err != nil {
		stepResult.Status = "failed"
		stepResult.Error = err.Error()

		// Apply retry policy if available
		if step.RetryPolicy != nil && stepResult.RetryCount < step.RetryPolicy.MaxRetries {
			stepResult.RetryCount++
			stepResult.Status = "pending"
			// In practice, this would schedule a retry
		}
	} else {
		stepResult.Status = "completed"
	}

	return err
}

// executeTask executes a task step
func (we *WorkflowExecutor) executeTask(execution *WorkflowExecution, step *WorkflowStep, result *StepResult) error {
	// This would execute the actual task
	// For now, just a placeholder
	result.Output["result"] = "task completed"
	return nil
}

// executeCondition executes a condition step
func (we *WorkflowExecutor) executeCondition(execution *WorkflowExecution, step *WorkflowStep, result *StepResult) error {
	// This would evaluate the condition
	// For now, just a placeholder
	result.Output["condition_result"] = true
	return nil
}

// executeLoop executes a loop step
func (we *WorkflowExecutor) executeLoop(execution *WorkflowExecution, step *WorkflowStep, result *StepResult) error {
	// This would execute the loop
	// For now, just a placeholder
	result.Output["loop_count"] = 3
	return nil
}

// executeParallel executes a parallel step
func (we *WorkflowExecutor) executeParallel(execution *WorkflowExecution, step *WorkflowStep, result *StepResult) error {
	// This would execute steps in parallel
	// For now, just a placeholder
	result.Output["parallel_results"] = []string{"result1", "result2", "result3"}
	return nil
}

// GetStats returns workflow engine statistics
func (we *WorkflowEngine) GetStats() map[string]interface{} {
	we.mutex.RLock()
	defer we.mutex.RUnlock()

	stats := map[string]interface{}{
		"workflows": len(we.workflows),
		"executions": len(we.executions),
		"config":    we.config,
	}

	// Calculate execution statistics
	totalExecutions := len(we.executions)
	completedExecutions := 0
	failedExecutions := 0
	runningExecutions := 0

	for _, execution := range we.executions {
		switch execution.Status {
		case "completed":
			completedExecutions++
		case "failed":
			failedExecutions++
		case "running":
			runningExecutions++
		}
	}

	stats["total_executions"] = totalExecutions
	stats["completed_executions"] = completedExecutions
	stats["failed_executions"] = failedExecutions
	stats["running_executions"] = runningExecutions

	if totalExecutions > 0 {
		stats["success_rate"] = float64(completedExecutions) / float64(totalExecutions)
	}

	return stats
} 