package main

import (
	"testing"
	"time"
	"fmt"
)

// TestAIOptimizationEngineBasic tests basic AI optimization functionality
func TestAIOptimizationEngineBasic(t *testing.T) {
	config := AIOConfig{
		EnableOptimization:  true,
		EnableAutoTune:      true,
		EnableMonitoring:    true,
		MonitorInterval:     30 * time.Second,
		EnablePersistence:   false,
		PersistencePath:     "",
		MaxOptimizations:    100,
		RetentionPeriod:     365 * 24 * time.Hour, // 1 year
		DefaultAlgorithm:    "genetic",
		EnableParallelOptimization: true,
	}

	aio := NewAIOptimizationEngine(config)
	if aio == nil {
		t.Fatal("Failed to create AIOptimizationEngine")
	}

	// Create an optimization problem
	problem := &OptimizationProblem{
		ID:          "test-problem",
		Name:        "Test Optimization Problem",
		Description: "A test optimization problem",
		Type:        "continuous",
		Objective:   "minimize",
		Function:    "x^2 + y^2",
		Variables: []*Variable{
			{
				Name: "x",
				Type: "float",
				Range: []float64{-10, 10},
			},
			{
				Name: "y",
				Type: "float",
				Range: []float64{-10, 10},
			},
		},
		Constraints: []*Constraint{
			{
				Type: "inequality",
				Expression: "x + y <= 5",
			},
		},
		CreatedAt: time.Now(),
		UpdatedAt: time.Now(),
		Metadata:  make(map[string]string),
	}

	// Register problem
	err := aio.RegisterProblem(problem)
	if err != nil {
		t.Fatalf("Failed to register problem: %v", err)
	}

	// Create an optimizer
	optimizer := &Optimizer{
		ID:          "test-optimizer",
		Name:        "Test Optimizer",
		Description: "A test AI optimizer",
		Algorithm:   "genetic",
		ProblemID:   "test-problem",
		Config: map[string]interface{}{
			"population_size": 100,
			"generations":     50,
			"mutation_rate":   0.01,
		},
		Status:    "initialized",
		CreatedAt: time.Now(),
		UpdatedAt: time.Now(),
		Metadata:  make(map[string]string),
	}

	// Register optimizer
	err = aio.RegisterOptimizer(optimizer)
	if err != nil {
		t.Fatalf("Failed to register optimizer: %v", err)
	}

	// Optimize
	result, err := aio.Optimize("test-optimizer", map[string]interface{}{
		"timeout": 300,
	})
	if err != nil {
		t.Fatalf("Failed to optimize: %v", err)
	}

	if result.OptimizerID != "test-optimizer" {
		t.Errorf("Expected optimizer ID 'test-optimizer', got '%s'", result.OptimizerID)
	}

	if result.Status != "completed" {
		t.Errorf("Expected status 'completed', got '%s'", result.Status)
	}

	if result.BestSolution == nil {
		t.Fatal("Best solution should not be nil")
	}
}

// TestAIOptimizationEngineAlgorithmManagement tests algorithm management
func TestAIOptimizationEngineAlgorithmManagement(t *testing.T) {
	config := AIOConfig{
		EnableOptimization:  true,
		EnableAutoTune:      true,
		EnableMonitoring:    true,
		MonitorInterval:     30 * time.Second,
		EnablePersistence:   false,
		PersistencePath:     "",
		MaxOptimizations:    100,
		RetentionPeriod:     365 * 24 * time.Hour,
		DefaultAlgorithm:    "genetic",
		EnableParallelOptimization: true,
	}

	aio := NewAIOptimizationEngine(config)

	// Create multiple optimizers with different algorithms
	algorithms := []string{"genetic", "particle_swarm", "bayesian", "gradient_descent"}

	for i, algorithm := range algorithms {
		optimizer := &Optimizer{
			ID:          fmt.Sprintf("optimizer-%d", i),
			Name:        fmt.Sprintf("Optimizer %d", i),
			Description: fmt.Sprintf("A test optimizer with %s", algorithm),
			Algorithm:   algorithm,
			ProblemID:   "test-problem",
			Config: map[string]interface{}{
				"max_iterations": 100,
			},
			Status:    "initialized",
			CreatedAt: time.Now(),
			UpdatedAt: time.Now(),
			Metadata:  make(map[string]string),
		}

		err := aio.RegisterOptimizer(optimizer)
		if err != nil {
			t.Fatalf("Failed to register optimizer %d: %v", i, err)
		}
	}

	// Get optimizer
	retrievedOptimizer, err := aio.GetOptimizer("optimizer-0")
	if err != nil {
		t.Fatalf("Failed to get optimizer: %v", err)
	}

	if retrievedOptimizer.ID != "optimizer-0" {
		t.Errorf("Expected optimizer ID 'optimizer-0', got '%s'", retrievedOptimizer.ID)
	}

	// List optimizers
	allOptimizers := aio.ListOptimizers()
	if len(allOptimizers) < 4 {
		t.Fatalf("Expected at least 4 optimizers, got %d", len(allOptimizers))
	}

	found := make(map[string]bool)
	for _, optimizer := range allOptimizers {
		found[optimizer.ID] = true
	}

	for i := 0; i < 4; i++ {
		optimizerID := fmt.Sprintf("optimizer-%d", i)
		if !found[optimizerID] {
			t.Fatalf("Optimizer %s should be in optimizer list", optimizerID)
		}
	}
}

// TestAIOptimizationEngineParallelOptimization tests parallel optimization
func TestAIOptimizationEngineParallelOptimization(t *testing.T) {
	config := AIOConfig{
		EnableOptimization:  true,
		EnableAutoTune:      true,
		EnableMonitoring:    true,
		MonitorInterval:     30 * time.Second,
		EnablePersistence:   false,
		PersistencePath:     "",
		MaxOptimizations:    100,
		RetentionPeriod:     365 * 24 * time.Hour,
		DefaultAlgorithm:    "genetic",
		EnableParallelOptimization: true,
	}

	aio := NewAIOptimizationEngine(config)

	// Create problem
	problem := &OptimizationProblem{
		ID:          "parallel-problem",
		Name:        "Parallel Optimization Problem",
		Description: "A problem for parallel optimization",
		Type:        "discrete",
		Objective:   "maximize",
		Function:    "x * y",
		Variables: []*Variable{
			{
				Name: "x",
				Type: "integer",
				Range: []float64{1, 10},
			},
			{
				Name: "y",
				Type: "integer",
				Range: []float64{1, 10},
			},
		},
		CreatedAt: time.Now(),
		UpdatedAt: time.Now(),
		Metadata:  make(map[string]string),
	}

	err := aio.RegisterProblem(problem)
	if err != nil {
		t.Fatalf("Failed to register problem: %v", err)
	}

	// Create optimizer with parallel config
	optimizer := &Optimizer{
		ID:          "parallel-optimizer",
		Name:        "Parallel Optimizer",
		Description: "An optimizer for parallel testing",
		Algorithm:   "particle_swarm",
		ProblemID:   "parallel-problem",
		Config: map[string]interface{}{
			"particles": 50,
			"iterations": 100,
			"parallel_workers": 4,
		},
		Status:    "initialized",
		CreatedAt: time.Now(),
		UpdatedAt: time.Now(),
		Metadata:  make(map[string]string),
	}

	err = aio.RegisterOptimizer(optimizer)
	if err != nil {
		t.Fatalf("Failed to register optimizer: %v", err)
	}

	// Optimize with parallel execution
	result, err := aio.Optimize("parallel-optimizer", map[string]interface{}{
		"parallel": true,
	})
	if err != nil {
		t.Fatalf("Failed to optimize: %v", err)
	}

	if result.Status != "completed" {
		t.Errorf("Expected status 'completed', got '%s'", result.Status)
	}

	if result.OptimizationTime <= 0 {
		t.Error("Expected positive optimization time")
	}
}

// TestAIOptimizationEngineAutoTune tests auto-tune functionality
func TestAIOptimizationEngineAutoTune(t *testing.T) {
	config := AIOConfig{
		EnableOptimization:  true,
		EnableAutoTune:      true,
		EnableMonitoring:    true,
		MonitorInterval:     30 * time.Second,
		EnablePersistence:   false,
		PersistencePath:     "",
		MaxOptimizations:    100,
		RetentionPeriod:     365 * 24 * time.Hour,
		DefaultAlgorithm:    "genetic",
		EnableParallelOptimization: true,
	}

	aio := NewAIOptimizationEngine(config)

	// Create auto-tune experiment
	experiment := &AutoTuneExperiment{
		ID:          "autotune-experiment",
		Name:        "AutoTune Experiment",
		Description: "An auto-tune experiment",
		ModelID:     "test-model",
		Type:        "hyperparameter",
		Config: map[string]interface{}{
			"n_trials": 5,
			"timeout": 300,
			"parameters": map[string]interface{}{
				"learning_rate": []float64{0.001, 0.01, 0.1},
				"batch_size": []int{16, 32, 64},
			},
		},
		Status:    "pending",
		CreatedAt: time.Now(),
		UpdatedAt: time.Now(),
		Metadata:  make(map[string]string),
	}

	// Register experiment
	err := aio.RegisterAutoTuneExperiment(experiment)
	if err != nil {
		t.Fatalf("Failed to register auto-tune experiment: %v", err)
	}

	// Start auto-tune
	result, err := aio.StartAutoTune("autotune-experiment")
	if err != nil {
		t.Fatalf("Failed to start auto-tune: %v", err)
	}

	if result.ExperimentID != "autotune-experiment" {
		t.Errorf("Expected experiment ID 'autotune-experiment', got '%s'", result.ExperimentID)
	}

	// Wait for auto-tune to complete
	time.Sleep(1 * time.Minute)

	// Get results
	tuneResults := aio.GetAutoTuneResults("autotune-experiment")
	if tuneResults == nil {
		t.Fatal("Auto-tune results should not be nil")
	}

	if tuneResults.BestConfiguration == nil {
		t.Log("No best configuration found (expected for short tests)")
	}
}

// TestAIOptimizationEngineMonitoring tests monitoring functionality
func TestAIOptimizationEngineMonitoring(t *testing.T) {
	config := AIOConfig{
		EnableOptimization:  true,
		EnableAutoTune:      true,
		EnableMonitoring:    true,
		MonitorInterval:     30 * time.Second,
		EnablePersistence:   false,
		PersistencePath:     "",
		MaxOptimizations:    100,
		RetentionPeriod:     365 * 24 * time.Hour,
		DefaultAlgorithm:    "genetic",
		EnableParallelOptimization: true,
	}

	aio := NewAIOptimizationEngine(config)

	// Create and run multiple optimizations to generate metrics
	for i := 0; i < 3; i++ {
		problemID := fmt.Sprintf("monitor-problem-%d", i)
		optimizerID := fmt.Sprintf("monitor-optimizer-%d", i)

		problem := &OptimizationProblem{
			ID:          problemID,
			Name:        fmt.Sprintf("Monitor Problem %d", i),
			Description: fmt.Sprintf("A problem for monitoring %d", i),
			Type:        "continuous",
			Objective:   "minimize",
			Function:    "x^2",
			Variables: []*Variable{
				{
					Name: "x",
					Type: "float",
					Range: []float64{-5, 5},
				},
			},
			CreatedAt: time.Now(),
			UpdatedAt: time.Now(),
			Metadata:  make(map[string]string),
		}

		err := aio.RegisterProblem(problem)
		if err != nil {
			t.Fatalf("Failed to register problem %d: %v", i, err)
		}

		optimizer := &Optimizer{
			ID:          optimizerID,
			Name:        fmt.Sprintf("Monitor Optimizer %d", i),
			Description: fmt.Sprintf("An optimizer for monitoring %d", i),
			Algorithm:   "gradient_descent",
			ProblemID:   problemID,
			Config: map[string]interface{}{
				"learning_rate": 0.01,
				"iterations": 100,
			},
			Status:    "initialized",
			CreatedAt: time.Now(),
			UpdatedAt: time.Now(),
			Metadata:  make(map[string]string),
		}

		err = aio.RegisterOptimizer(optimizer)
		if err != nil {
			t.Fatalf("Failed to register optimizer %d: %v", i, err)
		}

		_, err = aio.Optimize(optimizerID, map[string]interface{}{})
		if err != nil {
			t.Fatalf("Failed to optimize %d: %v", i, err)
		}
	}

	// Wait for monitoring
	time.Sleep(1 * time.Minute)

	// Get statistics
	stats := aio.GetStats()
	if stats == nil {
		t.Fatal("Statistics should not be nil")
	}

	if stats["total_problems"] == nil {
		t.Error("Statistics should contain total_problems")
	}

	if stats["total_optimizers"] == nil {
		t.Error("Statistics should contain total_optimizers")
	}

	if stats["total_optimizations"] == nil {
		t.Error("Statistics should contain total_optimizations")
	}
}

// BenchmarkAIOptimizationEngineOptimize benchmarks optimization
func BenchmarkAIOptimizationEngineOptimize(b *testing.B) {
	config := AIOConfig{
		EnableOptimization:  true,
		EnableAutoTune:      false,
		EnableMonitoring:    false,
		MonitorInterval:     30 * time.Second,
		EnablePersistence:   false,
		PersistencePath:     "",
		MaxOptimizations:    100,
		RetentionPeriod:     365 * 24 * time.Hour,
		DefaultAlgorithm:    "genetic",
		EnableParallelOptimization: false,
	}

	aio := NewAIOptimizationEngine(config)

	// Create simple problem
	problem := &OptimizationProblem{
		ID:          "benchmark-problem",
		Name:        "Benchmark Problem",
		Description: "A problem for benchmarking",
		Type:        "continuous",
		Objective:   "minimize",
		Function:    "x^2",
		Variables: []*Variable{
			{
				Name: "x",
				Type: "float",
				Range: []float64{-5, 5},
			},
		},
		CreatedAt: time.Now(),
		UpdatedAt: time.Now(),
		Metadata:  make(map[string]string),
	}

	err := aio.RegisterProblem(problem)
	if err != nil {
		b.Fatalf("Failed to register problem: %v", err)
	}

	// Create optimizer
	optimizer := &Optimizer{
		ID:          "benchmark-optimizer",
		Name:        "Benchmark Optimizer",
		Description: "An optimizer for benchmarking",
		Algorithm:   "gradient_descent",
		ProblemID:   "benchmark-problem",
		Config: map[string]interface{}{
			"learning_rate": 0.01,
			"iterations": 50,
		},
		Status:    "initialized",
		CreatedAt: time.Now(),
		UpdatedAt: time.Now(),
		Metadata:  make(map[string]string),
	}

	err = aio.RegisterOptimizer(optimizer)
	if err != nil {
		b.Fatalf("Failed to register optimizer: %v", err)
	}

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		_, err := aio.Optimize("benchmark-optimizer", map[string]interface{}{})
		if err != nil {
			b.Fatalf("Optimization failed: %v", err)
		}
	}
} 