package main

import (
	"fmt"
	"testing"
	"time"
)

// TestWorkflowEngineBasic tests basic workflow functionality
func TestWorkflowEngineBasic(t *testing.T) {
	config := WorkflowConfig{
		MaxConcurrentExecutions: 10,
		DefaultTimeout:          5 * time.Minute,
		EnableRetry:             true,
		MaxRetries:              3,
		EnableMonitoring:        true,
		MonitorInterval:         30 * time.Second,
		EnablePersistence:       false,
		PersistencePath:         "",
	}

	we := NewWorkflowEngine(config)
	if we == nil {
		t.Fatal("Failed to create WorkflowEngine")
	}

	// Create a simple workflow
	workflow := &Workflow{
		ID:          "test-workflow",
		Name:        "Test Workflow",
		Description: "A simple test workflow",
		Version:     "1.0.0",
		Steps: []*WorkflowStep{
			{
				ID:       "step1",
				Name:     "Step 1",
				Type:     "task",
				Action:   "print_hello",
				Input:    map[string]string{"message": "Hello, World!"},
				Output:   map[string]string{"result": "success"},
				Timeout:  30 * time.Second,
				Metadata: make(map[string]string),
			},
			{
				ID:       "step2",
				Name:     "Step 2",
				Type:     "task",
				Action:   "print_goodbye",
				Input:    map[string]string{"message": "Goodbye, World!"},
				Output:   map[string]string{"result": "success"},
				Timeout:  30 * time.Second,
				DependsOn: []string{"step1"},
				Metadata: make(map[string]string),
			},
		},
		Triggers: []*WorkflowTrigger{
			{
				ID:      "manual-trigger",
				Type:    "manual",
				Enabled: true,
				Metadata: make(map[string]string),
			},
		},
		Variables: make(map[string]string),
		CreatedAt: time.Now(),
		UpdatedAt: time.Now(),
		Metadata:  make(map[string]string),
	}

	// Register workflow
	err := we.RegisterWorkflow(workflow)
	if err != nil {
		t.Fatalf("Failed to register workflow: %v", err)
	}

	// Execute workflow
	input := map[string]interface{}{
		"user": "testuser",
		"data": "testdata",
	}

	execution, err := we.ExecuteWorkflow("test-workflow", input)
	if err != nil {
		t.Fatalf("Failed to execute workflow: %v", err)
	}

	if execution.WorkflowID != "test-workflow" {
		t.Errorf("Expected workflow ID 'test-workflow', got '%s'", execution.WorkflowID)
	}

	if execution.Status != "completed" {
		t.Errorf("Expected status 'completed', got '%s'", execution.Status)
	}

	// Verify step results
	if len(execution.StepResults) != 2 {
		t.Errorf("Expected 2 step results, got %d", len(execution.StepResults))
	}

	step1Result, exists := execution.StepResults["step1"]
	if !exists {
		t.Fatal("Step 1 result should exist")
	}

	if step1Result.Status != "completed" {
		t.Errorf("Expected step 1 status 'completed', got '%s'", step1Result.Status)
	}

	step2Result, exists := execution.StepResults["step2"]
	if !exists {
		t.Fatal("Step 2 result should exist")
	}

	if step2Result.Status != "completed" {
		t.Errorf("Expected step 2 status 'completed', got '%s'", step2Result.Status)
	}
}

// TestWorkflowEngineConditionalSteps tests conditional workflow steps
func TestWorkflowEngineConditionalSteps(t *testing.T) {
	config := WorkflowConfig{
		MaxConcurrentExecutions: 10,
		DefaultTimeout:          5 * time.Minute,
		EnableRetry:             true,
		MaxRetries:              3,
		EnableMonitoring:        true,
		MonitorInterval:         30 * time.Second,
		EnablePersistence:       false,
		PersistencePath:         "",
	}

	we := NewWorkflowEngine(config)

	// Create workflow with conditional steps
	workflow := &Workflow{
		ID:          "conditional-workflow",
		Name:        "Conditional Workflow",
		Description: "A workflow with conditional steps",
		Version:     "1.0.0",
		Steps: []*WorkflowStep{
			{
				ID:       "check-condition",
				Name:     "Check Condition",
				Type:     "condition",
				Action:   "check_value",
				Condition: "input.value > 10",
				Input:    map[string]string{"value": "input.value"},
				Output:   map[string]string{"result": "condition_result"},
				Timeout:  30 * time.Second,
				Metadata: make(map[string]string),
			},
			{
				ID:       "high-value-task",
				Name:     "High Value Task",
				Type:     "task",
				Action:   "process_high_value",
				Input:    map[string]string{"value": "input.value"},
				Output:   map[string]string{"result": "high_value_result"},
				Timeout:  30 * time.Second,
				DependsOn: []string{"check-condition"},
				Condition: "step.check-condition.result == true",
				Metadata: make(map[string]string),
			},
			{
				ID:       "low-value-task",
				Name:     "Low Value Task",
				Type:     "task",
				Action:   "process_low_value",
				Input:    map[string]string{"value": "input.value"},
				Output:   map[string]string{"result": "low_value_result"},
				Timeout:  30 * time.Second,
				DependsOn: []string{"check-condition"},
				Condition: "step.check-condition.result == false",
				Metadata: make(map[string]string),
			},
		},
		Triggers: []*WorkflowTrigger{
			{
				ID:      "manual-trigger",
				Type:    "manual",
				Enabled: true,
				Metadata: make(map[string]string),
			},
		},
		Variables: make(map[string]string),
		CreatedAt: time.Now(),
		UpdatedAt: time.Now(),
		Metadata:  make(map[string]string),
	}

	// Register workflow
	err := we.RegisterWorkflow(workflow)
	if err != nil {
		t.Fatalf("Failed to register workflow: %v", err)
	}

	// Test with high value (should execute high-value-task)
	input := map[string]interface{}{
		"value": 15,
	}

	execution, err := we.ExecuteWorkflow("conditional-workflow", input)
	if err != nil {
		t.Fatalf("Failed to execute workflow: %v", err)
	}

	if execution.Status != "completed" {
		t.Errorf("Expected status 'completed', got '%s'", execution.Status)
	}

	// Check that high-value-task was executed
	highValueResult, exists := execution.StepResults["high-value-task"]
	if !exists {
		t.Fatal("High value task result should exist")
	}

	if highValueResult.Status != "completed" {
		t.Errorf("Expected high value task status 'completed', got '%s'", highValueResult.Status)
	}

	// Check that low-value-task was skipped
	lowValueResult, exists := execution.StepResults["low-value-task"]
	if !exists {
		t.Fatal("Low value task result should exist")
	}

	if lowValueResult.Status != "skipped" {
		t.Errorf("Expected low value task status 'skipped', got '%s'", lowValueResult.Status)
	}

	// Test with low value (should execute low-value-task)
	input["value"] = 5

	execution2, err := we.ExecuteWorkflow("conditional-workflow", input)
	if err != nil {
		t.Fatalf("Failed to execute workflow: %v", err)
	}

	if execution2.Status != "completed" {
		t.Errorf("Expected status 'completed', got '%s'", execution2.Status)
	}

	// Check that low-value-task was executed
	lowValueResult2, exists := execution2.StepResults["low-value-task"]
	if !exists {
		t.Fatal("Low value task result should exist")
	}

	if lowValueResult2.Status != "completed" {
		t.Errorf("Expected low value task status 'completed', got '%s'", lowValueResult2.Status)
	}

	// Check that high-value-task was skipped
	highValueResult2, exists := execution2.StepResults["high-value-task"]
	if !exists {
		t.Fatal("High value task result should exist")
	}

	if highValueResult2.Status != "skipped" {
		t.Errorf("Expected high value task status 'skipped', got '%s'", highValueResult2.Status)
	}
}

// TestWorkflowEngineParallelSteps tests parallel workflow steps
func TestWorkflowEngineParallelSteps(t *testing.T) {
	config := WorkflowConfig{
		MaxConcurrentExecutions: 10,
		DefaultTimeout:          5 * time.Minute,
		EnableRetry:             true,
		MaxRetries:              3,
		EnableMonitoring:        true,
		MonitorInterval:         30 * time.Second,
		EnablePersistence:       false,
		PersistencePath:         "",
	}

	we := NewWorkflowEngine(config)

	// Create workflow with parallel steps
	workflow := &Workflow{
		ID:          "parallel-workflow",
		Name:        "Parallel Workflow",
		Description: "A workflow with parallel steps",
		Version:     "1.0.0",
		Steps: []*WorkflowStep{
			{
				ID:       "parallel-group",
				Name:     "Parallel Group",
				Type:     "parallel",
				Action:   "parallel_execution",
				Input:    map[string]string{"data": "input.data"},
				Output:   map[string]string{"results": "parallel_results"},
				Timeout:  60 * time.Second,
				Metadata: make(map[string]string),
			},
			{
				ID:       "task1",
				Name:     "Task 1",
				Type:     "task",
				Action:   "process_task1",
				Input:    map[string]string{"data": "input.data"},
				Output:   map[string]string{"result": "task1_result"},
				Timeout:  30 * time.Second,
				DependsOn: []string{"parallel-group"},
				Metadata: make(map[string]string),
			},
			{
				ID:       "task2",
				Name:     "Task 2",
				Type:     "task",
				Action:   "process_task2",
				Input:    map[string]string{"data": "input.data"},
				Output:   map[string]string{"result": "task2_result"},
				Timeout:  30 * time.Second,
				DependsOn: []string{"parallel-group"},
				Metadata: make(map[string]string),
			},
			{
				ID:       "final-task",
				Name:     "Final Task",
				Type:     "task",
				Action:   "combine_results",
				Input:    map[string]string{"task1": "step.task1.result", "task2": "step.task2.result"},
				Output:   map[string]string{"final_result": "combined_result"},
				Timeout:  30 * time.Second,
				DependsOn: []string{"task1", "task2"},
				Metadata: make(map[string]string),
			},
		},
		Triggers: []*WorkflowTrigger{
			{
				ID:      "manual-trigger",
				Type:    "manual",
				Enabled: true,
				Metadata: make(map[string]string),
			},
		},
		Variables: make(map[string]string),
		CreatedAt: time.Now(),
		UpdatedAt: time.Now(),
		Metadata:  make(map[string]string),
	}

	// Register workflow
	err := we.RegisterWorkflow(workflow)
	if err != nil {
		t.Fatalf("Failed to register workflow: %v", err)
	}

	// Execute workflow
	input := map[string]interface{}{
		"data": "parallel test data",
	}

	execution, err := we.ExecuteWorkflow("parallel-workflow", input)
	if err != nil {
		t.Fatalf("Failed to execute workflow: %v", err)
	}

	if execution.Status != "completed" {
		t.Errorf("Expected status 'completed', got '%s'", execution.Status)
	}

	// Verify all steps completed
	expectedSteps := []string{"parallel-group", "task1", "task2", "final-task"}
	for _, stepID := range expectedSteps {
		result, exists := execution.StepResults[stepID]
		if !exists {
			t.Fatalf("Step result for %s should exist", stepID)
		}

		if result.Status != "completed" {
			t.Errorf("Expected step %s status 'completed', got '%s'", stepID, result.Status)
		}
	}
}

// TestWorkflowEngineRetryPolicy tests workflow retry functionality
func TestWorkflowEngineRetryPolicy(t *testing.T) {
	config := WorkflowConfig{
		MaxConcurrentExecutions: 10,
		DefaultTimeout:          5 * time.Minute,
		EnableRetry:             true,
		MaxRetries:              3,
		EnableMonitoring:        true,
		MonitorInterval:         30 * time.Second,
		EnablePersistence:       false,
		PersistencePath:         "",
	}

	we := NewWorkflowEngine(config)

	// Create workflow with retry policy
	workflow := &Workflow{
		ID:          "retry-workflow",
		Name:        "Retry Workflow",
		Description: "A workflow with retry policy",
		Version:     "1.0.0",
		Steps: []*WorkflowStep{
			{
				ID:       "retry-step",
				Name:     "Retry Step",
				Type:     "task",
				Action:   "failing_task",
				Input:    map[string]string{"attempt": "retry_count"},
				Output:   map[string]string{"result": "success"},
				Timeout:  30 * time.Second,
				RetryPolicy: &RetryPolicy{
					MaxRetries: 3,
					Delay:      1 * time.Second,
					Backoff:    "exponential",
					MaxDelay:   10 * time.Second,
				},
				Metadata: make(map[string]string),
			},
		},
		Triggers: []*WorkflowTrigger{
			{
				ID:      "manual-trigger",
				Type:    "manual",
				Enabled: true,
				Metadata: make(map[string]string),
			},
		},
		Variables: make(map[string]string),
		CreatedAt: time.Now(),
		UpdatedAt: time.Now(),
		Metadata:  make(map[string]string),
	}

	// Register workflow
	err := we.RegisterWorkflow(workflow)
	if err != nil {
		t.Fatalf("Failed to register workflow: %v", err)
	}

	// Execute workflow
	input := map[string]interface{}{
		"data": "retry test data",
	}

	execution, err := we.ExecuteWorkflow("retry-workflow", input)
	if err != nil {
		t.Fatalf("Failed to execute workflow: %v", err)
	}

	// Check retry behavior
	result, exists := execution.StepResults["retry-step"]
	if !exists {
		t.Fatal("Retry step result should exist")
	}

	// The step should have been retried multiple times
	if result.RetryCount < 1 {
		t.Errorf("Expected retry count >= 1, got %d", result.RetryCount)
	}

	// Check that the step eventually completed or failed
	if result.Status != "completed" && result.Status != "failed" {
		t.Errorf("Expected status 'completed' or 'failed', got '%s'", result.Status)
	}
}

// TestWorkflowEngineScheduling tests workflow scheduling
func TestWorkflowEngineScheduling(t *testing.T) {
	config := WorkflowConfig{
		MaxConcurrentExecutions: 10,
		DefaultTimeout:          5 * time.Minute,
		EnableRetry:             true,
		MaxRetries:              3,
		EnableMonitoring:        true,
		MonitorInterval:         30 * time.Second,
		EnablePersistence:       false,
		PersistencePath:         "",
	}

	we := NewWorkflowEngine(config)

	// Create workflow with schedule trigger
	workflow := &Workflow{
		ID:          "scheduled-workflow",
		Name:        "Scheduled Workflow",
		Description: "A workflow with schedule trigger",
		Version:     "1.0.0",
		Steps: []*WorkflowStep{
			{
				ID:       "scheduled-step",
				Name:     "Scheduled Step",
				Type:     "task",
				Action:   "scheduled_task",
				Input:    map[string]string{"timestamp": "current_time"},
				Output:   map[string]string{"result": "scheduled_result"},
				Timeout:  30 * time.Second,
				Metadata: make(map[string]string),
			},
		},
		Triggers: []*WorkflowTrigger{
			{
				ID:       "schedule-trigger",
				Type:     "schedule",
				Schedule: "*/1 * * * *", // Every minute
				Enabled:  true,
				Metadata: make(map[string]string),
			},
		},
		Variables: make(map[string]string),
		CreatedAt: time.Now(),
		UpdatedAt: time.Now(),
		Metadata:  make(map[string]string),
	}

	// Register workflow
	err := we.RegisterWorkflow(workflow)
	if err != nil {
		t.Fatalf("Failed to register workflow: %v", err)
	}

	// Wait for scheduled execution
	time.Sleep(2 * time.Minute)

	// Check that workflow was executed
	executions := we.ListExecutions()
	found := false
	for _, execution := range executions {
		if execution.WorkflowID == "scheduled-workflow" {
			found = true
			break
		}
	}

	if !found {
		t.Fatal("Scheduled workflow should have been executed")
	}
}

// TestWorkflowEngineMonitoring tests workflow monitoring
func TestWorkflowEngineMonitoring(t *testing.T) {
	config := WorkflowConfig{
		MaxConcurrentExecutions: 10,
		DefaultTimeout:          5 * time.Minute,
		EnableRetry:             true,
		MaxRetries:              3,
		EnableMonitoring:        true,
		MonitorInterval:         30 * time.Second,
		EnablePersistence:       false,
		PersistencePath:         "",
	}

	we := NewWorkflowEngine(config)

	// Create and execute multiple workflows to generate metrics
	for i := 0; i < 5; i++ {
		workflow := &Workflow{
			ID:          fmt.Sprintf("monitor-workflow-%d", i),
			Name:        fmt.Sprintf("Monitor Workflow %d", i),
			Description: "A workflow for monitoring tests",
			Version:     "1.0.0",
			Steps: []*WorkflowStep{
				{
					ID:       "monitor-step",
					Name:     "Monitor Step",
					Type:     "task",
					Action:   "monitor_task",
					Input:    map[string]string{"index": fmt.Sprintf("%d", i)},
					Output:   map[string]string{"result": "monitor_result"},
					Timeout:  30 * time.Second,
					Metadata: make(map[string]string),
				},
			},
			Triggers: []*WorkflowTrigger{
				{
					ID:      "manual-trigger",
					Type:    "manual",
					Enabled: true,
					Metadata: make(map[string]string),
				},
			},
			Variables: make(map[string]string),
			CreatedAt: time.Now(),
			UpdatedAt: time.Now(),
			Metadata:  make(map[string]string),
		}

		err := we.RegisterWorkflow(workflow)
		if err != nil {
			t.Fatalf("Failed to register workflow %d: %v", i, err)
		}

		input := map[string]interface{}{
			"index": i,
		}

		_, err = we.ExecuteWorkflow(workflow.ID, input)
		if err != nil {
			t.Fatalf("Failed to execute workflow %d: %v", i, err)
		}
	}

	// Wait for monitoring to collect metrics
	time.Sleep(1 * time.Minute)

	// Get statistics
	stats := we.GetStats()
	if stats == nil {
		t.Fatal("Statistics should not be nil")
	}

	// Verify statistics contain expected data
	if stats["total_workflows"] == nil {
		t.Error("Statistics should contain total_workflows")
	}

	if stats["total_executions"] == nil {
		t.Error("Statistics should contain total_executions")
	}

	if stats["successful_executions"] == nil {
		t.Error("Statistics should contain successful_executions")
	}

	if stats["failed_executions"] == nil {
		t.Error("Statistics should contain failed_executions")
	}
}

// TestWorkflowEngineWorkflowManagement tests workflow management operations
func TestWorkflowEngineWorkflowManagement(t *testing.T) {
	config := WorkflowConfig{
		MaxConcurrentExecutions: 10,
		DefaultTimeout:          5 * time.Minute,
		EnableRetry:             true,
		MaxRetries:              3,
		EnableMonitoring:        true,
		MonitorInterval:         30 * time.Second,
		EnablePersistence:       false,
		PersistencePath:         "",
	}

	we := NewWorkflowEngine(config)

	// Create workflow
	workflow := &Workflow{
		ID:          "management-workflow",
		Name:        "Management Workflow",
		Description: "A workflow for management tests",
		Version:     "1.0.0",
		Steps: []*WorkflowStep{
			{
				ID:       "management-step",
				Name:     "Management Step",
				Type:     "task",
				Action:   "management_task",
				Input:    map[string]string{"data": "management_data"},
				Output:   map[string]string{"result": "management_result"},
				Timeout:  30 * time.Second,
				Metadata: make(map[string]string),
			},
		},
		Triggers: []*WorkflowTrigger{
			{
				ID:      "manual-trigger",
				Type:    "manual",
				Enabled: true,
				Metadata: make(map[string]string),
			},
		},
		Variables: make(map[string]string),
		CreatedAt: time.Now(),
		UpdatedAt: time.Now(),
		Metadata:  make(map[string]string),
	}

	// Register workflow
	err := we.RegisterWorkflow(workflow)
	if err != nil {
		t.Fatalf("Failed to register workflow: %v", err)
	}

	// Get workflow
	retrievedWorkflow, err := we.GetWorkflow("management-workflow")
	if err != nil {
		t.Fatalf("Failed to get workflow: %v", err)
	}

	if retrievedWorkflow.ID != "management-workflow" {
		t.Errorf("Expected workflow ID 'management-workflow', got '%s'", retrievedWorkflow.ID)
	}

	// List workflows
	workflows := we.ListWorkflows()
	if len(workflows) == 0 {
		t.Fatal("Should have at least one workflow")
	}

	found := false
	for _, w := range workflows {
		if w.ID == "management-workflow" {
			found = true
			break
		}
	}

	if !found {
		t.Fatal("Created workflow should be in workflow list")
	}

	// Execute workflow
	input := map[string]interface{}{
		"data": "management test data",
	}

	execution, err := we.ExecuteWorkflow("management-workflow", input)
	if err != nil {
		t.Fatalf("Failed to execute workflow: %v", err)
	}

	// Get execution
	retrievedExecution, err := we.GetExecution(execution.ID)
	if err != nil {
		t.Fatalf("Failed to get execution: %v", err)
	}

	if retrievedExecution.ID != execution.ID {
		t.Errorf("Expected execution ID %s, got %s", execution.ID, retrievedExecution.ID)
	}

	// List executions
	executions := we.ListExecutions()
	if len(executions) == 0 {
		t.Fatal("Should have at least one execution")
	}

	found = false
	for _, e := range executions {
		if e.ID == execution.ID {
			found = true
			break
		}
	}

	if !found {
		t.Fatal("Created execution should be in execution list")
	}
}

// BenchmarkWorkflowEngineExecuteWorkflow benchmarks workflow execution
func BenchmarkWorkflowEngineExecuteWorkflow(b *testing.B) {
	config := WorkflowConfig{
		MaxConcurrentExecutions: 10,
		DefaultTimeout:          5 * time.Minute,
		EnableRetry:             false,
		MaxRetries:              0,
		EnableMonitoring:        false,
		MonitorInterval:         30 * time.Second,
		EnablePersistence:       false,
		PersistencePath:         "",
	}

	we := NewWorkflowEngine(config)

	// Create simple workflow
	workflow := &Workflow{
		ID:          "benchmark-workflow",
		Name:        "Benchmark Workflow",
		Description: "A workflow for benchmarking",
		Version:     "1.0.0",
		Steps: []*WorkflowStep{
			{
				ID:       "benchmark-step",
				Name:     "Benchmark Step",
				Type:     "task",
				Action:   "benchmark_task",
				Input:    map[string]string{"data": "benchmark_data"},
				Output:   map[string]string{"result": "benchmark_result"},
				Timeout:  30 * time.Second,
				Metadata: make(map[string]string),
			},
		},
		Triggers: []*WorkflowTrigger{
			{
				ID:      "manual-trigger",
				Type:    "manual",
				Enabled: true,
				Metadata: make(map[string]string),
			},
		},
		Variables: make(map[string]string),
		CreatedAt: time.Now(),
		UpdatedAt: time.Now(),
		Metadata:  make(map[string]string),
	}

	err := we.RegisterWorkflow(workflow)
	if err != nil {
		b.Fatalf("Failed to register workflow: %v", err)
	}

	input := map[string]interface{}{
		"data": "benchmark test data",
	}

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		_, err := we.ExecuteWorkflow("benchmark-workflow", input)
		if err != nil {
			b.Fatalf("Workflow execution failed: %v", err)
		}
	}
} 