package main

import (
	"testing"
	"time"
)

// TestAnalyticsEngineBasic tests basic analytics functionality
func TestAnalyticsEngineBasic(t *testing.T) {
	config := AnalyticsConfig{
		EnableRealTime:      true,
		EnableBatch:         true,
		BatchSize:           1000,
		BatchInterval:       5 * time.Minute,
		EnableAggregation:   true,
		EnablePrediction:    true,
		EnableMonitoring:    true,
		MonitorInterval:     30 * time.Second,
		EnablePersistence:   false,
		PersistencePath:     "",
		MaxDataPoints:       1000000,
		RetentionPeriod:     30 * 24 * time.Hour, // 30 days
	}

	ae := NewAnalyticsEngine(config)
	if ae == nil {
		t.Fatal("Failed to create AnalyticsEngine")
	}

	// Create a data source
	dataSource := &DataSource{
		ID:          "test-source",
		Name:        "Test Data Source",
		Description: "A test data source for analytics",
		Type:        "stream",
		Config: map[string]interface{}{
			"url":      "http://localhost:8080/data",
			"interval": "1s",
		},
		Schema: []*DataField{
			{
				Name:     "timestamp",
				Type:     "timestamp",
				Required: true,
			},
			{
				Name:     "user_id",
				Type:     "string",
				Required: true,
			},
			{
				Name:     "value",
				Type:     "number",
				Required: true,
			},
		},
		CreatedAt: time.Now(),
		UpdatedAt: time.Now(),
		Metadata:  make(map[string]string),
	}

	// Register data source
	err := ae.RegisterDataSource(dataSource)
	if err != nil {
		t.Fatalf("Failed to register data source: %v", err)
	}

	// Create analytics query
	query := &AnalyticsQuery{
		ID:          "test-query",
		Name:        "Test Query",
		Description: "A test analytics query",
		DataSource:  "test-source",
		Type:        "aggregation",
		Query:       "SELECT user_id, AVG(value) as avg_value, COUNT(*) as count FROM data GROUP BY user_id",
		Filters: []*QueryFilter{
			{
				Field:    "timestamp",
				Operator: "gte",
				Value:    time.Now().Add(-1 * time.Hour),
			},
		},
		Aggregations: []*Aggregation{
			{
				Field: "value",
				Type:  "avg",
				Alias: "avg_value",
			},
			{
				Field: "value",
				Type:  "count",
				Alias: "count",
			},
		},
		GroupBy: []string{"user_id"},
		CreatedAt: time.Now(),
		UpdatedAt: time.Now(),
		Metadata:  make(map[string]string),
	}

	// Register query
	err = ae.RegisterQuery(query)
	if err != nil {
		t.Fatalf("Failed to register query: %v", err)
	}

	// Execute query
	result, err := ae.ExecuteQuery("test-query", map[string]interface{}{
		"start_time": time.Now().Add(-1 * time.Hour),
		"end_time":   time.Now(),
	})
	if err != nil {
		t.Fatalf("Failed to execute query: %v", err)
	}

	if result.QueryID != "test-query" {
		t.Errorf("Expected query ID 'test-query', got '%s'", result.QueryID)
	}

	if result.Status != "completed" {
		t.Errorf("Expected status 'completed', got '%s'", result.Status)
	}
}

// TestAnalyticsEngineDataIngestion tests data ingestion functionality
func TestAnalyticsEngineDataIngestion(t *testing.T) {
	config := AnalyticsConfig{
		EnableRealTime:      true,
		EnableBatch:         true,
		BatchSize:           100,
		BatchInterval:       1 * time.Minute,
		EnableAggregation:   true,
		EnablePrediction:    true,
		EnableMonitoring:    true,
		MonitorInterval:     30 * time.Second,
		EnablePersistence:   false,
		PersistencePath:     "",
		MaxDataPoints:       10000,
		RetentionPeriod:     24 * time.Hour,
	}

	ae := NewAnalyticsEngine(config)

	// Create data source
	dataSource := &DataSource{
		ID:          "ingestion-source",
		Name:        "Ingestion Data Source",
		Description: "A data source for ingestion tests",
		Type:        "stream",
		Config: map[string]interface{}{
			"url":      "http://localhost:8080/ingestion",
			"interval": "100ms",
		},
		Schema: []*DataField{
			{
				Name:     "timestamp",
				Type:     "timestamp",
				Required: true,
			},
			{
				Name:     "metric",
				Type:     "string",
				Required: true,
			},
			{
				Name:     "value",
				Type:     "number",
				Required: true,
			},
		},
		CreatedAt: time.Now(),
		UpdatedAt: time.Now(),
		Metadata:  make(map[string]string),
	}

	// Register data source
	err := ae.RegisterDataSource(dataSource)
	if err != nil {
		t.Fatalf("Failed to register data source: %v", err)
	}

	// Ingest data points
	dataPoints := []*DataPoint{
		{
			DataSource: "ingestion-source",
			Timestamp:  time.Now(),
			Data: map[string]interface{}{
				"metric": "cpu_usage",
				"value":  75.5,
			},
			Metadata: make(map[string]string),
		},
		{
			DataSource: "ingestion-source",
			Timestamp:  time.Now(),
			Data: map[string]interface{}{
				"metric": "memory_usage",
				"value":  82.3,
			},
			Metadata: make(map[string]string),
		},
		{
			DataSource: "ingestion-source",
			Timestamp:  time.Now(),
			Data: map[string]interface{}{
				"metric": "disk_usage",
				"value":  45.7,
			},
			Metadata: make(map[string]string),
		},
	}

	// Ingest data
	for _, point := range dataPoints {
		err := ae.IngestData(point)
		if err != nil {
			t.Fatalf("Failed to ingest data point: %v", err)
		}
	}

	// Wait for batch processing
	time.Sleep(2 * time.Minute)

	// Verify data ingestion
	stats := ae.GetStats()
	if stats == nil {
		t.Fatal("Statistics should not be nil")
	}

	if stats["total_data_points"] == nil {
		t.Error("Statistics should contain total_data_points")
	}

	if stats["ingestion_rate"] == nil {
		t.Error("Statistics should contain ingestion_rate")
	}
}

// TestAnalyticsEngineAggregation tests aggregation functionality
func TestAnalyticsEngineAggregation(t *testing.T) {
	config := AnalyticsConfig{
		EnableRealTime:      true,
		EnableBatch:         true,
		BatchSize:           100,
		BatchInterval:       1 * time.Minute,
		EnableAggregation:   true,
		EnablePrediction:    true,
		EnableMonitoring:    true,
		MonitorInterval:     30 * time.Second,
		EnablePersistence:   false,
		PersistencePath:     "",
		MaxDataPoints:       10000,
		RetentionPeriod:     24 * time.Hour,
	}

	ae := NewAnalyticsEngine(config)

	// Create data source
	dataSource := &DataSource{
		ID:          "aggregation-source",
		Name:        "Aggregation Data Source",
		Description: "A data source for aggregation tests",
		Type:        "batch",
		Config: map[string]interface{}{
			"file_path": "/tmp/aggregation_data.csv",
		},
		Schema: []*DataField{
			{
				Name:     "timestamp",
				Type:     "timestamp",
				Required: true,
			},
			{
				Name:     "category",
				Type:     "string",
				Required: true,
			},
			{
				Name:     "amount",
				Type:     "number",
				Required: true,
			},
		},
		CreatedAt: time.Now(),
		UpdatedAt: time.Now(),
		Metadata:  make(map[string]string),
	}

	// Register data source
	err := ae.RegisterDataSource(dataSource)
	if err != nil {
		t.Fatalf("Failed to register data source: %v", err)
	}

	// Create aggregation query
	query := &AnalyticsQuery{
		ID:          "aggregation-query",
		Name:        "Aggregation Query",
		Description: "A query for aggregation tests",
		DataSource:  "aggregation-source",
		Type:        "aggregation",
		Query:       "SELECT category, SUM(amount) as total, AVG(amount) as average, COUNT(*) as count FROM data GROUP BY category",
		Aggregations: []*Aggregation{
			{
				Field: "amount",
				Type:  "sum",
				Alias: "total",
			},
			{
				Field: "amount",
				Type:  "avg",
				Alias: "average",
			},
			{
				Field: "amount",
				Type:  "count",
				Alias: "count",
			},
		},
		GroupBy: []string{"category"},
		CreatedAt: time.Now(),
		UpdatedAt: time.Now(),
		Metadata:  make(map[string]string),
	}

	// Register query
	err = ae.RegisterQuery(query)
	if err != nil {
		t.Fatalf("Failed to register query: %v", err)
	}

	// Execute aggregation
	result, err := ae.ExecuteQuery("aggregation-query", map[string]interface{}{
		"start_time": time.Now().Add(-24 * time.Hour),
		"end_time":   time.Now(),
	})
	if err != nil {
		t.Fatalf("Failed to execute aggregation: %v", err)
	}

	if result.Status != "completed" {
		t.Errorf("Expected status 'completed', got '%s'", result.Status)
	}

	// Verify aggregation results
	if len(result.Data) == 0 {
		t.Fatal("Aggregation should return data")
	}

	// Check that aggregation fields exist
	for _, row := range result.Data {
		if row["total"] == nil {
			t.Error("Aggregation should contain 'total' field")
		}
		if row["average"] == nil {
			t.Error("Aggregation should contain 'average' field")
		}
		if row["count"] == nil {
			t.Error("Aggregation should contain 'count' field")
		}
	}
}

// TestAnalyticsEnginePrediction tests prediction functionality
func TestAnalyticsEnginePrediction(t *testing.T) {
	config := AnalyticsConfig{
		EnableRealTime:      true,
		EnableBatch:         true,
		BatchSize:           100,
		BatchInterval:       1 * time.Minute,
		EnableAggregation:   true,
		EnablePrediction:    true,
		EnableMonitoring:    true,
		MonitorInterval:     30 * time.Second,
		EnablePersistence:   false,
		PersistencePath:     "",
		MaxDataPoints:       10000,
		RetentionPeriod:     24 * time.Hour,
	}

	ae := NewAnalyticsEngine(config)

	// Create prediction model
	model := &PredictionModel{
		ID:          "test-model",
		Name:        "Test Prediction Model",
		Description: "A test prediction model",
		Type:        "linear_regression",
		Algorithm:   "linear",
		Features:    []string{"feature1", "feature2", "feature3"},
		Target:      "target",
		Config: map[string]interface{}{
			"learning_rate": 0.01,
			"epochs":        100,
		},
		Status:    "trained",
		Accuracy:  0.85,
		CreatedAt: time.Now(),
		UpdatedAt: time.Now(),
		Metadata:  make(map[string]string),
	}

	// Register model
	err := ae.RegisterModel(model)
	if err != nil {
		t.Fatalf("Failed to register model: %v", err)
	}

	// Create prediction query
	query := &AnalyticsQuery{
		ID:          "prediction-query",
		Name:        "Prediction Query",
		Description: "A query for prediction tests",
		DataSource:  "test-source",
		Type:        "prediction",
		ModelID:     "test-model",
		Query:       "SELECT feature1, feature2, feature3 FROM data WHERE timestamp >= $start_time",
		Features:    []string{"feature1", "feature2", "feature3"},
		CreatedAt:   time.Now(),
		UpdatedAt:   time.Now(),
		Metadata:    make(map[string]string),
	}

	// Register query
	err = ae.RegisterQuery(query)
	if err != nil {
		t.Fatalf("Failed to register query: %v", err)
	}

	// Execute prediction
	result, err := ae.ExecuteQuery("prediction-query", map[string]interface{}{
		"start_time": time.Now().Add(-1 * time.Hour),
		"end_time":   time.Now(),
	})
	if err != nil {
		t.Fatalf("Failed to execute prediction: %v", err)
	}

	if result.Status != "completed" {
		t.Errorf("Expected status 'completed', got '%s'", result.Status)
	}

	// Verify prediction results
	if len(result.Data) == 0 {
		t.Fatal("Prediction should return data")
	}

	// Check that prediction field exists
	for _, row := range result.Data {
		if row["prediction"] == nil {
			t.Error("Prediction should contain 'prediction' field")
		}
	}
}

// TestAnalyticsEngineRealTimeAnalytics tests real-time analytics
func TestAnalyticsEngineRealTimeAnalytics(t *testing.T) {
	config := AnalyticsConfig{
		EnableRealTime:      true,
		EnableBatch:         false,
		BatchSize:           100,
		BatchInterval:       1 * time.Minute,
		EnableAggregation:   true,
		EnablePrediction:    false,
		EnableMonitoring:    true,
		MonitorInterval:     30 * time.Second,
		EnablePersistence:   false,
		PersistencePath:     "",
		MaxDataPoints:       10000,
		RetentionPeriod:     24 * time.Hour,
	}

	ae := NewAnalyticsEngine(config)

	// Create real-time data source
	dataSource := &DataSource{
		ID:          "realtime-source",
		Name:        "Real-time Data Source",
		Description: "A real-time data source",
		Type:        "stream",
		Config: map[string]interface{}{
			"url":      "ws://localhost:8080/realtime",
			"interval": "100ms",
		},
		Schema: []*DataField{
			{
				Name:     "timestamp",
				Type:     "timestamp",
				Required: true,
			},
			{
				Name:     "event_type",
				Type:     "string",
				Required: true,
			},
			{
				Name:     "value",
				Type:     "number",
				Required: true,
			},
		},
		CreatedAt: time.Now(),
		UpdatedAt: time.Now(),
		Metadata:  make(map[string]string),
	}

	// Register data source
	err := ae.RegisterDataSource(dataSource)
	if err != nil {
		t.Fatalf("Failed to register data source: %v", err)
	}

	// Create real-time query
	query := &AnalyticsQuery{
		ID:          "realtime-query",
		Name:        "Real-time Query",
		Description: "A real-time analytics query",
		DataSource:  "realtime-source",
		Type:        "realtime",
		Query:       "SELECT event_type, COUNT(*) as event_count FROM data WHERE timestamp >= NOW() - INTERVAL '5 minutes' GROUP BY event_type",
		Window:      5 * time.Minute,
		Interval:    30 * time.Second,
		CreatedAt:   time.Now(),
		UpdatedAt:   time.Now(),
		Metadata:    make(map[string]string),
	}

	// Register query
	err = ae.RegisterQuery(query)
	if err != nil {
		t.Fatalf("Failed to register query: %v", err)
	}

	// Start real-time processing
	err = ae.StartRealTimeProcessing("realtime-query")
	if err != nil {
		t.Fatalf("Failed to start real-time processing: %v", err)
	}

	// Wait for real-time processing
	time.Sleep(1 * time.Minute)

	// Stop real-time processing
	err = ae.StopRealTimeProcessing("realtime-query")
	if err != nil {
		t.Fatalf("Failed to stop real-time processing: %v", err)
	}

	// Verify real-time processing
	stats := ae.GetStats()
	if stats == nil {
		t.Fatal("Statistics should not be nil")
	}

	if stats["realtime_queries"] == nil {
		t.Error("Statistics should contain realtime_queries")
	}
}

// TestAnalyticsEngineDataManagement tests data management functionality
func TestAnalyticsEngineDataManagement(t *testing.T) {
	config := AnalyticsConfig{
		EnableRealTime:      true,
		EnableBatch:         true,
		BatchSize:           100,
		BatchInterval:       1 * time.Minute,
		EnableAggregation:   true,
		EnablePrediction:    true,
		EnableMonitoring:    true,
		MonitorInterval:     30 * time.Second,
		EnablePersistence:   false,
		PersistencePath:     "",
		MaxDataPoints:       10000,
		RetentionPeriod:     24 * time.Hour,
	}

	ae := NewAnalyticsEngine(config)

	// Create multiple data sources
	sources := []*DataSource{
		{
			ID:          "source1",
			Name:        "Source 1",
			Description: "First test source",
			Type:        "stream",
			Config:      make(map[string]interface{}),
			Schema:      []*DataField{},
			CreatedAt:   time.Now(),
			UpdatedAt:   time.Now(),
			Metadata:    make(map[string]string),
		},
		{
			ID:          "source2",
			Name:        "Source 2",
			Description: "Second test source",
			Type:        "batch",
			Config:      make(map[string]interface{}),
			Schema:      []*DataField{},
			CreatedAt:   time.Now(),
			UpdatedAt:   time.Now(),
			Metadata:    make(map[string]string),
		},
	}

	// Register data sources
	for _, source := range sources {
		err := ae.RegisterDataSource(source)
		if err != nil {
			t.Fatalf("Failed to register data source %s: %v", source.ID, err)
		}
	}

	// Get data source
	retrievedSource, err := ae.GetDataSource("source1")
	if err != nil {
		t.Fatalf("Failed to get data source: %v", err)
	}

	if retrievedSource.ID != "source1" {
		t.Errorf("Expected data source ID 'source1', got '%s'", retrievedSource.ID)
	}

	// List data sources
	allSources := ae.ListDataSources()
	if len(allSources) < 2 {
		t.Fatalf("Expected at least 2 data sources, got %d", len(allSources))
	}

	found := make(map[string]bool)
	for _, source := range allSources {
		found[source.ID] = true
	}

	if !found["source1"] {
		t.Fatal("Source1 should be in data source list")
	}

	if !found["source2"] {
		t.Fatal("Source2 should be in data source list")
	}

	// Create multiple queries
	queries := []*AnalyticsQuery{
		{
			ID:          "query1",
			Name:        "Query 1",
			Description: "First test query",
			DataSource:  "source1",
			Type:        "aggregation",
			Query:       "SELECT * FROM data",
			CreatedAt:   time.Now(),
			UpdatedAt:   time.Now(),
			Metadata:    make(map[string]string),
		},
		{
			ID:          "query2",
			Name:        "Query 2",
			Description: "Second test query",
			DataSource:  "source2",
			Type:        "prediction",
			Query:       "SELECT * FROM data",
			CreatedAt:   time.Now(),
			UpdatedAt:   time.Now(),
			Metadata:    make(map[string]string),
		},
	}

	// Register queries
	for _, query := range queries {
		err := ae.RegisterQuery(query)
		if err != nil {
			t.Fatalf("Failed to register query %s: %v", query.ID, err)
		}
	}

	// Get query
	retrievedQuery, err := ae.GetQuery("query1")
	if err != nil {
		t.Fatalf("Failed to get query: %v", err)
	}

	if retrievedQuery.ID != "query1" {
		t.Errorf("Expected query ID 'query1', got '%s'", retrievedQuery.ID)
	}

	// List queries
	allQueries := ae.ListQueries()
	if len(allQueries) < 2 {
		t.Fatalf("Expected at least 2 queries, got %d", len(allQueries))
	}

	found = make(map[string]bool)
	for _, query := range allQueries {
		found[query.ID] = true
	}

	if !found["query1"] {
		t.Fatal("Query1 should be in query list")
	}

	if !found["query2"] {
		t.Fatal("Query2 should be in query list")
	}
}

// BenchmarkAnalyticsEngineExecuteQuery benchmarks query execution
func BenchmarkAnalyticsEngineExecuteQuery(b *testing.B) {
	config := AnalyticsConfig{
		EnableRealTime:      false,
		EnableBatch:         true,
		BatchSize:           1000,
		BatchInterval:       1 * time.Minute,
		EnableAggregation:   true,
		EnablePrediction:    false,
		EnableMonitoring:    false,
		MonitorInterval:     30 * time.Second,
		EnablePersistence:   false,
		PersistencePath:     "",
		MaxDataPoints:       100000,
		RetentionPeriod:     24 * time.Hour,
	}

	ae := NewAnalyticsEngine(config)

	// Create data source
	dataSource := &DataSource{
		ID:          "benchmark-source",
		Name:        "Benchmark Data Source",
		Description: "A data source for benchmarking",
		Type:        "batch",
		Config:      make(map[string]interface{}),
		Schema:      []*DataField{},
		CreatedAt:   time.Now(),
		UpdatedAt:   time.Now(),
		Metadata:    make(map[string]string),
	}

	err := ae.RegisterDataSource(dataSource)
	if err != nil {
		b.Fatalf("Failed to register data source: %v", err)
	}

	// Create query
	query := &AnalyticsQuery{
		ID:          "benchmark-query",
		Name:        "Benchmark Query",
		Description: "A query for benchmarking",
		DataSource:  "benchmark-source",
		Type:        "aggregation",
		Query:       "SELECT COUNT(*) as count FROM data",
		CreatedAt:   time.Now(),
		UpdatedAt:   time.Now(),
		Metadata:    make(map[string]string),
	}

	err = ae.RegisterQuery(query)
	if err != nil {
		b.Fatalf("Failed to register query: %v", err)
	}

	params := map[string]interface{}{
		"start_time": time.Now().Add(-1 * time.Hour),
		"end_time":   time.Now(),
	}

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		_, err := ae.ExecuteQuery("benchmark-query", params)
		if err != nil {
			b.Fatalf("Query execution failed: %v", err)
		}
	}
} 