package main

import (
	"testing"
	"time"
	"fmt"
)

// TestNaturalLanguageProcessingBasic tests basic NLP functionality
func TestNaturalLanguageProcessingBasic(t *testing.T) {
	config := NLPConfig{
		EnableTokenization:  true,
		EnableSentiment:     true,
		EnableNER:           true,
		EnableTranslation:   true,
		EnableMonitoring:    true,
		MonitorInterval:     30 * time.Second,
		EnablePersistence:   false,
		PersistencePath:     "",
		MaxModels:           50,
		DefaultLanguage:     "english",
		EnableMultilingual:  true,
	}

	nlp := NewNaturalLanguageProcessing(config)
	if nlp == nil {
		t.Fatal("Failed to create NaturalLanguageProcessing")
	}

	// Test text input
	text := "This is a test sentence for NLP processing."

	// Tokenization
	tokens, err := nlp.Tokenize(text, "english")
	if err != nil {
		t.Fatalf("Failed to tokenize: %v", err)
	}

	if len(tokens.Tokens) == 0 {
		t.Fatal("Tokens should not be empty")
	}

	// Sentiment analysis
	sentiment, err := nlp.AnalyzeSentiment(text, "english")
	if err != nil {
		t.Fatalf("Failed to analyze sentiment: %v", err)
	}

	if sentiment.Score == 0 {
		t.Error("Sentiment score should not be zero")
	}

	// Named Entity Recognition
	entities, err := nlp.RecognizeEntities(text, "english")
	if err != nil {
		t.Fatalf("Failed to recognize entities: %v", err)
	}

	if entities.Text != text {
		t.Errorf("Expected text '%s', got '%s'", text, entities.Text)
	}

	// Translation
	translation, err := nlp.Translate(text, "english", "spanish")
	if err != nil {
		t.Fatalf("Failed to translate: %v", err)
	}

	if translation.TranslatedText == "" {
		t.Error("Translated text should not be empty")
	}
}

// TestNaturalLanguageProcessingModelManagement tests model management
func TestNaturalLanguageProcessingModelManagement(t *testing.T) {
	config := NLPConfig{
		EnableTokenization:  true,
		EnableSentiment:     true,
		EnableNER:           true,
		EnableTranslation:   true,
		EnableMonitoring:    true,
		MonitorInterval:     30 * time.Second,
		EnablePersistence:   false,
		PersistencePath:     "",
		MaxModels:           50,
		DefaultLanguage:     "english",
		EnableMultilingual:  true,
	}

	nlp := NewNaturalLanguageProcessing(config)

	// Create multiple models
	models := []*NLPModel{
		{
			ID:          "nlp-model-1",
			Name:        "NLP Model 1",
			Description: "First NLP model",
			Type:        "sentiment",
			Language:    "english",
			Config: map[string]interface{}{
				"pretrained": true,
			},
			Status:    "initialized",
			CreatedAt: time.Now(),
			UpdatedAt: time.Now(),
			Metadata:  make(map[string]string),
		},
		{
			ID:          "nlp-model-2",
			Name:        "NLP Model 2",
			Description: "Second NLP model",
			Type:        "ner",
			Language:    "spanish",
			Config: map[string]interface{}{
				"pretrained": true,
			},
			Status:    "initialized",
			CreatedAt: time.Now(),
			UpdatedAt: time.Now(),
			Metadata:  make(map[string]string),
		},
	}

	// Register models
	for _, model := range models {
		err := nlp.RegisterModel(model)
		if err != nil {
			t.Fatalf("Failed to register model %s: %v", model.ID, err)
		}
	}

	// Get model
	retrievedModel, err := nlp.GetModel("nlp-model-1")
	if err != nil {
		t.Fatalf("Failed to get model: %v", err)
	}

	if retrievedModel.ID != "nlp-model-1" {
		t.Errorf("Expected model ID 'nlp-model-1', got '%s'", retrievedModel.ID)
	}

	// List models
	allModels := nlp.ListModels()
	if len(allModels) < 2 {
		t.Fatalf("Expected at least 2 models, got %d", len(allModels))
	}

	found := make(map[string]bool)
	for _, model := range allModels {
		found[model.ID] = true
	}

	if !found["nlp-model-1"] {
		t.Fatal("NLP-model-1 should be in model list")
	}

	if !found["nlp-model-2"] {
		t.Fatal("NLP-model-2 should be in model list")
	}
}

// TestNaturalLanguageProcessingMultilingual tests multilingual support
func TestNaturalLanguageProcessingMultilingual(t *testing.T) {
	config := NLPConfig{
		EnableTokenization:  true,
		EnableSentiment:     true,
		EnableNER:           true,
		EnableTranslation:   true,
		EnableMonitoring:    true,
		MonitorInterval:     30 * time.Second,
		EnablePersistence:   false,
		PersistencePath:     "",
		MaxModels:           50,
		DefaultLanguage:     "english",
		EnableMultilingual:  true,
	}

	nlp := NewNaturalLanguageProcessing(config)

	// Test texts in different languages
	texts := map[string]string{
		"english": "Hello, this is a test.",
		"spanish": "Hola, esto es una prueba.",
		"french": "Bonjour, c'est un test.",
	}

	for lang, text := range texts {
		// Tokenization
		tokens, err := nlp.Tokenize(text, lang)
		if err != nil {
			t.Fatalf("Failed to tokenize %s: %v", lang, err)
		}

		if len(tokens.Tokens) == 0 {
			t.Errorf("Tokens should not be empty for %s", lang)
		}

		// Sentiment
		sentiment, err := nlp.AnalyzeSentiment(text, lang)
		if err != nil {
			t.Fatalf("Failed to analyze sentiment %s: %v", lang, err)
		}

		if sentiment.Language != lang {
			t.Errorf("Expected language %s, got %s", lang, sentiment.Language)
		}
	}

	// Test translation between languages
	sourceText := "Good morning"
	sourceLang := "english"
	targetLang := "french"

	translation, err := nlp.Translate(sourceText, sourceLang, targetLang)
	if err != nil {
		t.Fatalf("Failed to translate: %v", err)
	}

	if translation.SourceLanguage != sourceLang {
		t.Errorf("Expected source %s, got %s", sourceLang, translation.SourceLanguage)
	}

	if translation.TargetLanguage != targetLang {
		t.Errorf("Expected target %s, got %s", targetLang, translation.TargetLanguage)
	}
}

// TestNaturalLanguageProcessingAdvancedFeatures tests advanced NLP features
func TestNaturalLanguageProcessingAdvancedFeatures(t *testing.T) {
	config := NLPConfig{
		EnableTokenization:  true,
		EnableSentiment:     true,
		EnableNER:           true,
		EnableTranslation:   true,
		EnableMonitoring:    true,
		MonitorInterval:     30 * time.Second,
		EnablePersistence:   false,
		PersistencePath:     "",
		MaxModels:           50,
		DefaultLanguage:     "english",
		EnableMultilingual:  true,
	}

	nlp := NewNaturalLanguageProcessing(config)

	text := "Apple Inc. was founded by Steve Jobs in California on April 1, 1976."

	// Named Entity Recognition
	entities, err := nlp.RecognizeEntities(text, "english")
	if err != nil {
		t.Fatalf("Failed to recognize entities: %v", err)
	}

	if len(entities.Entities) == 0 {
		t.Fatal("Entities should not be empty")
	}

	// Check for expected entities
	foundOrg := false
	foundPerson := false
	foundLocation := false
	foundDate := false

	for _, entity := range entities.Entities {
		switch entity.Type {
		case "ORGANIZATION":
			foundOrg = true
		case "PERSON":
			foundPerson = true
		case "LOCATION":
			foundLocation = true
		case "DATE":
			foundDate = true
		}
	}

	if !foundOrg {
		t.Error("Expected ORGANIZATION entity")
	}
	if !foundPerson {
		t.Error("Expected PERSON entity")
	}
	if !foundLocation {
		t.Error("Expected LOCATION entity")
	}
	if !foundDate {
		t.Error("Expected DATE entity")
	}

	// Test sentiment with context
	positiveText := "I love this product! It's amazing."
	negativeText := "I hate this service. It's terrible."

	posSentiment, _ := nlp.AnalyzeSentiment(positiveText, "english")
	if posSentiment.Sentiment != "positive" {
		t.Errorf("Expected positive sentiment, got %s", posSentiment.Sentiment)
	}

	negSentiment, _ := nlp.AnalyzeSentiment(negativeText, "english")
	if negSentiment.Sentiment != "negative" {
		t.Errorf("Expected negative sentiment, got %s", negSentiment.Sentiment)
	}
}

// BenchmarkNaturalLanguageProcessingTokenize benchmarks tokenization
func BenchmarkNaturalLanguageProcessingTokenize(b *testing.B) {
	config := NLPConfig{
		EnableTokenization:  true,
		EnableSentiment:     false,
		EnableNER:           false,
		EnableTranslation:   false,
		EnableMonitoring:    false,
		MonitorInterval:     30 * time.Second,
		EnablePersistence:   false,
		PersistencePath:     "",
		MaxModels:           50,
		DefaultLanguage:     "english",
		EnableMultilingual:  true,
	}

	nlp := NewNaturalLanguageProcessing(config)

	text := "This is a benchmark text for tokenization performance testing. It should be long enough to measure properly. " +
		"Repeat this sentence multiple times to increase length. This is a benchmark text for tokenization performance testing. " +
		"It should be long enough to measure properly. Repeat this sentence multiple times to increase length."

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		_, err := nlp.Tokenize(text, "english")
		if err != nil {
			b.Fatalf("Tokenization failed: %v", err)
		}
	}
}

// BenchmarkNaturalLanguageProcessingAnalyzeSentiment benchmarks sentiment analysis
func BenchmarkNaturalLanguageProcessingAnalyzeSentiment(b *testing.B) {
	config := NLPConfig{
		EnableTokenization:  false,
		EnableSentiment:     true,
		EnableNER:           false,
		EnableTranslation:   false,
		EnableMonitoring:    false,
		MonitorInterval:     30 * time.Second,
		EnablePersistence:   false,
		PersistencePath:     "",
		MaxModels:           50,
		DefaultLanguage:     "english",
		EnableMultilingual:  true,
	}

	nlp := NewNaturalLanguageProcessing(config)

	text := "This is a benchmark text for sentiment analysis performance testing. It should be long enough to measure properly. " +
		"The quick brown fox jumps over the lazy dog. This is a positive sentence. That was negative. Neutral statement."

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		_, err := nlp.AnalyzeSentiment(text, "english")
		if err != nil {
			b.Fatalf("Sentiment analysis failed: %v", err)
		}
	}
} 