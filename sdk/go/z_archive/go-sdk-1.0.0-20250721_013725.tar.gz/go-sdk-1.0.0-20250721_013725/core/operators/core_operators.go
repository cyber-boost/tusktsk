package operators

import (
	"context"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"os"
	"path/filepath"
	"regexp"
	"strconv"
	"strings"
	"time"
)

// VariableOperator handles @variable operations
type VariableOperator struct {
	*BaseOperator
	variables map[string]interface{}
}

// NewVariableOperator creates a new variable operator
func NewVariableOperator() *VariableOperator {
	return &VariableOperator{
		BaseOperator: NewBaseOperator(),
		variables:    make(map[string]interface{}),
	}
}

// Execute handles @variable operations
func (v *VariableOperator) Execute(ctx context.Context, params map[string]interface{}) OperatorResult {
	v.Log("Executing @variable operator with params: %v", params)
	
	name := v.GetStringParam(params, "name", "")
	if name == "" {
		return v.CreateErrorResult("variable name is required")
	}
	
	// Get variable value
	if value, exists := v.variables[name]; exists {
		return v.CreateSuccessResult(value)
	}
	
	// Check environment variables as fallback
	if envValue := os.Getenv(name); envValue != "" {
		return v.CreateSuccessResult(envValue)
	}
	
	return v.CreateErrorResult(fmt.Sprintf("variable '%s' not found", name))
}

// SetVariable sets a variable value
func (v *VariableOperator) SetVariable(name string, value interface{}) {
	v.variables[name] = value
	v.Log("Set variable '%s' = %v", name, value)
}

// EnvOperator handles @env operations
type EnvOperator struct {
	*BaseOperator
}

// NewEnvOperator creates a new environment operator
func NewEnvOperator() *EnvOperator {
	return &EnvOperator{
		BaseOperator: NewBaseOperator(),
	}
}

// Execute handles @env operations
func (e *EnvOperator) Execute(ctx context.Context, params map[string]interface{}) OperatorResult {
	e.Log("Executing @env operator with params: %v", params)
	
	name := e.GetStringParam(params, "name", "")
	if name == "" {
		return e.CreateErrorResult("environment variable name is required")
	}
	
	defaultValue := e.GetStringParam(params, "default", "")
	
	// Get environment variable
	if value := os.Getenv(name); value != "" {
		return e.CreateSuccessResult(value)
	}
	
	// Return default value if provided
	if defaultValue != "" {
		return e.CreateSuccessResult(defaultValue)
	}
	
	return e.CreateErrorResult(fmt.Sprintf("environment variable '%s' not found", name))
}

// DateOperator handles @date operations
type DateOperator struct {
	*BaseOperator
}

// NewDateOperator creates a new date operator
func NewDateOperator() *DateOperator {
	return &DateOperator{
		BaseOperator: NewBaseOperator(),
	}
}

// Execute handles @date operations
func (d *DateOperator) Execute(ctx context.Context, params map[string]interface{}) OperatorResult {
	d.Log("Executing @date operator with params: %v", params)
	
	format := d.GetStringParam(params, "format", "Y-m-d H:i:s")
	timezone := d.GetStringParam(params, "timezone", "UTC")
	
	// Parse timezone
	loc, err := time.LoadLocation(timezone)
	if err != nil {
		loc = time.UTC
		d.Log("Invalid timezone '%s', using UTC", timezone)
	}
	
	now := time.Now().In(loc)
	
	// Convert PHP-style format to Go
	goFormat := d.convertPHPFormat(format)
	
	result := now.Format(goFormat)
	return d.CreateSuccessResult(result)
}

// convertPHPFormat converts PHP date format to Go format
func (d *DateOperator) convertPHPFormat(phpFormat string) string {
	formatMap := map[string]string{
		"Y":           "2006",
		"y":           "06",
		"m":           "01",
		"d":           "02",
		"H":           "15",
		"h":           "03",
		"i":           "04",
		"s":           "05",
		"A":           "PM",
		"a":           "pm",
		"F":           "January",
		"M":           "Jan",
		"l":           "Monday",
		"D":           "Mon",
		"T":           "MST",
		"Z":           "-0700",
		"c":           time.RFC3339,
		"r":           time.RFC1123,
		"U":           "Unix",
	}
	
	result := phpFormat
	for php, go := range formatMap {
		result = strings.ReplaceAll(result, php, go)
	}
	
	return result
}

// FileOperator handles @file operations
type FileOperator struct {
	*BaseOperator
}

// NewFileOperator creates a new file operator
func NewFileOperator() *FileOperator {
	return &FileOperator{
		BaseOperator: NewBaseOperator(),
	}
}

// Execute handles @file operations
func (f *FileOperator) Execute(ctx context.Context, params map[string]interface{}) OperatorResult {
	f.Log("Executing @file operator with params: %v", params)
	
	operation := f.GetStringParam(params, "operation", "read")
	path := f.GetStringParam(params, "path", "")
	
	if path == "" {
		return f.CreateErrorResult("file path is required")
	}
	
	switch operation {
	case "read":
		return f.readFile(path)
	case "write":
		content := f.GetStringParam(params, "content", "")
		return f.writeFile(path, content)
	case "exists":
		return f.fileExists(path)
	case "delete":
		return f.deleteFile(path)
	case "copy":
		dest := f.GetStringParam(params, "destination", "")
		return f.copyFile(path, dest)
	case "move":
		dest := f.GetStringParam(params, "destination", "")
		return f.moveFile(path, dest)
	case "size":
		return f.fileSize(path)
	case "modified":
		return f.fileModified(path)
	default:
		return f.CreateErrorResult(fmt.Sprintf("unknown file operation: %s", operation))
	}
}

func (f *FileOperator) readFile(path string) OperatorResult {
	content, err := ioutil.ReadFile(path)
	if err != nil {
		return f.CreateErrorResult(fmt.Sprintf("failed to read file: %v", err))
	}
	return f.CreateSuccessResult(string(content))
}

func (f *FileOperator) writeFile(path, content string) OperatorResult {
	err := ioutil.WriteFile(path, []byte(content), 0644)
	if err != nil {
		return f.CreateErrorResult(fmt.Sprintf("failed to write file: %v", err))
	}
	return f.CreateSuccessResult(true)
}

func (f *FileOperator) fileExists(path string) OperatorResult {
	_, err := os.Stat(path)
	return f.CreateSuccessResult(err == nil)
}

func (f *FileOperator) deleteFile(path string) OperatorResult {
	err := os.Remove(path)
	if err != nil {
		return f.CreateErrorResult(fmt.Sprintf("failed to delete file: %v", err))
	}
	return f.CreateSuccessResult(true)
}

func (f *FileOperator) copyFile(src, dest string) OperatorResult {
	if dest == "" {
		return f.CreateErrorResult("destination path is required for copy operation")
	}
	
	input, err := ioutil.ReadFile(src)
	if err != nil {
		return f.CreateErrorResult(fmt.Sprintf("failed to read source file: %v", err))
	}
	
	err = ioutil.WriteFile(dest, input, 0644)
	if err != nil {
		return f.CreateErrorResult(fmt.Sprintf("failed to write destination file: %v", err))
	}
	
	return f.CreateSuccessResult(true)
}

func (f *FileOperator) moveFile(src, dest string) OperatorResult {
	if dest == "" {
		return f.CreateErrorResult("destination path is required for move operation")
	}
	
	err := os.Rename(src, dest)
	if err != nil {
		return f.CreateErrorResult(fmt.Sprintf("failed to move file: %v", err))
	}
	
	return f.CreateSuccessResult(true)
}

func (f *FileOperator) fileSize(path string) OperatorResult {
	info, err := os.Stat(path)
	if err != nil {
		return f.CreateErrorResult(fmt.Sprintf("failed to get file info: %v", err))
	}
	return f.CreateSuccessResult(info.Size())
}

func (f *FileOperator) fileModified(path string) OperatorResult {
	info, err := os.Stat(path)
	if err != nil {
		return f.CreateErrorResult(fmt.Sprintf("failed to get file info: %v", err))
	}
	return f.CreateSuccessResult(info.ModTime())
}

// JsonOperator handles @json operations
type JsonOperator struct {
	*BaseOperator
}

// NewJsonOperator creates a new JSON operator
func NewJsonOperator() *JsonOperator {
	return &JsonOperator{
		BaseOperator: NewBaseOperator(),
	}
}

// Execute handles @json operations
func (j *JsonOperator) Execute(ctx context.Context, params map[string]interface{}) OperatorResult {
	j.Log("Executing @json operator with params: %v", params)
	
	operation := j.GetStringParam(params, "operation", "encode")
	
	switch operation {
	case "encode":
		data := params["data"]
		return j.encode(data)
	case "decode":
		jsonStr := j.GetStringParam(params, "data", "")
		return j.decode(jsonStr)
	case "validate":
		jsonStr := j.GetStringParam(params, "data", "")
		return j.validate(jsonStr)
	case "merge":
		json1 := j.GetStringParam(params, "json1", "")
		json2 := j.GetStringParam(params, "json2", "")
		return j.merge(json1, json2)
	default:
		return j.CreateErrorResult(fmt.Sprintf("unknown JSON operation: %s", operation))
	}
}

func (j *JsonOperator) encode(data interface{}) OperatorResult {
	jsonBytes, err := json.Marshal(data)
	if err != nil {
		return j.CreateErrorResult(fmt.Sprintf("failed to encode JSON: %v", err))
	}
	return j.CreateSuccessResult(string(jsonBytes))
}

func (j *JsonOperator) decode(jsonStr string) OperatorResult {
	var result interface{}
	err := json.Unmarshal([]byte(jsonStr), &result)
	if err != nil {
		return j.CreateErrorResult(fmt.Sprintf("failed to decode JSON: %v", err))
	}
	return j.CreateSuccessResult(result)
}

func (j *JsonOperator) validate(jsonStr string) OperatorResult {
	var result interface{}
	err := json.Unmarshal([]byte(jsonStr), &result)
	return j.CreateSuccessResult(err == nil)
}

func (j *JsonOperator) merge(json1, json2 string) OperatorResult {
	var data1, data2 map[string]interface{}
	
	err := json.Unmarshal([]byte(json1), &data1)
	if err != nil {
		return j.CreateErrorResult(fmt.Sprintf("failed to parse first JSON: %v", err))
	}
	
	err = json.Unmarshal([]byte(json2), &data2)
	if err != nil {
		return j.CreateErrorResult(fmt.Sprintf("failed to parse second JSON: %v", err))
	}
	
	// Merge data2 into data1
	for key, value := range data2 {
		data1[key] = value
	}
	
	return j.CreateSuccessResult(data1)
}

// QueryOperator handles @query operations
type QueryOperator struct {
	*BaseOperator
}

// NewQueryOperator creates a new query operator
func NewQueryOperator() *QueryOperator {
	return &QueryOperator{
		BaseOperator: NewBaseOperator(),
	}
}

// Execute handles @query operations
func (q *QueryOperator) Execute(ctx context.Context, params map[string]interface{}) OperatorResult {
	q.Log("Executing @query operator with params: %v", params)
	
	query := q.GetStringParam(params, "query", "")
	if query == "" {
		return q.CreateErrorResult("query is required")
	}
	
	dbType := q.GetStringParam(params, "database", "sqlite")
	
	// Placeholder implementation - in a real implementation, this would use database drivers
	result := map[string]interface{}{
		"query":    query,
		"database": dbType,
		"result":   fmt.Sprintf("[Query executed: %s on %s]", query, dbType),
		"rows":     []map[string]interface{}{},
		"affected": 0,
	}
	
	return q.CreateSuccessResult(result)
}

// CacheOperator handles @cache operations
type CacheOperator struct {
	*BaseOperator
	cache map[string]cacheEntry
}

type cacheEntry struct {
	value      interface{}
	expiration time.Time
}

// NewCacheOperator creates a new cache operator
func NewCacheOperator() *CacheOperator {
	return &CacheOperator{
		BaseOperator: NewBaseOperator(),
		cache:        make(map[string]cacheEntry),
	}
}

// Execute handles @cache operations
func (c *CacheOperator) Execute(ctx context.Context, params map[string]interface{}) OperatorResult {
	c.Log("Executing @cache operator with params: %v", params)
	
	operation := c.GetStringParam(params, "operation", "get")
	key := c.GetStringParam(params, "key", "")
	
	if key == "" {
		return c.CreateErrorResult("cache key is required")
	}
	
	switch operation {
	case "get":
		return c.get(key)
	case "set":
		value := params["value"]
		ttl := c.GetIntParam(params, "ttl", 3600) // Default 1 hour
		return c.set(key, value, ttl)
	case "delete":
		return c.delete(key)
	case "clear":
		return c.clear()
	case "exists":
		return c.exists(key)
	default:
		return c.CreateErrorResult(fmt.Sprintf("unknown cache operation: %s", operation))
	}
}

func (c *CacheOperator) get(key string) OperatorResult {
	entry, exists := c.cache[key]
	if !exists {
		return c.CreateErrorResult(fmt.Sprintf("cache key '%s' not found", key))
	}
	
	if time.Now().After(entry.expiration) {
		delete(c.cache, key)
		return c.CreateErrorResult(fmt.Sprintf("cache key '%s' has expired", key))
	}
	
	return c.CreateSuccessResult(entry.value)
}

func (c *CacheOperator) set(key string, value interface{}, ttl int) OperatorResult {
	expiration := time.Now().Add(time.Duration(ttl) * time.Second)
	c.cache[key] = cacheEntry{
		value:      value,
		expiration: expiration,
	}
	return c.CreateSuccessResult(true)
}

func (c *CacheOperator) delete(key string) OperatorResult {
	delete(c.cache, key)
	return c.CreateSuccessResult(true)
}

func (c *CacheOperator) clear() OperatorResult {
	c.cache = make(map[string]cacheEntry)
	return c.CreateSuccessResult(true)
}

func (c *CacheOperator) exists(key string) OperatorResult {
	entry, exists := c.cache[key]
	if !exists {
		return c.CreateSuccessResult(false)
	}
	
	if time.Now().After(entry.expiration) {
		delete(c.cache, key)
		return c.CreateSuccessResult(false)
	}
	
	return c.CreateSuccessResult(true)
} 