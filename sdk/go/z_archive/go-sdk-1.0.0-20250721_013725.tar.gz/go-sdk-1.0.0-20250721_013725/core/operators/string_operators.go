package operators

import (
	"context"
	"crypto/md5"
	"crypto/sha1"
	"crypto/sha256"
	"crypto/sha512"
	"encoding/base64"
	"encoding/csv"
	"encoding/hex"
	"encoding/xml"
	"fmt"
	"gopkg.in/yaml.v3"
	"html/template"
	"io"
	"regexp"
	"strings"
	"text/template"
)

// StringOperator handles @string operations
type StringOperator struct {
	*BaseOperator
}

// NewStringOperator creates a new string operator
func NewStringOperator() *StringOperator {
	return &StringOperator{
		BaseOperator: NewBaseOperator(),
	}
}

// Execute handles @string operations
func (s *StringOperator) Execute(ctx context.Context, params map[string]interface{}) OperatorResult {
	s.Log("Executing @string operator with params: %v", params)
	
	operation := s.GetStringParam(params, "operation", "concat")
	input := s.GetStringParam(params, "input", "")
	
	switch operation {
	case "concat":
		separator := s.GetStringParam(params, "separator", "")
		values := s.GetArrayParam(params, "values", []interface{}{})
		return s.concat(values, separator)
	case "split":
		delimiter := s.GetStringParam(params, "delimiter", ",")
		return s.split(input, delimiter)
	case "replace":
		search := s.GetStringParam(params, "search", "")
		replace := s.GetStringParam(params, "replace", "")
		return s.replace(input, search, replace)
	case "trim":
		chars := s.GetStringParam(params, "chars", " \t\n\r")
		return s.trim(input, chars)
	case "upper":
		return s.upper(input)
	case "lower":
		return s.lower(input)
	case "capitalize":
		return s.capitalize(input)
	case "length":
		return s.length(input)
	case "substring":
		start := s.GetIntParam(params, "start", 0)
		length := s.GetIntParam(params, "length", -1)
		return s.substring(input, start, length)
	case "pad":
		length := s.GetIntParam(params, "length", 0)
		char := s.GetStringParam(params, "char", " ")
		side := s.GetStringParam(params, "side", "right")
		return s.pad(input, length, char, side)
	default:
		return s.CreateErrorResult(fmt.Sprintf("unknown string operation: %s", operation))
	}
}

func (s *StringOperator) concat(values []interface{}, separator string) OperatorResult {
	if len(values) == 0 {
		return s.CreateSuccessResult("")
	}
	
	strValues := make([]string, len(values))
	for i, v := range values {
		strValues[i] = fmt.Sprintf("%v", v)
	}
	
	result := strings.Join(strValues, separator)
	return s.CreateSuccessResult(result)
}

func (s *StringOperator) split(input, delimiter string) OperatorResult {
	if input == "" {
		return s.CreateSuccessResult([]string{})
	}
	
	parts := strings.Split(input, delimiter)
	return s.CreateSuccessResult(parts)
}

func (s *StringOperator) replace(input, search, replace string) OperatorResult {
	result := strings.ReplaceAll(input, search, replace)
	return s.CreateSuccessResult(result)
}

func (s *StringOperator) trim(input, chars string) OperatorResult {
	result := strings.Trim(input, chars)
	return s.CreateSuccessResult(result)
}

func (s *StringOperator) upper(input string) OperatorResult {
	result := strings.ToUpper(input)
	return s.CreateSuccessResult(result)
}

func (s *StringOperator) lower(input string) OperatorResult {
	result := strings.ToLower(input)
	return s.CreateSuccessResult(result)
}

func (s *StringOperator) capitalize(input string) OperatorResult {
	if input == "" {
		return s.CreateSuccessResult("")
	}
	
	result := strings.ToUpper(input[:1]) + strings.ToLower(input[1:])
	return s.CreateSuccessResult(result)
}

func (s *StringOperator) length(input string) OperatorResult {
	return s.CreateSuccessResult(len(input))
}

func (s *StringOperator) substring(input string, start, length int) OperatorResult {
	inputLen := len(input)
	
	if start < 0 {
		start = inputLen + start
	}
	if start < 0 {
		start = 0
	}
	if start >= inputLen {
		return s.CreateSuccessResult("")
	}
	
	end := inputLen
	if length > 0 && start+length < inputLen {
		end = start + length
	}
	
	result := input[start:end]
	return s.CreateSuccessResult(result)
}

func (s *StringOperator) pad(input string, length int, char, side string) OperatorResult {
	if len(char) == 0 {
		char = " "
	}
	
	currentLen := len(input)
	if currentLen >= length {
		return s.CreateSuccessResult(input)
	}
	
	padLen := length - currentLen
	padStr := strings.Repeat(char, padLen)
	
	var result string
	switch side {
	case "left":
		result = padStr + input
	case "right":
		result = input + padStr
	case "both":
		leftPad := padLen / 2
		rightPad := padLen - leftPad
		result = strings.Repeat(char, leftPad) + input + strings.Repeat(char, rightPad)
	default:
		result = input + padStr
	}
	
	return s.CreateSuccessResult(result)
}

// RegexOperator handles @regex operations
type RegexOperator struct {
	*BaseOperator
}

// NewRegexOperator creates a new regex operator
func NewRegexOperator() *RegexOperator {
	return &RegexOperator{
		BaseOperator: NewBaseOperator(),
	}
}

// Execute handles @regex operations
func (r *RegexOperator) Execute(ctx context.Context, params map[string]interface{}) OperatorResult {
	r.Log("Executing @regex operator with params: %v", params)
	
	operation := r.GetStringParam(params, "operation", "match")
	pattern := r.GetStringParam(params, "pattern", "")
	input := r.GetStringParam(params, "input", "")
	
	if pattern == "" {
		return r.CreateErrorResult("regex pattern is required")
	}
	
	regex, err := regexp.Compile(pattern)
	if err != nil {
		return r.CreateErrorResult(fmt.Sprintf("invalid regex pattern: %v", err))
	}
	
	switch operation {
	case "match":
		return r.match(regex, input)
	case "find":
		return r.find(regex, input)
	case "findAll":
		limit := r.GetIntParam(params, "limit", -1)
		return r.findAll(regex, input, limit)
	case "replace":
		replacement := r.GetStringParam(params, "replacement", "")
		return r.replace(regex, input, replacement)
	case "split":
		return r.split(regex, input)
	case "test":
		return r.test(regex, input)
	default:
		return r.CreateErrorResult(fmt.Sprintf("unknown regex operation: %s", operation))
	}
}

func (r *RegexOperator) match(regex *regexp.Regexp, input string) OperatorResult {
	matches := regex.FindStringSubmatch(input)
	if matches == nil {
		return r.CreateSuccessResult(nil)
	}
	
	result := make(map[string]string)
	for i, name := range regex.SubexpNames() {
		if i > 0 && name != "" {
			result[name] = matches[i]
		}
	}
	
	return r.CreateSuccessResult(result)
}

func (r *RegexOperator) find(regex *regexp.Regexp, input string) OperatorResult {
	match := regex.FindString(input)
	if match == "" {
		return r.CreateSuccessResult(nil)
	}
	
	return r.CreateSuccessResult(match)
}

func (r *RegexOperator) findAll(regex *regexp.Regexp, input string, limit int) OperatorResult {
	var matches []string
	if limit > 0 {
		matches = regex.FindAllString(input, limit)
	} else {
		matches = regex.FindAllString(input, -1)
	}
	
	return r.CreateSuccessResult(matches)
}

func (r *RegexOperator) replace(regex *regexp.Regexp, input, replacement string) OperatorResult {
	result := regex.ReplaceAllString(input, replacement)
	return r.CreateSuccessResult(result)
}

func (r *RegexOperator) split(regex *regexp.Regexp, input string) OperatorResult {
	parts := regex.Split(input, -1)
	return r.CreateSuccessResult(parts)
}

func (r *RegexOperator) test(regex *regexp.Regexp, input string) OperatorResult {
	result := regex.MatchString(input)
	return r.CreateSuccessResult(result)
}

// HashOperator handles @hash operations
type HashOperator struct {
	*BaseOperator
}

// NewHashOperator creates a new hash operator
func NewHashOperator() *HashOperator {
	return &HashOperator{
		BaseOperator: NewBaseOperator(),
	}
}

// Execute handles @hash operations
func (h *HashOperator) Execute(ctx context.Context, params map[string]interface{}) OperatorResult {
	h.Log("Executing @hash operator with params: %v", params)
	
	algorithm := h.GetStringParam(params, "algorithm", "md5")
	input := h.GetStringParam(params, "input", "")
	
	if input == "" {
		return h.CreateErrorResult("input is required")
	}
	
	switch algorithm {
	case "md5":
		return h.md5Hash(input)
	case "sha1":
		return h.sha1Hash(input)
	case "sha256":
		return h.sha256Hash(input)
	case "sha512":
		return h.sha512Hash(input)
	default:
		return h.CreateErrorResult(fmt.Sprintf("unsupported hash algorithm: %s", algorithm))
	}
}

func (h *HashOperator) md5Hash(input string) OperatorResult {
	hash := md5.Sum([]byte(input))
	result := hex.EncodeToString(hash[:])
	return h.CreateSuccessResult(result)
}

func (h *HashOperator) sha1Hash(input string) OperatorResult {
	hash := sha1.Sum([]byte(input))
	result := hex.EncodeToString(hash[:])
	return h.CreateSuccessResult(result)
}

func (h *HashOperator) sha256Hash(input string) OperatorResult {
	hash := sha256.Sum256([]byte(input))
	result := hex.EncodeToString(hash[:])
	return h.CreateSuccessResult(result)
}

func (h *HashOperator) sha512Hash(input string) OperatorResult {
	hash := sha512.Sum512([]byte(input))
	result := hex.EncodeToString(hash[:])
	return h.CreateSuccessResult(result)
}

// Base64Operator handles @base64 operations
type Base64Operator struct {
	*BaseOperator
}

// NewBase64Operator creates a new base64 operator
func NewBase64Operator() *Base64Operator {
	return &Base64Operator{
		BaseOperator: NewBaseOperator(),
	}
}

// Execute handles @base64 operations
func (b *Base64Operator) Execute(ctx context.Context, params map[string]interface{}) OperatorResult {
	b.Log("Executing @base64 operator with params: %v", params)
	
	operation := b.GetStringParam(params, "operation", "encode")
	input := b.GetStringParam(params, "input", "")
	
	if input == "" {
		return b.CreateErrorResult("input is required")
	}
	
	switch operation {
	case "encode":
		return b.encode(input)
	case "decode":
		return b.decode(input)
	default:
		return b.CreateErrorResult(fmt.Sprintf("unknown base64 operation: %s", operation))
	}
}

func (b *Base64Operator) encode(input string) OperatorResult {
	result := base64.StdEncoding.EncodeToString([]byte(input))
	return b.CreateSuccessResult(result)
}

func (b *Base64Operator) decode(input string) OperatorResult {
	decoded, err := base64.StdEncoding.DecodeString(input)
	if err != nil {
		return b.CreateErrorResult(fmt.Sprintf("invalid base64 string: %v", err))
	}
	
	result := string(decoded)
	return b.CreateSuccessResult(result)
}

// XmlOperator handles @xml operations
type XmlOperator struct {
	*BaseOperator
}

// NewXmlOperator creates a new XML operator
func NewXmlOperator() *XmlOperator {
	return &XmlOperator{
		BaseOperator: NewBaseOperator(),
	}
}

// Execute handles @xml operations
func (x *XmlOperator) Execute(ctx context.Context, params map[string]interface{}) OperatorResult {
	x.Log("Executing @xml operator with params: %v", params)
	
	operation := x.GetStringParam(params, "operation", "parse")
	input := x.GetStringParam(params, "input", "")
	
	if input == "" {
		return x.CreateErrorResult("input is required")
	}
	
	switch operation {
	case "parse":
		return x.parse(input)
	case "validate":
		return x.validate(input)
	case "extract":
		xpath := x.GetStringParam(params, "xpath", "")
		return x.extract(input, xpath)
	default:
		return x.CreateErrorResult(fmt.Sprintf("unknown XML operation: %s", operation))
	}
}

func (x *XmlOperator) parse(input string) OperatorResult {
	var result map[string]interface{}
	err := xml.Unmarshal([]byte(input), &result)
	if err != nil {
		return x.CreateErrorResult(fmt.Sprintf("failed to parse XML: %v", err))
	}
	
	return x.CreateSuccessResult(result)
}

func (x *XmlOperator) validate(input string) OperatorResult {
	var result map[string]interface{}
	err := xml.Unmarshal([]byte(input), &result)
	if err != nil {
		return x.CreateSuccessResult(false)
	}
	
	return x.CreateSuccessResult(true)
}

func (x *XmlOperator) extract(input, xpath string) OperatorResult {
	// Basic XML parsing for extraction (simplified)
	var result map[string]interface{}
	err := xml.Unmarshal([]byte(input), &result)
	if err != nil {
		return x.CreateErrorResult(fmt.Sprintf("failed to parse XML: %v", err))
	}
	
	// For now, return the parsed result
	// TODO: Implement proper XPath extraction
	return x.CreateSuccessResult(result)
}

// YamlOperator handles @yaml operations
type YamlOperator struct {
	*BaseOperator
}

// NewYamlOperator creates a new YAML operator
func NewYamlOperator() *YamlOperator {
	return &YamlOperator{
		BaseOperator: NewBaseOperator(),
	}
}

// Execute handles @yaml operations
func (y *YamlOperator) Execute(ctx context.Context, params map[string]interface{}) OperatorResult {
	y.Log("Executing @yaml operator with params: %v", params)
	
	operation := y.GetStringParam(params, "operation", "parse")
	input := y.GetStringParam(params, "input", "")
	
	if input == "" {
		return y.CreateErrorResult("input is required")
	}
	
	switch operation {
	case "parse":
		return y.parse(input)
	case "validate":
		return y.validate(input)
	case "stringify":
		data := params["data"]
		return y.stringify(data)
	default:
		return y.CreateErrorResult(fmt.Sprintf("unknown YAML operation: %s", operation))
	}
}

func (y *YamlOperator) parse(input string) OperatorResult {
	var result map[string]interface{}
	err := yaml.Unmarshal([]byte(input), &result)
	if err != nil {
		return y.CreateErrorResult(fmt.Sprintf("failed to parse YAML: %v", err))
	}
	
	return y.CreateSuccessResult(result)
}

func (y *YamlOperator) validate(input string) OperatorResult {
	var result map[string]interface{}
	err := yaml.Unmarshal([]byte(input), &result)
	if err != nil {
		return y.CreateSuccessResult(false)
	}
	
	return y.CreateSuccessResult(true)
}

func (y *YamlOperator) stringify(data interface{}) OperatorResult {
	result, err := yaml.Marshal(data)
	if err != nil {
		return y.CreateErrorResult(fmt.Sprintf("failed to stringify YAML: %v", err))
	}
	
	return y.CreateSuccessResult(string(result))
}

// CsvOperator handles @csv operations
type CsvOperator struct {
	*BaseOperator
}

// NewCsvOperator creates a new CSV operator
func NewCsvOperator() *CsvOperator {
	return &CsvOperator{
		BaseOperator: NewBaseOperator(),
	}
}

// Execute handles @csv operations
func (c *CsvOperator) Execute(ctx context.Context, params map[string]interface{}) OperatorResult {
	c.Log("Executing @csv operator with params: %v", params)
	
	operation := c.GetStringParam(params, "operation", "parse")
	input := c.GetStringParam(params, "input", "")
	
	if input == "" {
		return c.CreateErrorResult("input is required")
	}
	
	switch operation {
	case "parse":
		delimiter := c.GetStringParam(params, "delimiter", ",")
		return c.parse(input, delimiter)
	case "stringify":
		data := c.GetArrayParam(params, "data", []interface{}{})
		delimiter := c.GetStringParam(params, "delimiter", ",")
		return c.stringify(data, delimiter)
	default:
		return c.CreateErrorResult(fmt.Sprintf("unknown CSV operation: %s", operation))
	}
}

func (c *CsvOperator) parse(input, delimiter string) OperatorResult {
	reader := csv.NewReader(strings.NewReader(input))
	reader.Comma = rune(delimiter[0])
	
	records, err := reader.ReadAll()
	if err != nil {
		return c.CreateErrorResult(fmt.Sprintf("failed to parse CSV: %v", err))
	}
	
	return c.CreateSuccessResult(records)
}

func (c *CsvOperator) stringify(data []interface{}, delimiter string) OperatorResult {
	if len(data) == 0 {
		return c.CreateSuccessResult("")
	}
	
	var records [][]string
	for _, row := range data {
		if rowArray, ok := row.([]interface{}); ok {
			strRow := make([]string, len(rowArray))
			for i, cell := range rowArray {
				strRow[i] = fmt.Sprintf("%v", cell)
			}
			records = append(records, strRow)
		}
	}
	
	var result strings.Builder
	writer := csv.NewWriter(&result)
	writer.Comma = rune(delimiter[0])
	
	err := writer.WriteAll(records)
	if err != nil {
		return c.CreateErrorResult(fmt.Sprintf("failed to stringify CSV: %v", err))
	}
	
	return c.CreateSuccessResult(result.String())
}

// TemplateOperator handles @template operations
type TemplateOperator struct {
	*BaseOperator
}

// NewTemplateOperator creates a new template operator
func NewTemplateOperator() *TemplateOperator {
	return &TemplateOperator{
		BaseOperator: NewBaseOperator(),
	}
}

// Execute handles @template operations
func (t *TemplateOperator) Execute(ctx context.Context, params map[string]interface{}) OperatorResult {
	t.Log("Executing @template operator with params: %v", params)
	
	templateStr := t.GetStringParam(params, "template", "")
	data := params["data"]
	
	if templateStr == "" {
		return t.CreateErrorResult("template is required")
	}
	
	tmpl, err := template.New("template").Parse(templateStr)
	if err != nil {
		return t.CreateErrorResult(fmt.Sprintf("failed to parse template: %v", err))
	}
	
	var result strings.Builder
	err = tmpl.Execute(&result, data)
	if err != nil {
		return t.CreateErrorResult(fmt.Sprintf("failed to execute template: %v", err))
	}
	
	return t.CreateSuccessResult(result.String())
} 