package binary

import (
	"encoding/binary"
	"fmt"
	"io"
	"os"
	"time"
)

// BinaryWriter implements the Writer interface for .pnt files
type BinaryWriter struct {
	file   *os.File
	offset int64
	buffer []byte
}

// NewWriter creates a new binary writer for the given file
func NewWriter(filename string) (*BinaryWriter, error) {
	file, err := os.Create(filename)
	if err != nil {
		return nil, err
	}

	return &BinaryWriter{
		file:   file,
		offset: 0,
		buffer: make([]byte, 4096), // 4KB buffer
	}, nil
}

// WriteHeader writes the file header
func (w *BinaryWriter) WriteHeader(header *Header) error {
	// Set magic bytes
	copy(header.Magic[:], MagicHeader)
	
	// Set version
	header.Major = VersionMajor
	header.Minor = VersionMinor
	header.Patch = VersionPatch
	
	// Set data offset (64 bytes for header)
	header.DataOffset = 64
	
	// Calculate checksum (we'll update this after writing)
	header.Checksum = 0
	
	// Write header
	if err := binary.Write(w.file, binary.LittleEndian, header); err != nil {
		return &BinaryFormatError{
			Message: fmt.Sprintf("failed to write header: %v", err),
			Offset:  w.offset,
			Type:    "header_write",
		}
	}
	
	w.offset = 64
	return nil
}

// WriteValue writes a single value
func (w *BinaryWriter) WriteValue(value *Value) error {
	// Write type identifier
	if err := binary.Write(w.file, binary.LittleEndian, value.Type); err != nil {
		return &BinaryFormatError{
			Message: fmt.Sprintf("failed to write type identifier: %v", err),
			Offset:  w.offset,
			Type:    "type_write",
		}
	}
	w.offset++

	// Write value data based on type
	switch value.Type {
	case TypeNull:
		// No data to write
		value.Size = 0

	case TypeBool:
		var boolVal uint8
		if value.Data.(bool) {
			boolVal = 1
		}
		if err := binary.Write(w.file, binary.LittleEndian, boolVal); err != nil {
			return &BinaryFormatError{
				Message: fmt.Sprintf("failed to write bool value: %v", err),
				Offset:  w.offset,
				Type:    "bool_write",
			}
		}
		value.Size = 1
		w.offset++

	case TypeInt8:
		if err := binary.Write(w.file, binary.LittleEndian, value.Data.(int8)); err != nil {
			return &BinaryFormatError{
				Message: fmt.Sprintf("failed to write int8 value: %v", err),
				Offset:  w.offset,
				Type:    "int8_write",
			}
		}
		value.Size = 1
		w.offset++

	case TypeUint8:
		if err := binary.Write(w.file, binary.LittleEndian, value.Data.(uint8)); err != nil {
			return &BinaryFormatError{
				Message: fmt.Sprintf("failed to write uint8 value: %v", err),
				Offset:  w.offset,
				Type:    "uint8_write",
			}
		}
		value.Size = 1
		w.offset++

	case TypeInt16:
		if err := binary.Write(w.file, binary.LittleEndian, value.Data.(int16)); err != nil {
			return &BinaryFormatError{
				Message: fmt.Sprintf("failed to write int16 value: %v", err),
				Offset:  w.offset,
				Type:    "int16_write",
			}
		}
		value.Size = 2
		w.offset += 2

	case TypeUint16:
		if err := binary.Write(w.file, binary.LittleEndian, value.Data.(uint16)); err != nil {
			return &BinaryFormatError{
				Message: fmt.Sprintf("failed to write uint16 value: %v", err),
				Offset:  w.offset,
				Type:    "uint16_write",
			}
		}
		value.Size = 2
		w.offset += 2

	case TypeInt32:
		if err := binary.Write(w.file, binary.LittleEndian, value.Data.(int32)); err != nil {
			return &BinaryFormatError{
				Message: fmt.Sprintf("failed to write int32 value: %v", err),
				Offset:  w.offset,
				Type:    "int32_write",
			}
		}
		value.Size = 4
		w.offset += 4

	case TypeUint32:
		if err := binary.Write(w.file, binary.LittleEndian, value.Data.(uint32)); err != nil {
			return &BinaryFormatError{
				Message: fmt.Sprintf("failed to write uint32 value: %v", err),
				Offset:  w.offset,
				Type:    "uint32_write",
			}
		}
		value.Size = 4
		w.offset += 4

	case TypeInt64:
		if err := binary.Write(w.file, binary.LittleEndian, value.Data.(int64)); err != nil {
			return &BinaryFormatError{
				Message: fmt.Sprintf("failed to write int64 value: %v", err),
				Offset:  w.offset,
				Type:    "int64_write",
			}
		}
		value.Size = 8
		w.offset += 8

	case TypeUint64:
		if err := binary.Write(w.file, binary.LittleEndian, value.Data.(uint64)); err != nil {
			return &BinaryFormatError{
				Message: fmt.Sprintf("failed to write uint64 value: %v", err),
				Offset:  w.offset,
				Type:    "uint64_write",
			}
		}
		value.Size = 8
		w.offset += 8

	case TypeFloat32:
		if err := binary.Write(w.file, binary.LittleEndian, value.Data.(float32)); err != nil {
			return &BinaryFormatError{
				Message: fmt.Sprintf("failed to write float32 value: %v", err),
				Offset:  w.offset,
				Type:    "float32_write",
			}
		}
		value.Size = 4
		w.offset += 4

	case TypeFloat64:
		if err := binary.Write(w.file, binary.LittleEndian, value.Data.(float64)); err != nil {
			return &BinaryFormatError{
				Message: fmt.Sprintf("failed to write float64 value: %v", err),
				Offset:  w.offset,
				Type:    "float64_write",
			}
		}
		value.Size = 8
		w.offset += 8

	case TypeString:
		if err := w.WriteString(value.Data.(string)); err != nil {
			return err
		}
		value.Size = uint64(len(value.Data.(string)))

	case TypeBytes:
		if err := w.WriteBytes(value.Data.([]byte)); err != nil {
			return err
		}
		value.Size = uint64(len(value.Data.([]byte)))

	case TypeTimestamp:
		timestamp := value.Data.(time.Time)
		unixTime := uint64(timestamp.Unix())
		if err := binary.Write(w.file, binary.LittleEndian, unixTime); err != nil {
			return &BinaryFormatError{
				Message: fmt.Sprintf("failed to write timestamp value: %v", err),
				Offset:  w.offset,
				Type:    "timestamp_write",
			}
		}
		value.Size = 8
		w.offset += 8

	case TypeDuration:
		duration := value.Data.(time.Duration)
		nanoseconds := uint64(duration.Nanoseconds())
		if err := binary.Write(w.file, binary.LittleEndian, nanoseconds); err != nil {
			return &BinaryFormatError{
				Message: fmt.Sprintf("failed to write duration value: %v", err),
				Offset:  w.offset,
				Type:    "duration_write",
			}
		}
		value.Size = 8
		w.offset += 8

	case TypeArray:
		if err := w.WriteArray(value.Data.(*Array)); err != nil {
			return err
		}
		value.Size = value.Data.(*Array).Size

	case TypeObject:
		if err := w.WriteObject(value.Data.(*Object)); err != nil {
			return err
		}
		value.Size = value.Data.(*Object).Size

	case TypeReference:
		refOffset := value.Data.(uint64)
		if err := binary.Write(w.file, binary.LittleEndian, refOffset); err != nil {
			return &BinaryFormatError{
				Message: fmt.Sprintf("failed to write reference offset: %v", err),
				Offset:  w.offset,
				Type:    "reference_write",
			}
		}
		value.Size = 8
		w.offset += 8

	default:
		return &BinaryFormatError{
			Message: fmt.Sprintf("unknown type identifier: %d", value.Type),
			Offset:  w.offset,
			Type:    "unknown_type",
		}
	}

	return nil
}

// WriteString writes a string with length prefix
func (w *BinaryWriter) WriteString(str string) error {
	length := uint64(len(str))
	lengthBytes := encodeLength(length)
	
	if _, err := w.file.Write(lengthBytes); err != nil {
		return &BinaryFormatError{
			Message: fmt.Sprintf("failed to write string length: %v", err),
			Offset:  w.offset,
			Type:    "string_length_write",
		}
	}
	w.offset += int64(len(lengthBytes))

	if length > 0 {
		if _, err := w.file.Write([]byte(str)); err != nil {
			return &BinaryFormatError{
				Message: fmt.Sprintf("failed to write string data: %v", err),
				Offset:  w.offset,
				Type:    "string_data_write",
			}
		}
		w.offset += int64(length)
	}

	return nil
}

// WriteBytes writes a byte array with length prefix
func (w *BinaryWriter) WriteBytes(bytes []byte) error {
	length := uint64(len(bytes))
	lengthBytes := encodeLength(length)
	
	if _, err := w.file.Write(lengthBytes); err != nil {
		return &BinaryFormatError{
			Message: fmt.Sprintf("failed to write bytes length: %v", err),
			Offset:  w.offset,
			Type:    "bytes_length_write",
		}
	}
	w.offset += int64(len(lengthBytes))

	if length > 0 {
		if _, err := w.file.Write(bytes); err != nil {
			return &BinaryFormatError{
				Message: fmt.Sprintf("failed to write bytes data: %v", err),
				Offset:  w.offset,
				Type:    "bytes_data_write",
			}
		}
		w.offset += int64(length)
	}

	return nil
}

// WriteArray writes an array value
func (w *BinaryWriter) WriteArray(array *Array) error {
	length := uint64(len(array.Elements))
	lengthBytes := encodeLength(length)
	
	if _, err := w.file.Write(lengthBytes); err != nil {
		return &BinaryFormatError{
			Message: fmt.Sprintf("failed to write array length: %v", err),
			Offset:  w.offset,
			Type:    "array_length_write",
		}
	}
	w.offset += int64(len(lengthBytes))

	array.Offset = uint64(w.offset)

	// Write array elements
	for _, element := range array.Elements {
		if err := w.WriteValue(element); err != nil {
			return err
		}
	}

	// Calculate total size
	array.Size = uint64(w.offset) - array.Offset
	return nil
}

// WriteObject writes an object value
func (w *BinaryWriter) WriteObject(object *Object) error {
	length := uint64(len(object.Entries))
	lengthBytes := encodeLength(length)
	
	if _, err := w.file.Write(lengthBytes); err != nil {
		return &BinaryFormatError{
			Message: fmt.Sprintf("failed to write object length: %v", err),
			Offset:  w.offset,
			Type:    "object_length_write",
		}
	}
	w.offset += int64(len(lengthBytes))

	object.Offset = uint64(w.offset)

	// Write object entries
	for key, value := range object.Entries {
		// Write key
		if err := w.WriteString(key); err != nil {
			return err
		}

		// Write value
		if err := w.WriteValue(value); err != nil {
			return err
		}
	}

	// Calculate total size
	object.Size = uint64(w.offset) - object.Offset
	return nil
}

// WriteIndex writes the index table
func (w *BinaryWriter) WriteIndex(entries []*IndexEntry) error {
	// Write index length
	indexLength := uint16(len(entries))
	if err := binary.Write(w.file, binary.LittleEndian, indexLength); err != nil {
		return &BinaryFormatError{
			Message: fmt.Sprintf("failed to write index length: %v", err),
			Offset:  w.offset,
			Type:    "index_length_write",
		}
	}
	w.offset += 2

	// Write index entries
	for _, entry := range entries {
		// Write key length
		if err := binary.Write(w.file, binary.LittleEndian, entry.KeyLength); err != nil {
			return &BinaryFormatError{
				Message: fmt.Sprintf("failed to write index key length: %v", err),
				Offset:  w.offset,
				Type:    "index_key_length_write",
			}
		}
		w.offset += 2

		// Write key
		if _, err := w.file.Write([]byte(entry.Key)); err != nil {
			return &BinaryFormatError{
				Message: fmt.Sprintf("failed to write index key: %v", err),
				Offset:  w.offset,
				Type:    "index_key_write",
			}
		}
		w.offset += int64(entry.KeyLength)

		// Write value offset
		if err := binary.Write(w.file, binary.LittleEndian, entry.ValueOffset); err != nil {
			return &BinaryFormatError{
				Message: fmt.Sprintf("failed to write index value offset: %v", err),
				Offset:  w.offset,
				Type:    "index_value_offset_write",
			}
		}
		w.offset += 8

		// Write value type
		if err := binary.Write(w.file, binary.LittleEndian, entry.ValueType); err != nil {
			return &BinaryFormatError{
				Message: fmt.Sprintf("failed to write index value type: %v", err),
				Offset:  w.offset,
				Type:    "index_value_type_write",
			}
		}
		w.offset++

		// Write value size
		if err := binary.Write(w.file, binary.LittleEndian, entry.ValueSize); err != nil {
			return &BinaryFormatError{
				Message: fmt.Sprintf("failed to write index value size: %v", err),
				Offset:  w.offset,
				Type:    "index_value_size_write",
			}
		}
		w.offset += 4
	}

	return nil
}

// WriteFooter writes the file footer
func (w *BinaryWriter) WriteFooter(footer *Footer) error {
	// Set magic bytes
	copy(footer.Magic[:], MagicFooter)
	
	// Set file size
	footer.FileSize = uint32(w.offset + 16) // +16 for footer itself
	
	// Calculate checksum of entire file
	if err := w.Flush(); err != nil {
		return err
	}
	
	// Read entire file for checksum calculation
	w.file.Seek(0, io.SeekStart)
	fileData := make([]byte, w.offset)
	if _, err := io.ReadFull(w.file, fileData); err != nil {
		return &BinaryFormatError{
			Message: fmt.Sprintf("failed to read file for checksum: %v", err),
			Offset:  w.offset,
			Type:    "checksum_read",
		}
	}
	
	footer.Checksum = calculateCRC32(fileData)
	
	// Write footer
	if err := binary.Write(w.file, binary.LittleEndian, footer); err != nil {
		return &BinaryFormatError{
			Message: fmt.Sprintf("failed to write footer: %v", err),
			Offset:  w.offset,
			Type:    "footer_write",
		}
	}
	
	w.offset += 16
	return nil
}

// Flush writes any buffered data to the underlying file
func (w *BinaryWriter) Flush() error {
	return w.file.Sync()
}

// Close closes the underlying file
func (w *BinaryWriter) Close() error {
	return w.file.Close()
}

// UpdateHeaderChecksum updates the header checksum after data is written
func (w *BinaryWriter) UpdateHeaderChecksum() error {
	// Read header data (excluding checksum field)
	headerData := make([]byte, 28) // 0-27 bytes
	w.file.Seek(0, io.SeekStart)
	if _, err := io.ReadFull(w.file, headerData); err != nil {
		return &BinaryFormatError{
			Message: fmt.Sprintf("failed to read header for checksum update: %v", err),
			Offset:  0,
			Type:    "header_checksum_read",
		}
	}
	
	// Read reserved bytes (32-63)
	reservedData := make([]byte, 32)
	w.file.Seek(32, io.SeekStart)
	if _, err := io.ReadFull(w.file, reservedData); err != nil {
		return &BinaryFormatError{
			Message: fmt.Sprintf("failed to read reserved bytes for checksum: %v", err),
			Offset:  32,
			Type:    "reserved_checksum_read",
		}
	}
	
	// Combine data for checksum calculation
	checksumData := append(headerData, reservedData...)
	checksum := calculateCRC32(checksumData)
	
	// Write checksum to header
	w.file.Seek(28, io.SeekStart)
	if err := binary.Write(w.file, binary.LittleEndian, checksum); err != nil {
		return &BinaryFormatError{
			Message: fmt.Sprintf("failed to write header checksum: %v", err),
			Offset:  28,
			Type:    "header_checksum_write",
		}
	}
	
	return nil
} 