package binary

import (
	"encoding/binary"
	"fmt"
	"io"
	"time"
)

// Magic bytes for .pnt files
const (
	MagicHeader = "PNT\000"
	MagicFooter = "\000TNP"
)

// Version constants
const (
	VersionMajor = 1
	VersionMinor = 0
	VersionPatch = 0
)

// Feature flags
const (
	FlagCompressed = 1 << iota
	FlagEncrypted
	FlagIndexed
	FlagValidated
	FlagStreaming
)

// Type identifiers
const (
	TypeNull      = 0x00
	TypeBool      = 0x01
	TypeInt8      = 0x02
	TypeUint8     = 0x03
	TypeInt16     = 0x04
	TypeUint16    = 0x05
	TypeInt32     = 0x06
	TypeUint32    = 0x07
	TypeInt64     = 0x08
	TypeUint64    = 0x09
	TypeFloat32   = 0x0A
	TypeFloat64   = 0x0B
	TypeString    = 0x0C
	TypeBytes     = 0x0D
	TypeArray     = 0x0E
	TypeObject    = 0x0F
	TypeReference = 0x10
	TypeTimestamp = 0x11
	TypeDuration  = 0x12
	TypeDecimal   = 0x13
)

// Header represents the file header structure
type Header struct {
	Magic       [4]byte
	Major       uint8
	Minor       uint8
	Patch       uint8
	Flags       uint8
	DataOffset  uint64
	DataSize    uint64
	IndexOffset uint64
	IndexSize   uint64
	Checksum    uint32
	Reserved    [40]byte // 5 * 8 bytes
}

// Footer represents the file footer structure
type Footer struct {
	Magic    [4]byte
	FileSize uint32
	Checksum uint32
	Reserved [4]byte
}

// IndexEntry represents an entry in the index table
type IndexEntry struct {
	KeyLength  uint16
	Key        string
	ValueOffset uint64
	ValueType  uint8
	ValueSize  uint32
}

// Value represents a configuration value
type Value struct {
	Type  uint8
	Data  interface{}
	Size  uint64
	Offset uint64
}

// Object represents a configuration object
type Object struct {
	Entries map[string]*Value
	Size    uint64
	Offset  uint64
}

// Array represents a configuration array
type Array struct {
	Elements []*Value
	Size     uint64
	Offset   uint64
}

// Reader interface for reading binary format files
type Reader interface {
	ReadHeader() (*Header, error)
	ReadValue() (*Value, error)
	ReadObject() (*Object, error)
	ReadArray() (*Array, error)
	ReadString() (string, error)
	ReadBytes() ([]byte, error)
	ReadIndex() ([]*IndexEntry, error)
	ReadFooter() (*Footer, error)
	Seek(offset int64) error
	Close() error
}

// Writer interface for writing binary format files
type Writer interface {
	WriteHeader(*Header) error
	WriteValue(*Value) error
	WriteObject(*Object) error
	WriteArray(*Array) error
	WriteString(string) error
	WriteBytes([]byte) error
	WriteIndex([]*IndexEntry) error
	WriteFooter(*Footer) error
	Flush() error
	Close() error
}

// Validator interface for validating binary format files
type Validator interface {
	ValidateHeader(*Header) error
	ValidateValue(*Value) error
	ValidateObject(*Object) error
	ValidateArray(*Array) error
	ValidateChecksum([]byte, uint32) error
	ValidateFile(io.ReadSeeker) error
}

// Error types
type BinaryFormatError struct {
	Message string
	Offset  int64
	Type    string
}

func (e *BinaryFormatError) Error() string {
	return fmt.Sprintf("binary format error at offset %d (%s): %s", e.Offset, e.Type, e.Message)
}

// Utility functions
func encodeLength(length uint64) []byte {
	if length <= 127 {
		return []byte{uint8(length)}
	} else if length <= 16383 {
		return []byte{uint8(length>>8) | 0x80, uint8(length & 0xFF)}
	} else {
		result := make([]byte, 4)
		result[0] = 0xFF
		binary.LittleEndian.PutUint32(result[1:], uint32(length))
		return result
	}
}

func decodeLength(reader io.Reader) (uint64, error) {
	var first [1]byte
	if _, err := io.ReadFull(reader, first[:]); err != nil {
		return 0, err
	}

	if first[0] <= 127 {
		return uint64(first[0]), nil
	} else if first[0] <= 0xFF {
		var second [1]byte
		if _, err := io.ReadFull(reader, second[:]); err != nil {
			return 0, err
		}
		return uint64(first[0]&0x7F)<<8 | uint64(second[0]), nil
	} else {
		var length [3]byte
		if _, err := io.ReadFull(reader, length[:]); err != nil {
			return 0, err
		}
		return uint64(binary.LittleEndian.Uint32(append([]byte{0}, length[:]...))), nil
	}
}

// Type conversion helpers
func valueToBytes(v *Value) ([]byte, error) {
	switch v.Type {
	case TypeNull:
		return []byte{}, nil
	case TypeBool:
		if v.Data.(bool) {
			return []byte{1}, nil
		}
		return []byte{0}, nil
	case TypeInt8:
		return []byte{uint8(v.Data.(int8))}, nil
	case TypeUint8:
		return []byte{v.Data.(uint8)}, nil
	case TypeInt16:
		result := make([]byte, 2)
		binary.LittleEndian.PutUint16(result, uint16(v.Data.(int16)))
		return result, nil
	case TypeUint16:
		result := make([]byte, 2)
		binary.LittleEndian.PutUint16(result, v.Data.(uint16))
		return result, nil
	case TypeInt32:
		result := make([]byte, 4)
		binary.LittleEndian.PutUint32(result, uint32(v.Data.(int32)))
		return result, nil
	case TypeUint32:
		result := make([]byte, 4)
		binary.LittleEndian.PutUint32(result, v.Data.(uint32))
		return result, nil
	case TypeInt64:
		result := make([]byte, 8)
		binary.LittleEndian.PutUint64(result, uint64(v.Data.(int64)))
		return result, nil
	case TypeUint64:
		result := make([]byte, 8)
		binary.LittleEndian.PutUint64(result, v.Data.(uint64))
		return result, nil
	case TypeFloat32:
		result := make([]byte, 4)
		binary.LittleEndian.PutUint32(result, uint32(v.Data.(float32)))
		return result, nil
	case TypeFloat64:
		result := make([]byte, 8)
		binary.LittleEndian.PutUint64(result, uint64(v.Data.(float64)))
		return result, nil
	case TypeString:
		str := v.Data.(string)
		length := encodeLength(uint64(len(str)))
		return append(length, []byte(str)...), nil
	case TypeBytes:
		bytes := v.Data.([]byte)
		length := encodeLength(uint64(len(bytes)))
		return append(length, bytes...), nil
	case TypeTimestamp:
		timestamp := v.Data.(time.Time)
		result := make([]byte, 8)
		binary.LittleEndian.PutUint64(result, uint64(timestamp.Unix()))
		return result, nil
	case TypeDuration:
		duration := v.Data.(time.Duration)
		result := make([]byte, 8)
		binary.LittleEndian.PutUint64(result, uint64(duration.Nanoseconds()))
		return result, nil
	default:
		return nil, fmt.Errorf("unsupported type: %d", v.Type)
	}
}

// CRC32 calculation
func calculateCRC32(data []byte) uint32 {
	// Simple CRC32 implementation - in production, use a proper library
	var crc uint32 = 0xFFFFFFFF
	for _, b := range data {
		crc ^= uint32(b)
		for i := 0; i < 8; i++ {
			if crc&1 != 0 {
				crc = (crc >> 1) ^ 0xEDB88320
			} else {
				crc >>= 1
			}
		}
	}
	return ^crc
} 