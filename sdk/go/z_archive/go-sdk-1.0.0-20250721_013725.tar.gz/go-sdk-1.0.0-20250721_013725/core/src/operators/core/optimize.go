package core

import (
	"fmt"
	"math"
	"sort"
	"sync"
	"time"
)

// OptimizationResult represents an optimization result
type OptimizationResult struct {
	Metric     string      `json:"metric"`
	Value      float64     `json:"value"`
	Parameters map[string]interface{} `json:"parameters"`
	Timestamp  time.Time   `json:"timestamp"`
	Duration   time.Duration `json:"duration"`
}

// OptimizeOperator handles @optimize operations
type OptimizeOperator struct {
	results map[string][]OptimizationResult
	mutex   sync.RWMutex
}

// NewOptimizeOperator creates a new optimization operator
func NewOptimizeOperator() *OptimizeOperator {
	return &OptimizeOperator{
		results: make(map[string][]OptimizationResult),
	}
}

// Execute handles @optimize operations
func (o *OptimizeOperator) Execute(params string) interface{} {
	// Parse parameters (format: "action,metric,parameters")
	// Example: @optimize("minimize", "response_time", '{"threads": [1,2,4,8]}')
	
	if params == "" {
		return fmt.Sprintf("@optimize(%s)", params)
	}
	
	// Remove quotes if present
	cleanParams := params
	if len(cleanParams) >= 2 && (cleanParams[0] == '"' || cleanParams[0] == '\'') {
		cleanParams = cleanParams[1 : len(cleanParams)-1]
	}
	
	parts := splitParams(cleanParams)
	if len(parts) == 0 {
		return fmt.Sprintf("@optimize(%s) - Invalid parameters", params)
	}
	
	action := parts[0]
	
	switch action {
	case "minimize":
		if len(parts) < 2 {
			return fmt.Sprintf("@optimize(%s) - Missing metric for minimize", params)
		}
		return o.Minimize(parts[1])
	case "maximize":
		if len(parts) < 2 {
			return fmt.Sprintf("@optimize(%s) - Missing metric for maximize", params)
		}
		return o.Maximize(parts[1])
	case "best":
		if len(parts) < 2 {
			return fmt.Sprintf("@optimize(%s) - Missing metric for best", params)
		}
		return o.GetBestResult(parts[1])
	case "history":
		if len(parts) < 2 {
			return fmt.Sprintf("@optimize(%s) - Missing metric for history", params)
		}
		return o.GetHistory(parts[1])
	case "clear":
		return o.ClearResults()
	default:
		return fmt.Sprintf("@optimize(%s) - Unknown action: %s", params, action)
	}
}

// AddResult adds an optimization result
func (o *OptimizeOperator) AddResult(metric string, value float64, parameters map[string]interface{}) {
	o.mutex.Lock()
	defer o.mutex.Unlock()
	
	result := OptimizationResult{
		Metric:     metric,
		Value:      value,
		Parameters: parameters,
		Timestamp:  time.Now(),
	}
	
	o.results[metric] = append(o.results[metric], result)
}

// Minimize finds the minimum value for a metric
func (o *OptimizeOperator) Minimize(metric string) interface{} {
	o.mutex.RLock()
	defer o.mutex.RUnlock()
	
	results, exists := o.results[metric]
	if !exists || len(results) == 0 {
		return fmt.Sprintf("No results found for metric: %s", metric)
	}
	
	minResult := results[0]
	minValue := minResult.Value
	
	for _, result := range results {
		if result.Value < minValue {
			minValue = result.Value
			minResult = result
		}
	}
	
	return map[string]interface{}{
		"metric":     metric,
		"min_value":  minValue,
		"parameters": minResult.Parameters,
		"timestamp":  minResult.Timestamp,
	}
}

// Maximize finds the maximum value for a metric
func (o *OptimizeOperator) Maximize(metric string) interface{} {
	o.mutex.RLock()
	defer o.mutex.RUnlock()
	
	results, exists := o.results[metric]
	if !exists || len(results) == 0 {
		return fmt.Sprintf("No results found for metric: %s", metric)
	}
	
	maxResult := results[0]
	maxValue := maxResult.Value
	
	for _, result := range results {
		if result.Value > maxValue {
			maxValue = result.Value
			maxResult = result
		}
	}
	
	return map[string]interface{}{
		"metric":     metric,
		"max_value":  maxValue,
		"parameters": maxResult.Parameters,
		"timestamp":  maxResult.Timestamp,
	}
}

// GetBestResult gets the best result for a metric (minimum for most metrics)
func (o *OptimizeOperator) GetBestResult(metric string) interface{} {
	o.mutex.RLock()
	defer o.mutex.RUnlock()
	
	results, exists := o.results[metric]
	if !exists || len(results) == 0 {
		return fmt.Sprintf("No results found for metric: %s", metric)
	}
	
	// Sort by value (ascending for most metrics)
	sort.Slice(results, func(i, j int) bool {
		return results[i].Value < results[j].Value
	})
	
	best := results[0]
	
	return map[string]interface{}{
		"metric":     metric,
		"best_value": best.Value,
		"parameters": best.Parameters,
		"timestamp":  best.Timestamp,
		"rank":       1,
	}
}

// GetHistory returns optimization history for a metric
func (o *OptimizeOperator) GetHistory(metric string) interface{} {
	o.mutex.RLock()
	defer o.mutex.RUnlock()
	
	results, exists := o.results[metric]
	if !exists {
		return []OptimizationResult{}
	}
	
	// Sort by timestamp (newest first)
	sort.Slice(results, func(i, j int) bool {
		return results[i].Timestamp.After(results[j].Timestamp)
	})
	
	return results
}

// ClearResults removes all optimization results
func (o *OptimizeOperator) ClearResults() interface{} {
	o.mutex.Lock()
	defer o.mutex.Unlock()
	
	count := 0
	for _, results := range o.results {
		count += len(results)
	}
	
	o.results = make(map[string][]OptimizationResult)
	
	return fmt.Sprintf("Cleared %d optimization results", count)
}

// GetStats returns optimization statistics
func (o *OptimizeOperator) GetStats(metric string) map[string]interface{} {
	o.mutex.RLock()
	defer o.mutex.RUnlock()
	
	results, exists := o.results[metric]
	if !exists || len(results) == 0 {
		return map[string]interface{}{
			"metric": metric,
			"count":  0,
		}
	}
	
	var sum, min, max float64
	min = math.MaxFloat64
	max = -math.MaxFloat64
	
	for _, result := range results {
		sum += result.Value
		if result.Value < min {
			min = result.Value
		}
		if result.Value > max {
			max = result.Value
		}
	}
	
	count := len(results)
	avg := sum / float64(count)
	
	// Calculate standard deviation
	var variance float64
	for _, result := range results {
		diff := result.Value - avg
		variance += diff * diff
	}
	variance /= float64(count)
	stdDev := math.Sqrt(variance)
	
	return map[string]interface{}{
		"metric":        metric,
		"count":         count,
		"min":           min,
		"max":           max,
		"average":       avg,
		"std_deviation": stdDev,
		"range":         max - min,
	}
}

// GetTrends analyzes optimization trends
func (o *OptimizeOperator) GetTrends(metric string) map[string]interface{} {
	o.mutex.RLock()
	defer o.mutex.RUnlock()
	
	results, exists := o.results[metric]
	if !exists || len(results) < 2 {
		return map[string]interface{}{
			"metric": metric,
			"trend":  "insufficient_data",
		}
	}
	
	// Sort by timestamp
	sort.Slice(results, func(i, j int) bool {
		return results[i].Timestamp.Before(results[j].Timestamp)
	})
	
	// Calculate trend
	firstValue := results[0].Value
	lastValue := results[len(results)-1].Value
	trend := "stable"
	
	if lastValue < firstValue {
		trend = "improving"
	} else if lastValue > firstValue {
		trend = "worsening"
	}
	
	// Calculate improvement percentage
	improvement := ((firstValue - lastValue) / firstValue) * 100
	
	return map[string]interface{}{
		"metric":      metric,
		"trend":       trend,
		"first_value": firstValue,
		"last_value":  lastValue,
		"improvement": improvement,
		"data_points": len(results),
	}
}

// GetParameterAnalysis analyzes parameter effectiveness
func (o *OptimizeOperator) GetParameterAnalysis(metric, parameter string) map[string]interface{} {
	o.mutex.RLock()
	defer o.mutex.RUnlock()
	
	results, exists := o.results[metric]
	if !exists || len(results) == 0 {
		return map[string]interface{}{
			"metric":    metric,
			"parameter": parameter,
			"error":     "no_data",
		}
	}
	
	// Group by parameter value
	paramGroups := make(map[interface{}][]float64)
	for _, result := range results {
		if paramValue, exists := result.Parameters[parameter]; exists {
			paramGroups[paramValue] = append(paramGroups[paramValue], result.Value)
		}
	}
	
	if len(paramGroups) == 0 {
		return map[string]interface{}{
			"metric":    metric,
			"parameter": parameter,
			"error":     "parameter_not_found",
		}
	}
	
	// Calculate statistics for each parameter value
	analysis := make(map[interface{}]map[string]interface{})
	for paramValue, values := range paramGroups {
		var sum, min, max float64
		min = math.MaxFloat64
		max = -math.MaxFloat64
		
		for _, value := range values {
			sum += value
			if value < min {
				min = value
			}
			if value > max {
				max = value
			}
		}
		
		count := len(values)
		avg := sum / float64(count)
		
		analysis[paramValue] = map[string]interface{}{
			"count":   count,
			"average": avg,
			"min":     min,
			"max":     max,
			"range":   max - min,
		}
	}
	
	return map[string]interface{}{
		"metric":    metric,
		"parameter": parameter,
		"analysis":  analysis,
	}
}

 