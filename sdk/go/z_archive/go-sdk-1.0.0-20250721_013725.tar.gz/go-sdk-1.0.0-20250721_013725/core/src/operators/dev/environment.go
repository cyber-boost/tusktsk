package dev

import (
	"context"
	"encoding/json"
	"fmt"
	"io/fs"
	"log"
	"net/http"
	"os"
	"path/filepath"
	"runtime"
	"runtime/pprof"
	"strings"
	"sync"
	"time"

	"github.com/fsnotify/fsnotify"
	"github.com/gorilla/websocket"
	"github.com/shirou/gopsutil/v3/cpu"
	"github.com/shirou/gopsutil/v3/mem"
)

// DevEnvironment handles development environment with live reload
type DevEnvironment struct {
	watcher         *fsnotify.Watcher
	config          *DevConfig
	server          *http.Server
	websocketConns  map[*websocket.Conn]bool
	debugger        *Debugger
	profiler        *Profiler
	collaboration   *Collaboration
	mutex           sync.RWMutex
	isRunning       bool
	fileCache       map[string]time.Time
	reloadCallbacks map[string][]func(string)
}

// DevConfig holds development environment configuration
type DevConfig struct {
	Port              int      `json:"port"`
	WatchPaths        []string `json:"watch_paths"`
	IgnorePatterns    []string `json:"ignore_patterns"`
	LiveReloadEnabled bool     `json:"live_reload_enabled"`
	DebugEnabled      bool     `json:"debug_enabled"`
	ProfilingEnabled  bool     `json:"profiling_enabled"`
	CollaborationEnabled bool  `json:"collaboration_enabled"`
	MaxFileSize       int64    `json:"max_file_size"`
	ReloadDelay       time.Duration `json:"reload_delay"`
	WebSocketPath     string   `json:"websocket_path"`
	StaticDir         string   `json:"static_dir"`
}

// Debugger handles debugging operations
type Debugger struct {
	breakpoints map[string][]int
	variables   map[string]interface{}
	callStack   []string
	isActive    bool
	mutex       sync.RWMutex
}

// Profiler handles performance profiling
type Profiler struct {
	cpuProfile    *os.File
	memProfile    *os.File
	flameGraph    *os.File
	isProfiling   bool
	startTime     time.Time
	metrics       map[string]float64
	mutex         sync.RWMutex
}

// Collaboration handles real-time collaboration
type Collaboration struct {
	clients       map[string]*CollaborationClient
	documents     map[string]*CollaborationDocument
	broadcastChan chan CollaborationMessage
	mutex         sync.RWMutex
}

// CollaborationClient represents a collaboration client
type CollaborationClient struct {
	ID       string          `json:"id"`
	Name     string          `json:"name"`
	Conn     *websocket.Conn `json:"-"`
	Color    string          `json:"color"`
	Position int             `json:"position"`
}

// CollaborationDocument represents a shared document
type CollaborationDocument struct {
	ID      string                     `json:"id"`
	Name    string                     `json:"name"`
	Content string                     `json:"content"`
	Cursors map[string]CollaborationCursor `json:"cursors"`
	History []CollaborationChange      `json:"history"`
	mutex   sync.RWMutex
}

// CollaborationCursor represents a cursor position
type CollaborationCursor struct {
	Line   int    `json:"line"`
	Column int    `json:"column"`
	Client string `json:"client"`
}

// CollaborationChange represents a document change
type CollaborationChange struct {
	Type      string    `json:"type"`
	Position  int       `json:"position"`
	Text      string    `json:"text"`
	ClientID  string    `json:"client_id"`
	Timestamp time.Time `json:"timestamp"`
}

// CollaborationMessage represents a collaboration message
type CollaborationMessage struct {
	Type     string      `json:"type"`
	ClientID string      `json:"client_id"`
	Document string      `json:"document"`
	Data     interface{} `json:"data"`
}

// DefaultDevConfig returns default development configuration
func DefaultDevConfig() *DevConfig {
	return &DevConfig{
		Port:              3000,
		WatchPaths:        []string{"./src", "./config"},
		IgnorePatterns:    []string{"*.tmp", "*.log", ".git/*", "node_modules/*"},
		LiveReloadEnabled: true,
		DebugEnabled:      true,
		ProfilingEnabled:  false,
		CollaborationEnabled: true,
		MaxFileSize:       10 * 1024 * 1024, // 10MB
		ReloadDelay:       500 * time.Millisecond,
		WebSocketPath:     "/ws",
		StaticDir:         "./public",
	}
}

// NewDevEnvironment creates a new development environment
func NewDevEnvironment(config *DevConfig) (*DevEnvironment, error) {
	if config == nil {
		config = DefaultDevConfig()
	}

	// Create file watcher
	watcher, err := fsnotify.NewWatcher()
	if err != nil {
		return nil, fmt.Errorf("failed to create file watcher: %v", err)
	}

	env := &DevEnvironment{
		watcher:         watcher,
		config:          config,
		websocketConns:  make(map[*websocket.Conn]bool),
		fileCache:       make(map[string]time.Time),
		reloadCallbacks: make(map[string][]func(string)),
	}

	// Initialize components
	env.debugger = &Debugger{
		breakpoints: make(map[string][]int),
		variables:   make(map[string]interface{}),
		callStack:   []string{},
	}

	env.profiler = &Profiler{
		metrics: make(map[string]float64),
	}

	env.collaboration = &Collaboration{
		clients:       make(map[string]*CollaborationClient),
		documents:     make(map[string]*CollaborationDocument),
		broadcastChan: make(chan CollaborationMessage, 100),
	}

	// Setup file watching
	if err := env.setupFileWatching(); err != nil {
		return nil, fmt.Errorf("failed to setup file watching: %v", err)
	}

	// Setup HTTP server
	if err := env.setupHTTPServer(); err != nil {
		return nil, fmt.Errorf("failed to setup HTTP server: %v", err)
	}

	log.Printf("DEV ENVIRONMENT INITIALIZED: port=%d, watch_paths=%d", config.Port, len(config.WatchPaths))
	return env, nil
}

// setupFileWatching sets up file watching for live reload
func (d *DevEnvironment) setupFileWatching() error {
	for _, path := range d.config.WatchPaths {
		if err := d.watchDirectory(path); err != nil {
			log.Printf("DEV WATCH ERROR: path=%s, error=%v", path, err)
			continue
		}
	}

	// Start file watching goroutine
	go d.handleFileEvents()

	return nil
}

// watchDirectory recursively watches a directory
func (d *DevEnvironment) watchDirectory(path string) error {
	return filepath.WalkDir(path, func(path string, d fs.DirEntry, err error) error {
		if err != nil {
			return err
		}

		// Skip ignored patterns
		for _, pattern := range d.config.IgnorePatterns {
			if strings.Contains(path, pattern) {
				return nil
			}
		}

		if d.IsDir() {
			return d.watcher.Add(path)
		}

		return nil
	})
}

// handleFileEvents handles file system events
func (d *DevEnvironment) handleFileEvents() {
	for {
		select {
		case event, ok := <-d.watcher.Events:
			if !ok {
				return
			}

			if event.Has(fsnotify.Write) || event.Has(fsnotify.Create) || event.Has(fsnotify.Remove) {
				d.handleFileChange(event.Name, event.Op)
			}

		case err, ok := <-d.watcher.Errors:
			if !ok {
				return
			}
			log.Printf("DEV WATCH ERROR: %v", err)
		}
	}
}

// handleFileChange handles file changes for live reload
func (d *DevEnvironment) handleFileChange(filename string, op fsnotify.Op) {
	// Check if file should be ignored
	for _, pattern := range d.config.IgnorePatterns {
		if strings.Contains(filename, pattern) {
			return
		}
	}

	// Check file size
	info, err := os.Stat(filename)
	if err == nil && info.Size() > d.config.MaxFileSize {
		log.Printf("DEV FILE TOO LARGE: %s (%d bytes)", filename, info.Size())
		return
	}

	// Debounce file changes
	now := time.Now()
	if lastChange, exists := d.fileCache[filename]; exists {
		if now.Sub(lastChange) < d.config.ReloadDelay {
			return
		}
	}
	d.fileCache[filename] = now

	log.Printf("DEV FILE CHANGE: %s %v", filename, op)

	// Trigger reload callbacks
	d.mutex.RLock()
	callbacks := d.reloadCallbacks[filepath.Ext(filename)]
	d.mutex.RUnlock()

	for _, callback := range callbacks {
		go callback(filename)
	}

	// Broadcast to WebSocket clients
	if d.config.LiveReloadEnabled {
		d.broadcastReload(filename, op.String())
	}
}

// setupHTTPServer sets up the development HTTP server
func (d *DevEnvironment) setupHTTPServer() error {
	mux := http.NewServeMux()

	// Static file serving
	if d.config.StaticDir != "" {
		mux.Handle("/", http.FileServer(http.Dir(d.config.StaticDir)))
	}

	// WebSocket endpoint for live reload
	if d.config.LiveReloadEnabled {
		mux.HandleFunc(d.config.WebSocketPath, d.handleWebSocket)
	}

	// Development API endpoints
	mux.HandleFunc("/api/status", d.handleStatus)
	mux.HandleFunc("/api/debug", d.handleDebug)
	mux.HandleFunc("/api/profile", d.handleProfile)
	mux.HandleFunc("/api/collaboration", d.handleCollaboration)

	d.server = &http.Server{
		Addr:    fmt.Sprintf(":%d", d.config.Port),
		Handler: mux,
	}

	return nil
}

// handleWebSocket handles WebSocket connections for live reload
func (d *DevEnvironment) handleWebSocket(w http.ResponseWriter, r *http.Request) {
	upgrader := websocket.Upgrader{
		CheckOrigin: func(r *http.Request) bool {
			return true // Allow all origins in development
		},
	}

	conn, err := upgrader.Upgrade(w, r, nil)
	if err != nil {
		log.Printf("DEV WEBSOCKET ERROR: %v", err)
		return
	}

	d.mutex.Lock()
	d.websocketConns[conn] = true
	d.mutex.Unlock()

	log.Printf("DEV WEBSOCKET CONNECTED: %s", conn.RemoteAddr())

	// Handle WebSocket messages
	go d.handleWebSocketMessages(conn)
}

// handleWebSocketMessages handles WebSocket messages
func (d *DevEnvironment) handleWebSocketMessages(conn *websocket.Conn) {
	defer func() {
		d.mutex.Lock()
		delete(d.websocketConns, conn)
		d.mutex.Unlock()
		conn.Close()
	}()

	for {
		_, message, err := conn.ReadMessage()
		if err != nil {
			log.Printf("DEV WEBSOCKET READ ERROR: %v", err)
			break
		}

		// Handle collaboration messages
		if d.config.CollaborationEnabled {
			var msg CollaborationMessage
			if err := json.Unmarshal(message, &msg); err == nil {
				d.handleCollaborationMessage(conn, msg)
			}
		}
	}
}

// broadcastReload broadcasts reload events to WebSocket clients
func (d *DevEnvironment) broadcastReload(filename, operation string) {
	message := map[string]interface{}{
		"type":      "reload",
		"file":      filename,
		"operation": operation,
		"timestamp": time.Now().Unix(),
	}

	data, err := json.Marshal(message)
	if err != nil {
		log.Printf("DEV BROADCAST ERROR: %v", err)
		return
	}

	d.mutex.RLock()
	for conn := range d.websocketConns {
		if err := conn.WriteMessage(websocket.TextMessage, data); err != nil {
			log.Printf("DEV WEBSOCKET WRITE ERROR: %v", err)
		}
	}
	d.mutex.RUnlock()
}

// handleStatus handles status API requests
func (d *DevEnvironment) handleStatus(w http.ResponseWriter, r *http.Request) {
	status := map[string]interface{}{
		"running":           d.isRunning,
		"port":             d.config.Port,
		"watch_paths":      d.config.WatchPaths,
		"websocket_clients": len(d.websocketConns),
		"uptime":           time.Since(d.startTime).String(),
	}

	// Add system metrics
	if cpuPercent, err := cpu.Percent(0, false); err == nil && len(cpuPercent) > 0 {
		status["cpu_usage"] = cpuPercent[0]
	}

	if memInfo, err := mem.VirtualMemory(); err == nil {
		status["memory_usage"] = memInfo.UsedPercent
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(status)
}

// handleDebug handles debug API requests
func (d *DevEnvironment) handleDebug(w http.ResponseWriter, r *http.Request) {
	if !d.config.DebugEnabled {
		http.Error(w, "Debug mode disabled", http.StatusForbidden)
		return
	}

	switch r.Method {
	case "GET":
		// Get debug information
		debugInfo := map[string]interface{}{
			"breakpoints": d.debugger.breakpoints,
			"variables":   d.debugger.variables,
			"call_stack":  d.debugger.callStack,
			"active":      d.debugger.isActive,
		}
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(debugInfo)

	case "POST":
		// Set breakpoint
		var req map[string]interface{}
		if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
			http.Error(w, "Invalid request", http.StatusBadRequest)
			return
		}

		if file, ok := req["file"].(string); ok {
			if line, ok := req["line"].(float64); ok {
				d.debugger.SetBreakpoint(file, int(line))
				w.WriteHeader(http.StatusOK)
				return
			}
		}

		http.Error(w, "Invalid breakpoint", http.StatusBadRequest)
	}
}

// handleProfile handles profiling API requests
func (d *DevEnvironment) handleProfile(w http.ResponseWriter, r *http.Request) {
	if !d.config.ProfilingEnabled {
		http.Error(w, "Profiling disabled", http.StatusForbidden)
		return
	}

	switch r.Method {
	case "POST":
		// Start profiling
		if err := d.profiler.StartProfiling(); err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}
		w.WriteHeader(http.StatusOK)

	case "DELETE":
		// Stop profiling
		profileData := d.profiler.StopProfiling()
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(profileData)
	}
}

// handleCollaboration handles collaboration API requests
func (d *DevEnvironment) handleCollaboration(w http.ResponseWriter, r *http.Request) {
	if !d.config.CollaborationEnabled {
		http.Error(w, "Collaboration disabled", http.StatusForbidden)
		return
	}

	switch r.Method {
	case "GET":
		// Get collaboration status
		status := map[string]interface{}{
			"clients":   len(d.collaboration.clients),
			"documents": len(d.collaboration.documents),
		}
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(status)
	}
}

// handleCollaborationMessage handles collaboration messages
func (d *DevEnvironment) handleCollaborationMessage(conn *websocket.Conn, msg CollaborationMessage) {
	switch msg.Type {
	case "join":
		// Client joining
		client := &CollaborationClient{
			ID:   msg.ClientID,
			Name: fmt.Sprintf("User %s", msg.ClientID[:8]),
			Conn: conn,
			Color: fmt.Sprintf("#%06x", time.Now().UnixNano()%0xFFFFFF),
		}
		d.collaboration.mutex.Lock()
		d.collaboration.clients[msg.ClientID] = client
		d.collaboration.mutex.Unlock()

		// Broadcast join
		d.broadcastCollaborationMessage(CollaborationMessage{
			Type:     "client_joined",
			ClientID: msg.ClientID,
			Data:     client,
		})

	case "document_change":
		// Document change
		if docID, ok := msg.Document.(string); ok {
			if doc, exists := d.collaboration.documents[docID]; exists {
				doc.mutex.Lock()
				// Apply change
				doc.mutex.Unlock()

				// Broadcast change
				d.broadcastCollaborationMessage(msg)
			}
		}
	}
}

// broadcastCollaborationMessage broadcasts collaboration messages
func (d *DevEnvironment) broadcastCollaborationMessage(msg CollaborationMessage) {
	data, err := json.Marshal(msg)
	if err != nil {
		log.Printf("DEV COLLABORATION BROADCAST ERROR: %v", err)
		return
	}

	d.mutex.RLock()
	for conn := range d.websocketConns {
		if err := conn.WriteMessage(websocket.TextMessage, data); err != nil {
			log.Printf("DEV COLLABORATION WEBSOCKET ERROR: %v", err)
		}
	}
	d.mutex.RUnlock()
}

// AddReloadCallback adds a callback for file reload events
func (d *DevEnvironment) AddReloadCallback(extension string, callback func(string)) {
	d.mutex.Lock()
	d.reloadCallbacks[extension] = append(d.reloadCallbacks[extension], callback)
	d.mutex.Unlock()
}

// Start starts the development environment
func (d *DevEnvironment) Start() error {
	if d.isRunning {
		return fmt.Errorf("development environment already running")
	}

	d.isRunning = true
	d.startTime = time.Now()

	log.Printf("DEV ENVIRONMENT STARTING: port=%d", d.config.Port)

	// Start collaboration broadcast
	if d.config.CollaborationEnabled {
		go d.collaboration.broadcastLoop()
	}

	// Start HTTP server
	go func() {
		if err := d.server.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			log.Printf("DEV SERVER ERROR: %v", err)
		}
	}()

	log.Printf("DEV ENVIRONMENT STARTED: http://localhost:%d", d.config.Port)
	return nil
}

// Stop stops the development environment
func (d *DevEnvironment) Stop() error {
	if !d.isRunning {
		return fmt.Errorf("development environment not running")
	}

	d.isRunning = false

	// Stop HTTP server
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	
	if err := d.server.Shutdown(ctx); err != nil {
		log.Printf("DEV SERVER SHUTDOWN ERROR: %v", err)
	}

	// Close WebSocket connections
	d.mutex.Lock()
	for conn := range d.websocketConns {
		conn.Close()
	}
	d.websocketConns = make(map[*websocket.Conn]bool)
	d.mutex.Unlock()

	// Close file watcher
	if err := d.watcher.Close(); err != nil {
		log.Printf("DEV WATCHER CLOSE ERROR: %v", err)
	}

	log.Printf("DEV ENVIRONMENT STOPPED")
	return nil
}

// Debugger methods
func (d *Debugger) SetBreakpoint(file string, line int) {
	d.mutex.Lock()
	d.breakpoints[file] = append(d.breakpoints[file], line)
	d.mutex.Unlock()
	log.Printf("DEV BREAKPOINT SET: %s:%d", file, line)
}

func (d *Debugger) RemoveBreakpoint(file string, line int) {
	d.mutex.Lock()
	if lines, exists := d.breakpoints[file]; exists {
		for i, l := range lines {
			if l == line {
				d.breakpoints[file] = append(lines[:i], lines[i+1:]...)
				break
			}
		}
	}
	d.mutex.Unlock()
	log.Printf("DEV BREAKPOINT REMOVED: %s:%d", file, line)
}

// Profiler methods
func (d *Profiler) StartProfiling() error {
	d.mutex.Lock()
	defer d.mutex.Unlock()

	if d.isProfiling {
		return fmt.Errorf("profiling already active")
	}

	d.isProfiling = true
	d.startTime = time.Now()

	// Start CPU profiling
	if cpuFile, err := os.Create("cpu.prof"); err == nil {
		d.cpuProfile = cpuFile
		pprof.StartCPUProfile(cpuFile)
	}

	// Start memory profiling
	if memFile, err := os.Create("mem.prof"); err == nil {
		d.memProfile = memFile
	}

	log.Printf("DEV PROFILING STARTED")
	return nil
}

func (d *Profiler) StopProfiling() map[string]interface{} {
	d.mutex.Lock()
	defer d.mutex.Unlock()

	if !d.isProfiling {
		return nil
	}

	d.isProfiling = false
	duration := time.Since(d.startTime)

	// Stop CPU profiling
	if d.cpuProfile != nil {
		pprof.StopCPUProfile()
		d.cpuProfile.Close()
	}

	// Write memory profile
	if d.memProfile != nil {
		pprof.WriteHeapProfile(d.memProfile)
		d.memProfile.Close()
	}

	// Collect metrics
	var m runtime.MemStats
	runtime.ReadMemStats(&m)

	profileData := map[string]interface{}{
		"duration":        duration.String(),
		"cpu_profile":     "cpu.prof",
		"memory_profile":  "mem.prof",
		"memory_alloc":    m.Alloc,
		"memory_total":    m.TotalAlloc,
		"memory_sys":      m.Sys,
		"goroutines":      runtime.NumGoroutine(),
	}

	log.Printf("DEV PROFILING STOPPED: duration=%v", duration)
	return profileData
}

// Collaboration broadcast loop
func (c *Collaboration) broadcastLoop() {
	for msg := range c.broadcastChan {
		// Implementation would broadcast to all clients
		log.Printf("DEV COLLABORATION BROADCAST: %s", msg.Type)
	}
} 