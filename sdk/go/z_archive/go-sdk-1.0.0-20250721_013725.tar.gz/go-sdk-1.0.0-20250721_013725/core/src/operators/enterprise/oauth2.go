package enterprise

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"net/url"
	"strings"
	"time"

	"golang.org/x/oauth2"
	"golang.org/x/oauth2/google"
	"golang.org/x/oauth2/github"
	"golang.org/x/oauth2/facebook"
)

// OAuth2Operator handles @oauth2 operations
type OAuth2Operator struct {
	configs map[string]*oauth2.Config
	tokens  map[string]*oauth2.Token
	client  *http.Client
}

// OAuth2Config represents OAuth2 configuration
type OAuth2Config struct {
	ClientID     string   `json:"client_id"`
	ClientSecret string   `json:"client_secret"`
	RedirectURL  string   `json:"redirect_url"`
	Scopes       []string `json:"scopes"`
	AuthURL      string   `json:"auth_url"`
	TokenURL     string   `json:"token_url"`
}

// OAuth2Token represents OAuth2 token information
type OAuth2Token struct {
	AccessToken  string    `json:"access_token"`
	TokenType    string    `json:"token_type"`
	RefreshToken string    `json:"refresh_token,omitempty"`
	Expiry       time.Time `json:"expiry,omitempty"`
	Scope        string    `json:"scope,omitempty"`
}

// OAuth2User represents OAuth2 user information
type OAuth2User struct {
	ID        string            `json:"id"`
	Email     string            `json:"email"`
	Name      string            `json:"name"`
	Picture   string            `json:"picture,omitempty"`
	Provider  string            `json:"provider"`
	RawData   map[string]interface{} `json:"raw_data,omitempty"`
}

// NewOAuth2Operator creates a new OAuth2 operator
func NewOAuth2Operator() *OAuth2Operator {
	return &OAuth2Operator{
		configs: make(map[string]*oauth2.Config),
		tokens:  make(map[string]*oauth2.Token),
		client:  &http.Client{Timeout: 30 * time.Second},
	}
}

// Execute handles @oauth2 operations
func (o *OAuth2Operator) Execute(params string) interface{} {
	// Parse parameters (format: "action", "provider", "config")
	// Example: @oauth2("authorize", "google", '{"client_id": "..."}')
	
	return fmt.Sprintf("@oauth2(%s)", params)
}

// ConfigureProvider configures an OAuth2 provider
func (o *OAuth2Operator) ConfigureProvider(name string, config OAuth2Config) error {
	var oauthConfig *oauth2.Config

	switch name {
	case "google":
		oauthConfig = &oauth2.Config{
			ClientID:     config.ClientID,
			ClientSecret: config.ClientSecret,
			RedirectURL:  config.RedirectURL,
			Scopes:       config.Scopes,
			Endpoint:     google.Endpoint,
		}
	case "github":
		oauthConfig = &oauth2.Config{
			ClientID:     config.ClientID,
			ClientSecret: config.ClientSecret,
			RedirectURL:  config.RedirectURL,
			Scopes:       config.Scopes,
			Endpoint:     github.Endpoint,
		}
	case "facebook":
		oauthConfig = &oauth2.Config{
			ClientID:     config.ClientID,
			ClientSecret: config.ClientSecret,
			RedirectURL:  config.RedirectURL,
			Scopes:       config.Scopes,
			Endpoint:     facebook.Endpoint,
		}
	case "linkedin":
		oauthConfig = &oauth2.Config{
			ClientID:     config.ClientID,
			ClientSecret: config.ClientSecret,
			RedirectURL:  config.RedirectURL,
			Scopes:       config.Scopes,
			Endpoint: oauth2.Endpoint{
				AuthURL:  "https://www.linkedin.com/oauth/v2/authorization",
				TokenURL: "https://www.linkedin.com/oauth/v2/accessToken",
			},
		}
	default:
		// Custom provider
		oauthConfig = &oauth2.Config{
			ClientID:     config.ClientID,
			ClientSecret: config.ClientSecret,
			RedirectURL:  config.RedirectURL,
			Scopes:       config.Scopes,
			Endpoint: oauth2.Endpoint{
				AuthURL:  config.AuthURL,
				TokenURL: config.TokenURL,
			},
		}
	}

	o.configs[name] = oauthConfig
	return nil
}

// GetAuthURL generates an authorization URL
func (o *OAuth2Operator) GetAuthURL(providerName, state string) (string, error) {
	config, exists := o.configs[providerName]
	if !exists {
		return "", fmt.Errorf("provider %s not configured", providerName)
	}

	authURL := config.AuthCodeURL(state, oauth2.AccessTypeOffline)
	return authURL, nil
}

// ExchangeCode exchanges authorization code for access token
func (o *OAuth2Operator) ExchangeCode(providerName, code string) (*OAuth2Token, error) {
	config, exists := o.configs[providerName]
	if !exists {
		return nil, fmt.Errorf("provider %s not configured", providerName)
	}

	ctx := context.Background()
	token, err := config.Exchange(ctx, code)
	if err != nil {
		return nil, fmt.Errorf("failed to exchange code for token: %v", err)
	}

	// Store token
	o.tokens[providerName] = token

	// Convert to our format
	oauthToken := &OAuth2Token{
		AccessToken:  token.AccessToken,
		TokenType:    token.TokenType,
		RefreshToken: token.RefreshToken,
		Expiry:       token.Expiry,
		Scope:        strings.Join(config.Scopes, " "),
	}

	return oauthToken, nil
}

// RefreshToken refreshes an access token
func (o *OAuth2Operator) RefreshToken(providerName string) (*OAuth2Token, error) {
	config, exists := o.configs[providerName]
	if !exists {
		return nil, fmt.Errorf("provider %s not configured", providerName)
	}

	token, exists := o.tokens[providerName]
	if !exists {
		return nil, fmt.Errorf("no token found for provider %s", providerName)
	}

	ctx := context.Background()
	newToken, err := config.TokenSource(ctx, token).Token()
	if err != nil {
		return nil, fmt.Errorf("failed to refresh token: %v", err)
	}

	// Update stored token
	o.tokens[providerName] = newToken

	// Convert to our format
	oauthToken := &OAuth2Token{
		AccessToken:  newToken.AccessToken,
		TokenType:    newToken.TokenType,
		RefreshToken: newToken.RefreshToken,
		Expiry:       newToken.Expiry,
		Scope:        strings.Join(config.Scopes, " "),
	}

	return oauthToken, nil
}

// GetUserInfo retrieves user information from the OAuth2 provider
func (o *OAuth2Operator) GetUserInfo(providerName string) (*OAuth2User, error) {
	token, exists := o.tokens[providerName]
	if !exists {
		return nil, fmt.Errorf("no token found for provider %s", providerName)
	}

	var userInfoURL string
	switch providerName {
	case "google":
		userInfoURL = "https://www.googleapis.com/oauth2/v2/userinfo"
	case "github":
		userInfoURL = "https://api.github.com/user"
	case "facebook":
		userInfoURL = "https://graph.facebook.com/me?fields=id,name,email,picture"
	case "linkedin":
		userInfoURL = "https://api.linkedin.com/v2/me"
	default:
		return nil, fmt.Errorf("unsupported provider %s for user info", providerName)
	}

	// Create request
	req, err := http.NewRequest("GET", userInfoURL, nil)
	if err != nil {
		return nil, fmt.Errorf("failed to create request: %v", err)
	}

	// Add authorization header
	req.Header.Set("Authorization", "Bearer "+token.AccessToken)

	// Execute request
	resp, err := o.client.Do(req)
	if err != nil {
		return nil, fmt.Errorf("failed to get user info: %v", err)
	}
	defer resp.Body.Close()

	// Parse response
	var rawData map[string]interface{}
	if err := json.NewDecoder(resp.Body).Decode(&rawData); err != nil {
		return nil, fmt.Errorf("failed to decode user info: %v", err)
	}

	// Extract user information based on provider
	user := &OAuth2User{
		Provider: providerName,
		RawData:  rawData,
	}

	switch providerName {
	case "google":
		if id, ok := rawData["id"].(string); ok {
			user.ID = id
		}
		if email, ok := rawData["email"].(string); ok {
			user.Email = email
		}
		if name, ok := rawData["name"].(string); ok {
			user.Name = name
		}
		if picture, ok := rawData["picture"].(string); ok {
			user.Picture = picture
		}
	case "github":
		if id, ok := rawData["id"].(float64); ok {
			user.ID = fmt.Sprintf("%.0f", id)
		}
		if email, ok := rawData["email"].(string); ok {
			user.Email = email
		}
		if name, ok := rawData["name"].(string); ok {
			user.Name = name
		}
		if avatar, ok := rawData["avatar_url"].(string); ok {
			user.Picture = avatar
		}
	case "facebook":
		if id, ok := rawData["id"].(string); ok {
			user.ID = id
		}
		if email, ok := rawData["email"].(string); ok {
			user.Email = email
		}
		if name, ok := rawData["name"].(string); ok {
			user.Name = name
		}
		if picture, ok := rawData["picture"].(map[string]interface{}); ok {
			if data, ok := picture["data"].(map[string]interface{}); ok {
				if url, ok := data["url"].(string); ok {
					user.Picture = url
				}
			}
		}
	case "linkedin":
		if id, ok := rawData["id"].(string); ok {
			user.ID = id
		}
		if email, ok := rawData["email"].(string); ok {
			user.Email = email
		}
		if name, ok := rawData["localizedFirstName"].(string); ok {
			user.Name = name
		}
	}

	return user, nil
}

// ValidateToken validates an access token
func (o *OAuth2Operator) ValidateToken(providerName string) (bool, error) {
	token, exists := o.tokens[providerName]
	if !exists {
		return false, fmt.Errorf("no token found for provider %s", providerName)
	}

	// Check if token is expired
	if token.Expiry.Before(time.Now()) {
		return false, nil
	}

	// Try to get user info to validate token
	_, err := o.GetUserInfo(providerName)
	if err != nil {
		return false, nil
	}

	return true, nil
}

// RevokeToken revokes an access token
func (o *OAuth2Operator) RevokeToken(providerName string) error {
	token, exists := o.tokens[providerName]
	if !exists {
		return fmt.Errorf("no token found for provider %s", providerName)
	}

	var revokeURL string
	switch providerName {
	case "google":
		revokeURL = "https://oauth2.googleapis.com/revoke"
	case "github":
		// GitHub doesn't have a token revocation endpoint
		delete(o.tokens, providerName)
		return nil
	case "facebook":
		revokeURL = "https://graph.facebook.com/me/permissions"
	case "linkedin":
		// LinkedIn doesn't have a token revocation endpoint
		delete(o.tokens, providerName)
		return nil
	default:
		return fmt.Errorf("unsupported provider %s for token revocation", providerName)
	}

	// Create revocation request
	data := url.Values{}
	data.Set("token", token.AccessToken)

	req, err := http.NewRequest("POST", revokeURL, strings.NewReader(data.Encode()))
	if err != nil {
		return fmt.Errorf("failed to create revocation request: %v", err)
	}

	req.Header.Set("Content-Type", "application/x-www-form-urlencoded")

	// Execute request
	resp, err := o.client.Do(req)
	if err != nil {
		return fmt.Errorf("failed to revoke token: %v", err)
	}
	defer resp.Body.Close()

	// Remove token from storage
	delete(o.tokens, providerName)

	return nil
}

// ListProviders returns a list of configured providers
func (o *OAuth2Operator) ListProviders() []string {
	providers := make([]string, 0, len(o.configs))
	for name := range o.configs {
		providers = append(providers, name)
	}
	return providers
}

// GetTokenInfo returns information about a stored token
func (o *OAuth2Operator) GetTokenInfo(providerName string) (*OAuth2Token, error) {
	token, exists := o.tokens[providerName]
	if !exists {
		return nil, fmt.Errorf("no token found for provider %s", providerName)
	}

	config, exists := o.configs[providerName]
	if !exists {
		return nil, fmt.Errorf("provider %s not configured", providerName)
	}

	oauthToken := &OAuth2Token{
		AccessToken:  token.AccessToken,
		TokenType:    token.TokenType,
		RefreshToken: token.RefreshToken,
		Expiry:       token.Expiry,
		Scope:        strings.Join(config.Scopes, " "),
	}

	return oauthToken, nil
}

// Close closes the OAuth2 operator
func (o *OAuth2Operator) Close() error {
	// Clear stored tokens
	o.tokens = make(map[string]*oauth2.Token)
	return nil
} 