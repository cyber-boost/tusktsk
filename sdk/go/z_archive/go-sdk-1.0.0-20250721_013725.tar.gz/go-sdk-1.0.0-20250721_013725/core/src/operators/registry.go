package operators

import (
	"fmt"
	"sync"
	"strings"

	"tusk-go-sdk/src/operators/communication"
	"tusk-go-sdk/src/operators/core"
	"tusk-go-sdk/src/operators/security"
	"tusk-go-sdk/src/operators/enterprise"
	"tusk-go-sdk/src/operators/platform"
	"tusk-go-sdk/src/operators/cloud"
	packageops "tusk-go-sdk/src/operators/package"
	"tusk-go-sdk/src/operators/cli"
	"tusk-go-sdk/src/operators/dev"
	"tusk-go-sdk/src/operators/generator"
	"tusk-go-sdk/src/operators/testing"
)

// OperatorRegistry manages all available operators
type OperatorRegistry struct {
	operators map[string]Operator
	mutex     sync.RWMutex
}

// Operator interface that all operators must implement
type Operator interface {
	Execute(params string) interface{}
}

// NewOperatorRegistry creates a new operator registry
func NewOperatorRegistry() *OperatorRegistry {
	registry := &OperatorRegistry{
		operators: make(map[string]Operator),
	}
	registry.registerDefaultOperators()
	return registry
}

// RegisterOperator registers a new operator
func (r *OperatorRegistry) RegisterOperator(name string, operator Operator) {
	r.mutex.Lock()
	defer r.mutex.Unlock()
	r.operators[name] = operator
}

// GetOperator retrieves an operator by name
func (r *OperatorRegistry) GetOperator(name string) (Operator, error) {
	r.mutex.RLock()
	defer r.mutex.RUnlock()
	
	operator, exists := r.operators[name]
	if !exists {
		return nil, fmt.Errorf("operator '%s' not found", name)
	}
	
	return operator, nil
}

// ListOperators returns all registered operators
func (r *OperatorRegistry) ListOperators() map[string]Operator {
	r.mutex.RLock()
	defer r.mutex.RUnlock()
	
	operators := make(map[string]Operator)
	for name, operator := range r.operators {
		operators[name] = operator
	}
	
	return operators
}

// GetSecurityOperators returns all security-related operators
func (r *OperatorRegistry) GetSecurityOperators() map[string]Operator {
	r.mutex.RLock()
	defer r.mutex.RUnlock()
	
	securityOperators := make(map[string]Operator)
	for name, operator := range r.operators {
		if strings.HasPrefix(name, "security.") {
			securityOperators[name] = operator
		}
	}
	
	return securityOperators
}

// GetEnterpriseOperators returns all enterprise-related operators
func (r *OperatorRegistry) GetEnterpriseOperators() map[string]Operator {
	r.mutex.RLock()
	defer r.mutex.RUnlock()
	
	enterpriseOperators := make(map[string]Operator)
	for name, operator := range r.operators {
		if strings.HasPrefix(name, "enterprise.") {
			enterpriseOperators[name] = operator
		}
	}
	
	return enterpriseOperators
}

// GetComplianceOperators returns all compliance-related operators
func (r *OperatorRegistry) GetComplianceOperators() map[string]Operator {
	r.mutex.RLock()
	defer r.mutex.RUnlock()
	
	complianceOperators := make(map[string]Operator)
	for name, operator := range r.operators {
		if strings.Contains(name, "compliance") || 
		   strings.Contains(name, "audit") || 
		   strings.Contains(name, "soc2") || 
		   strings.Contains(name, "hipaa") || 
		   strings.Contains(name, "gdpr") {
			complianceOperators[name] = operator
		}
	}
	
	return complianceOperators
}

// ValidateSecurityConfiguration validates the security operator configuration
func (r *OperatorRegistry) ValidateSecurityConfiguration() []string {
	var issues []string
	
	requiredOperators := []string{
		"security.mfa",
		"security.zero_trust", 
		"enterprise.compliance",
		"enterprise.blockchain_audit",
	}
	
	for _, opName := range requiredOperators {
		if _, exists := r.operators[opName]; !exists {
			issues = append(issues, fmt.Sprintf("Critical security operator '%s' not registered", opName))
		}
	}
	
	return issues
}

// GetOperatorCount returns the total number of registered operators
func (r *OperatorRegistry) GetOperatorCount() int {
	r.mutex.RLock()
	defer r.mutex.RUnlock()
	return len(r.operators)
}

// GetSecurityOperatorCount returns the number of security operators
func (r *OperatorRegistry) GetSecurityOperatorCount() int {
	return len(r.GetSecurityOperators())
}

// GetEnterpriseOperatorCount returns the number of enterprise operators  
func (r *OperatorRegistry) GetEnterpriseOperatorCount() int {
	return len(r.GetEnterpriseOperators())
} 

// registerDefaultOperators registers all built-in operators including A5 platform operators
func (r *OperatorRegistry) registerDefaultOperators() {
	// Core operators
	r.RegisterOperator("@date", core.NewDateOperator())
	r.RegisterOperator("@env", core.NewEnvOperator())
	r.RegisterOperator("@learn", core.NewLearnOperator())
	r.RegisterOperator("@feature", core.NewFeatureOperator())

	// Communication operators
	r.RegisterOperator("@graphql", communication.NewGraphQLOperator(""))
	r.RegisterOperator("@grpc", communication.NewGRPCOperator())
	r.RegisterOperator("@websocket", communication.NewWebSocketOperator())

	// 🚀 A5 PLATFORM INTEGRATION OPERATORS - MISSION ACCOMPLISHED!
	
	// Platform operators - Advanced cluster & WASM management
	r.RegisterOperator("@kubernetes", platform.NewKubernetesOperator())
	r.RegisterOperator("@wasm", platform.NewWasmOperator())

	// Cloud operators - Service mesh & serverless functions
	r.RegisterOperator("@istio", cloud.NewIstioOperator())
	r.RegisterOperator("@multicloud", cloud.NewMultiCloudOperator())

	// Universal Package Management - Complete ecosystem support
	r.RegisterOperator("@packages", packageops.NewUniversalPackageOperator())
	r.RegisterOperator("@npm", packageops.NewUniversalPackageOperator())
	r.RegisterOperator("@pip", packageops.NewUniversalPackageOperator())
	r.RegisterOperator("@cargo", packageops.NewUniversalPackageOperator())
	r.RegisterOperator("@maven", packageops.NewUniversalPackageOperator())
	r.RegisterOperator("@nuget", packageops.NewUniversalPackageOperator())
	r.RegisterOperator("@gem", packageops.NewUniversalPackageOperator())
	r.RegisterOperator("@composer", packageops.NewUniversalPackageOperator())

	// 🎯 A6 DEVELOPER EXPERIENCE OPERATORS - MISSION ACCOMPLISHED!
	
	// CLI Framework & Shell Integration
	r.RegisterOperator("@cli", cli.NewCLIFramework(nil))
	
	// Development Environment & Live Reload
	r.RegisterOperator("@dev", dev.NewDevEnvironment(nil))
	
	// Code Generation & IDE Integration
	r.RegisterOperator("@generator", generator.NewCodeGenerator(nil))
	
	// Testing & Quality Assurance Framework
	r.RegisterOperator("@testing", testing.NewTestingFramework(nil))

	// 🚨 A7 ADVANCED SECURITY & THREAT INTELLIGENCE OPERATORS - MISSION ACCOMPLISHED!
	
	// Advanced Security & SOAR Platform
	r.RegisterOperator("@soar", security.NewSOAROperator(nil))
	r.RegisterOperator("@dlp", security.NewDLPOperator(nil))
	r.RegisterOperator("@pam", security.NewPAMOperator(nil))
	r.RegisterOperator("@compliance", enterprise.NewComplianceOperator(nil))
} 