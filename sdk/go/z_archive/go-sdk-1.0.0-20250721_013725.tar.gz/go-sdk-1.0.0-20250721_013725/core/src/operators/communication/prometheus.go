package communication

import (
	"fmt"
	"sync"

	"github.com/prometheus/client_golang/prometheus"
	"github.com/prometheus/client_golang/prometheus/promauto"
)

// PrometheusOperator handles @prometheus operations
type PrometheusOperator struct {
	endpoint string
	metrics  map[string]prometheus.Collector
	mutex    sync.RWMutex
}

// NewPrometheusOperator creates a new Prometheus operator
func NewPrometheusOperator(endpoint string) *PrometheusOperator {
	return &PrometheusOperator{
		endpoint: endpoint,
		metrics:  make(map[string]prometheus.Collector),
	}
}

// Execute handles @prometheus operations
func (p *PrometheusOperator) Execute(params string) interface{} {
	// Parse parameters (format: "action,metric_name,value,labels")
	// Example: @prometheus("increment", "http_requests_total", "1", "method=GET,status=200")
	
	if params == "" {
		return fmt.Sprintf("@prometheus(%s)", params)
	}
	
	// Remove quotes if present
	cleanParams := params
	if len(cleanParams) >= 2 && (cleanParams[0] == '"' || cleanParams[0] == '\'') {
		cleanParams = cleanParams[1 : len(cleanParams)-1]
	}
	
	parts := splitParams(cleanParams)
	if len(parts) == 0 {
		return fmt.Sprintf("@prometheus(%s) - Invalid parameters", params)
	}
	
	action := parts[0]
	
	switch action {
	case "increment":
		if len(parts) < 2 {
			return fmt.Sprintf("@prometheus(%s) - Missing metric name for increment", params)
		}
		value := "1"
		if len(parts) > 2 {
			value = parts[2]
		}
		labels := ""
		if len(parts) > 3 {
			labels = parts[3]
		}
		return p.Increment(parts[1], value, labels)
	case "gauge":
		if len(parts) < 3 {
			return fmt.Sprintf("@prometheus(%s) - Missing metric name or value for gauge", params)
		}
		labels := ""
		if len(parts) > 3 {
			labels = parts[3]
		}
		return p.SetGauge(parts[1], parts[2], labels)
	case "histogram":
		if len(parts) < 3 {
			return fmt.Sprintf("@prometheus(%s) - Missing metric name or value for histogram", params)
		}
		labels := ""
		if len(parts) > 3 {
			labels = parts[3]
		}
		return p.ObserveHistogram(parts[1], parts[2], labels)
	case "summary":
		if len(parts) < 3 {
			return fmt.Sprintf("@prometheus(%s) - Missing metric name or value for summary", params)
		}
		labels := ""
		if len(parts) > 3 {
			labels = parts[3]
		}
		return p.ObserveSummary(parts[1], parts[2], labels)
	case "list":
		return p.ListMetrics()
	default:
		return fmt.Sprintf("@prometheus(%s) - Unknown action: %s", params, action)
	}
}

// Increment increments a counter metric
func (p *PrometheusOperator) Increment(name, value, labels string) interface{} {
	p.mutex.Lock()
	defer p.mutex.Unlock()
	
	metric, exists := p.metrics[name]
	if !exists {
		// Create new counter
		counter := promauto.NewCounter(prometheus.CounterOpts{
			Name: name,
			Help: fmt.Sprintf("Counter for %s", name),
		})
		p.metrics[name] = counter
		metric = counter
	}
	
	if counter, ok := metric.(prometheus.Counter); ok {
		// Parse value
		var increment float64
		if value == "1" {
			increment = 1
		} else {
			// Try to parse as float
			if v, err := parseFloat(value); err == nil {
				increment = v
			} else {
				increment = 1
			}
		}
		
		counter.Add(increment)
		return fmt.Sprintf("Incremented %s by %f", name, increment)
	}
	
	return fmt.Sprintf("Failed to increment %s - not a counter", name)
}

// SetGauge sets a gauge metric
func (p *PrometheusOperator) SetGauge(name, value, labels string) interface{} {
	p.mutex.Lock()
	defer p.mutex.Unlock()
	
	metric, exists := p.metrics[name]
	if !exists {
		// Create new gauge
		gauge := promauto.NewGauge(prometheus.GaugeOpts{
			Name: name,
			Help: fmt.Sprintf("Gauge for %s", name),
		})
		p.metrics[name] = gauge
		metric = gauge
	}
	
	if gauge, ok := metric.(prometheus.Gauge); ok {
		// Parse value
		if v, err := parseFloat(value); err == nil {
			gauge.Set(v)
			return fmt.Sprintf("Set gauge %s to %f", name, v)
		}
		return fmt.Sprintf("Failed to parse value %s for gauge %s", value, name)
	}
	
	return fmt.Sprintf("Failed to set gauge %s - not a gauge", name)
}

// ObserveHistogram observes a histogram metric
func (p *PrometheusOperator) ObserveHistogram(name, value, labels string) interface{} {
	p.mutex.Lock()
	defer p.mutex.Unlock()
	
	metric, exists := p.metrics[name]
	if !exists {
		// Create new histogram
		histogram := promauto.NewHistogram(prometheus.HistogramOpts{
			Name: name,
			Help: fmt.Sprintf("Histogram for %s", name),
		})
		p.metrics[name] = histogram
		metric = histogram
	}
	
	if histogram, ok := metric.(prometheus.Histogram); ok {
		// Parse value
		if v, err := parseFloat(value); err == nil {
			histogram.Observe(v)
			return fmt.Sprintf("Observed histogram %s with value %f", name, v)
		}
		return fmt.Sprintf("Failed to parse value %s for histogram %s", value, name)
	}
	
	return fmt.Sprintf("Failed to observe histogram %s - not a histogram", name)
}

// ObserveSummary observes a summary metric
func (p *PrometheusOperator) ObserveSummary(name, value, labels string) interface{} {
	p.mutex.Lock()
	defer p.mutex.Unlock()
	
	metric, exists := p.metrics[name]
	if !exists {
		// Create new summary
		summary := promauto.NewSummary(prometheus.SummaryOpts{
			Name: name,
			Help: fmt.Sprintf("Summary for %s", name),
		})
		p.metrics[name] = summary
		metric = summary
	}
	
	if summary, ok := metric.(prometheus.Summary); ok {
		// Parse value
		if v, err := parseFloat(value); err == nil {
			summary.Observe(v)
			return fmt.Sprintf("Observed summary %s with value %f", name, v)
		}
		return fmt.Sprintf("Failed to parse value %s for summary %s", value, name)
	}
	
	return fmt.Sprintf("Failed to observe summary %s - not a summary", name)
}

// ListMetrics returns all registered metrics
func (p *PrometheusOperator) ListMetrics() interface{} {
	p.mutex.RLock()
	defer p.mutex.RUnlock()
	
	metrics := make([]string, 0, len(p.metrics))
	for name := range p.metrics {
		metrics = append(metrics, name)
	}
	
	return map[string]interface{}{
		"metrics":  metrics,
		"count":    len(metrics),
		"endpoint": p.endpoint,
	}
}

// GetMetric retrieves a metric by name
func (p *PrometheusOperator) GetMetric(name string) (prometheus.Collector, bool) {
	p.mutex.RLock()
	defer p.mutex.RUnlock()
	
	metric, exists := p.metrics[name]
	return metric, exists
}

// RemoveMetric removes a metric
func (p *PrometheusOperator) RemoveMetric(name string) interface{} {
	p.mutex.Lock()
	defer p.mutex.Unlock()
	
	if _, exists := p.metrics[name]; exists {
		delete(p.metrics, name)
		return fmt.Sprintf("Removed metric %s", name)
	}
	
	return fmt.Sprintf("Metric %s not found", name)
}

// ClearMetrics removes all metrics
func (p *PrometheusOperator) ClearMetrics() interface{} {
	p.mutex.Lock()
	defer p.mutex.Unlock()
	
	count := len(p.metrics)
	p.metrics = make(map[string]prometheus.Collector)
	
	return fmt.Sprintf("Cleared %d metrics", count)
}

// GetEndpoint returns the Prometheus endpoint
func (p *PrometheusOperator) GetEndpoint() string {
	return p.endpoint
}

// SetEndpoint sets the Prometheus endpoint
func (p *PrometheusOperator) SetEndpoint(endpoint string) {
	p.mutex.Lock()
	defer p.mutex.Unlock()
	
	p.endpoint = endpoint
}

// parseFloat parses a string to float64
func parseFloat(s string) (float64, error) {
	// This is a simplified implementation
	// In a real implementation, you would use strconv.ParseFloat
	var result float64
	_, err := fmt.Sscanf(s, "%f", &result)
	return result, err
}

 