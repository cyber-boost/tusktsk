package database

import (
	"fmt"
	"sync"
)

// DatabaseFactory manages database connections and operator creation
type DatabaseFactory struct {
	connections map[string]interface{}
	mutex       sync.RWMutex
}

// NewDatabaseFactory creates a new database factory
func NewDatabaseFactory() *DatabaseFactory {
	return &DatabaseFactory{
		connections: make(map[string]interface{}),
	}
}

// CreateMySQLOperator creates a new MySQL operator
func (f *DatabaseFactory) CreateMySQLOperator(name, connectionString string) (*MySQLOperator, error) {
	f.mutex.Lock()
	defer f.mutex.Unlock()

	// Check if connection already exists
	if conn, exists := f.connections[name]; exists {
		if mysqlOp, ok := conn.(*MySQLOperator); ok {
			return mysqlOp, nil
		}
	}

	operator, err := NewMySQLOperator(connectionString)
	if err != nil {
		return nil, fmt.Errorf("failed to create MySQL operator: %v", err)
	}

	f.connections[name] = operator
	return operator, nil
}

// CreatePostgreSQLOperator creates a new PostgreSQL operator
func (f *DatabaseFactory) CreatePostgreSQLOperator(name, connectionString string) (*PostgreSQLOperator, error) {
	f.mutex.Lock()
	defer f.mutex.Unlock()

	// Check if connection already exists
	if conn, exists := f.connections[name]; exists {
		if pgOp, ok := conn.(*PostgreSQLOperator); ok {
			return pgOp, nil
		}
	}

	operator, err := NewPostgreSQLOperator(connectionString)
	if err != nil {
		return nil, fmt.Errorf("failed to create PostgreSQL operator: %v", err)
	}

	f.connections[name] = operator
	return operator, nil
}

// CreateMongoDBOperator creates a new MongoDB operator
func (f *DatabaseFactory) CreateMongoDBOperator(name, connectionString, database string) (*MongoDBOperator, error) {
	f.mutex.Lock()
	defer f.mutex.Unlock()

	// Check if connection already exists
	if conn, exists := f.connections[name]; exists {
		if mongoOp, ok := conn.(*MongoDBOperator); ok {
			return mongoOp, nil
		}
	}

	operator, err := NewMongoDBOperator(connectionString, database)
	if err != nil {
		return nil, fmt.Errorf("failed to create MongoDB operator: %v", err)
	}

	f.connections[name] = operator
	return operator, nil
}

// CreateRedisOperator creates a new Redis operator
func (f *DatabaseFactory) CreateRedisOperator(name, addr, password string, db int) (*RedisOperator, error) {
	f.mutex.Lock()
	defer f.mutex.Unlock()

	// Check if connection already exists
	if conn, exists := f.connections[name]; exists {
		if redisOp, ok := conn.(*RedisOperator); ok {
			return redisOp, nil
		}
	}

	operator, err := NewRedisOperator(addr, password, db)
	if err != nil {
		return nil, fmt.Errorf("failed to create Redis operator: %v", err)
	}

	f.connections[name] = operator
	return operator, nil
}

// GetConnection retrieves a database connection by name
func (f *DatabaseFactory) GetConnection(name string) (interface{}, bool) {
	f.mutex.RLock()
	defer f.mutex.RUnlock()

	conn, exists := f.connections[name]
	return conn, exists
}

// GetMySQLOperator retrieves a MySQL operator by name
func (f *DatabaseFactory) GetMySQLOperator(name string) (*MySQLOperator, bool) {
	conn, exists := f.GetConnection(name)
	if !exists {
		return nil, false
	}

	if mysqlOp, ok := conn.(*MySQLOperator); ok {
		return mysqlOp, true
	}

	return nil, false
}

// GetPostgreSQLOperator retrieves a PostgreSQL operator by name
func (f *DatabaseFactory) GetPostgreSQLOperator(name string) (*PostgreSQLOperator, bool) {
	conn, exists := f.GetConnection(name)
	if !exists {
		return nil, false
	}

	if pgOp, ok := conn.(*PostgreSQLOperator); ok {
		return pgOp, true
	}

	return nil, false
}

// GetMongoDBOperator retrieves a MongoDB operator by name
func (f *DatabaseFactory) GetMongoDBOperator(name string) (*MongoDBOperator, bool) {
	conn, exists := f.GetConnection(name)
	if !exists {
		return nil, false
	}

	if mongoOp, ok := conn.(*MongoDBOperator); ok {
		return mongoOp, true
	}

	return nil, false
}

// GetRedisOperator retrieves a Redis operator by name
func (f *DatabaseFactory) GetRedisOperator(name string) (*RedisOperator, bool) {
	conn, exists := f.GetConnection(name)
	if !exists {
		return nil, false
	}

	if redisOp, ok := conn.(*RedisOperator); ok {
		return redisOp, true
	}

	return nil, false
}

// CloseConnection closes a specific database connection
func (f *DatabaseFactory) CloseConnection(name string) error {
	f.mutex.Lock()
	defer f.mutex.Unlock()

	if conn, exists := f.connections[name]; exists {
		switch operator := conn.(type) {
		case *MySQLOperator:
			err := operator.Close()
			delete(f.connections, name)
			return err
		case *PostgreSQLOperator:
			err := operator.Close()
			delete(f.connections, name)
			return err
		case *MongoDBOperator:
			err := operator.Close()
			delete(f.connections, name)
			return err
		case *RedisOperator:
			err := operator.Close()
			delete(f.connections, name)
			return err
		}
	}

	return nil
}

// CloseAllConnections closes all database connections
func (f *DatabaseFactory) CloseAllConnections() {
	f.mutex.Lock()
	defer f.mutex.Unlock()

	for name, conn := range f.connections {
		switch operator := conn.(type) {
		case *MySQLOperator:
			operator.Close()
		case *PostgreSQLOperator:
			operator.Close()
		case *MongoDBOperator:
			operator.Close()
		case *RedisOperator:
			operator.Close()
		}
		delete(f.connections, name)
	}
}

// ListConnections returns a list of all connection names
func (f *DatabaseFactory) ListConnections() []string {
	f.mutex.RLock()
	defer f.mutex.RUnlock()

	names := make([]string, 0, len(f.connections))
	for name := range f.connections {
		names = append(names, name)
	}

	return names
}

// Global factory instance
var globalFactory *DatabaseFactory
var globalFactoryOnce sync.Once

// GetGlobalFactory returns the global database factory instance
func GetGlobalFactory() *DatabaseFactory {
	globalFactoryOnce.Do(func() {
		globalFactory = NewDatabaseFactory()
	})
	return globalFactory
}

// CreateMySQLOperatorGlobal creates a MySQL operator in the global factory
func CreateMySQLOperatorGlobal(name, connectionString string) (*MySQLOperator, error) {
	return GetGlobalFactory().CreateMySQLOperator(name, connectionString)
}

// CreatePostgreSQLOperatorGlobal creates a PostgreSQL operator in the global factory
func CreatePostgreSQLOperatorGlobal(name, connectionString string) (*PostgreSQLOperator, error) {
	return GetGlobalFactory().CreatePostgreSQLOperator(name, connectionString)
}

// CreateMongoDBOperatorGlobal creates a MongoDB operator in the global factory
func CreateMongoDBOperatorGlobal(name, connectionString, database string) (*MongoDBOperator, error) {
	return GetGlobalFactory().CreateMongoDBOperator(name, connectionString, database)
}

// CreateRedisOperatorGlobal creates a Redis operator in the global factory
func CreateRedisOperatorGlobal(name, addr, password string, db int) (*RedisOperator, error) {
	return GetGlobalFactory().CreateRedisOperator(name, addr, password, db)
}

// CloseGlobalConnections closes all connections in the global factory
func CloseGlobalConnections() {
	GetGlobalFactory().CloseAllConnections()
} 