package cli

import (
	"bufio"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strings"
	"sync"
	"time"

	"github.com/c-bata/go-prompt"
	"github.com/fatih/color"
	"github.com/spf13/cobra"
	"github.com/spf13/viper"
)

// CLIFramework handles advanced CLI operations with shell integration
type CLIFramework struct {
	rootCmd        *cobra.Command
	completer      *prompt.Completer
	plugins        map[string]*Plugin
	config         *CLIConfig
	mutex          sync.RWMutex
	isInteractive  bool
	analytics      *CLIAnalytics
	shellProfiles  map[string]string
}

// CLIConfig holds CLI configuration
type CLIConfig struct {
	AutoComplete     bool              `json:"auto_complete"`
	InteractiveMode  bool              `json:"interactive_mode"`
	PluginDir        string            `json:"plugin_dir"`
	ShellProfiles    map[string]string `json:"shell_profiles"`
	AnalyticsEnabled bool              `json:"analytics_enabled"`
	Theme            *CLITheme         `json:"theme"`
	HistoryFile      string            `json:"history_file"`
	MaxHistory       int               `json:"max_history"`
}

// CLITheme defines CLI color scheme
type CLITheme struct {
	Primary   string `json:"primary"`
	Secondary string `json:"secondary"`
	Success   string `json:"success"`
	Warning   string `json:"warning"`
	Error     string `json:"error"`
	Info      string `json:"info"`
}

// Plugin represents a CLI plugin
type Plugin struct {
	Name        string                 `json:"name"`
	Version     string                 `json:"version"`
	Description string                 `json:"description"`
	Commands    []*PluginCommand       `json:"commands"`
	Config      map[string]interface{} `json:"config"`
	Enabled     bool                   `json:"enabled"`
	HotReload   bool                   `json:"hot_reload"`
}

// PluginCommand represents a plugin command
type PluginCommand struct {
	Name        string   `json:"name"`
	Description string   `json:"description"`
	Usage       string   `json:"usage"`
	Aliases     []string `json:"aliases"`
	Flags       []string `json:"flags"`
}

// CLIAnalytics tracks CLI usage
type CLIAnalytics struct {
	Commands    map[string]int64 `json:"commands"`
	Errors      map[string]int64 `json:"errors"`
	Performance map[string]int64 `json:"performance"`
	UserAgent   string           `json:"user_agent"`
	SessionID   string           `json:"session_id"`
	StartTime   time.Time        `json:"start_time"`
}

// DefaultCLIConfig returns default CLI configuration
func DefaultCLIConfig() *CLIConfig {
	return &CLIConfig{
		AutoComplete:     true,
		InteractiveMode:  true,
		PluginDir:        "~/.tusk/plugins",
		AnalyticsEnabled: true,
		MaxHistory:       1000,
		Theme: &CLITheme{
			Primary:   "cyan",
			Secondary: "blue",
			Success:   "green",
			Warning:   "yellow",
			Error:     "red",
			Info:      "white",
		},
		ShellProfiles: map[string]string{
			"bash": "~/.bashrc",
			"zsh":  "~/.zshrc",
			"fish": "~/.config/fish/config.fish",
		},
	}
}

// NewCLIFramework creates a new CLI framework
func NewCLIFramework(config *CLIConfig) (*CLIFramework, error) {
	if config == nil {
		config = DefaultCLIConfig()
	}

	// Expand plugin directory
	if strings.HasPrefix(config.PluginDir, "~") {
		home, _ := os.UserHomeDir()
		config.PluginDir = strings.Replace(config.PluginDir, "~", home, 1)
	}

	// Create plugin directory if it doesn't exist
	if err := os.MkdirAll(config.PluginDir, 0755); err != nil {
		return nil, fmt.Errorf("failed to create plugin directory: %v", err)
	}

	framework := &CLIFramework{
		plugins:       make(map[string]*Plugin),
		config:        config,
		analytics:     &CLIAnalytics{},
		shellProfiles: config.ShellProfiles,
	}

	// Initialize analytics
	framework.analytics.Commands = make(map[string]int64)
	framework.analytics.Errors = make(map[string]int64)
	framework.analytics.Performance = make(map[string]int64)
	framework.analytics.StartTime = time.Now()
	framework.analytics.SessionID = generateSessionID()
	framework.analytics.UserAgent = fmt.Sprintf("TuskCLI/%s (%s; %s)", "1.0.0", runtime.GOOS, runtime.GOARCH)

	// Initialize root command
	framework.initializeRootCommand()

	// Load plugins
	if err := framework.loadPlugins(); err != nil {
		log.Printf("CLI PLUGIN LOAD ERROR: %v", err)
	}

	// Setup shell integration
	if err := framework.setupShellIntegration(); err != nil {
		log.Printf("CLI SHELL INTEGRATION ERROR: %v", err)
	}

	log.Printf("CLI FRAMEWORK INITIALIZED: plugins=%d, interactive=%v", len(framework.plugins), config.InteractiveMode)
	return framework, nil
}

// initializeRootCommand sets up the root command
func (c *CLIFramework) initializeRootCommand() {
	c.rootCmd = &cobra.Command{
		Use:   "tusk",
		Short: "Tusk CLI - Advanced Development Framework",
		Long: `Tusk CLI provides advanced development tools with:
- Interactive shell with auto-completion
- Plugin system for extensibility
- Real-time configuration validation
- Development environment integration
- Testing and quality assurance tools`,
		Run: func(cmd *cobra.Command, args []string) {
			if c.config.InteractiveMode {
				c.startInteractiveMode()
			} else {
				cmd.Help()
			}
		},
	}

	// Add global flags
	c.rootCmd.PersistentFlags().BoolP("verbose", "v", false, "Enable verbose output")
	c.rootCmd.PersistentFlags().StringP("config", "c", "", "Configuration file path")
	c.rootCmd.PersistentFlags().BoolP("no-analytics", "", false, "Disable analytics")

	// Add subcommands
	c.addBuiltinCommands()
}

// addBuiltinCommands adds built-in CLI commands
func (c *CLIFramework) addBuiltinCommands() {
	// Plugin management
	pluginCmd := &cobra.Command{
		Use:   "plugin",
		Short: "Manage CLI plugins",
	}
	pluginCmd.AddCommand(
		&cobra.Command{
			Use:   "list",
			Short: "List installed plugins",
			Run:   c.listPlugins,
		},
		&cobra.Command{
			Use:   "install [plugin]",
			Short: "Install a plugin",
			Args:  cobra.ExactArgs(1),
			Run:   c.installPlugin,
		},
		&cobra.Command{
			Use:   "uninstall [plugin]",
			Short: "Uninstall a plugin",
			Args:  cobra.ExactArgs(1),
			Run:   c.uninstallPlugin,
		},
		&cobra.Command{
			Use:   "reload",
			Short: "Reload all plugins",
			Run:   c.reloadPlugins,
		},
	)
	c.rootCmd.AddCommand(pluginCmd)

	// Configuration management
	configCmd := &cobra.Command{
		Use:   "config",
		Short: "Manage CLI configuration",
	}
	configCmd.AddCommand(
		&cobra.Command{
			Use:   "show",
			Short: "Show current configuration",
			Run:   c.showConfig,
		},
		&cobra.Command{
			Use:   "wizard",
			Short: "Interactive configuration wizard",
			Run:   c.configWizard,
		},
		&cobra.Command{
			Use:   "validate",
			Short: "Validate configuration",
			Run:   c.validateConfig,
		},
	)
	c.rootCmd.AddCommand(configCmd)

	// Shell integration
	shellCmd := &cobra.Command{
		Use:   "shell",
		Short: "Shell integration commands",
	}
	shellCmd.AddCommand(
		&cobra.Command{
			Use:   "setup",
			Short: "Setup shell integration",
			Run:   c.setupShell,
		},
		&cobra.Command{
			Use:   "completion [shell]",
			Short: "Generate shell completion",
			Args:  cobra.ExactArgs(1),
			Run:   c.generateCompletion,
		},
	)
	c.rootCmd.AddCommand(shellCmd)

	// Analytics
	analyticsCmd := &cobra.Command{
		Use:   "analytics",
		Short: "CLI analytics and insights",
	}
	analyticsCmd.AddCommand(
		&cobra.Command{
			Use:   "show",
			Short: "Show analytics data",
			Run:   c.showAnalytics,
		},
		&cobra.Command{
			Use:   "reset",
			Short: "Reset analytics data",
			Run:   c.resetAnalytics,
		},
	)
	c.rootCmd.AddCommand(analyticsCmd)
}

// startInteractiveMode starts interactive CLI mode
func (c *CLIFramework) startInteractiveMode() {
	color.Cyan("🚀 Tusk CLI Interactive Mode")
	color.Cyan("Type 'help' for available commands, 'exit' to quit\n")

	completer := prompt.NewCompleter(
		prompt.Suggest{Text: "help", Description: "Show available commands"},
		prompt.Suggest{Text: "plugin list", Description: "List installed plugins"},
		prompt.Suggest{Text: "config wizard", Description: "Interactive configuration wizard"},
		prompt.Suggest{Text: "shell setup", Description: "Setup shell integration"},
		prompt.Suggest{Text: "analytics show", Description: "Show usage analytics"},
		prompt.Suggest{Text: "exit", Description: "Exit interactive mode"},
	)

	for {
		input := prompt.Input("tusk> ", completer,
			prompt.OptionTitle("Tusk CLI"),
			prompt.OptionPrefixTextColor(prompt.Yellow),
			prompt.OptionPreviewSuggestionTextColor(prompt.Blue),
			prompt.OptionSelectedSuggestionTextColor(prompt.Yellow),
			prompt.OptionSuggestionTextColor(prompt.DarkGray),
		)

		if input == "exit" || input == "quit" {
			break
		}

		if input == "help" {
			c.showHelp()
			continue
		}

		// Execute command
		args := strings.Fields(input)
		if len(args) > 0 {
			c.rootCmd.SetArgs(args)
			if err := c.rootCmd.Execute(); err != nil {
				color.Red("Error: %v", err)
				c.trackError("command_execution", err.Error())
			}
		}
	}
}

// loadPlugins loads all available plugins
func (c *CLIFramework) loadPlugins() error {
	entries, err := os.ReadDir(c.config.PluginDir)
	if err != nil {
		return fmt.Errorf("failed to read plugin directory: %v", err)
	}

	for _, entry := range entries {
		if entry.IsDir() {
			pluginPath := filepath.Join(c.config.PluginDir, entry.Name())
			if err := c.loadPlugin(pluginPath); err != nil {
				log.Printf("CLI PLUGIN LOAD ERROR: %s - %v", entry.Name(), err)
			}
		}
	}

	log.Printf("CLI PLUGINS LOADED: %d", len(c.plugins))
	return nil
}

// loadPlugin loads a single plugin
func (c *CLIFramework) loadPlugin(pluginPath string) error {
	configFile := filepath.Join(pluginPath, "plugin.json")
	data, err := os.ReadFile(configFile)
	if err != nil {
		return fmt.Errorf("failed to read plugin config: %v", err)
	}

	var plugin Plugin
	if err := json.Unmarshal(data, &plugin); err != nil {
		return fmt.Errorf("failed to parse plugin config: %v", err)
	}

	c.mutex.Lock()
	c.plugins[plugin.Name] = &plugin
	c.mutex.Unlock()

	log.Printf("CLI PLUGIN LOADED: %s v%s", plugin.Name, plugin.Version)
	return nil
}

// setupShellIntegration sets up shell integration
func (c *CLIFramework) setupShellIntegration() error {
	shell := os.Getenv("SHELL")
	if shell == "" {
		return fmt.Errorf("SHELL environment variable not set")
	}

	shellName := filepath.Base(shell)
	profilePath, exists := c.shellProfiles[shellName]
	if !exists {
		return fmt.Errorf("unsupported shell: %s", shellName)
	}

	// Expand home directory
	if strings.HasPrefix(profilePath, "~") {
		home, _ := os.UserHomeDir()
		profilePath = strings.Replace(profilePath, "~", home, 1)
	}

	// Check if integration is already set up
	profileData, err := os.ReadFile(profilePath)
	if err != nil {
		return fmt.Errorf("failed to read shell profile: %v", err)
	}

	if strings.Contains(string(profileData), "tusk shell integration") {
		log.Printf("CLI SHELL INTEGRATION ALREADY SETUP: %s", shellName)
		return nil
	}

	// Add integration
	integration := fmt.Sprintf(`
# Tusk CLI shell integration
if command -v tusk >/dev/null 2>&1; then
    eval "$(tusk shell completion %s)"
fi
`, shellName)

	file, err := os.OpenFile(profilePath, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
	if err != nil {
		return fmt.Errorf("failed to write to shell profile: %v", err)
	}
	defer file.Close()

	if _, err := file.WriteString(integration); err != nil {
		return fmt.Errorf("failed to write integration: %v", err)
	}

	log.Printf("CLI SHELL INTEGRATION SETUP: %s", shellName)
	return nil
}

// Command handlers
func (c *CLIFramework) listPlugins(cmd *cobra.Command, args []string) {
	c.mutex.RLock()
	defer c.mutex.RUnlock()

	if len(c.plugins) == 0 {
		color.Yellow("No plugins installed")
		return
	}

	color.Cyan("Installed Plugins:")
	for name, plugin := range c.plugins {
		status := "✓"
		if !plugin.Enabled {
			status = "✗"
		}
		color.Green("%s %s v%s - %s", status, name, plugin.Version, plugin.Description)
	}
}

func (c *CLIFramework) installPlugin(cmd *cobra.Command, args []string) {
	pluginName := args[0]
	color.Cyan("Installing plugin: %s", pluginName)
	// Implementation would download and install plugin
	color.Green("Plugin %s installed successfully", pluginName)
}

func (c *CLIFramework) uninstallPlugin(cmd *cobra.Command, args []string) {
	pluginName := args[0]
	color.Cyan("Uninstalling plugin: %s", pluginName)
	// Implementation would remove plugin
	color.Green("Plugin %s uninstalled successfully", pluginName)
}

func (c *CLIFramework) reloadPlugins(cmd *cobra.Command, args []string) {
	color.Cyan("Reloading plugins...")
	c.mutex.Lock()
	c.plugins = make(map[string]*Plugin)
	c.mutex.Unlock()
	
	if err := c.loadPlugins(); err != nil {
		color.Red("Failed to reload plugins: %v", err)
		return
	}
	color.Green("Plugins reloaded successfully")
}

func (c *CLIFramework) showConfig(cmd *cobra.Command, args []string) {
	configJSON, _ := json.MarshalIndent(c.config, "", "  ")
	color.Cyan("Current Configuration:")
	fmt.Println(string(configJSON))
}

func (c *CLIFramework) configWizard(cmd *cobra.Command, args []string) {
	color.Cyan("🔧 Tusk CLI Configuration Wizard")
	
	reader := bufio.NewReader(os.Stdin)
	
	color.Yellow("Enable auto-completion? (y/n): ")
	response, _ := reader.ReadString('\n')
	c.config.AutoComplete = strings.ToLower(strings.TrimSpace(response)) == "y"
	
	color.Yellow("Enable interactive mode? (y/n): ")
	response, _ = reader.ReadString('\n')
	c.config.InteractiveMode = strings.ToLower(strings.TrimSpace(response)) == "y"
	
	color.Yellow("Enable analytics? (y/n): ")
	response, _ = reader.ReadString('\n')
	c.config.AnalyticsEnabled = strings.ToLower(strings.TrimSpace(response)) == "y"
	
	color.Green("Configuration updated successfully!")
}

func (c *CLIFramework) validateConfig(cmd *cobra.Command, args []string) {
	color.Cyan("Validating configuration...")
	
	errors := []string{}
	
	if c.config.PluginDir == "" {
		errors = append(errors, "Plugin directory not set")
	}
	
	if c.config.MaxHistory <= 0 {
		errors = append(errors, "Invalid max history value")
	}
	
	if len(errors) == 0 {
		color.Green("Configuration is valid!")
	} else {
		color.Red("Configuration errors found:")
		for _, err := range errors {
			color.Red("  - %s", err)
		}
	}
}

func (c *CLIFramework) setupShell(cmd *cobra.Command, args []string) {
	color.Cyan("Setting up shell integration...")
	if err := c.setupShellIntegration(); err != nil {
		color.Red("Failed to setup shell integration: %v", err)
		return
	}
	color.Green("Shell integration setup successfully!")
}

func (c *CLIFramework) generateCompletion(cmd *cobra.Command, args []string) {
	shell := args[0]
	color.Cyan("Generating completion for %s...", shell)
	
	// Generate completion script
	completionScript := fmt.Sprintf(`# Tusk CLI completion for %s
_tusk_completion() {
    local cur prev opts
    COMPREPLY=()
    cur="${COMP_WORDS[COMP_CWORD]}"
    prev="${COMP_WORDS[COMP_CWORD-1]}"
    
    opts="help plugin config shell analytics"
    
    if [[ ${cur} == * ]] ; then
        COMPREPLY=( $(compgen -W "${opts}" -- ${cur}) )
        return 0
    fi
}
complete -F _tusk_completion tusk
`, shell)
	
	fmt.Println(completionScript)
}

func (c *CLIFramework) showAnalytics(cmd *cobra.Command, args []string) {
	color.Cyan("📊 CLI Analytics")
	color.Cyan("Session: %s", c.analytics.SessionID)
	color.Cyan("Duration: %v", time.Since(c.analytics.StartTime))
	
	color.Yellow("\nMost Used Commands:")
	for cmd, count := range c.analytics.Commands {
		color.Yellow("  %s: %d", cmd, count)
	}
	
	color.Red("\nErrors:")
	for err, count := range c.analytics.Errors {
		color.Red("  %s: %d", err, count)
	}
}

func (c *CLIFramework) resetAnalytics(cmd *cobra.Command, args []string) {
	c.analytics.Commands = make(map[string]int64)
	c.analytics.Errors = make(map[string]int64)
	c.analytics.Performance = make(map[string]int64)
	color.Green("Analytics data reset successfully!")
}

func (c *CLIFramework) showHelp() {
	color.Cyan("Available Commands:")
	color.Cyan("  help                    - Show this help")
	color.Cyan("  plugin list             - List installed plugins")
	color.Cyan("  plugin install <name>   - Install a plugin")
	color.Cyan("  plugin uninstall <name> - Uninstall a plugin")
	color.Cyan("  plugin reload           - Reload all plugins")
	color.Cyan("  config show             - Show current configuration")
	color.Cyan("  config wizard           - Interactive configuration wizard")
	color.Cyan("  config validate         - Validate configuration")
	color.Cyan("  shell setup             - Setup shell integration")
	color.Cyan("  shell completion <shell> - Generate shell completion")
	color.Cyan("  analytics show          - Show usage analytics")
	color.Cyan("  analytics reset         - Reset analytics data")
	color.Cyan("  exit                    - Exit interactive mode")
}

// Utility functions
func (c *CLIFramework) trackCommand(cmd string) {
	c.mutex.Lock()
	c.analytics.Commands[cmd]++
	c.mutex.Unlock()
}

func (c *CLIFramework) trackError(errorType, message string) {
	c.mutex.Lock()
	c.analytics.Errors[errorType]++
	c.mutex.Unlock()
}

func generateSessionID() string {
	return fmt.Sprintf("%d", time.Now().UnixNano())
}

// Execute runs the CLI framework
func (c *CLIFramework) Execute() error {
	return c.rootCmd.Execute()
}

// Close cleans up CLI framework resources
func (c *CLIFramework) Close() error {
	// Save analytics
	if c.config.AnalyticsEnabled {
		// Implementation would save analytics data
		log.Printf("CLI ANALYTICS SAVED: commands=%d, errors=%d", 
			len(c.analytics.Commands), len(c.analytics.Errors))
	}
	
	log.Printf("CLI FRAMEWORK SHUTDOWN")
	return nil
} 