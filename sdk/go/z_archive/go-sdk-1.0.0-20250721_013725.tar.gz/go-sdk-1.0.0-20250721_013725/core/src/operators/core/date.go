package core

import (
	"time"
)

// DateOperator handles @date operations
type DateOperator struct{}

// NewDateOperator creates a new date operator
func NewDateOperator() *DateOperator {
	return &DateOperator{}
}

// Execute handles @date operations
func (d *DateOperator) Execute(params string) interface{} {
	// Parse parameters (format: "format_string")
	// Example: @date("2006-01-02 15:04:05")
	
	if params == "" {
		return time.Now().Format("2006-01-02 15:04:05")
	}
	
	// Remove quotes if present
	format := params
	if len(format) >= 2 && (format[0] == '"' || format[0] == '\'') {
		format = format[1 : len(format)-1]
	}
	
	return time.Now().Format(format)
}

// Format formats current time with given format
func (d *DateOperator) Format(format string) string {
	return time.Now().Format(format)
}

// Parse parses a date string with given format
func (d *DateOperator) Parse(dateStr, format string) (time.Time, error) {
	return time.Parse(format, dateStr)
}

// Add adds duration to current time
func (d *DateOperator) Add(duration string) (time.Time, error) {
	dur, err := time.ParseDuration(duration)
	if err != nil {
		return time.Time{}, err
	}
	return time.Now().Add(dur), nil
}

// Sub subtracts duration from current time
func (d *DateOperator) Sub(duration string) (time.Time, error) {
	dur, err := time.ParseDuration(duration)
	if err != nil {
		return time.Time{}, err
	}
	return time.Now().Add(-dur), nil
}

// Unix returns current Unix timestamp
func (d *DateOperator) Unix() int64 {
	return time.Now().Unix()
}

// UnixNano returns current Unix timestamp in nanoseconds
func (d *DateOperator) UnixNano() int64 {
	return time.Now().UnixNano()
} 