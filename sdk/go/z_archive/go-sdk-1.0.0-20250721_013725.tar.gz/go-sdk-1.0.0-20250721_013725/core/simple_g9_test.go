package main

import (
	"fmt"
	"testing"
	"time"
)

// Simple test to verify Goal 9 components can be created
func TestGoal9Simple(t *testing.T) {
	t.Run("MessageQueue", func(t *testing.T) {
		config := QueueConfig{
			DefaultBackend:    "memory",
			Backends:          map[string]string{"memory": "memory"},
			EnableRetry:       false,
			EnableDeadLetter:  false,
			EnableMonitoring:  false,
			EnableCompression: false,
			EnableEncryption:  false,
		}
		
		mq := NewMessageQueue(config)
		if mq == nil {
			t.Fatal("Failed to create MessageQueue")
		}
		
		fmt.Printf("✅ MessageQueue created successfully\n")
	})
	
	t.Run("EventBus", func(t *testing.T) {
		config := EventBusConfig{
			EnableAsync:       false,
			EnableRetry:       false,
			EnableDeadLetter:  false,
			EnableMonitoring:  false,
			EnablePersistence: false,
		}
		
		eb := NewEventBus(config)
		if eb == nil {
			t.Fatal("Failed to create EventBus")
		}
		
		fmt.Printf("✅ EventBus created successfully\n")
	})
	
	t.Run("StreamProcessor", func(t *testing.T) {
		config := StreamConfig{
			DefaultBufferSize:     1000,
			MaxBufferSize:         10000,
			ProcessingTimeout:     30 * time.Second,
			EnableBackpressure:    false,
			EnableCheckpointing:   false,
			EnableMonitoring:      false,
			EnableMetrics:         false,
		}
		
		sp := NewStreamProcessor(config)
		if sp == nil {
			t.Fatal("Failed to create StreamProcessor")
		}
		
		fmt.Printf("✅ StreamProcessor created successfully\n")
	})
}

// Test basic message queue functionality
func TestMessageQueueBasic(t *testing.T) {
	config := QueueConfig{
		DefaultBackend:    "memory",
		Backends:          map[string]string{"memory": "memory"},
		EnableRetry:       false,
		EnableDeadLetter:  false,
		EnableMonitoring:  false,
		EnableCompression: false,
		EnableEncryption:  false,
	}

	mq := NewMessageQueue(config)
	if mq == nil {
		t.Fatal("Failed to create MessageQueue")
	}

	// Test connection
	err := mq.Connect()
	if err != nil {
		t.Fatalf("Failed to connect: %v", err)
	}

	// Test message publishing
	testData := []byte("test message")
	testHeaders := map[string]string{"test": "header"}

	err = mq.Publish("test-queue", testData, testHeaders)
	if err != nil {
		t.Fatalf("Failed to publish message: %v", err)
	}

	fmt.Printf("✅ MessageQueue basic functionality works\n")
}

// Test basic event bus functionality
func TestEventBusBasic(t *testing.T) {
	config := EventBusConfig{
		EnableAsync:       false,
		EnableRetry:       false,
		EnableDeadLetter:  false,
		EnableMonitoring:  false,
		EnablePersistence: false,
	}

	eb := NewEventBus(config)
	if eb == nil {
		t.Fatal("Failed to create EventBus")
	}

	// Test event publishing
	testData := map[string]interface{}{"message": "test event"}
	testHeaders := map[string]string{"test": "header"}

	err := eb.Publish("test.event", testData, testHeaders)
	if err != nil {
		t.Fatalf("Failed to publish event: %v", err)
	}

	fmt.Printf("✅ EventBus basic functionality works\n")
}

// Test basic stream processor functionality
func TestStreamProcessorBasic(t *testing.T) {
	config := StreamConfig{
		DefaultBufferSize:     1000,
		MaxBufferSize:         10000,
		ProcessingTimeout:     30 * time.Second,
		EnableBackpressure:    false,
		EnableCheckpointing:   false,
		EnableMonitoring:      false,
		EnableMetrics:         false,
	}

	sp := NewStreamProcessor(config)
	if sp == nil {
		t.Fatal("Failed to create StreamProcessor")
	}

	// Test stream creation
	stream, err := sp.CreateStream("test-stream", "test-source", map[string]string{
		"field1": "string",
		"field2": "int",
	}, 1, 1)
	if err != nil {
		t.Fatalf("Failed to create stream: %v", err)
	}

	if stream.Name != "test-stream" {
		t.Errorf("Expected stream name 'test-stream', got '%s'", stream.Name)
	}

	fmt.Printf("✅ StreamProcessor basic functionality works\n")
} 