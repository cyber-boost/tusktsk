package main

import (
	"context"
	"database/sql"
	"fmt"
	"sync"
	"time"

	_ "github.com/lib/pq"
	_ "github.com/go-sql-driver/mysql"
	_ "github.com/mattn/go-sqlite3"
)

// DatabaseConnector provides unified database connectivity
type DatabaseConnector struct {
	connections map[string]*DatabaseConnection
	config      DatabaseConfig
	mutex       sync.RWMutex
	pool        *ConnectionPool
}

// DatabaseConnection represents a database connection
type DatabaseConnection struct {
	ID          string            `json:"id"`
	Name        string            `json:"name"`
	Type        string            `json:"type"` // postgres, mysql, sqlite, etc.
	DSN         string            `json:"dsn"`
	DB          *sql.DB           `json:"-"`
	Config      ConnectionConfig  `json:"config"`
	Status      string            `json:"status"` // connected, disconnected, error
	LastUsed    time.Time         `json:"last_used"`
	Stats       *ConnectionStats  `json:"stats"`
	mutex       sync.RWMutex
}

// ConnectionConfig represents connection configuration
type ConnectionConfig struct {
	MaxOpenConns    int           `json:"max_open_conns"`
	MaxIdleConns    int           `json:"max_idle_conns"`
	ConnMaxLifetime time.Duration `json:"conn_max_lifetime"`
	ConnMaxIdleTime time.Duration `json:"conn_max_idle_time"`
	Timeout         time.Duration `json:"timeout"`
	RetryAttempts   int           `json:"retry_attempts"`
	RetryDelay      time.Duration `json:"retry_delay"`
}

// ConnectionStats represents connection statistics
type ConnectionStats struct {
	TotalQueries    int64         `json:"total_queries"`
	FailedQueries   int64         `json:"failed_queries"`
	TotalDuration   time.Duration `json:"total_duration"`
	AverageDuration time.Duration `json:"average_duration"`
	LastQuery       time.Time     `json:"last_query"`
	mutex           sync.RWMutex
}

// DatabaseConfig represents database configuration
type DatabaseConfig struct {
	DefaultConnection string            `json:"default_connection"`
	Connections       map[string]string `json:"connections"`
	PoolConfig        PoolConfig        `json:"pool_config"`
	EnableStats       bool              `json:"enable_stats"`
	EnableHealthCheck bool              `json:"enable_health_check"`
	HealthCheckInterval time.Duration   `json:"health_check_interval"`
}

// ConnectionPool manages database connection pooling
type ConnectionPool struct {
	connections map[string]*sql.DB
	config      PoolConfig
	mutex       sync.RWMutex
}

// PoolConfig represents pool configuration
type PoolConfig struct {
	MaxConnections     int           `json:"max_connections"`
	MinConnections     int           `json:"min_connections"`
	AcquireTimeout     time.Duration `json:"acquire_timeout"`
	IdleTimeout        time.Duration `json:"idle_timeout"`
	MaxLifetime        time.Duration `json:"max_lifetime"`
	HealthCheckTimeout time.Duration `json:"health_check_timeout"`
}

// QueryResult represents a query result
type QueryResult struct {
	RowsAffected int64                   `json:"rows_affected"`
	LastInsertID int64                   `json:"last_insert_id"`
	Data         []map[string]interface{} `json:"data"`
	Error        error                   `json:"error,omitempty"`
	Duration     time.Duration           `json:"duration"`
}

// Transaction represents a database transaction
type Transaction struct {
	Tx      *sql.Tx
	ConnID  string
	Started time.Time
}

// DatabaseConnector creates a new database connector
func NewDatabaseConnector(config DatabaseConfig) *DatabaseConnector {
	dc := &DatabaseConnector{
		connections: make(map[string]*DatabaseConnection),
		config:      config,
		pool: &ConnectionPool{
			connections: make(map[string]*sql.DB),
			config:      config.PoolConfig,
		},
	}

	// Initialize connections
	dc.initializeConnections()

	// Start health checks if enabled
	if config.EnableHealthCheck {
		go dc.startHealthChecks()
	}

	return dc
}

// initializeConnections initializes database connections
func (dc *DatabaseConnector) initializeConnections() {
	for name, dsn := range dc.config.Connections {
		conn := &DatabaseConnection{
			ID:   name,
			Name: name,
			DSN:  dsn,
			Config: ConnectionConfig{
				MaxOpenConns:    10,
				MaxIdleConns:    5,
				ConnMaxLifetime: 1 * time.Hour,
				ConnMaxIdleTime: 30 * time.Minute,
				Timeout:         30 * time.Second,
				RetryAttempts:   3,
				RetryDelay:      1 * time.Second,
			},
			Status: "disconnected",
			Stats:  &ConnectionStats{},
		}

		// Determine database type from DSN
		conn.Type = dc.determineDatabaseType(dsn)

		dc.connections[name] = conn
	}
}

// determineDatabaseType determines database type from DSN
func (dc *DatabaseConnector) determineDatabaseType(dsn string) string {
	if len(dsn) > 0 {
		switch dsn[0] {
		case 'p':
			if len(dsn) > 8 && dsn[:8] == "postgres" {
				return "postgres"
			}
		case 'm':
			if len(dsn) > 5 && dsn[:5] == "mysql" {
				return "mysql"
			}
		case 's':
			if len(dsn) > 6 && dsn[:6] == "sqlite" {
				return "sqlite"
			}
		}
	}
	return "unknown"
}

// Connect establishes connection to a database
func (dc *DatabaseConnector) Connect(connID string) error {
	dc.mutex.Lock()
	defer dc.mutex.Unlock()

	conn, exists := dc.connections[connID]
	if !exists {
		return fmt.Errorf("connection %s not found", connID)
	}

	// Open database connection
	db, err := sql.Open(conn.Type, conn.DSN)
	if err != nil {
		conn.Status = "error"
		return fmt.Errorf("failed to open database connection: %v", err)
	}

	// Configure connection pool
	db.SetMaxOpenConns(conn.Config.MaxOpenConns)
	db.SetMaxIdleConns(conn.Config.MaxIdleConns)
	db.SetConnMaxLifetime(conn.Config.ConnMaxLifetime)
	db.SetConnMaxIdleTime(conn.Config.ConnMaxIdleTime)

	// Test connection
	ctx, cancel := context.WithTimeout(context.Background(), conn.Config.Timeout)
	defer cancel()

	if err := db.PingContext(ctx); err != nil {
		conn.Status = "error"
		return fmt.Errorf("failed to ping database: %v", err)
	}

	conn.DB = db
	conn.Status = "connected"
	conn.LastUsed = time.Now()

	// Add to pool
	dc.pool.connections[connID] = db

	return nil
}

// Disconnect closes a database connection
func (dc *DatabaseConnector) Disconnect(connID string) error {
	dc.mutex.Lock()
	defer dc.mutex.Unlock()

	conn, exists := dc.connections[connID]
	if !exists {
		return fmt.Errorf("connection %s not found", connID)
	}

	if conn.DB != nil {
		if err := conn.DB.Close(); err != nil {
			return fmt.Errorf("failed to close database connection: %v", err)
		}
		conn.DB = nil
	}

	conn.Status = "disconnected"

	// Remove from pool
	delete(dc.pool.connections, connID)

	return nil
}

// GetConnection returns a database connection
func (dc *DatabaseConnector) GetConnection(connID string) (*DatabaseConnection, error) {
	dc.mutex.RLock()
	defer dc.mutex.RUnlock()

	conn, exists := dc.connections[connID]
	if !exists {
		return nil, fmt.Errorf("connection %s not found", connID)
	}

	if conn.Status != "connected" {
		return nil, fmt.Errorf("connection %s is not connected", connID)
	}

	conn.LastUsed = time.Now()
	return conn, nil
}

// ExecuteQuery executes a query on the specified connection
func (dc *DatabaseConnector) ExecuteQuery(connID, query string, args ...interface{}) (*QueryResult, error) {
	conn, err := dc.GetConnection(connID)
	if err != nil {
		return nil, err
	}

	start := time.Now()
	
	// Execute query with retry logic
	var result *QueryResult
	for attempt := 0; attempt <= conn.Config.RetryAttempts; attempt++ {
		result, err = dc.executeQueryWithRetry(conn, query, args...)
		if err == nil {
			break
		}
		
		if attempt < conn.Config.RetryAttempts {
			time.Sleep(conn.Config.RetryDelay)
		}
	}

	duration := time.Since(start)

	// Update stats
	if dc.config.EnableStats {
		conn.updateStats(err == nil, duration)
	}

	if err != nil {
		return nil, err
	}

	result.Duration = duration
	return result, nil
}

// executeQueryWithRetry executes a query with retry logic
func (dc *DatabaseConnector) executeQueryWithRetry(conn *DatabaseConnection, query string, args ...interface{}) (*QueryResult, error) {
	ctx, cancel := context.WithTimeout(context.Background(), conn.Config.Timeout)
	defer cancel()

	rows, err := conn.DB.QueryContext(ctx, query, args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	// Get column names
	columns, err := rows.Columns()
	if err != nil {
		return nil, err
	}

	// Prepare data slice
	var data []map[string]interface{}

	// Create value slice for scanning
	values := make([]interface{}, len(columns))
	valuePtrs := make([]interface{}, len(columns))
	for i := range values {
		valuePtrs[i] = &values[i]
	}

	// Iterate through rows
	for rows.Next() {
		if err := rows.Scan(valuePtrs...); err != nil {
			return nil, err
		}

		// Create row map
		row := make(map[string]interface{})
		for i, col := range columns {
			val := values[i]
			row[col] = val
		}

		data = append(data, row)
	}

	if err := rows.Err(); err != nil {
		return nil, err
	}

	return &QueryResult{
		Data: data,
	}, nil
}

// ExecuteCommand executes a command (INSERT, UPDATE, DELETE) on the specified connection
func (dc *DatabaseConnector) ExecuteCommand(connID, command string, args ...interface{}) (*QueryResult, error) {
	conn, err := dc.GetConnection(connID)
	if err != nil {
		return nil, err
	}

	start := time.Now()

	ctx, cancel := context.WithTimeout(context.Background(), conn.Config.Timeout)
	defer cancel()

	result, err := conn.DB.ExecContext(ctx, command, args...)
	if err != nil {
		if dc.config.EnableStats {
			conn.updateStats(false, time.Since(start))
		}
		return nil, err
	}

	rowsAffected, _ := result.RowsAffected()
	lastInsertID, _ := result.LastInsertId()

	queryResult := &QueryResult{
		RowsAffected: rowsAffected,
		LastInsertID: lastInsertID,
		Duration:     time.Since(start),
	}

	// Update stats
	if dc.config.EnableStats {
		conn.updateStats(true, queryResult.Duration)
	}

	return queryResult, nil
}

// BeginTransaction begins a transaction
func (dc *DatabaseConnector) BeginTransaction(connID string) (*Transaction, error) {
	conn, err := dc.GetConnection(connID)
	if err != nil {
		return nil, err
	}

	ctx, cancel := context.WithTimeout(context.Background(), conn.Config.Timeout)
	defer cancel()

	tx, err := conn.DB.BeginTx(ctx, nil)
	if err != nil {
		return nil, err
	}

	return &Transaction{
		Tx:      tx,
		ConnID:  connID,
		Started: time.Now(),
	}, nil
}

// CommitTransaction commits a transaction
func (dc *DatabaseConnector) CommitTransaction(tx *Transaction) error {
	if tx == nil || tx.Tx == nil {
		return fmt.Errorf("invalid transaction")
	}

	return tx.Tx.Commit()
}

// RollbackTransaction rolls back a transaction
func (dc *DatabaseConnector) RollbackTransaction(tx *Transaction) error {
	if tx == nil || tx.Tx == nil {
		return fmt.Errorf("invalid transaction")
	}

	return tx.Tx.Rollback()
}

// GetConnectionStats returns connection statistics
func (dc *DatabaseConnector) GetConnectionStats(connID string) (*ConnectionStats, error) {
	dc.mutex.RLock()
	defer dc.mutex.RUnlock()

	conn, exists := dc.connections[connID]
	if !exists {
		return nil, fmt.Errorf("connection %s not found", connID)
	}

	return conn.Stats, nil
}

// GetAllConnections returns all connections
func (dc *DatabaseConnector) GetAllConnections() map[string]*DatabaseConnection {
	dc.mutex.RLock()
	defer dc.mutex.RUnlock()

	connections := make(map[string]*DatabaseConnection)
	for key, conn := range dc.connections {
		connections[key] = conn
	}

	return connections
}

// startHealthChecks starts health check monitoring
func (dc *DatabaseConnector) startHealthChecks() {
	ticker := time.NewTicker(dc.config.HealthCheckInterval)
	defer ticker.Stop()

	for {
		select {
		case <-ticker.C:
			dc.performHealthChecks()
		}
	}
}

// performHealthChecks performs health checks on all connections
func (dc *DatabaseConnector) performHealthChecks() {
	dc.mutex.RLock()
	defer dc.mutex.RUnlock()

	for _, conn := range dc.connections {
		if conn.Status == "connected" && conn.DB != nil {
			ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
			err := conn.DB.PingContext(ctx)
			cancel()

			if err != nil {
				conn.Status = "error"
			}
		}
	}
}

// updateStats updates connection statistics
func (conn *DatabaseConnection) updateStats(success bool, duration time.Duration) {
	conn.Stats.mutex.Lock()
	defer conn.Stats.mutex.Unlock()

	conn.Stats.TotalQueries++
	conn.Stats.TotalDuration += duration
	conn.Stats.LastQuery = time.Now()

	if !success {
		conn.Stats.FailedQueries++
	}

	// Calculate average duration
	if conn.Stats.TotalQueries > 0 {
		conn.Stats.AverageDuration = conn.Stats.TotalDuration / time.Duration(conn.Stats.TotalQueries)
	}
}

// Close closes all database connections
func (dc *DatabaseConnector) Close() error {
	dc.mutex.Lock()
	defer dc.mutex.Unlock()

	for _, conn := range dc.connections {
		if conn.DB != nil {
			if err := conn.DB.Close(); err != nil {
				return fmt.Errorf("failed to close connection %s: %v", conn.ID, err)
			}
		}
	}

	return nil
} 