package main

import (
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"crypto/rsa"
	"crypto/sha256"
	"crypto/x509"
	"encoding/base64"
	"encoding/pem"
	"fmt"
	"sync"
	"time"
)

// SecurityManager provides comprehensive security capabilities
type SecurityManager struct {
	encryption   *EncryptionManager
	keyManager   *KeyManager
	policyManager *SecurityPolicyManager
	auditManager *SecurityAuditManager
	config       SecurityConfig
	mutex        sync.RWMutex
}

// EncryptionManager manages encryption operations
type EncryptionManager struct {
	securityManager *SecurityManager
	algorithms      map[string]EncryptionAlgorithm
	config          EncryptionConfig
	mutex           sync.RWMutex
}

// EncryptionAlgorithm interface for encryption algorithms
type EncryptionAlgorithm interface {
	Encrypt(data []byte, key []byte) ([]byte, error)
	Decrypt(data []byte, key []byte) ([]byte, error)
	GetName() string
	GetKeySize() int
}

// KeyManager manages cryptographic keys
type KeyManager struct {
	securityManager *SecurityManager
	keys            map[string]*Key
	config          KeyConfig
	mutex           sync.RWMutex
}

// Key represents a cryptographic key
type Key struct {
	ID          string            `json:"id"`
	Name        string            `json:"name"`
	Type        string            `json:"type"` // aes, rsa, hmac
	Algorithm   string            `json:"algorithm"`
	KeyData     []byte            `json:"-"`
	PublicKey   []byte            `json:"public_key,omitempty"`
	PrivateKey  []byte            `json:"-"`
	CreatedAt   time.Time         `json:"created_at"`
	ExpiresAt   *time.Time        `json:"expires_at"`
	Status      string            `json:"status"` // active, expired, revoked
	Usage       []string          `json:"usage"` // encrypt, decrypt, sign, verify
	Metadata    map[string]string `json:"metadata"`
}

// SecurityPolicyManager manages security policies
type SecurityPolicyManager struct {
	securityManager *SecurityManager
	policies        map[string]*SecurityPolicy
	config          PolicyConfig
	mutex           sync.RWMutex
}

// SecurityPolicy represents a security policy
type SecurityPolicy struct {
	ID          string            `json:"id"`
	Name        string            `json:"name"`
	Description string            `json:"description"`
	Type        string            `json:"type"` // encryption, key_rotation, access_control
	Rules       []*SecurityRule   `json:"rules"`
	Enabled     bool              `json:"enabled"`
	Priority    int               `json:"priority"`
	CreatedAt   time.Time         `json:"created_at"`
	UpdatedAt   time.Time         `json:"updated_at"`
	Metadata    map[string]string `json:"metadata"`
}

// SecurityRule represents a security rule
type SecurityRule struct {
	ID          string            `json:"id"`
	Name        string            `json:"name"`
	Type        string            `json:"type"` // min_key_length, key_rotation_period, algorithm_whitelist
	Condition   string            `json:"condition"`
	Value       interface{}       `json:"value"`
	Action      string            `json:"action"` // allow, deny, warn
	Description string            `json:"description"`
}

// SecurityAuditManager manages security audit logging
type SecurityAuditManager struct {
	securityManager *SecurityManager
	events          []*SecurityEvent
	config          AuditConfig
	mutex           sync.RWMutex
}

// SecurityEvent represents a security event
type SecurityEvent struct {
	ID          string            `json:"id"`
	Type        string            `json:"type"` // encryption, key_operation, policy_violation
	UserID      string            `json:"user_id"`
	Resource    string            `json:"resource"`
	Action      string            `json:"action"`
	Result      string            `json:"result"` // success, failure, warning
	Details     map[string]string `json:"details"`
	Timestamp   time.Time         `json:"timestamp"`
	IPAddress   string            `json:"ip_address"`
	UserAgent   string            `json:"user_agent"`
	Metadata    map[string]string `json:"metadata"`
}

// SecurityConfig represents security configuration
type SecurityConfig struct {
	DefaultAlgorithm    string        `json:"default_algorithm"`
	KeyRotationPeriod   time.Duration `json:"key_rotation_period"`
	EnableAudit         bool          `json:"enable_audit"`
	EnableKeyRotation   bool          `json:"enable_key_rotation"`
	EnablePolicyEnforcement bool      `json:"enable_policy_enforcement"`
	MaxKeyAge           time.Duration `json:"max_key_age"`
	MinKeyLength        int           `json:"min_key_length"`
}

// EncryptionConfig represents encryption configuration
type EncryptionConfig struct {
	DefaultAlgorithm string `json:"default_algorithm"`
	EnableCompression bool  `json:"enable_compression"`
	EnablePadding     bool  `json:"enable_padding"`
}

// KeyConfig represents key configuration
type KeyConfig struct {
	DefaultKeyType     string        `json:"default_key_type"`
	KeyRotationPeriod  time.Duration `json:"key_rotation_period"`
	MaxKeyAge          time.Duration `json:"max_key_age"`
	EnableAutoRotation bool          `json:"enable_auto_rotation"`
}

// PolicyConfig represents policy configuration
type PolicyConfig struct {
	EnableEnforcement bool `json:"enable_enforcement"`
	EnableValidation  bool `json:"enable_validation"`
	EnableMonitoring  bool `json:"enable_monitoring"`
}

// AuditConfig represents audit configuration
type AuditConfig struct {
	EnableLogging     bool          `json:"enable_logging"`
	MaxEvents         int           `json:"max_events"`
	RetentionPeriod   time.Duration `json:"retention_period"`
	EnableCompression bool          `json:"enable_compression"`
}

// AESAlgorithm implements AES encryption
type AESAlgorithm struct {
	keySize int
}

// RSAAlgorithm implements RSA encryption
type RSAAlgorithm struct {
	keySize int
}

// SecurityManager creates a new security manager
func NewSecurityManager(config SecurityConfig) *SecurityManager {
	sm := &SecurityManager{
		config: config,
		encryption: &EncryptionManager{
			algorithms: make(map[string]EncryptionAlgorithm),
			config: EncryptionConfig{
				DefaultAlgorithm: "aes-256-gcm",
				EnableCompression: false,
				EnablePadding:     true,
			},
		},
		keyManager: &KeyManager{
			keys: make(map[string]*Key),
			config: KeyConfig{
				DefaultKeyType:     "aes",
				KeyRotationPeriod:  config.KeyRotationPeriod,
				MaxKeyAge:          config.MaxKeyAge,
				EnableAutoRotation: config.EnableKeyRotation,
			},
		},
		policyManager: &SecurityPolicyManager{
			policies: make(map[string]*SecurityPolicy),
			config: PolicyConfig{
				EnableEnforcement: config.EnablePolicyEnforcement,
				EnableValidation:  true,
				EnableMonitoring:  true,
			},
		},
		auditManager: &SecurityAuditManager{
			events: make([]*SecurityEvent, 0),
			config: AuditConfig{
				EnableLogging:   config.EnableAudit,
				MaxEvents:       10000,
				RetentionPeriod: 30 * 24 * time.Hour, // 30 days
			},
		},
	}

	sm.encryption.securityManager = sm
	sm.keyManager.securityManager = sm
	sm.policyManager.securityManager = sm
	sm.auditManager.securityManager = sm

	// Initialize encryption algorithms
	sm.initializeAlgorithms()

	// Initialize default policies
	sm.initializeDefaultPolicies()

	// Start key rotation if enabled
	if config.EnableKeyRotation {
		go sm.startKeyRotation()
	}

	return sm
}

// initializeAlgorithms initializes encryption algorithms
func (sm *SecurityManager) initializeAlgorithms() {
	// AES algorithms
	aes128 := &AESAlgorithm{keySize: 128}
	aes256 := &AESAlgorithm{keySize: 256}
	sm.encryption.algorithms["aes-128-gcm"] = aes128
	sm.encryption.algorithms["aes-256-gcm"] = aes256

	// RSA algorithms
	rsa2048 := &RSAAlgorithm{keySize: 2048}
	rsa4096 := &RSAAlgorithm{keySize: 4096}
	sm.encryption.algorithms["rsa-2048"] = rsa2048
	sm.encryption.algorithms["rsa-4096"] = rsa4096
}

// initializeDefaultPolicies initializes default security policies
func (sm *SecurityManager) initializeDefaultPolicies() {
	// Encryption policy
	encryptionPolicy := &SecurityPolicy{
		ID:          "encryption_policy",
		Name:        "Encryption Policy",
		Description: "Default encryption policy",
		Type:        "encryption",
		Rules: []*SecurityRule{
			{
				ID:          "min_key_length",
				Name:        "Minimum Key Length",
				Type:        "min_key_length",
				Condition:   "key_length >= 256",
				Value:       256,
				Action:      "deny",
				Description: "Require minimum 256-bit keys",
			},
			{
				ID:          "algorithm_whitelist",
				Name:        "Algorithm Whitelist",
				Type:        "algorithm_whitelist",
				Condition:   "algorithm in [aes-256-gcm, rsa-2048, rsa-4096]",
				Value:       []string{"aes-256-gcm", "rsa-2048", "rsa-4096"},
				Action:      "deny",
				Description: "Only allow approved algorithms",
			},
		},
		Enabled:  true,
		Priority: 100,
	}

	// Key rotation policy
	keyRotationPolicy := &SecurityPolicy{
		ID:          "key_rotation_policy",
		Name:        "Key Rotation Policy",
		Description: "Default key rotation policy",
		Type:        "key_rotation",
		Rules: []*SecurityRule{
			{
				ID:          "rotation_period",
				Name:        "Rotation Period",
				Type:        "rotation_period",
				Condition:   "key_age <= 90_days",
				Value:       90 * 24 * time.Hour,
				Action:      "warn",
				Description: "Rotate keys every 90 days",
			},
		},
		Enabled:  true,
		Priority: 50,
	}

	encryptionPolicy.CreatedAt = time.Now()
	encryptionPolicy.UpdatedAt = time.Now()
	encryptionPolicy.Metadata = make(map[string]string)

	keyRotationPolicy.CreatedAt = time.Now()
	keyRotationPolicy.UpdatedAt = time.Now()
	keyRotationPolicy.Metadata = make(map[string]string)

	sm.policyManager.policies[encryptionPolicy.ID] = encryptionPolicy
	sm.policyManager.policies[keyRotationPolicy.ID] = keyRotationPolicy
}

// Encrypt encrypts data
func (sm *SecurityManager) Encrypt(data []byte, algorithm string, keyID string) ([]byte, error) {
	// Get key
	key, err := sm.keyManager.GetKey(keyID)
	if err != nil {
		return nil, err
	}

	// Get algorithm
	alg, exists := sm.encryption.algorithms[algorithm]
	if !exists {
		return nil, fmt.Errorf("algorithm %s not supported", algorithm)
	}

	// Check policy compliance
	if sm.config.EnablePolicyEnforcement {
		if err := sm.policyManager.checkEncryptionPolicy(algorithm, key); err != nil {
			sm.auditManager.logEvent("encryption", "policy_violation", "failure", map[string]string{
				"algorithm": algorithm,
				"key_id":    keyID,
				"error":     err.Error(),
			})
			return nil, err
		}
	}

	// Encrypt data
	encrypted, err := alg.Encrypt(data, key.KeyData)
	if err != nil {
		sm.auditManager.logEvent("encryption", "encryption_failure", "failure", map[string]string{
			"algorithm": algorithm,
			"key_id":    keyID,
			"error":     err.Error(),
		})
		return nil, err
	}

	// Log success
	sm.auditManager.logEvent("encryption", "encryption_success", "success", map[string]string{
		"algorithm": algorithm,
		"key_id":    keyID,
		"data_size": fmt.Sprintf("%d", len(data)),
	})

	return encrypted, nil
}

// Decrypt decrypts data
func (sm *SecurityManager) Decrypt(data []byte, algorithm string, keyID string) ([]byte, error) {
	// Get key
	key, err := sm.keyManager.GetKey(keyID)
	if err != nil {
		return nil, err
	}

	// Get algorithm
	alg, exists := sm.encryption.algorithms[algorithm]
	if !exists {
		return nil, fmt.Errorf("algorithm %s not supported", algorithm)
	}

	// Decrypt data
	decrypted, err := alg.Decrypt(data, key.KeyData)
	if err != nil {
		sm.auditManager.logEvent("decryption", "decryption_failure", "failure", map[string]string{
			"algorithm": algorithm,
			"key_id":    keyID,
			"error":     err.Error(),
		})
		return nil, err
	}

	// Log success
	sm.auditManager.logEvent("decryption", "decryption_success", "success", map[string]string{
		"algorithm": algorithm,
		"key_id":    keyID,
		"data_size": fmt.Sprintf("%d", len(decrypted)),
	})

	return decrypted, nil
}

// GenerateKey generates a new key
func (sm *SecurityManager) GenerateKey(name, keyType, algorithm string) (*Key, error) {
	// Check policy compliance
	if sm.config.EnablePolicyEnforcement {
		if err := sm.policyManager.checkKeyGenerationPolicy(keyType, algorithm); err != nil {
			sm.auditManager.logEvent("key_generation", "policy_violation", "failure", map[string]string{
				"key_type":  keyType,
				"algorithm": algorithm,
				"error":     err.Error(),
			})
			return nil, err
		}
	}

	// Generate key
	key, err := sm.keyManager.GenerateKey(name, keyType, algorithm)
	if err != nil {
		sm.auditManager.logEvent("key_generation", "generation_failure", "failure", map[string]string{
			"key_type":  keyType,
			"algorithm": algorithm,
			"error":     err.Error(),
		})
		return nil, err
	}

	// Log success
	sm.auditManager.logEvent("key_generation", "generation_success", "success", map[string]string{
		"key_id":    key.ID,
		"key_type":  keyType,
		"algorithm": algorithm,
	})

	return key, nil
}

// GetKey returns a key by ID
func (sm *SecurityManager) GetKey(keyID string) (*Key, error) {
	return sm.keyManager.GetKey(keyID)
}

// ListKeys lists all keys
func (sm *SecurityManager) ListKeys() []*Key {
	return sm.keyManager.ListKeys()
}

// RotateKey rotates a key
func (sm *SecurityManager) RotateKey(keyID string) error {
	// Check if key exists
	oldKey, err := sm.keyManager.GetKey(keyID)
	if err != nil {
		return err
	}

	// Generate new key
	newKey, err := sm.keyManager.GenerateKey(oldKey.Name+"_new", oldKey.Type, oldKey.Algorithm)
	if err != nil {
		return err
	}

	// Mark old key as expired
	sm.keyManager.ExpireKey(keyID)

	// Log rotation
	sm.auditManager.logEvent("key_rotation", "rotation_success", "success", map[string]string{
		"old_key_id": keyID,
		"new_key_id": newKey.ID,
		"key_type":   oldKey.Type,
	})

	return nil
}

// CreatePolicy creates a security policy
func (sm *SecurityManager) CreatePolicy(policy *SecurityPolicy) error {
	return sm.policyManager.CreatePolicy(policy)
}

// GetPolicy returns a policy by ID
func (sm *SecurityManager) GetPolicy(policyID string) (*SecurityPolicy, error) {
	return sm.policyManager.GetPolicy(policyID)
}

// ListPolicies lists all policies
func (sm *SecurityManager) ListPolicies() []*SecurityPolicy {
	return sm.policyManager.ListPolicies()
}

// GetEvents returns security events
func (sm *SecurityManager) GetEvents() []*SecurityEvent {
	return sm.auditManager.GetEvents()
}

// startKeyRotation starts automatic key rotation
func (sm *SecurityManager) startKeyRotation() {
	ticker := time.NewTicker(sm.config.KeyRotationPeriod)
	defer ticker.Stop()

	for {
		select {
		case <-ticker.C:
			sm.performKeyRotation()
		}
	}
}

// performKeyRotation performs key rotation
func (sm *SecurityManager) performKeyRotation() {
	keys := sm.keyManager.ListKeys()
	now := time.Now()

	for _, key := range keys {
		if key.ExpiresAt != nil && now.After(*key.ExpiresAt) {
			// Key is expired, rotate it
			sm.RotateKey(key.ID)
		}
	}
}

// GetStats returns security manager statistics
func (sm *SecurityManager) GetStats() map[string]interface{} {
	sm.mutex.RLock()
	defer sm.mutex.RUnlock()

	stats := map[string]interface{}{
		"algorithms": len(sm.encryption.algorithms),
		"keys":       len(sm.keyManager.keys),
		"policies":   len(sm.policyManager.policies),
		"config":     sm.config,
	}

	// Calculate key statistics
	activeKeys := 0
	expiredKeys := 0
	for _, key := range sm.keyManager.keys {
		if key.Status == "active" {
			activeKeys++
		} else if key.Status == "expired" {
			expiredKeys++
		}
	}

	stats["active_keys"] = activeKeys
	stats["expired_keys"] = expiredKeys

	// Calculate audit statistics
	if sm.config.EnableAudit {
		stats["audit_events"] = len(sm.auditManager.events)
	}

	return stats
}

// AESAlgorithm implementation
func (aes *AESAlgorithm) Encrypt(data []byte, key []byte) ([]byte, error) {
	block, err := aes.NewCipher(key)
	if err != nil {
		return nil, err
	}

	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return nil, err
	}

	nonce := make([]byte, gcm.NonceSize())
	if _, err := rand.Read(nonce); err != nil {
		return nil, err
	}

	return gcm.Seal(nonce, nonce, data, nil), nil
}

func (aes *AESAlgorithm) Decrypt(data []byte, key []byte) ([]byte, error) {
	block, err := aes.NewCipher(key)
	if err != nil {
		return nil, err
	}

	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return nil, err
	}

	nonceSize := gcm.NonceSize()
	if len(data) < nonceSize {
		return nil, fmt.Errorf("ciphertext too short")
	}

	nonce, ciphertext := data[:nonceSize], data[nonceSize:]
	return gcm.Open(nil, nonce, ciphertext, nil)
}

func (aes *AESAlgorithm) GetName() string {
	return fmt.Sprintf("aes-%d-gcm", aes.keySize)
}

func (aes *AESAlgorithm) GetKeySize() int {
	return aes.keySize
}

// RSAAlgorithm implementation
func (rsa *RSAAlgorithm) Encrypt(data []byte, key []byte) ([]byte, error) {
	// This would implement RSA encryption
	// For now, just a placeholder
	return data, nil
}

func (rsa *RSAAlgorithm) Decrypt(data []byte, key []byte) ([]byte, error) {
	// This would implement RSA decryption
	// For now, just a placeholder
	return data, nil
}

func (rsa *RSAAlgorithm) GetName() string {
	return fmt.Sprintf("rsa-%d", rsa.keySize)
}

func (rsa *RSAAlgorithm) GetKeySize() int {
	return rsa.keySize
}

// KeyManager implementation
func (km *KeyManager) GenerateKey(name, keyType, algorithm string) (*Key, error) {
	km.mutex.Lock()
	defer km.mutex.Unlock()

	keyID := generateKeyID()
	key := &Key{
		ID:        keyID,
		Name:      name,
		Type:      keyType,
		Algorithm: algorithm,
		CreatedAt: time.Now(),
		Status:    "active",
		Usage:     []string{"encrypt", "decrypt"},
		Metadata:  make(map[string]string),
	}

	// Generate key data based on type
	switch keyType {
	case "aes":
		key.KeyData = make([]byte, 32) // 256-bit key
		if _, err := rand.Read(key.KeyData); err != nil {
			return nil, err
		}
	case "rsa":
		privateKey, err := rsa.GenerateKey(rand.Reader, 2048)
		if err != nil {
			return nil, err
		}

		// Encode private key
		privateKeyBytes := x509.MarshalPKCS1PrivateKey(privateKey)
		key.PrivateKey = privateKeyBytes

		// Encode public key
		publicKeyBytes := x509.MarshalPKCS1PublicKey(&privateKey.PublicKey)
		key.PublicKey = publicKeyBytes
		key.KeyData = publicKeyBytes
	}

	km.keys[keyID] = key
	return key, nil
}

func (km *KeyManager) GetKey(keyID string) (*Key, error) {
	km.mutex.RLock()
	defer km.mutex.RUnlock()

	key, exists := km.keys[keyID]
	if !exists {
		return nil, fmt.Errorf("key %s not found", keyID)
	}

	return key, nil
}

func (km *KeyManager) ListKeys() []*Key {
	km.mutex.RLock()
	defer km.mutex.RUnlock()

	keys := make([]*Key, 0, len(km.keys))
	for _, key := range km.keys {
		keys = append(keys, key)
	}

	return keys
}

func (km *KeyManager) ExpireKey(keyID string) error {
	km.mutex.Lock()
	defer km.mutex.Unlock()

	key, exists := km.keys[keyID]
	if !exists {
		return fmt.Errorf("key %s not found", keyID)
	}

	key.Status = "expired"
	now := time.Now()
	key.ExpiresAt = &now

	return nil
}

// generateKeyID generates a unique key ID
func generateKeyID() string {
	return fmt.Sprintf("key_%d", time.Now().UnixNano())
}

// SecurityPolicyManager implementation
func (spm *SecurityPolicyManager) CreatePolicy(policy *SecurityPolicy) error {
	spm.mutex.Lock()
	defer spm.mutex.Unlock()

	if _, exists := spm.policies[policy.ID]; exists {
		return fmt.Errorf("policy %s already exists", policy.ID)
	}

	policy.CreatedAt = time.Now()
	policy.UpdatedAt = time.Now()
	if policy.Metadata == nil {
		policy.Metadata = make(map[string]string)
	}

	spm.policies[policy.ID] = policy
	return nil
}

func (spm *SecurityPolicyManager) GetPolicy(policyID string) (*SecurityPolicy, error) {
	spm.mutex.RLock()
	defer spm.mutex.RUnlock()

	policy, exists := spm.policies[policyID]
	if !exists {
		return nil, fmt.Errorf("policy %s not found", policyID)
	}

	return policy, nil
}

func (spm *SecurityPolicyManager) ListPolicies() []*SecurityPolicy {
	spm.mutex.RLock()
	defer spm.mutex.RUnlock()

	policies := make([]*SecurityPolicy, 0, len(spm.policies))
	for _, policy := range spm.policies {
		policies = append(policies, policy)
	}

	return policies
}

func (spm *SecurityPolicyManager) checkEncryptionPolicy(algorithm string, key *Key) error {
	// Check encryption policies
	for _, policy := range spm.policies {
		if !policy.Enabled || policy.Type != "encryption" {
			continue
		}

		for _, rule := range policy.Rules {
			if rule.Type == "algorithm_whitelist" {
				allowedAlgorithms := rule.Value.([]string)
				found := false
				for _, allowed := range allowedAlgorithms {
					if allowed == algorithm {
						found = true
						break
					}
				}
				if !found {
					return fmt.Errorf("algorithm %s not allowed by policy", algorithm)
				}
			}
		}
	}

	return nil
}

func (spm *SecurityPolicyManager) checkKeyGenerationPolicy(keyType, algorithm string) error {
	// Check key generation policies
	for _, policy := range spm.policies {
		if !policy.Enabled || policy.Type != "encryption" {
			continue
		}

		for _, rule := range policy.Rules {
			if rule.Type == "min_key_length" {
				minLength := rule.Value.(int)
				if keyType == "aes" && minLength > 256 {
					return fmt.Errorf("key length too short for policy")
				}
			}
		}
	}

	return nil
}

// SecurityAuditManager implementation
func (sam *SecurityAuditManager) logEvent(eventType, action, result string, details map[string]string) {
	sam.mutex.Lock()
	defer sam.mutex.Unlock()

	event := &SecurityEvent{
		ID:        generateEventID(),
		Type:      eventType,
		Action:    action,
		Result:    result,
		Details:   details,
		Timestamp: time.Now(),
		Metadata:  make(map[string]string),
	}

	sam.events = append(sam.events, event)

	// Limit events if configured
	if len(sam.events) > sam.config.MaxEvents {
		sam.events = sam.events[1:]
	}
}

func (sam *SecurityAuditManager) GetEvents() []*SecurityEvent {
	sam.mutex.RLock()
	defer sam.mutex.RUnlock()

	events := make([]*SecurityEvent, len(sam.events))
	copy(events, sam.events)
	return events
} 