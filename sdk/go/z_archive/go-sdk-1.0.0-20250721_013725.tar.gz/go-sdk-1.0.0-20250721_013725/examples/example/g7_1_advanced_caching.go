package main

import (
	"context"
	"encoding/json"
	"fmt"
	"sync"
	"time"
)

// AdvancedCache provides sophisticated caching capabilities
type AdvancedCache struct {
	strategies map[string]CacheStrategy
	config     CacheConfig
	mutex      sync.RWMutex
	stats      *CacheStats
}

// CacheStrategy interface for different caching strategies
type CacheStrategy interface {
	Get(key string) (interface{}, bool)
	Set(key string, value interface{}, ttl time.Duration)
	Delete(key string)
	Clear()
	GetStats() map[string]interface{}
}

// CacheConfig represents cache configuration
type CacheConfig struct {
	DefaultTTL       time.Duration `json:"default_ttl"`
	MaxSize          int           `json:"max_size"`
	EvictionPolicy   string        `json:"eviction_policy"` // lru, lfu, fifo, random
	CleanupInterval  time.Duration `json:"cleanup_interval"`
	EnableStats      bool          `json:"enable_stats"`
	Compression      bool          `json:"compression"`
	Persistence      bool          `json:"persistence"`
	PersistencePath  string        `json:"persistence_path"`
}

// CacheStats represents cache statistics
type CacheStats struct {
	Hits        int64         `json:"hits"`
	Misses      int64         `json:"misses"`
	Evictions   int64         `json:"evictions"`
	Size        int           `json:"size"`
	LastAccess  time.Time     `json:"last_access"`
	HitRate     float64       `json:"hit_rate"`
	TotalAccess int64         `json:"total_access"`
	mutex       sync.RWMutex
}

// LRUCache implements Least Recently Used cache strategy
type LRUCache struct {
	capacity int
	cache    map[string]*LRUNode
	head     *LRUNode
	tail     *LRUNode
	mutex    sync.RWMutex
}

// LRUNode represents a node in LRU cache
type LRUNode struct {
	key      string
	value    interface{}
	expiry   time.Time
	prev     *LRUNode
	next     *LRUNode
}

// LFUCache implements Least Frequently Used cache strategy
type LFUCache struct {
	capacity int
	cache    map[string]*LFUNode
	freqMap  map[int]*FreqNode
	minFreq  int
	mutex    sync.RWMutex
}

// LFUNode represents a node in LFU cache
type LFUNode struct {
	key      string
	value    interface{}
	freq     int
	expiry   time.Time
	prev     *LFUNode
	next     *LFUNode
}

// FreqNode represents a frequency node in LFU cache
type FreqNode struct {
	freq int
	head *LFUNode
	tail *LFUNode
	prev *FreqNode
	next *FreqNode
}

// FIFOCache implements First In First Out cache strategy
type FIFOCache struct {
	capacity int
	cache    map[string]*FIFONode
	head     *FIFONode
	tail     *FIFONode
	mutex    sync.RWMutex
}

// FIFONode represents a node in FIFO cache
type FIFONode struct {
	key    string
	value  interface{}
	expiry time.Time
	next   *FIFONode
}

// RandomCache implements Random eviction cache strategy
type RandomCache struct {
	capacity int
	cache    map[string]*RandomNode
	keys     []string
	mutex    sync.RWMutex
}

// RandomNode represents a node in Random cache
type RandomNode struct {
	key    string
	value  interface{}
	expiry time.Time
}

// AdvancedCache creates a new advanced cache
func NewAdvancedCache(config CacheConfig) *AdvancedCache {
	cache := &AdvancedCache{
		strategies: make(map[string]CacheStrategy),
		config:     config,
		stats:      &CacheStats{},
	}

	// Initialize strategies
	cache.initializeStrategies()

	// Start cleanup goroutine
	if config.CleanupInterval > 0 {
		go cache.startCleanup()
	}

	return cache
}

// initializeStrategies initializes all cache strategies
func (ac *AdvancedCache) initializeStrategies() {
	// LRU Cache
	ac.strategies["lru"] = NewLRUCache(ac.config.MaxSize)

	// LFU Cache
	ac.strategies["lfu"] = NewLFUCache(ac.config.MaxSize)

	// FIFO Cache
	ac.strategies["fifo"] = NewFIFOCache(ac.config.MaxSize)

	// Random Cache
	ac.strategies["random"] = NewRandomCache(ac.config.MaxSize)
}

// Get retrieves a value from cache
func (ac *AdvancedCache) Get(key string) (interface{}, bool) {
	ac.mutex.RLock()
	strategy, exists := ac.strategies[ac.config.EvictionPolicy]
	ac.mutex.RUnlock()

	if !exists {
		return nil, false
	}

	value, found := strategy.Get(key)
	
	// Update stats
	ac.updateStats(found)
	
	return value, found
}

// Set stores a value in cache
func (ac *AdvancedCache) Set(key string, value interface{}, ttl time.Duration) {
	if ttl == 0 {
		ttl = ac.config.DefaultTTL
	}

	ac.mutex.RLock()
	strategy, exists := ac.strategies[ac.config.EvictionPolicy]
	ac.mutex.RUnlock()

	if exists {
		strategy.Set(key, value, ttl)
	}
}

// Delete removes a value from cache
func (ac *AdvancedCache) Delete(key string) {
	ac.mutex.RLock()
	strategy, exists := ac.strategies[ac.config.EvictionPolicy]
	ac.mutex.RUnlock()

	if exists {
		strategy.Delete(key)
	}
}

// Clear clears all cache data
func (ac *AdvancedCache) Clear() {
	ac.mutex.RLock()
	defer ac.mutex.RUnlock()

	for _, strategy := range ac.strategies {
		strategy.Clear()
	}
}

// SetStrategy sets the active cache strategy
func (ac *AdvancedCache) SetStrategy(strategy string) {
	ac.mutex.Lock()
	defer ac.mutex.Unlock()

	if _, exists := ac.strategies[strategy]; exists {
		ac.config.EvictionPolicy = strategy
	}
}

// GetStats returns cache statistics
func (ac *AdvancedCache) GetStats() map[string]interface{} {
	ac.mutex.RLock()
	defer ac.mutex.RUnlock()

	stats := map[string]interface{}{
		"active_strategy": ac.config.EvictionPolicy,
		"total_strategies": len(ac.strategies),
		"config":          ac.config,
	}

	if ac.config.EnableStats {
		ac.stats.mutex.RLock()
		stats["performance"] = map[string]interface{}{
			"hits":        ac.stats.Hits,
			"misses":      ac.stats.Misses,
			"evictions":   ac.stats.Evictions,
			"hit_rate":    ac.stats.HitRate,
			"total_access": ac.stats.TotalAccess,
			"last_access": ac.stats.LastAccess,
		}
		ac.stats.mutex.RUnlock()
	}

	// Add strategy-specific stats
	if strategy, exists := ac.strategies[ac.config.EvictionPolicy]; exists {
		stats["strategy_stats"] = strategy.GetStats()
	}

	return stats
}

// updateStats updates cache statistics
func (ac *AdvancedCache) updateStats(hit bool) {
	if !ac.config.EnableStats {
		return
	}

	ac.stats.mutex.Lock()
	defer ac.stats.mutex.Unlock()

	ac.stats.TotalAccess++
	ac.stats.LastAccess = time.Now()

	if hit {
		ac.stats.Hits++
	} else {
		ac.stats.Misses++
	}

	// Calculate hit rate
	if ac.stats.TotalAccess > 0 {
		ac.stats.HitRate = float64(ac.stats.Hits) / float64(ac.stats.TotalAccess)
	}
}

// startCleanup starts the cleanup goroutine
func (ac *AdvancedCache) startCleanup() {
	ticker := time.NewTicker(ac.config.CleanupInterval)
	defer ticker.Stop()

	for {
		select {
		case <-ticker.C:
			ac.cleanup()
		}
	}
}

// cleanup removes expired entries
func (ac *AdvancedCache) cleanup() {
	ac.mutex.RLock()
	strategy, exists := ac.strategies[ac.config.EvictionPolicy]
	ac.mutex.RUnlock()

	if exists {
		// This would be implemented in each strategy
		// For now, just a placeholder
	}
}

// LRUCache implementation
func NewLRUCache(capacity int) *LRUCache {
	cache := &LRUCache{
		capacity: capacity,
		cache:    make(map[string]*LRUNode),
	}
	
	// Initialize dummy head and tail
	cache.head = &LRUNode{}
	cache.tail = &LRUNode{}
	cache.head.next = cache.tail
	cache.tail.prev = cache.head
	
	return cache
}

func (lru *LRUCache) Get(key string) (interface{}, bool) {
	lru.mutex.Lock()
	defer lru.mutex.Unlock()

	if node, exists := lru.cache[key]; exists {
		// Check expiry
		if !node.expiry.IsZero() && time.Now().After(node.expiry) {
			lru.removeNode(node)
			delete(lru.cache, key)
			return nil, false
		}

		// Move to front
		lru.moveToFront(node)
		return node.value, true
	}

	return nil, false
}

func (lru *LRUCache) Set(key string, value interface{}, ttl time.Duration) {
	lru.mutex.Lock()
	defer lru.mutex.Unlock()

	var expiry time.Time
	if ttl > 0 {
		expiry = time.Now().Add(ttl)
	}

	if node, exists := lru.cache[key]; exists {
		// Update existing node
		node.value = value
		node.expiry = expiry
		lru.moveToFront(node)
	} else {
		// Create new node
		node = &LRUNode{
			key:    key,
			value:  value,
			expiry: expiry,
		}

		lru.cache[key] = node
		lru.addToFront(node)

		// Check capacity
		if len(lru.cache) > lru.capacity {
			lru.evict()
		}
	}
}

func (lru *LRUCache) Delete(key string) {
	lru.mutex.Lock()
	defer lru.mutex.Unlock()

	if node, exists := lru.cache[key]; exists {
		lru.removeNode(node)
		delete(lru.cache, key)
	}
}

func (lru *LRUCache) Clear() {
	lru.mutex.Lock()
	defer lru.mutex.Unlock()

	lru.cache = make(map[string]*LRUNode)
	lru.head.next = lru.tail
	lru.tail.prev = lru.head
}

func (lru *LRUCache) GetStats() map[string]interface{} {
	lru.mutex.RLock()
	defer lru.mutex.RUnlock()

	return map[string]interface{}{
		"size":     len(lru.cache),
		"capacity": lru.capacity,
		"strategy": "lru",
	}
}

func (lru *LRUCache) moveToFront(node *LRUNode) {
	lru.removeNode(node)
	lru.addToFront(node)
}

func (lru *LRUCache) addToFront(node *LRUNode) {
	node.next = lru.head.next
	node.prev = lru.head
	lru.head.next.prev = node
	lru.head.next = node
}

func (lru *LRUCache) removeNode(node *LRUNode) {
	node.prev.next = node.next
	node.next.prev = node.prev
}

func (lru *LRUCache) evict() {
	if lru.tail.prev != lru.head {
		node := lru.tail.prev
		lru.removeNode(node)
		delete(lru.cache, node.key)
	}
}

// LFUCache implementation
func NewLFUCache(capacity int) *LFUCache {
	return &LFUCache{
		capacity: capacity,
		cache:    make(map[string]*LFUNode),
		freqMap:  make(map[int]*FreqNode),
		minFreq:  0,
	}
}

func (lfu *LFUCache) Get(key string) (interface{}, bool) {
	lfu.mutex.Lock()
	defer lfu.mutex.Unlock()

	if node, exists := lfu.cache[key]; exists {
		// Check expiry
		if !node.expiry.IsZero() && time.Now().After(node.expiry) {
			lfu.removeNode(node)
			delete(lfu.cache, key)
			return nil, false
		}

		// Update frequency
		lfu.updateFrequency(node)
		return node.value, true
	}

	return nil, false
}

func (lfu *LFUCache) Set(key string, value interface{}, ttl time.Duration) {
	lfu.mutex.Lock()
	defer lfu.mutex.Unlock()

	var expiry time.Time
	if ttl > 0 {
		expiry = time.Now().Add(ttl)
	}

	if node, exists := lfu.cache[key]; exists {
		// Update existing node
		node.value = value
		node.expiry = expiry
		lfu.updateFrequency(node)
	} else {
		// Create new node
		node = &LFUNode{
			key:    key,
			value:  value,
			freq:   1,
			expiry: expiry,
		}

		lfu.cache[key] = node
		lfu.addToFreqMap(node)

		// Check capacity
		if len(lfu.cache) > lfu.capacity {
			lfu.evict()
		}
	}
}

func (lfu *LFUCache) Delete(key string) {
	lfu.mutex.Lock()
	defer lfu.mutex.Unlock()

	if node, exists := lfu.cache[key]; exists {
		lfu.removeNode(node)
		delete(lfu.cache, key)
	}
}

func (lfu *LFUCache) Clear() {
	lfu.mutex.Lock()
	defer lfu.mutex.Unlock()

	lfu.cache = make(map[string]*LFUNode)
	lfu.freqMap = make(map[int]*FreqNode)
	lfu.minFreq = 0
}

func (lfu *LFUCache) GetStats() map[string]interface{} {
	lfu.mutex.RLock()
	defer lfu.mutex.RUnlock()

	return map[string]interface{}{
		"size":     len(lfu.cache),
		"capacity": lfu.capacity,
		"strategy": "lfu",
		"min_freq": lfu.minFreq,
	}
}

func (lfu *LFUCache) updateFrequency(node *LFUNode) {
	// Remove from current frequency
	lfu.removeFromFreqMap(node)
	
	// Update frequency
	node.freq++
	
	// Add to new frequency
	lfu.addToFreqMap(node)
}

func (lfu *LFUCache) addToFreqMap(node *LFUNode) {
	freq := node.freq
	
	if freqNode, exists := lfu.freqMap[freq]; exists {
		// Add to existing frequency node
		node.next = freqNode.head.next
		node.prev = freqNode.head
		freqNode.head.next.prev = node
		freqNode.head.next = node
	} else {
		// Create new frequency node
		freqNode = &FreqNode{
			freq: freq,
			head: &LFUNode{},
			tail: &LFUNode{},
		}
		freqNode.head.next = freqNode.tail
		freqNode.tail.prev = freqNode.head
		
		// Add node to frequency
		node.next = freqNode.head.next
		node.prev = freqNode.head
		freqNode.head.next.prev = node
		freqNode.head.next = node
		
		lfu.freqMap[freq] = freqNode
	}
	
	// Update min frequency
	if freq < lfu.minFreq || lfu.minFreq == 0 {
		lfu.minFreq = freq
	}
}

func (lfu *LFUCache) removeFromFreqMap(node *LFUNode) {
	freq := node.freq
	
	if freqNode, exists := lfu.freqMap[freq]; exists {
		// Remove from frequency node
		node.prev.next = node.next
		node.next.prev = node.prev
		
		// If frequency node is empty, remove it
		if freqNode.head.next == freqNode.tail {
			delete(lfu.freqMap, freq)
			
			// Update min frequency
			if freq == lfu.minFreq {
				lfu.minFreq = 0
				for f := range lfu.freqMap {
					if lfu.minFreq == 0 || f < lfu.minFreq {
						lfu.minFreq = f
					}
				}
			}
		}
	}
}

func (lfu *LFUCache) removeNode(node *LFUNode) {
	lfu.removeFromFreqMap(node)
}

func (lfu *LFUCache) evict() {
	if freqNode, exists := lfu.freqMap[lfu.minFreq]; exists {
		if freqNode.head.next != freqNode.tail {
			node := freqNode.head.next
			lfu.removeNode(node)
			delete(lfu.cache, node.key)
		}
	}
}

// FIFOCache implementation
func NewFIFOCache(capacity int) *FIFOCache {
	cache := &FIFOCache{
		capacity: capacity,
		cache:    make(map[string]*FIFONode),
	}
	
	return cache
}

func (fifo *FIFOCache) Get(key string) (interface{}, bool) {
	fifo.mutex.RLock()
	defer fifo.mutex.RUnlock()

	if node, exists := fifo.cache[key]; exists {
		// Check expiry
		if !node.expiry.IsZero() && time.Now().After(node.expiry) {
			return nil, false
		}
		return node.value, true
	}

	return nil, false
}

func (fifo *FIFOCache) Set(key string, value interface{}, ttl time.Duration) {
	fifo.mutex.Lock()
	defer fifo.mutex.Unlock()

	var expiry time.Time
	if ttl > 0 {
		expiry = time.Now().Add(ttl)
	}

	if _, exists := fifo.cache[key]; exists {
		// Update existing node
		fifo.cache[key].value = value
		fifo.cache[key].expiry = expiry
	} else {
		// Create new node
		node := &FIFONode{
			key:    key,
			value:  value,
			expiry: expiry,
		}

		fifo.cache[key] = node

		// Add to queue
		if fifo.head == nil {
			fifo.head = node
			fifo.tail = node
		} else {
			fifo.tail.next = node
			fifo.tail = node
		}

		// Check capacity
		if len(fifo.cache) > fifo.capacity {
			fifo.evict()
		}
	}
}

func (fifo *FIFOCache) Delete(key string) {
	fifo.mutex.Lock()
	defer fifo.mutex.Unlock()

	if node, exists := fifo.cache[key]; exists {
		// Remove from queue
		if fifo.head == node {
			fifo.head = node.next
		} else {
			current := fifo.head
			for current != nil && current.next != node {
				current = current.next
			}
			if current != nil {
				current.next = node.next
			}
		}
		
		delete(fifo.cache, key)
	}
}

func (fifo *FIFOCache) Clear() {
	fifo.mutex.Lock()
	defer fifo.mutex.Unlock()

	fifo.cache = make(map[string]*FIFONode)
	fifo.head = nil
	fifo.tail = nil
}

func (fifo *FIFOCache) GetStats() map[string]interface{} {
	fifo.mutex.RLock()
	defer fifo.mutex.RUnlock()

	return map[string]interface{}{
		"size":     len(fifo.cache),
		"capacity": fifo.capacity,
		"strategy": "fifo",
	}
}

func (fifo *FIFOCache) evict() {
	if fifo.head != nil {
		oldHead := fifo.head
		fifo.head = oldHead.next
		delete(fifo.cache, oldHead.key)
	}
}

// RandomCache implementation
func NewRandomCache(capacity int) *RandomCache {
	return &RandomCache{
		capacity: capacity,
		cache:    make(map[string]*RandomNode),
		keys:     make([]string, 0),
	}
}

func (rc *RandomCache) Get(key string) (interface{}, bool) {
	rc.mutex.RLock()
	defer rc.mutex.RUnlock()

	if node, exists := rc.cache[key]; exists {
		// Check expiry
		if !node.expiry.IsZero() && time.Now().After(node.expiry) {
			return nil, false
		}
		return node.value, true
	}

	return nil, false
}

func (rc *RandomCache) Set(key string, value interface{}, ttl time.Duration) {
	rc.mutex.Lock()
	defer rc.mutex.Unlock()

	var expiry time.Time
	if ttl > 0 {
		expiry = time.Now().Add(ttl)
	}

	if _, exists := rc.cache[key]; exists {
		// Update existing node
		rc.cache[key].value = value
		rc.cache[key].expiry = expiry
	} else {
		// Create new node
		node := &RandomNode{
			key:    key,
			value:  value,
			expiry: expiry,
		}

		rc.cache[key] = node
		rc.keys = append(rc.keys, key)

		// Check capacity
		if len(rc.cache) > rc.capacity {
			rc.evict()
		}
	}
}

func (rc *RandomCache) Delete(key string) {
	rc.mutex.Lock()
	defer rc.mutex.Unlock()

	if _, exists := rc.cache[key]; exists {
		delete(rc.cache, key)
		
		// Remove from keys slice
		for i, k := range rc.keys {
			if k == key {
				rc.keys = append(rc.keys[:i], rc.keys[i+1:]...)
				break
			}
		}
	}
}

func (rc *RandomCache) Clear() {
	rc.mutex.Lock()
	defer rc.mutex.Unlock()

	rc.cache = make(map[string]*RandomNode)
	rc.keys = make([]string, 0)
}

func (rc *RandomCache) GetStats() map[string]interface{} {
	rc.mutex.RLock()
	defer rc.mutex.RUnlock()

	return map[string]interface{}{
		"size":     len(rc.cache),
		"capacity": rc.capacity,
		"strategy": "random",
	}
}

func (rc *RandomCache) evict() {
	if len(rc.keys) > 0 {
		// Random eviction
		index := int(time.Now().UnixNano()) % len(rc.keys)
		key := rc.keys[index]
		
		delete(rc.cache, key)
		rc.keys = append(rc.keys[:index], rc.keys[index+1:]...)
	}
} 