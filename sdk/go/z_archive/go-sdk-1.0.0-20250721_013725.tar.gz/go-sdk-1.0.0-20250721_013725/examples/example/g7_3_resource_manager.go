package main

import (
	"context"
	"fmt"
	"sync"
	"time"
)

// ResourceManager manages system resources efficiently
type ResourceManager struct {
	resources  map[string]*Resource
	pools      map[string]*ResourcePool
	allocator  *ResourceAllocator
	monitor    *ResourceMonitor
	config     ResourceConfig
	mutex      sync.RWMutex
}

// Resource represents a system resource
type Resource struct {
	ID          string            `json:"id"`
	Name        string            `json:"name"`
	Type        string            `json:"type"`
	Capacity    int64             `json:"capacity"`
	Used        int64             `json:"used"`
	Available   int64             `json:"available"`
	Status      string            `json:"status"` // available, in_use, reserved, offline
	Priority    int               `json:"priority"`
	Metadata    map[string]string `json:"metadata"`
	LastUpdated time.Time         `json:"last_updated"`
}

// ResourcePool manages a pool of similar resources
type ResourcePool struct {
	Name        string            `json:"name"`
	Type        string            `json:"type"`
	Resources   []*Resource       `json:"resources"`
	Strategy    string            `json:"strategy"` // round_robin, least_used, priority
	MaxSize     int               `json:"max_size"`
	CurrentSize int               `json:"current_size"`
	Config      PoolConfig        `json:"config"`
	mutex       sync.RWMutex
}

// PoolConfig represents pool configuration
type PoolConfig struct {
	AutoScale     bool          `json:"auto_scale"`
	ScaleUpThreshold   float64   `json:"scale_up_threshold"`
	ScaleDownThreshold float64   `json:"scale_down_threshold"`
	MinSize       int           `json:"min_size"`
	MaxSize       int           `json:"max_size"`
	IdleTimeout   time.Duration `json:"idle_timeout"`
	HealthCheck   bool          `json:"health_check"`
	CheckInterval time.Duration `json:"check_interval"`
}

// ResourceAllocator manages resource allocation
type ResourceAllocator struct {
	strategies map[string]AllocationStrategy
	config     AllocatorConfig
	mutex      sync.RWMutex
}

// AllocationStrategy interface for different allocation strategies
type AllocationStrategy interface {
	Allocate(pool *ResourcePool, request ResourceRequest) (*Resource, error)
	Release(resource *Resource) error
	GetStats() map[string]interface{}
}

// AllocatorConfig represents allocator configuration
type AllocatorConfig struct {
	DefaultStrategy string        `json:"default_strategy"`
	Timeout         time.Duration `json:"timeout"`
	RetryAttempts   int           `json:"retry_attempts"`
	RetryDelay      time.Duration `json:"retry_delay"`
}

// ResourceRequest represents a resource allocation request
type ResourceRequest struct {
	Type     string            `json:"type"`
	Amount   int64             `json:"amount"`
	Priority int               `json:"priority"`
	Timeout  time.Duration     `json:"timeout"`
	Metadata map[string]string `json:"metadata"`
}

// ResourceMonitor monitors resource usage
type ResourceMonitor struct {
	config     MonitorConfig
	metrics    map[string]*ResourceMetric
	alerts     []ResourceAlert
	mutex      sync.RWMutex
}

// ResourceMetric represents resource metrics
type ResourceMetric struct {
	ResourceID  string                 `json:"resource_id"`
	Name        string                 `json:"name"`
	Value       float64                `json:"value"`
	Unit        string                 `json:"unit"`
	Timestamp   time.Time              `json:"timestamp"`
	History     []MetricPoint          `json:"history"`
	Thresholds  map[string]float64     `json:"thresholds"`
	Metadata    map[string]interface{} `json:"metadata"`
}

// ResourceAlert represents a resource alert
type ResourceAlert struct {
	ResourceID  string    `json:"resource_id"`
	Type        string    `json:"type"`
	Message     string    `json:"message"`
	Severity    string    `json:"severity"`
	Timestamp   time.Time `json:"timestamp"`
	Value       float64   `json:"value"`
	Threshold   float64   `json:"threshold"`
}

// ResourceConfig represents resource manager configuration
type ResourceConfig struct {
	EnableMonitoring    bool          `json:"enable_monitoring"`
	EnableAutoScaling   bool          `json:"enable_auto_scaling"`
	MonitorInterval     time.Duration `json:"monitor_interval"`
	CleanupInterval     time.Duration `json:"cleanup_interval"`
	MaxResourceAge      time.Duration `json:"max_resource_age"`
	EnableHealthChecks  bool          `json:"enable_health_checks"`
	HealthCheckInterval time.Duration `json:"health_check_interval"`
}

// RoundRobinAllocator implements round-robin allocation strategy
type RoundRobinAllocator struct {
	lastIndex int
	mutex     sync.Mutex
}

// LeastUsedAllocator implements least-used allocation strategy
type LeastUsedAllocator struct{}

// PriorityAllocator implements priority-based allocation strategy
type PriorityAllocator struct{}

// ResourceManager creates a new resource manager
func NewResourceManager(config ResourceConfig) *ResourceManager {
	rm := &ResourceManager{
		resources: make(map[string]*Resource),
		pools:     make(map[string]*ResourcePool),
		allocator: &ResourceAllocator{
			strategies: make(map[string]AllocationStrategy),
			config: AllocatorConfig{
				DefaultStrategy: "round_robin",
				Timeout:         30 * time.Second,
				RetryAttempts:   3,
				RetryDelay:      1 * time.Second,
			},
		},
		monitor: &ResourceMonitor{
			config: MonitorConfig{
				MemoryMonitoring:    true,
				GoroutineMonitoring: true,
				CPUMonitoring:       true,
				NetworkMonitoring:   false,
				Interval:            30 * time.Second,
				AlertThreshold:      0.8,
			},
			metrics: make(map[string]*ResourceMetric),
			alerts:  make([]ResourceAlert, 0),
		},
		config: config,
	}

	// Initialize allocation strategies
	rm.initializeAllocationStrategies()

	// Start monitoring if enabled
	if config.EnableMonitoring {
		go rm.startMonitoring()
	}

	// Start health checks if enabled
	if config.EnableHealthChecks {
		go rm.startHealthChecks()
	}

	return rm
}

// initializeAllocationStrategies initializes allocation strategies
func (rm *ResourceManager) initializeAllocationStrategies() {
	rm.allocator.strategies["round_robin"] = &RoundRobinAllocator{}
	rm.allocator.strategies["least_used"] = &LeastUsedAllocator{}
	rm.allocator.strategies["priority"] = &PriorityAllocator{}
}

// RegisterResource registers a new resource
func (rm *ResourceManager) RegisterResource(resource *Resource) error {
	rm.mutex.Lock()
	defer rm.mutex.Unlock()

	// Validate resource
	if err := rm.validateResource(resource); err != nil {
		return err
	}

	// Set default values
	if resource.Status == "" {
		resource.Status = "available"
	}
	if resource.Priority == 0 {
		resource.Priority = 1
	}
	if resource.Metadata == nil {
		resource.Metadata = make(map[string]string)
	}

	resource.LastUpdated = time.Now()
	rm.resources[resource.ID] = resource

	return nil
}

// validateResource validates resource configuration
func (rm *ResourceManager) validateResource(resource *Resource) error {
	if resource.ID == "" {
		return fmt.Errorf("resource ID cannot be empty")
	}
	if resource.Name == "" {
		return fmt.Errorf("resource name cannot be empty")
	}
	if resource.Type == "" {
		return fmt.Errorf("resource type cannot be empty")
	}
	if resource.Capacity <= 0 {
		return fmt.Errorf("resource capacity must be positive")
	}
	return nil
}

// CreatePool creates a new resource pool
func (rm *ResourceManager) CreatePool(name, resourceType string, config PoolConfig) error {
	rm.mutex.Lock()
	defer rm.mutex.Unlock()

	if _, exists := rm.pools[name]; exists {
		return fmt.Errorf("pool %s already exists", name)
	}

	pool := &ResourcePool{
		Name:        name,
		Type:        resourceType,
		Resources:   make([]*Resource, 0),
		Strategy:    "round_robin",
		Config:      config,
		CurrentSize: 0,
	}

	rm.pools[name] = pool
	return nil
}

// AddResourceToPool adds a resource to a pool
func (rm *ResourceManager) AddResourceToPool(poolName string, resourceID string) error {
	rm.mutex.Lock()
	defer rm.mutex.Unlock()

	pool, exists := rm.pools[poolName]
	if !exists {
		return fmt.Errorf("pool %s not found", poolName)
	}

	resource, exists := rm.resources[resourceID]
	if !exists {
		return fmt.Errorf("resource %s not found", resourceID)
	}

	if resource.Type != pool.Type {
		return fmt.Errorf("resource type %s does not match pool type %s", resource.Type, pool.Type)
	}

	pool.Resources = append(pool.Resources, resource)
	pool.CurrentSize++

	return nil
}

// AllocateResource allocates a resource from a pool
func (rm *ResourceManager) AllocateResource(poolName string, request ResourceRequest) (*Resource, error) {
	rm.mutex.RLock()
	pool, exists := rm.pools[poolName]
	rm.mutex.RUnlock()

	if !exists {
		return nil, fmt.Errorf("pool %s not found", poolName)
	}

	// Get allocation strategy
	strategy, exists := rm.allocator.strategies[pool.Strategy]
	if !exists {
		strategy = rm.allocator.strategies[rm.allocator.config.DefaultStrategy]
	}

	// Allocate resource
	resource, err := strategy.Allocate(pool, request)
	if err != nil {
		return nil, err
	}

	// Update resource status
	rm.mutex.Lock()
	resource.Status = "in_use"
	resource.Used += request.Amount
	resource.Available = resource.Capacity - resource.Used
	resource.LastUpdated = time.Now()
	rm.mutex.Unlock()

	return resource, nil
}

// ReleaseResource releases a resource back to the pool
func (rm *ResourceManager) ReleaseResource(resourceID string) error {
	rm.mutex.Lock()
	defer rm.mutex.Unlock()

	resource, exists := rm.resources[resourceID]
	if !exists {
		return fmt.Errorf("resource %s not found", resourceID)
	}

	// Reset resource
	resource.Status = "available"
	resource.Used = 0
	resource.Available = resource.Capacity
	resource.LastUpdated = time.Now()

	return nil
}

// GetResource returns a resource by ID
func (rm *ResourceManager) GetResource(resourceID string) (*Resource, error) {
	rm.mutex.RLock()
	defer rm.mutex.RUnlock()

	resource, exists := rm.resources[resourceID]
	if !exists {
		return nil, fmt.Errorf("resource %s not found", resourceID)
	}

	return resource, nil
}

// ListResources lists all resources
func (rm *ResourceManager) ListResources() []*Resource {
	rm.mutex.RLock()
	defer rm.mutex.RUnlock()

	resources := make([]*Resource, 0, len(rm.resources))
	for _, resource := range rm.resources {
		resources = append(resources, resource)
	}

	return resources
}

// ListPools lists all resource pools
func (rm *ResourceManager) ListPools() []*ResourcePool {
	rm.mutex.RLock()
	defer rm.mutex.RUnlock()

	pools := make([]*ResourcePool, 0, len(rm.pools))
	for _, pool := range rm.pools {
		pools = append(pools, pool)
	}

	return pools
}

// startMonitoring starts resource monitoring
func (rm *ResourceManager) startMonitoring() {
	ticker := time.NewTicker(rm.config.MonitorInterval)
	defer ticker.Stop()

	for {
		select {
		case <-ticker.C:
			rm.collectResourceMetrics()
			rm.checkResourceAlerts()
		}
	}
}

// collectResourceMetrics collects resource metrics
func (rm *ResourceManager) collectResourceMetrics() {
	rm.mutex.RLock()
	defer rm.mutex.RUnlock()

	for _, resource := range rm.resources {
		// Calculate utilization
		utilization := float64(resource.Used) / float64(resource.Capacity)

		// Update metric
		rm.updateResourceMetric(resource.ID, "utilization", utilization, "percentage")
		rm.updateResourceMetric(resource.ID, "used", float64(resource.Used), "bytes")
		rm.updateResourceMetric(resource.ID, "available", float64(resource.Available), "bytes")
	}
}

// updateResourceMetric updates a resource metric
func (rm *ResourceManager) updateResourceMetric(resourceID, name string, value float64, unit string) {
	metricKey := fmt.Sprintf("%s_%s", resourceID, name)
	
	rm.monitor.mutex.Lock()
	defer rm.monitor.mutex.Unlock()

	metric, exists := rm.monitor.metrics[metricKey]
	if !exists {
		metric = &ResourceMetric{
			ResourceID: resourceID,
			Name:       name,
			Unit:       unit,
			History:    make([]MetricPoint, 0),
			Thresholds: make(map[string]float64),
			Metadata:   make(map[string]interface{}),
		}
		rm.monitor.metrics[metricKey] = metric
	}

	metric.Value = value
	metric.Timestamp = time.Now()

	// Add to history (keep last 100 points)
	metric.History = append(metric.History, MetricPoint{
		Value:     value,
		Timestamp: time.Now(),
	})

	if len(metric.History) > 100 {
		metric.History = metric.History[1:]
	}
}

// checkResourceAlerts checks for resource alerts
func (rm *ResourceManager) checkResourceAlerts() {
	rm.monitor.mutex.RLock()
	defer rm.monitor.mutex.RUnlock()

	for _, metric := range rm.monitor.metrics {
		// Check utilization threshold
		if metric.Name == "utilization" && metric.Value > 0.8 {
			alert := ResourceAlert{
				ResourceID: metric.ResourceID,
				Type:       "high_utilization",
				Message:    fmt.Sprintf("Resource %s utilization is high", metric.ResourceID),
				Severity:   "warning",
				Timestamp:  time.Now(),
				Value:      metric.Value,
				Threshold:  0.8,
			}

			rm.monitor.alerts = append(rm.monitor.alerts, alert)
		}
	}
}

// startHealthChecks starts resource health checks
func (rm *ResourceManager) startHealthChecks() {
	ticker := time.NewTicker(rm.config.HealthCheckInterval)
	defer ticker.Stop()

	for {
		select {
		case <-ticker.C:
			rm.performHealthChecks()
		}
	}
}

// performHealthChecks performs health checks on resources
func (rm *ResourceManager) performHealthChecks() {
	rm.mutex.RLock()
	defer rm.mutex.RUnlock()

	for _, resource := range rm.resources {
		// Perform health check based on resource type
		healthy := rm.checkResourceHealth(resource)
		
		if !healthy && resource.Status != "offline" {
			resource.Status = "offline"
			resource.LastUpdated = time.Now()
		} else if healthy && resource.Status == "offline" {
			resource.Status = "available"
			resource.LastUpdated = time.Now()
		}
	}
}

// checkResourceHealth checks the health of a resource
func (rm *ResourceManager) checkResourceHealth(resource *Resource) bool {
	// This would implement resource-specific health checks
	// For now, just return true as placeholder
	return true
}

// GetMetrics returns all resource metrics
func (rm *ResourceManager) GetMetrics() map[string]*ResourceMetric {
	rm.monitor.mutex.RLock()
	defer rm.monitor.mutex.RUnlock()

	metrics := make(map[string]*ResourceMetric)
	for key, metric := range rm.monitor.metrics {
		metrics[key] = metric
	}

	return metrics
}

// GetAlerts returns all resource alerts
func (rm *ResourceManager) GetAlerts() []ResourceAlert {
	rm.monitor.mutex.RLock()
	defer rm.monitor.mutex.RUnlock()

	alerts := make([]ResourceAlert, len(rm.monitor.alerts))
	copy(alerts, rm.monitor.alerts)
	return alerts
}

// RoundRobinAllocator implementation
func (rra *RoundRobinAllocator) Allocate(pool *ResourcePool, request ResourceRequest) (*Resource, error) {
	rra.mutex.Lock()
	defer rra.mutex.Unlock()

	if len(pool.Resources) == 0 {
		return nil, fmt.Errorf("no resources available in pool")
	}

	// Find next available resource
	for i := 0; i < len(pool.Resources); i++ {
		index := (rra.lastIndex + i) % len(pool.Resources)
		resource := pool.Resources[index]
		
		if resource.Status == "available" && resource.Available >= request.Amount {
			rra.lastIndex = (index + 1) % len(pool.Resources)
			return resource, nil
		}
	}

	return nil, fmt.Errorf("no suitable resource available")
}

func (rra *RoundRobinAllocator) Release(resource *Resource) error {
	// Implementation would reset resource state
	return nil
}

func (rra *RoundRobinAllocator) GetStats() map[string]interface{} {
	return map[string]interface{}{
		"strategy": "round_robin",
		"last_index": rra.lastIndex,
	}
}

// LeastUsedAllocator implementation
func (lua *LeastUsedAllocator) Allocate(pool *ResourcePool, request ResourceRequest) (*Resource, error) {
	var selectedResource *Resource
	minUsage := int64(^uint64(0) >> 1) // Max int64

	for _, resource := range pool.Resources {
		if resource.Status == "available" && resource.Available >= request.Amount {
			usage := resource.Used
			if usage < minUsage {
				minUsage = usage
				selectedResource = resource
			}
		}
	}

	if selectedResource == nil {
		return nil, fmt.Errorf("no suitable resource available")
	}

	return selectedResource, nil
}

func (lua *LeastUsedAllocator) Release(resource *Resource) error {
	// Implementation would reset resource state
	return nil
}

func (lua *LeastUsedAllocator) GetStats() map[string]interface{} {
	return map[string]interface{}{
		"strategy": "least_used",
	}
}

// PriorityAllocator implementation
func (pa *PriorityAllocator) Allocate(pool *ResourcePool, request ResourceRequest) (*Resource, error) {
	var selectedResource *Resource
	highestPriority := -1

	for _, resource := range pool.Resources {
		if resource.Status == "available" && resource.Available >= request.Amount {
			if resource.Priority > highestPriority {
				highestPriority = resource.Priority
				selectedResource = resource
			}
		}
	}

	if selectedResource == nil {
		return nil, fmt.Errorf("no suitable resource available")
	}

	return selectedResource, nil
}

func (pa *PriorityAllocator) Release(resource *Resource) error {
	// Implementation would reset resource state
	return nil
}

func (pa *PriorityAllocator) GetStats() map[string]interface{} {
	return map[string]interface{}{
		"strategy": "priority",
	}
} 