package monitoring

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"
	"strings"
	"time"
)

// GrafanaOperator handles @grafana dashboard integration and visualization
type GrafanaOperator struct {
	endpoint   string
	apiKey     string
	client     *http.Client
	dashboards map[string]*GrafanaDashboard
	dataSources map[string]*GrafanaDataSource
	alerts     map[string]*GrafanaAlert
}

// GrafanaDashboard represents a Grafana dashboard
type GrafanaDashboard struct {
	ID          int                    `json:"id,omitempty"`
	UID         string                 `json:"uid,omitempty"`
	Title       string                 `json:"title"`
	Tags        []string               `json:"tags"`
	Timezone    string                 `json:"timezone"`
	Panels      []GrafanaPanel         `json:"panels"`
	Time        GrafanaTimeRange       `json:"time"`
	Templating  GrafanaTemplating      `json:"templating"`
	Annotations GrafanaAnnotations     `json:"annotations"`
	Refresh     string                 `json:"refresh"`
	SchemaVersion int                  `json:"schemaVersion"`
	Version     int                    `json:"version"`
	Links       []GrafanaLink          `json:"links"`
}

// GrafanaPanel represents a dashboard panel
type GrafanaPanel struct {
	ID          int                    `json:"id"`
	Title       string                 `json:"title"`
	Type        string                 `json:"type"`
	GridPos     GrafanaGridPos         `json:"gridPos"`
	Targets     []GrafanaTarget        `json:"targets"`
	Options     map[string]interface{} `json:"options"`
	FieldConfig GrafanaFieldConfig     `json:"fieldConfig"`
	Datasource  *GrafanaDataSource     `json:"datasource,omitempty"`
}

// GrafanaTarget represents a query target
type GrafanaTarget struct {
	Expr         string            `json:"expr,omitempty"`
	Format       string            `json:"format"`
	IntervalMs   int               `json:"intervalMs"`
	LegendFormat string            `json:"legendFormat"`
	RefID        string            `json:"refId"`
	Datasource   *GrafanaDataSource `json:"datasource"`
}

// GrafanaDataSource represents a data source configuration
type GrafanaDataSource struct {
	ID       int                    `json:"id,omitempty"`
	UID      string                 `json:"uid,omitempty"`
	Name     string                 `json:"name"`
	Type     string                 `json:"type"`
	URL      string                 `json:"url"`
	Access   string                 `json:"access"`
	Database string                 `json:"database,omitempty"`
	User     string                 `json:"user,omitempty"`
	Password string                 `json:"password,omitempty"`
	Settings map[string]interface{} `json:"jsonData,omitempty"`
}

// GrafanaAlert represents an alert rule
type GrafanaAlert struct {
	ID          int                    `json:"id,omitempty"`
	UID         string                 `json:"uid,omitempty"`
	Title       string                 `json:"title"`
	Condition   string                 `json:"condition"`
	Data        []GrafanaAlertQuery    `json:"data"`
	NoDataState string                 `json:"noDataState"`
	ExecErrState string                `json:"execErrState"`
	For         string                 `json:"for"`
	Annotations map[string]string      `json:"annotations"`
	Labels      map[string]string      `json:"labels"`
}

// NewGrafanaOperator creates a new Grafana integration operator
func NewGrafanaOperator(endpoint, apiKey string) *GrafanaOperator {
	if endpoint == "" {
		endpoint = "http://localhost:3000"
	}

	return &GrafanaOperator{
		endpoint:    endpoint,
		apiKey:      apiKey,
		client:      &http.Client{Timeout: 30 * time.Second},
		dashboards:  make(map[string]*GrafanaDashboard),
		dataSources: make(map[string]*GrafanaDataSource),
		alerts:      make(map[string]*GrafanaAlert),
	}
}

// Execute handles @grafana dashboard and visualization operations
func (g *GrafanaOperator) Execute(params string) interface{} {
	if params == "" {
		return g.GetStatus()
	}

	cleanParams := strings.Trim(params, `"'`)
	
	var paramMap map[string]interface{}
	if err := json.Unmarshal([]byte(cleanParams), &paramMap); err != nil {
		parts := strings.Split(cleanParams, ",")
		if len(parts) > 0 {
			action := strings.TrimSpace(parts[0])
			return g.executeAction(action, parts[1:])
		}
		return g.CreateErrorResult(fmt.Sprintf("Failed to parse parameters: %v", err))
	}

	action, ok := paramMap["action"].(string)
	if !ok {
		return g.CreateErrorResult("Action parameter is required")
	}

	return g.executeActionFromMap(action, paramMap)
}

// executeAction handles simple parameter format
func (g *GrafanaOperator) executeAction(action string, params []string) interface{} {
	switch action {
	case "create_dashboard":
		title := "Monitoring Dashboard"
		if len(params) > 0 {
			title = strings.TrimSpace(params[0])
		}
		return g.CreateDashboard(title, []string{}, []GrafanaPanel{})
	case "create_datasource":
		name := "prometheus"
		dsType := "prometheus"
		url := "http://localhost:9090"
		if len(params) > 0 {
			name = strings.TrimSpace(params[0])
		}
		if len(params) > 1 {
			dsType = strings.TrimSpace(params[1])
		}
		if len(params) > 2 {
			url = strings.TrimSpace(params[2])
		}
		return g.CreateDataSource(name, dsType, url, nil)
	case "create_alert":
		title := "High CPU Alert"
		condition := "avg() > 80"
		if len(params) > 0 {
			title = strings.TrimSpace(params[0])
		}
		if len(params) > 1 {
			condition = strings.TrimSpace(params[1])
		}
		return g.CreateAlert(title, condition, nil)
	case "health":
		return g.HealthCheck()
	default:
		return g.CreateErrorResult(fmt.Sprintf("Unknown action: %s", action))
	}
}

// executeActionFromMap handles JSON parameter format
func (g *GrafanaOperator) executeActionFromMap(action string, params map[string]interface{}) interface{} {
	switch action {
	case "create_dashboard":
		title := g.getStringParam(params, "title", "Monitoring Dashboard")
		tags := g.getStringArrayParam(params, "tags")
		panels := g.getPanelsParam(params, "panels")
		return g.CreateDashboard(title, tags, panels)
	case "create_datasource":
		name := g.getStringParam(params, "name", "prometheus")
		dsType := g.getStringParam(params, "type", "prometheus")
		url := g.getStringParam(params, "url", "http://localhost:9090")
		settings := g.getMapParam(params, "settings")
		return g.CreateDataSource(name, dsType, url, settings)
	case "create_panel":
		dashboardUID := g.getStringParam(params, "dashboard_uid", "")
		panelTitle := g.getStringParam(params, "title", "Panel")
		panelType := g.getStringParam(params, "type", "graph")
		return g.CreatePanel(dashboardUID, panelTitle, panelType, nil)
	case "create_alert":
		title := g.getStringParam(params, "title", "Alert")
		condition := g.getStringParam(params, "condition", "")
		data := g.getAlertDataParam(params, "data")
		return g.CreateAlert(title, condition, data)
	default:
		return g.CreateErrorResult(fmt.Sprintf("Unknown action: %s", action))
	}
}

// CreateDashboard creates a new Grafana dashboard
func (g *GrafanaOperator) CreateDashboard(title string, tags []string, panels []GrafanaPanel) interface{} {
	dashboard := &GrafanaDashboard{
		Title:   title,
		Tags:    tags,
		Timezone: "browser",
		Panels:  panels,
		Time: GrafanaTimeRange{
			From: "now-1h",
			To:   "now",
		},
		Refresh: "30s",
		SchemaVersion: 37,
		Version: 1,
	}

	// Send to Grafana API
	dashboardPayload := map[string]interface{}{
		"dashboard": dashboard,
		"overwrite": false,
	}

	body, err := json.Marshal(dashboardPayload)
	if err != nil {
		return g.CreateErrorResult(fmt.Sprintf("Failed to marshal dashboard: %v", err))
	}

	req, err := http.NewRequest("POST", g.endpoint+"/api/dashboards/db", bytes.NewBuffer(body))
	if err != nil {
		return g.CreateErrorResult(fmt.Sprintf("Failed to create request: %v", err))
	}

	req.Header.Set("Content-Type", "application/json")
	if g.apiKey != "" {
		req.Header.Set("Authorization", "Bearer "+g.apiKey)
	}

	resp, err := g.client.Do(req)
	if err != nil {
		return g.CreateErrorResult(fmt.Sprintf("Failed to create dashboard: %v", err))
	}
	defer resp.Body.Close()

	respBody, _ := ioutil.ReadAll(resp.Body)
	var result map[string]interface{}
	json.Unmarshal(respBody, &result)

	if resp.StatusCode != http.StatusOK {
		return g.CreateErrorResult(fmt.Sprintf("Grafana API returned status %d: %s", resp.StatusCode, string(respBody)))
	}

	// Store locally
	if uid, ok := result["uid"].(string); ok {
		dashboard.UID = uid
		g.dashboards[uid] = dashboard
	}

	return g.CreateSuccessResult(result)
}

// CreateDataSource creates a new Grafana data source
func (g *GrafanaOperator) CreateDataSource(name, dsType, url string, settings map[string]interface{}) interface{} {
	dataSource := &GrafanaDataSource{
		Name:     name,
		Type:     dsType,
		URL:      url,
		Access:   "proxy",
		Settings: settings,
	}

	body, err := json.Marshal(dataSource)
	if err != nil {
		return g.CreateErrorResult(fmt.Sprintf("Failed to marshal data source: %v", err))
	}

	req, err := http.NewRequest("POST", g.endpoint+"/api/datasources", bytes.NewBuffer(body))
	if err != nil {
		return g.CreateErrorResult(fmt.Sprintf("Failed to create request: %v", err))
	}

	req.Header.Set("Content-Type", "application/json")
	if g.apiKey != "" {
		req.Header.Set("Authorization", "Bearer "+g.apiKey)
	}

	resp, err := g.client.Do(req)
	if err != nil {
		return g.CreateErrorResult(fmt.Sprintf("Failed to create data source: %v", err))
	}
	defer resp.Body.Close()

	respBody, _ := ioutil.ReadAll(resp.Body)
	var result map[string]interface{}
	json.Unmarshal(respBody, &result)

	if resp.StatusCode != http.StatusOK {
		return g.CreateErrorResult(fmt.Sprintf("Grafana API returned status %d: %s", resp.StatusCode, string(respBody)))
	}

	// Store locally
	if uid, ok := result["uid"].(string); ok {
		dataSource.UID = uid
		g.dataSources[uid] = dataSource
	}

	return g.CreateSuccessResult(result)
}

// CreatePanel creates a new panel in a dashboard
func (g *GrafanaOperator) CreatePanel(dashboardUID, title, panelType string, targets []GrafanaTarget) interface{} {
	dashboard, exists := g.dashboards[dashboardUID]
	if !exists {
		return g.CreateErrorResult(fmt.Sprintf("Dashboard %s not found", dashboardUID))
	}

	panel := GrafanaPanel{
		ID:    len(dashboard.Panels) + 1,
		Title: title,
		Type:  panelType,
		GridPos: GrafanaGridPos{
			H: 8,
			W: 12,
			X: 0,
			Y: 0,
		},
		Targets: targets,
		Options: map[string]interface{}{
			"legend": map[string]interface{}{
				"displayMode": "table",
				"placement":   "right",
			},
		},
	}

	dashboard.Panels = append(dashboard.Panels, panel)

	return g.CreateSuccessResult(map[string]interface{}{
		"panel_id": panel.ID,
		"title":    title,
		"type":     panelType,
		"dashboard_uid": dashboardUID,
	})
}

// CreateAlert creates a new Grafana alert rule
func (g *GrafanaOperator) CreateAlert(title, condition string, data []GrafanaAlertQuery) interface{} {
	alert := &GrafanaAlert{
		Title:        title,
		Condition:    condition,
		Data:         data,
		NoDataState:  "NoData",
		ExecErrState: "Alerting",
		For:          "5m",
		Annotations: map[string]string{
			"description": "Alert for " + title,
		},
		Labels: map[string]string{
			"team": "monitoring",
		},
	}

	body, err := json.Marshal(alert)
	if err != nil {
		return g.CreateErrorResult(fmt.Sprintf("Failed to marshal alert: %v", err))
	}

	req, err := http.NewRequest("POST", g.endpoint+"/api/ruler/grafana/api/v1/rules", bytes.NewBuffer(body))
	if err != nil {
		return g.CreateErrorResult(fmt.Sprintf("Failed to create request: %v", err))
	}

	req.Header.Set("Content-Type", "application/json")
	if g.apiKey != "" {
		req.Header.Set("Authorization", "Bearer "+g.apiKey)
	}

	resp, err := g.client.Do(req)
	if err != nil {
		return g.CreateErrorResult(fmt.Sprintf("Failed to create alert: %v", err))
	}
	defer resp.Body.Close()

	respBody, _ := ioutil.ReadAll(resp.Body)
	var result map[string]interface{}
	json.Unmarshal(respBody, &result)

	// Store locally
	alertID := fmt.Sprintf("alert-%d", time.Now().Unix())
	g.alerts[alertID] = alert

	return g.CreateSuccessResult(map[string]interface{}{
		"alert_id": alertID,
		"title":    title,
		"condition": condition,
		"status":   "created",
	})
}

// GetStatus returns current Grafana integration status
func (g *GrafanaOperator) GetStatus() interface{} {
	return g.CreateSuccessResult(map[string]interface{}{
		"endpoint":     g.endpoint,
		"dashboards":   len(g.dashboards),
		"data_sources": len(g.dataSources),
		"alerts":       len(g.alerts),
		"api_configured": g.apiKey != "",
		"timestamp":    time.Now(),
	})
}

// HealthCheck performs health check on Grafana system
func (g *GrafanaOperator) HealthCheck() interface{} {
	req, err := http.NewRequest("GET", g.endpoint+"/api/health", nil)
	if err != nil {
		return g.CreateErrorResult(fmt.Sprintf("Failed to create health check request: %v", err))
	}

	if g.apiKey != "" {
		req.Header.Set("Authorization", "Bearer "+g.apiKey)
	}

	resp, err := g.client.Do(req)
	if err != nil {
		return g.CreateErrorResult(fmt.Sprintf("Health check failed: %v", err))
	}
	defer resp.Body.Close()

	return g.CreateSuccessResult(map[string]interface{}{
		"status": "healthy",
		"grafana_status": resp.StatusCode,
		"response_time": "< 1s",
		"timestamp": time.Now(),
	})
}

// Helper structs
type GrafanaTimeRange struct {
	From string `json:"from"`
	To   string `json:"to"`
}

type GrafanaGridPos struct {
	H int `json:"h"`
	W int `json:"w"`
	X int `json:"x"`
	Y int `json:"y"`
}

type GrafanaFieldConfig struct {
	Defaults map[string]interface{} `json:"defaults"`
}

type GrafanaTemplating struct {
	List []interface{} `json:"list"`
}

type GrafanaAnnotations struct {
	List []interface{} `json:"list"`
}

type GrafanaLink struct {
	Title string `json:"title"`
	URL   string `json:"url"`
	Type  string `json:"type"`
}

type GrafanaAlertQuery struct {
	RefID      string                 `json:"refId"`
	QueryType  string                 `json:"queryType"`
	Model      map[string]interface{} `json:"model"`
	Datasource *GrafanaDataSource     `json:"datasource"`
}

// Helper methods
func (g *GrafanaOperator) getStringParam(params map[string]interface{}, key, defaultValue string) string {
	if value, ok := params[key].(string); ok {
		return value
	}
	return defaultValue
}

func (g *GrafanaOperator) getStringArrayParam(params map[string]interface{}, key string) []string {
	if value, ok := params[key].([]interface{}); ok {
		result := make([]string, len(value))
		for i, v := range value {
			if str, ok := v.(string); ok {
				result[i] = str
			}
		}
		return result
	}
	return []string{}
}

func (g *GrafanaOperator) getMapParam(params map[string]interface{}, key string) map[string]interface{} {
	if value, ok := params[key].(map[string]interface{}); ok {
		return value
	}
	return nil
}

func (g *GrafanaOperator) getPanelsParam(params map[string]interface{}, key string) []GrafanaPanel {
	// Return empty panels array - would be populated from params in production
	return []GrafanaPanel{}
}

func (g *GrafanaOperator) getAlertDataParam(params map[string]interface{}, key string) []GrafanaAlertQuery {
	// Return empty alert data array - would be populated from params in production
	return []GrafanaAlertQuery{}
}

func (g *GrafanaOperator) CreateSuccessResult(data interface{}) interface{} {
	return map[string]interface{}{
		"success": true,
		"data":    data,
		"timestamp": time.Now(),
	}
}

func (g *GrafanaOperator) CreateErrorResult(error string) interface{} {
	return map[string]interface{}{
		"success": false,
		"error":   error,
		"timestamp": time.Now(),
	}
} 