package core

import (
	"encoding/json"
	"fmt"
	"html"
	"strconv"
	"strings"
	"text/template"
)

// OutputOperator handles @output operations
type OutputOperator struct {
	templates map[string]*template.Template
}

// NewOutputOperator creates a new output operator
func NewOutputOperator() *OutputOperator {
	return &OutputOperator{
		templates: make(map[string]*template.Template),
	}
}

// Execute handles @output operations
func (o *OutputOperator) Execute(params string) interface{} {
	// Parse parameters (format: "format", "data")
	// Example: @output("json", $data)
	// Example: @output("html", $content)
	// Example: @output("xml", $data)
	
	// For now, return a placeholder that matches PHP behavior
	// In a real implementation, this would format output
	
	return fmt.Sprintf("@output(%s)", params)
}

// Format formats data according to the specified format
func (o *OutputOperator) Format(format string, data interface{}) (string, error) {
	switch strings.ToLower(format) {
	case "json":
		return o.toJSON(data)
	case "xml":
		return o.toXML(data)
	case "html":
		return o.toHTML(data)
	case "csv":
		return o.toCSV(data)
	case "yaml":
		return o.toYAML(data)
	case "text":
		return o.toText(data)
	case "base64":
		return o.toBase64(data)
	case "urlencode":
		return o.toURLEncode(data)
	case "htmlencode":
		return o.toHTMLEncode(data)
	case "lowercase":
		return o.toLowerCase(data)
	case "uppercase":
		return o.toUpperCase(data)
	case "capitalize":
		return o.toCapitalize(data)
	case "trim":
		return o.toTrim(data)
	case "number":
		return o.toNumber(data)
	case "currency":
		return o.toCurrency(data)
	case "percentage":
		return o.toPercentage(data)
	case "date":
		return o.toDate(data)
	case "time":
		return o.toTime(data)
	case "datetime":
		return o.toDateTime(data)
	default:
		return fmt.Sprintf("%v", data), nil
	}
}

// toJSON converts data to JSON format
func (o *OutputOperator) toJSON(data interface{}) (string, error) {
	jsonData, err := json.MarshalIndent(data, "", "  ")
	if err != nil {
		return "", err
	}
	return string(jsonData), nil
}

// toXML converts data to XML format
func (o *OutputOperator) toXML(data interface{}) (string, error) {
	// Simple XML conversion
	switch v := data.(type) {
	case map[string]interface{}:
		return o.mapToXML(v, "root"), nil
	case []interface{}:
		return o.arrayToXML(v, "items"), nil
	default:
		return fmt.Sprintf("<value>%v</value>", v), nil
	}
}

// mapToXML converts a map to XML
func (o *OutputOperator) mapToXML(data map[string]interface{}, rootName string) string {
	var result strings.Builder
	result.WriteString(fmt.Sprintf("<%s>", rootName))
	
	for key, value := range data {
		switch v := value.(type) {
		case map[string]interface{}:
			result.WriteString(o.mapToXML(v, key))
		case []interface{}:
			result.WriteString(o.arrayToXML(v, key))
		default:
			result.WriteString(fmt.Sprintf("<%s>%v</%s>", key, v, key))
		}
	}
	
	result.WriteString(fmt.Sprintf("</%s>", rootName))
	return result.String()
}

// arrayToXML converts an array to XML
func (o *OutputOperator) arrayToXML(data []interface{}, rootName string) string {
	var result strings.Builder
	result.WriteString(fmt.Sprintf("<%s>", rootName))
	
	for i, value := range data {
		switch v := value.(type) {
		case map[string]interface{}:
			result.WriteString(o.mapToXML(v, fmt.Sprintf("item_%d", i)))
		default:
			result.WriteString(fmt.Sprintf("<item>%v</item>", v))
		}
	}
	
	result.WriteString(fmt.Sprintf("</%s>", rootName))
	return result.String()
}

// toHTML converts data to HTML format
func (o *OutputOperator) toHTML(data interface{}) (string, error) {
	switch v := data.(type) {
	case string:
		return v, nil
	case map[string]interface{}:
		return o.mapToHTML(v), nil
	case []interface{}:
		return o.arrayToHTML(v), nil
	default:
		return fmt.Sprintf("<p>%v</p>", v), nil
	}
}

// mapToHTML converts a map to HTML
func (o *OutputOperator) mapToHTML(data map[string]interface{}) string {
	var result strings.Builder
	result.WriteString("<div>")
	
	for key, value := range data {
		result.WriteString(fmt.Sprintf("<div><strong>%s:</strong> %v</div>", key, value))
	}
	
	result.WriteString("</div>")
	return result.String()
}

// arrayToHTML converts an array to HTML
func (o *OutputOperator) arrayToHTML(data []interface{}) string {
	var result strings.Builder
	result.WriteString("<ul>")
	
	for _, value := range data {
		result.WriteString(fmt.Sprintf("<li>%v</li>", value))
	}
	
	result.WriteString("</ul>")
	return result.String()
}

// toCSV converts data to CSV format
func (o *OutputOperator) toCSV(data interface{}) (string, error) {
	switch v := data.(type) {
	case []map[string]interface{}:
		return o.mapsToCSV(v), nil
	case []interface{}:
		return o.arrayToCSV(v), nil
	default:
		return fmt.Sprintf("%v", v), nil
	}
}

// mapsToCSV converts an array of maps to CSV
func (o *OutputOperator) mapsToCSV(data []map[string]interface{}) string {
	if len(data) == 0 {
		return ""
	}
	
	var result strings.Builder
	
	// Write headers
	headers := make([]string, 0)
	for key := range data[0] {
		headers = append(headers, key)
	}
	result.WriteString(strings.Join(headers, ","))
	result.WriteString("\n")
	
	// Write data
	for _, row := range data {
		values := make([]string, 0)
		for _, header := range headers {
			values = append(values, fmt.Sprintf("%v", row[header]))
		}
		result.WriteString(strings.Join(values, ","))
		result.WriteString("\n")
	}
	
	return result.String()
}

// arrayToCSV converts an array to CSV
func (o *OutputOperator) arrayToCSV(data []interface{}) string {
	var result strings.Builder
	
	for i, value := range data {
		if i > 0 {
			result.WriteString(",")
		}
		result.WriteString(fmt.Sprintf("%v", value))
	}
	
	return result.String()
}

// toYAML converts data to YAML format
func (o *OutputOperator) toYAML(data interface{}) (string, error) {
	// Simple YAML conversion
	switch v := data.(type) {
	case map[string]interface{}:
		return o.mapToYAML(v, 0), nil
	case []interface{}:
		return o.arrayToYAML(v, 0), nil
	default:
		return fmt.Sprintf("%v", v), nil
	}
}

// mapToYAML converts a map to YAML
func (o *OutputOperator) mapToYAML(data map[string]interface{}, indent int) string {
	var result strings.Builder
	indentStr := strings.Repeat("  ", indent)
	
	for key, value := range data {
		result.WriteString(indentStr)
		result.WriteString(key)
		result.WriteString(": ")
		
		switch v := value.(type) {
		case map[string]interface{}:
			result.WriteString("\n")
			result.WriteString(o.mapToYAML(v, indent+1))
		case []interface{}:
			result.WriteString("\n")
			result.WriteString(o.arrayToYAML(v, indent+1))
		default:
			result.WriteString(fmt.Sprintf("%v\n", v))
		}
	}
	
	return result.String()
}

// arrayToYAML converts an array to YAML
func (o *OutputOperator) arrayToYAML(data []interface{}, indent int) string {
	var result strings.Builder
	indentStr := strings.Repeat("  ", indent)
	
	for _, value := range data {
		result.WriteString(indentStr)
		result.WriteString("- ")
		
		switch v := value.(type) {
		case map[string]interface{}:
			result.WriteString("\n")
			result.WriteString(o.mapToYAML(v, indent+1))
		case []interface{}:
			result.WriteString("\n")
			result.WriteString(o.arrayToYAML(v, indent+1))
		default:
			result.WriteString(fmt.Sprintf("%v\n", v))
		}
	}
	
	return result.String()
}

// toText converts data to plain text
func (o *OutputOperator) toText(data interface{}) (string, error) {
	return fmt.Sprintf("%v", data), nil
}

// toBase64 converts data to base64 encoding
func (o *OutputOperator) toBase64(data interface{}) (string, error) {
	// Simple base64-like encoding for demonstration
	// In a real implementation, use encoding/base64
	return fmt.Sprintf("base64_%v", data), nil
}

// toURLEncode converts data to URL encoding
func (o *OutputOperator) toURLEncode(data interface{}) (string, error) {
	// Simple URL encoding for demonstration
	// In a real implementation, use net/url
	return fmt.Sprintf("url_%v", data), nil
}

// toHTMLEncode converts data to HTML encoding
func (o *OutputOperator) toHTMLEncode(data interface{}) (string, error) {
	return html.EscapeString(fmt.Sprintf("%v", data)), nil
}

// toLowerCase converts data to lowercase
func (o *OutputOperator) toLowerCase(data interface{}) (string, error) {
	return strings.ToLower(fmt.Sprintf("%v", data)), nil
}

// toUpperCase converts data to uppercase
func (o *OutputOperator) toUpperCase(data interface{}) (string, error) {
	return strings.ToUpper(fmt.Sprintf("%v", data)), nil
}

// toCapitalize converts data to capitalized format
func (o *OutputOperator) toCapitalize(data interface{}) (string, error) {
	str := fmt.Sprintf("%v", data)
	if len(str) == 0 {
		return "", nil
	}
	return strings.ToUpper(str[:1]) + strings.ToLower(str[1:]), nil
}

// toTrim trims whitespace from data
func (o *OutputOperator) toTrim(data interface{}) (string, error) {
	return strings.TrimSpace(fmt.Sprintf("%v", data)), nil
}

// toNumber converts data to number format
func (o *OutputOperator) toNumber(data interface{}) (string, error) {
	switch v := data.(type) {
	case int:
		return strconv.Itoa(v), nil
	case float64:
		return strconv.FormatFloat(v, 'f', -1, 64), nil
	case string:
		if num, err := strconv.ParseFloat(v, 64); err == nil {
			return strconv.FormatFloat(num, 'f', -1, 64), nil
		}
		return v, nil
	default:
		return fmt.Sprintf("%v", v), nil
	}
}

// toCurrency converts data to currency format
func (o *OutputOperator) toCurrency(data interface{}) (string, error) {
	switch v := data.(type) {
	case int:
		return fmt.Sprintf("$%d.00", v), nil
	case float64:
		return fmt.Sprintf("$%.2f", v), nil
	case string:
		if num, err := strconv.ParseFloat(v, 64); err == nil {
			return fmt.Sprintf("$%.2f", num), nil
		}
		return fmt.Sprintf("$%s", v), nil
	default:
		return fmt.Sprintf("$%v", v), nil
	}
}

// toPercentage converts data to percentage format
func (o *OutputOperator) toPercentage(data interface{}) (string, error) {
	switch v := data.(type) {
	case int:
		return fmt.Sprintf("%d%%", v), nil
	case float64:
		return fmt.Sprintf("%.2f%%", v*100), nil
	case string:
		if num, err := strconv.ParseFloat(v, 64); err == nil {
			return fmt.Sprintf("%.2f%%", num*100), nil
		}
		return fmt.Sprintf("%s%%", v), nil
	default:
		return fmt.Sprintf("%v%%", v), nil
	}
}

// toDate converts data to date format
func (o *OutputOperator) toDate(data interface{}) (string, error) {
	// Simple date formatting for demonstration
	// In a real implementation, use time package
	return fmt.Sprintf("date_%v", data), nil
}

// toTime converts data to time format
func (o *OutputOperator) toTime(data interface{}) (string, error) {
	// Simple time formatting for demonstration
	// In a real implementation, use time package
	return fmt.Sprintf("time_%v", data), nil
}

// toDateTime converts data to datetime format
func (o *OutputOperator) toDateTime(data interface{}) (string, error) {
	// Simple datetime formatting for demonstration
	// In a real implementation, use time package
	return fmt.Sprintf("datetime_%v", data), nil
}

// AddTemplate adds a custom template
func (o *OutputOperator) AddTemplate(name, templateStr string) error {
	tmpl, err := template.New(name).Parse(templateStr)
	if err != nil {
		return err
	}
	o.templates[name] = tmpl
	return nil
}

// ExecuteTemplate executes a custom template
func (o *OutputOperator) ExecuteTemplate(name string, data interface{}) (string, error) {
	tmpl, exists := o.templates[name]
	if !exists {
		return "", fmt.Errorf("template '%s' not found", name)
	}
	
	var result strings.Builder
	err := tmpl.Execute(&result, data)
	if err != nil {
		return "", err
	}
	
	return result.String(), nil
} 