package core

import (
	"os"
	"strconv"
)

// EnvOperator handles @env operations
type EnvOperator struct{}

// NewEnvOperator creates a new environment operator
func NewEnvOperator() *EnvOperator {
	return &EnvOperator{}
}

// Execute handles @env operations
func (e *EnvOperator) Execute(params string) interface{} {
	// Parse parameters (format: "variable_name,default_value")
	// Example: @env("DATABASE_URL", "localhost:5432")
	
	if params == "" {
		return ""
	}
	
	// Remove quotes if present
	cleanParams := params
	if len(cleanParams) >= 2 && (cleanParams[0] == '"' || cleanParams[0] == '\'') {
		cleanParams = cleanParams[1 : len(cleanParams)-1]
	}
	
	// Split by comma for variable name and default value
	parts := splitParams(cleanParams)
	varName := parts[0]
	defaultValue := ""
	if len(parts) > 1 {
		defaultValue = parts[1]
	}
	
	return e.Get(varName, defaultValue)
}

// Get retrieves an environment variable with default
func (e *EnvOperator) Get(name, defaultValue string) string {
	if value := os.Getenv(name); value != "" {
		return value
	}
	return defaultValue
}

// GetInt retrieves an environment variable as integer
func (e *EnvOperator) GetInt(name string, defaultValue int) int {
	if value := os.Getenv(name); value != "" {
		if intValue, err := strconv.Atoi(value); err == nil {
			return intValue
		}
	}
	return defaultValue
}

// GetBool retrieves an environment variable as boolean
func (e *EnvOperator) GetBool(name string, defaultValue bool) bool {
	if value := os.Getenv(name); value != "" {
		if boolValue, err := strconv.ParseBool(value); err == nil {
			return boolValue
		}
	}
	return defaultValue
}

// GetFloat retrieves an environment variable as float64
func (e *EnvOperator) GetFloat(name string, defaultValue float64) float64 {
	if value := os.Getenv(name); value != "" {
		if floatValue, err := strconv.ParseFloat(value, 64); err == nil {
			return floatValue
		}
	}
	return defaultValue
}

// Set sets an environment variable
func (e *EnvOperator) Set(name, value string) error {
	return os.Setenv(name, value)
}

// Unset removes an environment variable
func (e *EnvOperator) Unset(name string) error {
	return os.Unsetenv(name)
}

// List returns all environment variables
func (e *EnvOperator) List() map[string]string {
	env := make(map[string]string)
	for _, pair := range os.Environ() {
		key, value := splitEnvPair(pair)
		env[key] = value
	}
	return env
}

// Has checks if an environment variable exists
func (e *EnvOperator) Has(name string) bool {
	_, exists := os.LookupEnv(name)
	return exists
}



// splitEnvPair splits an environment variable pair
func splitEnvPair(pair string) (string, string) {
	for i := 0; i < len(pair); i++ {
		if pair[i] == '=' {
			return pair[:i], pair[i+1:]
		}
	}
	return pair, ""
} 