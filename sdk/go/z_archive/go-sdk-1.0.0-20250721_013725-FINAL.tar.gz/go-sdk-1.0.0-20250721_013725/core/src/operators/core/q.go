package core

import (
	"database/sql"
	"fmt"
	"strings"
)

// QOperator handles @q operations (query shorthand)
type QOperator struct {
	db *sql.DB
}

// NewQOperator creates a new query shorthand operator
func NewQOperator() *QOperator {
	return &QOperator{}
}

// SetDatabase sets the database connection
func (q *QOperator) SetDatabase(db *sql.DB) {
	q.db = db
}

// Execute handles @q operations
func (q *QOperator) Execute(params string) interface{} {
	// Parse parameters (format: "table,conditions,fields")
	// Example: @q("users", "id=1", "id,name,email")
	
	if params == "" {
		return fmt.Sprintf("@q(%s)", params)
	}
	
	// Remove quotes if present
	cleanParams := params
	if len(cleanParams) >= 2 && (cleanParams[0] == '"' || cleanParams[0] == '\'') {
		cleanParams = cleanParams[1 : len(cleanParams)-1]
	}
	
	parts := splitParams(cleanParams)
	if len(parts) == 0 {
		return fmt.Sprintf("@q(%s) - Invalid parameters", params)
	}
	
	table := parts[0]
	conditions := ""
	if len(parts) > 1 {
		conditions = parts[1]
	}
	
	fields := "*"
	if len(parts) > 2 {
		fields = parts[2]
	}
	
	return q.Query(table, conditions, fields)
}

// Query executes a shorthand query
func (q *QOperator) Query(table, conditions, fields string) interface{} {
	if q.db == nil {
		return fmt.Sprintf("@q(%s,%s,%s) - No database connection", table, conditions, fields)
	}
	
	// Build SQL query
	query := fmt.Sprintf("SELECT %s FROM %s", fields, table)
	
	if conditions != "" {
		query += " WHERE " + conditions
	}
	
	// Execute query
	rows, err := q.db.Query(query)
	if err != nil {
		return fmt.Sprintf("@q(%s,%s,%s) - Error: %v", table, conditions, fields, err)
	}
	defer rows.Close()
	
	// Get column names
	columns, err := rows.Columns()
	if err != nil {
		return fmt.Sprintf("@q(%s,%s,%s) - Error getting columns: %v", table, conditions, fields, err)
	}
	
	// Scan results
	var results []map[string]interface{}
	for rows.Next() {
		values := make([]interface{}, len(columns))
		valuePtrs := make([]interface{}, len(columns))
		for i := range values {
			valuePtrs[i] = &values[i]
		}
		
		if err := rows.Scan(valuePtrs...); err != nil {
			return fmt.Sprintf("@q(%s,%s,%s) - Error scanning row: %v", table, conditions, fields, err)
		}
		
		row := make(map[string]interface{})
		for i, col := range columns {
			val := values[i]
			row[col] = val
		}
		
		results = append(results, row)
	}
	
	if err = rows.Err(); err != nil {
		return fmt.Sprintf("@q(%s,%s,%s) - Error iterating rows: %v", table, conditions, fields, err)
	}
	
	return results
}

// Get executes a shorthand query and returns a single row
func (q *QOperator) Get(table, conditions, fields string) interface{} {
	if q.db == nil {
		return fmt.Sprintf("@q.get(%s,%s,%s) - No database connection", table, conditions, fields)
	}
	
	// Build SQL query with LIMIT 1
	query := fmt.Sprintf("SELECT %s FROM %s", fields, table)
	
	if conditions != "" {
		query += " WHERE " + conditions
	}
	
	query += " LIMIT 1"
	
	// Execute query
	row := q.db.QueryRow(query)
	
	// Get column names
	columns, err := q.getColumnsFromQuery(query)
	if err != nil {
		return fmt.Sprintf("@q.get(%s,%s,%s) - Error getting columns: %v", table, conditions, fields, err)
	}
	
	// Scan result
	values := make([]interface{}, len(columns))
	valuePtrs := make([]interface{}, len(columns))
	for i := range values {
		valuePtrs[i] = &values[i]
	}
	
	if err := row.Scan(valuePtrs...); err != nil {
		if err == sql.ErrNoRows {
			return nil
		}
		return fmt.Sprintf("@q.get(%s,%s,%s) - Error scanning row: %v", table, conditions, fields, err)
	}
	
	result := make(map[string]interface{})
	for i, col := range columns {
		result[col] = values[i]
	}
	
	return result
}

// Count executes a COUNT query
func (q *QOperator) Count(table, conditions string) interface{} {
	if q.db == nil {
		return fmt.Sprintf("@q.count(%s,%s) - No database connection", table, conditions)
	}
	
	// Build SQL query
	query := fmt.Sprintf("SELECT COUNT(*) FROM %s", table)
	
	if conditions != "" {
		query += " WHERE " + conditions
	}
	
	// Execute query
	var count int
	err := q.db.QueryRow(query).Scan(&count)
	if err != nil {
		return fmt.Sprintf("@q.count(%s,%s) - Error: %v", table, conditions, err)
	}
	
	return count
}

// Insert executes an INSERT query
func (q *QOperator) Insert(table string, data map[string]interface{}) interface{} {
	if q.db == nil {
		return fmt.Sprintf("@q.insert(%s) - No database connection", table)
	}
	
	if len(data) == 0 {
		return fmt.Sprintf("@q.insert(%s) - No data provided", table)
	}
	
	// Build INSERT query
	columns := make([]string, 0, len(data))
	placeholders := make([]string, 0, len(data))
	values := make([]interface{}, 0, len(data))
	
	for column, value := range data {
		columns = append(columns, column)
		placeholders = append(placeholders, "?")
		values = append(values, value)
	}
	
	query := fmt.Sprintf("INSERT INTO %s (%s) VALUES (%s)",
		table,
		strings.Join(columns, ", "),
		strings.Join(placeholders, ", "))
	
	// Execute query
	result, err := q.db.Exec(query, values...)
	if err != nil {
		return fmt.Sprintf("@q.insert(%s) - Error: %v", table, err)
	}
	
	lastInsertID, _ := result.LastInsertId()
	rowsAffected, _ := result.RowsAffected()
	
	return map[string]interface{}{
		"last_insert_id": lastInsertID,
		"rows_affected":  rowsAffected,
		"success":        true,
	}
}

// Update executes an UPDATE query
func (q *QOperator) Update(table, conditions string, data map[string]interface{}) interface{} {
	if q.db == nil {
		return fmt.Sprintf("@q.update(%s,%s) - No database connection", table, conditions)
	}
	
	if len(data) == 0 {
		return fmt.Sprintf("@q.update(%s,%s) - No data provided", table, conditions)
	}
	
	// Build UPDATE query
	setClauses := make([]string, 0, len(data))
	values := make([]interface{}, 0, len(data))
	
	for column, value := range data {
		setClauses = append(setClauses, column+"=?")
		values = append(values, value)
	}
	
	query := fmt.Sprintf("UPDATE %s SET %s", table, strings.Join(setClauses, ", "))
	
	if conditions != "" {
		query += " WHERE " + conditions
	}
	
	// Execute query
	result, err := q.db.Exec(query, values...)
	if err != nil {
		return fmt.Sprintf("@q.update(%s,%s) - Error: %v", table, conditions, err)
	}
	
	rowsAffected, _ := result.RowsAffected()
	
	return map[string]interface{}{
		"rows_affected": rowsAffected,
		"success":       true,
	}
}

// Delete executes a DELETE query
func (q *QOperator) Delete(table, conditions string) interface{} {
	if q.db == nil {
		return fmt.Sprintf("@q.delete(%s,%s) - No database connection", table, conditions)
	}
	
	// Build DELETE query
	query := fmt.Sprintf("DELETE FROM %s", table)
	
	if conditions != "" {
		query += " WHERE " + conditions
	}
	
	// Execute query
	result, err := q.db.Exec(query)
	if err != nil {
		return fmt.Sprintf("@q.delete(%s,%s) - Error: %v", table, conditions, err)
	}
	
	rowsAffected, _ := result.RowsAffected()
	
	return map[string]interface{}{
		"rows_affected": rowsAffected,
		"success":       true,
	}
}

// getColumnsFromQuery extracts column names from a SELECT query
func (q *QOperator) getColumnsFromQuery(query string) ([]string, error) {
	// This is a simplified implementation
	// In a real implementation, you might want to parse the SQL properly
	
	// For now, we'll execute the query once to get columns
	rows, err := q.db.Query(query)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	
	return rows.Columns()
}

// Close closes the database connection
func (q *QOperator) Close() error {
	if q.db != nil {
		return q.db.Close()
	}
	return nil
}

 