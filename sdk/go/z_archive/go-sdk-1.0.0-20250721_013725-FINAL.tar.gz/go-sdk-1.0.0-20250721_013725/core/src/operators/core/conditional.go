package core

import (
	"fmt"
	"regexp"
	"strconv"
	"strings"
)

// ConditionalOperator handles @if operations
type ConditionalOperator struct {
	variables map[string]interface{}
}

// NewConditionalOperator creates a new conditional operator
func NewConditionalOperator() *ConditionalOperator {
	return &ConditionalOperator{
		variables: make(map[string]interface{}),
	}
}

// Execute handles @if operations
func (c *ConditionalOperator) Execute(params string) interface{} {
	// Parse parameters (format: "condition", "true_value", "false_value")
	// Example: @if("$user.role == 'admin'", "admin_panel", "user_panel")
	// Example: @if("$count > 10", "many", "few")
	
	// For now, return a placeholder that matches PHP behavior
	// In a real implementation, this would evaluate conditions
	
	return fmt.Sprintf("@if(%s)", params)
}

// Evaluate evaluates a condition and returns true or false
func (c *ConditionalOperator) Evaluate(condition string) bool {
	condition = strings.TrimSpace(condition)
	
	// Handle simple boolean values
	if condition == "true" {
		return true
	}
	if condition == "false" {
		return false
	}
	
	// Handle variable references
	if strings.HasPrefix(condition, "$") {
		varName := condition[1:]
		if value, exists := c.variables[varName]; exists {
			return c.isTruthy(value)
		}
		return false
	}
	
	// Handle equality comparisons
	if strings.Contains(condition, "==") {
		return c.evaluateEquality(condition)
	}
	
	// Handle inequality comparisons
	if strings.Contains(condition, "!=") {
		return c.evaluateInequality(condition)
	}
	
	// Handle greater than comparisons
	if strings.Contains(condition, ">") && !strings.Contains(condition, ">=") {
		return c.evaluateGreaterThan(condition)
	}
	
	// Handle less than comparisons
	if strings.Contains(condition, "<") && !strings.Contains(condition, "<=") {
		return c.evaluateLessThan(condition)
	}
	
	// Handle greater than or equal comparisons
	if strings.Contains(condition, ">=") {
		return c.evaluateGreaterThanEqual(condition)
	}
	
	// Handle less than or equal comparisons
	if strings.Contains(condition, "<=") {
		return c.evaluateLessThanEqual(condition)
	}
	
	// Handle logical AND
	if strings.Contains(condition, "&&") {
		return c.evaluateLogicalAND(condition)
	}
	
	// Handle logical OR
	if strings.Contains(condition, "||") {
		return c.evaluateLogicalOR(condition)
	}
	
	// Handle contains
	if strings.Contains(condition, "contains") {
		return c.evaluateContains(condition)
	}
	
	// Handle starts with
	if strings.Contains(condition, "starts_with") {
		return c.evaluateStartsWith(condition)
	}
	
	// Handle ends with
	if strings.Contains(condition, "ends_with") {
		return c.evaluateEndsWith(condition)
	}
	
	// Default: treat as string and check if truthy
	return c.isTruthy(condition)
}

// SetVariable sets a variable for use in conditions
func (c *ConditionalOperator) SetVariable(name string, value interface{}) {
	c.variables[name] = value
}

// GetVariable gets a variable value
func (c *ConditionalOperator) GetVariable(name string) (interface{}, bool) {
	value, exists := c.variables[name]
	return value, exists
}

// ClearVariables clears all variables
func (c *ConditionalOperator) ClearVariables() {
	c.variables = make(map[string]interface{})
}

// isTruthy checks if a value is truthy
func (c *ConditionalOperator) isTruthy(value interface{}) bool {
	switch v := value.(type) {
	case bool:
		return v
	case string:
		return v != "" && v != "false" && v != "0" && v != "null"
	case int:
		return v != 0
	case float64:
		return v != 0
	case nil:
		return false
	default:
		return true
	}
}

// evaluateEquality evaluates equality comparisons
func (c *ConditionalOperator) evaluateEquality(condition string) bool {
	parts := strings.Split(condition, "==")
	if len(parts) != 2 {
		return false
	}
	
	left := strings.TrimSpace(parts[0])
	right := strings.TrimSpace(parts[1])
	
	leftValue := c.resolveValue(left)
	rightValue := c.resolveValue(right)
	
	return c.compareValues(leftValue, rightValue) == 0
}

// evaluateInequality evaluates inequality comparisons
func (c *ConditionalOperator) evaluateInequality(condition string) bool {
	parts := strings.Split(condition, "!=")
	if len(parts) != 2 {
		return false
	}
	
	left := strings.TrimSpace(parts[0])
	right := strings.TrimSpace(parts[1])
	
	leftValue := c.resolveValue(left)
	rightValue := c.resolveValue(right)
	
	return c.compareValues(leftValue, rightValue) != 0
}

// evaluateGreaterThan evaluates greater than comparisons
func (c *ConditionalOperator) evaluateGreaterThan(condition string) bool {
	parts := strings.Split(condition, ">")
	if len(parts) != 2 {
		return false
	}
	
	left := strings.TrimSpace(parts[0])
	right := strings.TrimSpace(parts[1])
	
	leftValue := c.resolveValue(left)
	rightValue := c.resolveValue(right)
	
	return c.compareValues(leftValue, rightValue) > 0
}

// evaluateLessThan evaluates less than comparisons
func (c *ConditionalOperator) evaluateLessThan(condition string) bool {
	parts := strings.Split(condition, "<")
	if len(parts) != 2 {
		return false
	}
	
	left := strings.TrimSpace(parts[0])
	right := strings.TrimSpace(parts[1])
	
	leftValue := c.resolveValue(left)
	rightValue := c.resolveValue(right)
	
	return c.compareValues(leftValue, rightValue) < 0
}

// evaluateGreaterThanEqual evaluates greater than or equal comparisons
func (c *ConditionalOperator) evaluateGreaterThanEqual(condition string) bool {
	parts := strings.Split(condition, ">=")
	if len(parts) != 2 {
		return false
	}
	
	left := strings.TrimSpace(parts[0])
	right := strings.TrimSpace(parts[1])
	
	leftValue := c.resolveValue(left)
	rightValue := c.resolveValue(right)
	
	return c.compareValues(leftValue, rightValue) >= 0
}

// evaluateLessThanEqual evaluates less than or equal comparisons
func (c *ConditionalOperator) evaluateLessThanEqual(condition string) bool {
	parts := strings.Split(condition, "<=")
	if len(parts) != 2 {
		return false
	}
	
	left := strings.TrimSpace(parts[0])
	right := strings.TrimSpace(parts[1])
	
	leftValue := c.resolveValue(left)
	rightValue := c.resolveValue(right)
	
	return c.compareValues(leftValue, rightValue) <= 0
}

// evaluateLogicalAND evaluates logical AND operations
func (c *ConditionalOperator) evaluateLogicalAND(condition string) bool {
	parts := strings.Split(condition, "&&")
	for _, part := range parts {
		if !c.Evaluate(strings.TrimSpace(part)) {
			return false
		}
	}
	return true
}

// evaluateLogicalOR evaluates logical OR operations
func (c *ConditionalOperator) evaluateLogicalOR(condition string) bool {
	parts := strings.Split(condition, "||")
	for _, part := range parts {
		if c.Evaluate(strings.TrimSpace(part)) {
			return true
		}
	}
	return false
}

// evaluateContains evaluates contains operations
func (c *ConditionalOperator) evaluateContains(condition string) bool {
	// Format: "value contains substring"
	re := regexp.MustCompile(`(.+)\s+contains\s+(.+)`)
	matches := re.FindStringSubmatch(condition)
	if len(matches) != 3 {
		return false
	}
	
	value := strings.TrimSpace(matches[1])
	substring := strings.TrimSpace(matches[2])
	
	valueStr := fmt.Sprintf("%v", c.resolveValue(value))
	substringStr := fmt.Sprintf("%v", c.resolveValue(substring))
	
	return strings.Contains(valueStr, substringStr)
}

// evaluateStartsWith evaluates starts_with operations
func (c *ConditionalOperator) evaluateStartsWith(condition string) bool {
	// Format: "value starts_with prefix"
	re := regexp.MustCompile(`(.+)\s+starts_with\s+(.+)`)
	matches := re.FindStringSubmatch(condition)
	if len(matches) != 3 {
		return false
	}
	
	value := strings.TrimSpace(matches[1])
	prefix := strings.TrimSpace(matches[2])
	
	valueStr := fmt.Sprintf("%v", c.resolveValue(value))
	prefixStr := fmt.Sprintf("%v", c.resolveValue(prefix))
	
	return strings.HasPrefix(valueStr, prefixStr)
}

// evaluateEndsWith evaluates ends_with operations
func (c *ConditionalOperator) evaluateEndsWith(condition string) bool {
	// Format: "value ends_with suffix"
	re := regexp.MustCompile(`(.+)\s+ends_with\s+(.+)`)
	matches := re.FindStringSubmatch(condition)
	if len(matches) != 3 {
		return false
	}
	
	value := strings.TrimSpace(matches[1])
	suffix := strings.TrimSpace(matches[2])
	
	valueStr := fmt.Sprintf("%v", c.resolveValue(value))
	suffixStr := fmt.Sprintf("%v", c.resolveValue(suffix))
	
	return strings.HasSuffix(valueStr, suffixStr)
}

// resolveValue resolves a value, handling variables and literals
func (c *ConditionalOperator) resolveValue(value string) interface{} {
	value = strings.TrimSpace(value)
	
	// Handle variable references
	if strings.HasPrefix(value, "$") {
		varName := value[1:]
		if val, exists := c.variables[varName]; exists {
			return val
		}
		return nil
	}
	
	// Handle string literals
	if strings.HasPrefix(value, `"`) && strings.HasSuffix(value, `"`) {
		return strings.Trim(value, `"`)
	}
	if strings.HasPrefix(value, `'`) && strings.HasSuffix(value, `'`) {
		return strings.Trim(value, `'`)
	}
	
	// Handle numeric literals
	if num, err := strconv.Atoi(value); err == nil {
		return num
	}
	if num, err := strconv.ParseFloat(value, 64); err == nil {
		return num
	}
	
	// Handle boolean literals
	if value == "true" {
		return true
	}
	if value == "false" {
		return false
	}
	
	// Return as string
	return value
}

// compareValues compares two values and returns -1, 0, or 1
func (c *ConditionalOperator) compareValues(a, b interface{}) int {
	// Handle nil values
	if a == nil && b == nil {
		return 0
	}
	if a == nil {
		return -1
	}
	if b == nil {
		return 1
	}
	
	// Try to convert to numbers for comparison
	if aNum, aOk := c.toNumber(a); aOk {
		if bNum, bOk := c.toNumber(b); bOk {
			if aNum < bNum {
				return -1
			}
			if aNum > bNum {
				return 1
			}
			return 0
		}
	}
	
	// Fall back to string comparison
	aStr := fmt.Sprintf("%v", a)
	bStr := fmt.Sprintf("%v", b)
	
	if aStr < bStr {
		return -1
	}
	if aStr > bStr {
		return 1
	}
	return 0
}

// toNumber attempts to convert a value to a number
func (c *ConditionalOperator) toNumber(value interface{}) (float64, bool) {
	switch v := value.(type) {
	case int:
		return float64(v), true
	case float64:
		return v, true
	case string:
		if num, err := strconv.ParseFloat(v, 64); err == nil {
			return num, true
		}
	}
	return 0, false
}

// IfThenElse evaluates a condition and returns the appropriate value
func (c *ConditionalOperator) IfThenElse(condition string, trueValue, falseValue interface{}) interface{} {
	if c.Evaluate(condition) {
		return trueValue
	}
	return falseValue
}

// Switch evaluates multiple conditions and returns the first matching value
func (c *ConditionalOperator) Switch(cases map[string]interface{}, defaultValue interface{}) interface{} {
	for condition, value := range cases {
		if c.Evaluate(condition) {
			return value
		}
	}
	return defaultValue
} 