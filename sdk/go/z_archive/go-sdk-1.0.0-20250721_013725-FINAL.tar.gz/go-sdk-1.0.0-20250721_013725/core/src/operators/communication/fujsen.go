package communication

import (
	"encoding/json"
	"fmt"
	"strings"
	"sync"
)

// FUJSENOperator handles @fujsen operations
type FUJSENOperator struct {
	functions map[string]interface{}
	mutex     sync.RWMutex
}

// FUJSENFunction represents a serialized JavaScript function
type FUJSENFunction struct {
	Name       string                 `json:"name"`
	Code       string                 `json:"code"`
	Parameters []string               `json:"parameters"`
	Returns    string                 `json:"returns"`
	Metadata   map[string]interface{} `json:"metadata"`
}

// NewFUJSENOperator creates a new FUJSEN operator
func NewFUJSENOperator() *FUJSENOperator {
	return &FUJSENOperator{
		functions: make(map[string]interface{}),
	}
}

// Execute handles @fujsen operations
func (f *FUJSENOperator) Execute(params string) interface{} {
	// Parse parameters (format: "action,function_name,code")
	// Example: @fujsen("serialize", "add", "function(a, b) { return a + b; }")
	
	if params == "" {
		return fmt.Sprintf("@fujsen(%s)", params)
	}
	
	// Remove quotes if present
	cleanParams := params
	if len(cleanParams) >= 2 && (cleanParams[0] == '"' || cleanParams[0] == '\'') {
		cleanParams = cleanParams[1 : len(cleanParams)-1]
	}
	
	parts := splitParams(cleanParams)
	if len(parts) == 0 {
		return fmt.Sprintf("@fujsen(%s) - Invalid parameters", params)
	}
	
	action := parts[0]
	
	switch action {
	case "serialize":
		if len(parts) < 3 {
			return fmt.Sprintf("@fujsen(%s) - Missing function name or code for serialize", params)
		}
		return f.Serialize(parts[1], parts[2])
	case "deserialize":
		if len(parts) < 2 {
			return fmt.Sprintf("@fujsen(%s) - Missing function name for deserialize", params)
		}
		return f.Deserialize(parts[1])
	case "execute":
		if len(parts) < 3 {
			return fmt.Sprintf("@fujsen(%s) - Missing function name or arguments for execute", params)
		}
		args := ""
		if len(parts) > 3 {
			args = parts[3]
		}
		return f.ExecuteFunction(parts[1], parts[2], args)
	case "list":
		return f.ListFunctions()
	case "clear":
		return f.ClearFunctions()
	default:
		return fmt.Sprintf("@fujsen(%s) - Unknown action: %s", params, action)
	}
}

// Serialize serializes a JavaScript function
func (f *FUJSENOperator) Serialize(name, code string) interface{} {
	f.mutex.Lock()
	defer f.mutex.Unlock()
	
	// Parse function code to extract parameters
	parameters := f.extractParameters(code)
	
	// Create FUJSEN function
	fujsenFunc := &FUJSENFunction{
		Name:       name,
		Code:       code,
		Parameters: parameters,
		Returns:    f.extractReturnType(code),
		Metadata: map[string]interface{}{
			"created_at": "now",
			"language":   "javascript",
		},
	}
	
	f.functions[name] = fujsenFunc
	
	// Serialize to JSON
	jsonData, err := json.Marshal(fujsenFunc)
	if err != nil {
		return fmt.Sprintf("Failed to serialize function %s: %v", name, err)
	}
	
	return map[string]interface{}{
		"function": name,
		"json":     string(jsonData),
		"size":     len(jsonData),
	}
}

// Deserialize deserializes a JavaScript function
func (f *FUJSENOperator) Deserialize(name string) interface{} {
	f.mutex.RLock()
	defer f.mutex.RUnlock()
	
	function, exists := f.functions[name]
	if !exists {
		return fmt.Sprintf("Function %s not found", name)
	}
	
	if fujsenFunc, ok := function.(*FUJSENFunction); ok {
		return map[string]interface{}{
			"name":       fujsenFunc.Name,
			"code":       fujsenFunc.Code,
			"parameters": fujsenFunc.Parameters,
			"returns":    fujsenFunc.Returns,
			"metadata":   fujsenFunc.Metadata,
		}
	}
	
	return fmt.Sprintf("Function %s is not a FUJSEN function", name)
}

// ExecuteFunction executes a serialized function
func (f *FUJSENOperator) ExecuteFunction(name, functionJSON, args string) interface{} {
	f.mutex.RLock()
	defer f.mutex.RUnlock()
	
	// Parse function JSON
	var fujsenFunc FUJSENFunction
	if err := json.Unmarshal([]byte(functionJSON), &fujsenFunc); err != nil {
		return fmt.Sprintf("Failed to parse function JSON: %v", err)
	}
	
	// Parse arguments
	var arguments []interface{}
	if args != "" {
		if err := json.Unmarshal([]byte(args), &arguments); err != nil {
			return fmt.Sprintf("Failed to parse arguments: %v", err)
		}
	}
	
	// This is a simplified implementation
	// In a real implementation, you would use a JavaScript engine like otto or v8
	
	// For now, we'll return a mock execution result
	return map[string]interface{}{
		"function":   name,
		"arguments":  arguments,
		"result":     "mock_execution_result",
		"executed":   true,
		"timestamp":  "now",
	}
}

// ListFunctions returns all serialized functions
func (f *FUJSENOperator) ListFunctions() interface{} {
	f.mutex.RLock()
	defer f.mutex.RUnlock()
	
	functions := make([]string, 0, len(f.functions))
	for name := range f.functions {
		functions = append(functions, name)
	}
	
	return map[string]interface{}{
		"functions": functions,
		"count":     len(functions),
	}
}

// ClearFunctions removes all serialized functions
func (f *FUJSENOperator) ClearFunctions() interface{} {
	f.mutex.Lock()
	defer f.mutex.Unlock()
	
	count := len(f.functions)
	f.functions = make(map[string]interface{})
	
	return fmt.Sprintf("Cleared %d functions", count)
}

// extractParameters extracts parameter names from JavaScript function code
func (f *FUJSENOperator) extractParameters(code string) []string {
	// Simple parameter extraction
	// This is a basic implementation - in production you'd use a proper JS parser
	
	// Look for function parameters
	start := strings.Index(code, "(")
	if start == -1 {
		return []string{}
	}
	
	end := strings.Index(code[start:], ")")
	if end == -1 {
		return []string{}
	}
	
	paramStr := code[start+1 : start+end]
	if paramStr == "" {
		return []string{}
	}
	
	// Split by comma and clean up
	params := strings.Split(paramStr, ",")
	result := make([]string, 0, len(params))
	
	for _, param := range params {
		param = strings.TrimSpace(param)
		if param != "" {
			result = append(result, param)
		}
	}
	
	return result
}

// extractReturnType extracts return type from JavaScript function code
func (f *FUJSENOperator) extractReturnType(code string) string {
	// Simple return type detection
	// In production, you'd use a proper JS parser
	
	if strings.Contains(code, "return") {
		return "any"
	}
	
	return "void"
}

// GetFunction retrieves a function by name
func (f *FUJSENOperator) GetFunction(name string) (*FUJSENFunction, bool) {
	f.mutex.RLock()
	defer f.mutex.RUnlock()
	
	function, exists := f.functions[name]
	if !exists {
		return nil, false
	}
	
	if fujsenFunc, ok := function.(*FUJSENFunction); ok {
		return fujsenFunc, true
	}
	
	return nil, false
}

// SetFunction sets a function
func (f *FUJSENOperator) SetFunction(name string, function *FUJSENFunction) {
	f.mutex.Lock()
	defer f.mutex.Unlock()
	
	f.functions[name] = function
}

// RemoveFunction removes a function
func (f *FUJSENOperator) RemoveFunction(name string) interface{} {
	f.mutex.Lock()
	defer f.mutex.Unlock()
	
	if _, exists := f.functions[name]; exists {
		delete(f.functions, name)
		return fmt.Sprintf("Removed function %s", name)
	}
	
	return fmt.Sprintf("Function %s not found", name)
}

// ValidateFunction validates a JavaScript function
func (f *FUJSENOperator) ValidateFunction(code string) interface{} {
	// Basic validation
	errors := make([]string, 0)
	
	if !strings.Contains(code, "function") && !strings.Contains(code, "=>") {
		errors = append(errors, "Not a valid function declaration")
	}
	
	if !strings.Contains(code, "(") || !strings.Contains(code, ")") {
		errors = append(errors, "Missing function parameters")
	}
	
	if !strings.Contains(code, "{") || !strings.Contains(code, "}") {
		errors = append(errors, "Missing function body")
	}
	
	return map[string]interface{}{
		"valid":  len(errors) == 0,
		"errors": errors,
	}
}

// GetFunctionStats returns statistics about serialized functions
func (f *FUJSENOperator) GetFunctionStats() map[string]interface{} {
	f.mutex.RLock()
	defer f.mutex.RUnlock()
	
	totalSize := 0
	avgParams := 0
	totalParams := 0
	
	for _, function := range f.functions {
		if fujsenFunc, ok := function.(*FUJSENFunction); ok {
			totalSize += len(fujsenFunc.Code)
			totalParams += len(fujsenFunc.Parameters)
		}
	}
	
	count := len(f.functions)
	if count > 0 {
		avgParams = totalParams / count
	}
	
	return map[string]interface{}{
		"total_functions": count,
		"total_size":      totalSize,
		"avg_parameters":  avgParams,
		"total_parameters": totalParams,
	}
}

 