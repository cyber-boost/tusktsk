package communication

import (
	"fmt"
	"net/http"
	"sync"
	"time"
)

// SSEOperator handles @sse operations
type SSEOperator struct {
	connections map[string]*SSEConnection
	mutex       sync.RWMutex
}

// SSEConnection represents an SSE connection
type SSEConnection struct {
	ID       string
	URL      string
	Headers  map[string]string
	LastID   string
	Retry    time.Duration
	Active   bool
	Messages chan SSEEvent
}

// SSEEvent represents an SSE event
type SSEEvent struct {
	ID      string                 `json:"id"`
	Event   string                 `json:"event"`
	Data    interface{}            `json:"data"`
	Retry   time.Duration          `json:"retry,omitempty"`
	Comment string                 `json:"comment,omitempty"`
	Headers map[string]string      `json:"headers,omitempty"`
}

// NewSSEOperator creates a new SSE operator
func NewSSEOperator() *SSEOperator {
	return &SSEOperator{
		connections: make(map[string]*SSEConnection),
	}
}

// Execute handles @sse operations
func (s *SSEOperator) Execute(params string) interface{} {
	// Parse parameters (format: "action", "url", "event_type")
	// Example: @sse("connect", "http://localhost:8080/events", "message")
	
	return fmt.Sprintf("@sse(%s)", params)
}

// Connect establishes an SSE connection
func (s *SSEOperator) Connect(name, url string, headers map[string]string) error {
	s.mutex.Lock()
	defer s.mutex.Unlock()

	connection := &SSEConnection{
		ID:       name,
		URL:      url,
		Headers:  headers,
		Retry:    3 * time.Second,
		Active:   true,
		Messages: make(chan SSEEvent, 100),
	}

	s.connections[name] = connection

	// Start listening for events
	go s.listenForEvents(connection)

	return nil
}

// Disconnect closes an SSE connection
func (s *SSEOperator) Disconnect(name string) error {
	s.mutex.Lock()
	defer s.mutex.Unlock()

	if conn, exists := s.connections[name]; exists {
		conn.Active = false
		close(conn.Messages)
		delete(s.connections, name)
		return nil
	}

	return fmt.Errorf("connection %s not found", name)
}

// SendEvent sends an event to an SSE connection
func (s *SSEOperator) SendEvent(name, eventType string, data interface{}) error {
	s.mutex.RLock()
	conn, exists := s.connections[name]
	s.mutex.RUnlock()

	if !exists {
		return fmt.Errorf("connection %s not found", name)
	}

	event := SSEEvent{
		ID:    fmt.Sprintf("%d", time.Now().UnixNano()),
		Event: eventType,
		Data:  data,
	}

	select {
	case conn.Messages <- event:
		return nil
	default:
		return fmt.Errorf("message buffer full for connection %s", name)
	}
}

// ReceiveEvent receives an event from an SSE connection
func (s *SSEOperator) ReceiveEvent(name string, timeout time.Duration) (*SSEEvent, error) {
	s.mutex.RLock()
	conn, exists := s.connections[name]
	s.mutex.RUnlock()

	if !exists {
		return nil, fmt.Errorf("connection %s not found", name)
	}

	select {
	case event := <-conn.Messages:
		return &event, nil
	case <-time.After(timeout):
		return nil, fmt.Errorf("timeout waiting for event from connection %s", name)
	}
}

// listenForEvents listens for SSE events from the server
func (s *SSEOperator) listenForEvents(conn *SSEConnection) {
	for conn.Active {
		// Create HTTP request
		req, err := http.NewRequest("GET", conn.URL, nil)
		if err != nil {
			continue
		}

		// Set headers
		req.Header.Set("Accept", "text/event-stream")
		req.Header.Set("Cache-Control", "no-cache")
		req.Header.Set("Connection", "keep-alive")

		for key, value := range conn.Headers {
			req.Header.Set(key, value)
		}

		// Execute request
		client := &http.Client{Timeout: 30 * time.Second}
		resp, err := client.Do(req)
		if err != nil {
			time.Sleep(conn.Retry)
			continue
		}
		defer resp.Body.Close()

		// Parse SSE stream
		s.parseSSEStream(conn, resp)
	}
}

// parseSSEStream parses the SSE event stream
func (s *SSEOperator) parseSSEStream(conn *SSEConnection, resp *http.Response) {
	// This is a simplified implementation
	// In a real implementation, you would parse the actual SSE format
	
	event := SSEEvent{
		ID:    fmt.Sprintf("%d", time.Now().UnixNano()),
		Event: "message",
		Data:  "SSE event received",
	}

	select {
	case conn.Messages <- event:
	default:
		// Buffer full, skip event
	}
}

// SetRetry sets the retry interval for a connection
func (s *SSEOperator) SetRetry(name string, retry time.Duration) error {
	s.mutex.Lock()
	defer s.mutex.Unlock()

	if conn, exists := s.connections[name]; exists {
		conn.Retry = retry
		return nil
	}

	return fmt.Errorf("connection %s not found", name)
}

// ListConnections returns a list of active connection names
func (s *SSEOperator) ListConnections() []string {
	s.mutex.RLock()
	defer s.mutex.RUnlock()

	names := make([]string, 0, len(s.connections))
	for name := range s.connections {
		names = append(names, name)
	}
	return names
}

// GetConnectionStatus returns the status of a connection
func (s *SSEOperator) GetConnectionStatus(name string) string {
	s.mutex.RLock()
	defer s.mutex.RUnlock()

	if conn, exists := s.connections[name]; exists {
		if conn.Active {
			return "connected"
		}
		return "disconnected"
	}
	return "not_found"
}

// Close closes all SSE connections
func (s *SSEOperator) Close() error {
	s.mutex.Lock()
	defer s.mutex.Unlock()

	for name, conn := range s.connections {
		conn.Active = false
		close(conn.Messages)
		delete(s.connections, name)
	}
	return nil
} 