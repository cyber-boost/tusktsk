package core

import (
	"database/sql"
	"fmt"
	"strings"
	"time"
)

// QueryShorthandOperator handles @q operations (shorthand for @query)
type QueryShorthandOperator struct {
	db *sql.DB
}

// NewQueryShorthandOperator creates a new query shorthand operator
func NewQueryShorthandOperator(db *sql.DB) *QueryShorthandOperator {
	return &QueryShorthandOperator{
		db: db,
	}
}

// Execute handles @q operations
func (q *QueryShorthandOperator) Execute(params string) interface{} {
	// Parse parameters (format: "query_string")
	// Example: @q("SELECT * FROM users")
	// Example: @q("SELECT COUNT(*) FROM orders WHERE status = 'pending'")
	
	// For now, return a placeholder that matches PHP behavior
	// In a real implementation, this would execute database queries
	
	return fmt.Sprintf("@q(%s)", params)
}

// ExecuteQuery executes a database query and returns results
func (q *QueryShorthandOperator) ExecuteQuery(query string) (interface{}, error) {
	if q.db == nil {
		return fmt.Sprintf("[Query: %s - No database connection]", query), nil
	}
	
	// Determine query type
	query = strings.TrimSpace(query)
	queryUpper := strings.ToUpper(query)
	
	if strings.HasPrefix(queryUpper, "SELECT") {
		return q.executeSelect(query)
	} else if strings.HasPrefix(queryUpper, "INSERT") {
		return q.executeInsert(query)
	} else if strings.HasPrefix(queryUpper, "UPDATE") {
		return q.executeUpdate(query)
	} else if strings.HasPrefix(queryUpper, "DELETE") {
		return q.executeDelete(query)
	} else {
		return q.executeOther(query)
	}
}

// executeSelect executes a SELECT query
func (q *QueryShorthandOperator) executeSelect(query string) (interface{}, error) {
	rows, err := q.db.Query(query)
	if err != nil {
		return nil, fmt.Errorf("query execution failed: %v", err)
	}
	defer rows.Close()
	
	// Get column names
	columns, err := rows.Columns()
	if err != nil {
		return nil, fmt.Errorf("failed to get columns: %v", err)
	}
	
	// Prepare result slice
	var results []map[string]interface{}
	
	// Prepare scan destination
	values := make([]interface{}, len(columns))
	valuePtrs := make([]interface{}, len(columns))
	for i := range values {
		valuePtrs[i] = &values[i]
	}
	
	// Scan rows
	for rows.Next() {
		err := rows.Scan(valuePtrs...)
		if err != nil {
			return nil, fmt.Errorf("failed to scan row: %v", err)
		}
		
		// Create row map
		row := make(map[string]interface{})
		for i, col := range columns {
			val := values[i]
			
			// Handle different data types
			switch v := val.(type) {
			case []byte:
				row[col] = string(v)
			case time.Time:
				row[col] = v.Format("2006-01-02 15:04:05")
			default:
				row[col] = v
			}
		}
		
		results = append(results, row)
	}
	
	if err = rows.Err(); err != nil {
		return nil, fmt.Errorf("error iterating rows: %v", err)
	}
	
	return results, nil
}

// executeInsert executes an INSERT query
func (q *QueryShorthandOperator) executeInsert(query string) (interface{}, error) {
	result, err := q.db.Exec(query)
	if err != nil {
		return nil, fmt.Errorf("insert execution failed: %v", err)
	}
	
	lastID, err := result.LastInsertId()
	if err != nil {
		return map[string]interface{}{
			"affected_rows": 0,
			"last_insert_id": nil,
		}, nil
	}
	
	affectedRows, err := result.RowsAffected()
	if err != nil {
		return map[string]interface{}{
			"affected_rows": 0,
			"last_insert_id": lastID,
		}, nil
	}
	
	return map[string]interface{}{
		"affected_rows": affectedRows,
		"last_insert_id": lastID,
	}, nil
}

// executeUpdate executes an UPDATE query
func (q *QueryShorthandOperator) executeUpdate(query string) (interface{}, error) {
	result, err := q.db.Exec(query)
	if err != nil {
		return nil, fmt.Errorf("update execution failed: %v", err)
	}
	
	affectedRows, err := result.RowsAffected()
	if err != nil {
		return map[string]interface{}{
			"affected_rows": 0,
		}, nil
	}
	
	return map[string]interface{}{
		"affected_rows": affectedRows,
	}, nil
}

// executeDelete executes a DELETE query
func (q *QueryShorthandOperator) executeDelete(query string) (interface{}, error) {
	result, err := q.db.Exec(query)
	if err != nil {
		return nil, fmt.Errorf("delete execution failed: %v", err)
	}
	
	affectedRows, err := result.RowsAffected()
	if err != nil {
		return map[string]interface{}{
			"affected_rows": 0,
		}, nil
	}
	
	return map[string]interface{}{
		"affected_rows": affectedRows,
	}, nil
}

// executeOther executes other types of queries (CREATE, ALTER, DROP, etc.)
func (q *QueryShorthandOperator) executeOther(query string) (interface{}, error) {
	result, err := q.db.Exec(query)
	if err != nil {
		return nil, fmt.Errorf("query execution failed: %v", err)
	}
	
	affectedRows, err := result.RowsAffected()
	if err != nil {
		return map[string]interface{}{
			"affected_rows": 0,
		}, nil
	}
	
	return map[string]interface{}{
		"affected_rows": affectedRows,
	}, nil
}

// Count executes a COUNT query and returns the count
func (q *QueryShorthandOperator) Count(table string, where string) (int64, error) {
	query := fmt.Sprintf("SELECT COUNT(*) FROM %s", table)
	if where != "" {
		query += " WHERE " + where
	}
	
	var count int64
	err := q.db.QueryRow(query).Scan(&count)
	if err != nil {
		return 0, fmt.Errorf("count query failed: %v", err)
	}
	
	return count, nil
}

// Find executes a SELECT query with WHERE clause
func (q *QueryShorthandOperator) Find(table string, where string, limit int) (interface{}, error) {
	query := fmt.Sprintf("SELECT * FROM %s", table)
	if where != "" {
		query += " WHERE " + where
	}
	if limit > 0 {
		query += fmt.Sprintf(" LIMIT %d", limit)
	}
	
	return q.executeSelect(query)
}

// FindOne executes a SELECT query and returns the first result
func (q *QueryShorthandOperator) FindOne(table string, where string) (interface{}, error) {
	query := fmt.Sprintf("SELECT * FROM %s", table)
	if where != "" {
		query += " WHERE " + where
	}
	query += " LIMIT 1"
	
	results, err := q.executeSelect(query)
	if err != nil {
		return nil, err
	}
	
	if resultsSlice, ok := results.([]map[string]interface{}); ok && len(resultsSlice) > 0 {
		return resultsSlice[0], nil
	}
	
	return nil, nil
}

// Insert executes an INSERT query with data
func (q *QueryShorthandOperator) Insert(table string, data map[string]interface{}) (interface{}, error) {
	if len(data) == 0 {
		return nil, fmt.Errorf("no data provided for insert")
	}
	
	// Build INSERT query
	columns := make([]string, 0, len(data))
	values := make([]string, 0, len(data))
	args := make([]interface{}, 0, len(data))
	
	for column, value := range data {
		columns = append(columns, column)
		values = append(values, "?")
		args = append(args, value)
	}
	
	query := fmt.Sprintf("INSERT INTO %s (%s) VALUES (%s)",
		table,
		strings.Join(columns, ", "),
		strings.Join(values, ", "))
	
	// Execute with prepared statement
	stmt, err := q.db.Prepare(query)
	if err != nil {
		return nil, fmt.Errorf("failed to prepare statement: %v", err)
	}
	defer stmt.Close()
	
	result, err := stmt.Exec(args...)
	if err != nil {
		return nil, fmt.Errorf("insert execution failed: %v", err)
	}
	
	lastID, err := result.LastInsertId()
	if err != nil {
		return map[string]interface{}{
			"affected_rows": 0,
			"last_insert_id": nil,
		}, nil
	}
	
	affectedRows, err := result.RowsAffected()
	if err != nil {
		return map[string]interface{}{
			"affected_rows": 0,
			"last_insert_id": lastID,
		}, nil
	}
	
	return map[string]interface{}{
		"affected_rows": affectedRows,
		"last_insert_id": lastID,
	}, nil
}

// Update executes an UPDATE query with data
func (q *QueryShorthandOperator) Update(table string, data map[string]interface{}, where string) (interface{}, error) {
	if len(data) == 0 {
		return nil, fmt.Errorf("no data provided for update")
	}
	
	// Build UPDATE query
	setParts := make([]string, 0, len(data))
	args := make([]interface{}, 0, len(data))
	
	for column, value := range data {
		setParts = append(setParts, fmt.Sprintf("%s = ?", column))
		args = append(args, value)
	}
	
	query := fmt.Sprintf("UPDATE %s SET %s", table, strings.Join(setParts, ", "))
	if where != "" {
		query += " WHERE " + where
	}
	
	// Execute with prepared statement
	stmt, err := q.db.Prepare(query)
	if err != nil {
		return nil, fmt.Errorf("failed to prepare statement: %v", err)
	}
	defer stmt.Close()
	
	result, err := stmt.Exec(args...)
	if err != nil {
		return nil, fmt.Errorf("update execution failed: %v", err)
	}
	
	affectedRows, err := result.RowsAffected()
	if err != nil {
		return map[string]interface{}{
			"affected_rows": 0,
		}, nil
	}
	
	return map[string]interface{}{
		"affected_rows": affectedRows,
	}, nil
}

// Delete executes a DELETE query
func (q *QueryShorthandOperator) Delete(table string, where string) (interface{}, error) {
	query := fmt.Sprintf("DELETE FROM %s", table)
	if where != "" {
		query += " WHERE " + where
	}
	
	return q.executeDelete(query)
}

// Transaction executes multiple queries in a transaction
func (q *QueryShorthandOperator) Transaction(queries []string) (interface{}, error) {
	if q.db == nil {
		return nil, fmt.Errorf("no database connection")
	}
	
	tx, err := q.db.Begin()
	if err != nil {
		return nil, fmt.Errorf("failed to begin transaction: %v", err)
	}
	
	results := make([]interface{}, 0, len(queries))
	
	for i, query := range queries {
		result, err := tx.Exec(query)
		if err != nil {
			tx.Rollback()
			return nil, fmt.Errorf("query %d failed: %v", i+1, err)
		}
		
		affectedRows, _ := result.RowsAffected()
		results = append(results, map[string]interface{}{
			"query":         query,
			"affected_rows": affectedRows,
		})
	}
	
	err = tx.Commit()
	if err != nil {
		return nil, fmt.Errorf("failed to commit transaction: %v", err)
	}
	
	return results, nil
}

// SetDatabase sets the database connection
func (q *QueryShorthandOperator) SetDatabase(db *sql.DB) {
	q.db = db
}

// GetDatabase returns the current database connection
func (q *QueryShorthandOperator) GetDatabase() *sql.DB {
	return q.db
} 