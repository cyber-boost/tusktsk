package communication

import (
	"context"
	"encoding/json"
	"fmt"
	"sync"
	"time"

	"github.com/redis/go-redis/v9"
)

// RedisPubSubOperator handles @redis_pubsub operations
type RedisPubSubOperator struct {
	clients    map[string]*redis.Client
	pubsubs    map[string]*redis.PubSub
	mutex      sync.RWMutex
}

// RedisPubSubMessage represents a Redis Pub/Sub message
type RedisPubSubMessage struct {
	Channel      string                 `json:"channel"`
	Pattern      string                 `json:"pattern,omitempty"`
	Payload      interface{}            `json:"payload"`
	PayloadSlice string                 `json:"payload_slice"`
	Timestamp    time.Time              `json:"timestamp"`
}

// NewRedisPubSubOperator creates a new Redis Pub/Sub operator
func NewRedisPubSubOperator() *RedisPubSubOperator {
	return &RedisPubSubOperator{
		clients: make(map[string]*redis.Client),
		pubsubs: make(map[string]*redis.PubSub),
	}
}

// Execute handles @redis_pubsub operations
func (r *RedisPubSubOperator) Execute(params string) interface{} {
	// Parse parameters (format: "action", "channel", "message")
	// Example: @redis_pubsub("publish", "user_events", '{"id": "123"}')
	
	return fmt.Sprintf("@redis_pubsub(%s)", params)
}

// Connect establishes a Redis connection
func (r *RedisPubSubOperator) Connect(name, addr string, password string, db int) error {
	r.mutex.Lock()
	defer r.mutex.Unlock()

	client := redis.NewClient(&redis.Options{
		Addr:     addr,
		Password: password,
		DB:       db,
	})

	// Test the connection
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	if err := client.Ping(ctx).Err(); err != nil {
		return fmt.Errorf("failed to connect to Redis %s at %s: %v", name, addr, err)
	}

	r.clients[name] = client
	return nil
}

// Disconnect closes a Redis connection
func (r *RedisPubSubOperator) Disconnect(name string) error {
	r.mutex.Lock()
	defer r.mutex.Unlock()

	if pubsub, exists := r.pubsubs[name]; exists {
		pubsub.Close()
		delete(r.pubsubs, name)
	}

	if client, exists := r.clients[name]; exists {
		client.Close()
		delete(r.clients, name)
		return nil
	}

	return fmt.Errorf("connection %s not found", name)
}

// Publish publishes a message to a Redis channel
func (r *RedisPubSubOperator) Publish(connectionName, channel string, message interface{}) error {
	r.mutex.RLock()
	client, exists := r.clients[connectionName]
	r.mutex.RUnlock()

	if !exists {
		return fmt.Errorf("connection %s not found", connectionName)
	}

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	var messageStr string
	switch v := message.(type) {
	case string:
		messageStr = v
	default:
		messageBytes, err := json.Marshal(message)
		if err != nil {
			return fmt.Errorf("failed to marshal message: %v", err)
		}
		messageStr = string(messageBytes)
	}

	result := client.Publish(ctx, channel, messageStr)
	if result.Err() != nil {
		return fmt.Errorf("failed to publish to channel %s: %v", channel, result.Err())
	}

	fmt.Printf("Message published to channel %s, received by %d subscribers\n", channel, result.Val())
	return nil
}

// Subscribe subscribes to a Redis channel
func (r *RedisPubSubOperator) Subscribe(connectionName, channel string, handler func(*RedisPubSubMessage)) error {
	r.mutex.RLock()
	client, exists := r.clients[connectionName]
	r.mutex.RUnlock()

	if !exists {
		return fmt.Errorf("connection %s not found", connectionName)
	}

	pubsub := client.Subscribe(context.Background(), channel)
	
	// Wait for subscription confirmation
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	if _, err := pubsub.Receive(ctx); err != nil {
		pubsub.Close()
		return fmt.Errorf("failed to subscribe to channel %s: %v", channel, err)
	}

	subKey := fmt.Sprintf("%s:%s", connectionName, channel)
	r.mutex.Lock()
	r.pubsubs[subKey] = pubsub
	r.mutex.Unlock()

	go func() {
		ch := pubsub.Channel()
		for msg := range ch {
			var payload interface{}
			if err := json.Unmarshal([]byte(msg.Payload), &payload); err != nil {
				payload = msg.Payload
			}

			redisMessage := &RedisPubSubMessage{
				Channel:      msg.Channel,
				Pattern:      msg.Pattern,
				Payload:      payload,
				PayloadSlice: msg.Payload,
				Timestamp:    time.Now(),
			}

			handler(redisMessage)
		}
	}()

	return nil
}

// PSubscribe subscribes to Redis channels using patterns
func (r *RedisPubSubOperator) PSubscribe(connectionName, pattern string, handler func(*RedisPubSubMessage)) error {
	r.mutex.RLock()
	client, exists := r.clients[connectionName]
	r.mutex.RUnlock()

	if !exists {
		return fmt.Errorf("connection %s not found", connectionName)
	}

	pubsub := client.PSubscribe(context.Background(), pattern)
	
	// Wait for subscription confirmation
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	if _, err := pubsub.Receive(ctx); err != nil {
		pubsub.Close()
		return fmt.Errorf("failed to psubscribe to pattern %s: %v", pattern, err)
	}

	subKey := fmt.Sprintf("%s:pattern:%s", connectionName, pattern)
	r.mutex.Lock()
	r.pubsubs[subKey] = pubsub
	r.mutex.Unlock()

	go func() {
		ch := pubsub.Channel()
		for msg := range ch {
			var payload interface{}
			if err := json.Unmarshal([]byte(msg.Payload), &payload); err != nil {
				payload = msg.Payload
			}

			redisMessage := &RedisPubSubMessage{
				Channel:      msg.Channel,
				Pattern:      msg.Pattern,
				Payload:      payload,
				PayloadSlice: msg.Payload,
				Timestamp:    time.Now(),
			}

			handler(redisMessage)
		}
	}()

	return nil
}

// Unsubscribe unsubscribes from a Redis channel
func (r *RedisPubSubOperator) Unsubscribe(connectionName, channel string) error {
	subKey := fmt.Sprintf("%s:%s", connectionName, channel)
	
	r.mutex.Lock()
	defer r.mutex.Unlock()

	if pubsub, exists := r.pubsubs[subKey]; exists {
		pubsub.Unsubscribe(context.Background(), channel)
		pubsub.Close()
		delete(r.pubsubs, subKey)
		return nil
	}

	return fmt.Errorf("subscription %s not found", subKey)
}

// PUnsubscribe unsubscribes from Redis channel patterns
func (r *RedisPubSubOperator) PUnsubscribe(connectionName, pattern string) error {
	subKey := fmt.Sprintf("%s:pattern:%s", connectionName, pattern)
	
	r.mutex.Lock()
	defer r.mutex.Unlock()

	if pubsub, exists := r.pubsubs[subKey]; exists {
		pubsub.PUnsubscribe(context.Background(), pattern)
		pubsub.Close()
		delete(r.pubsubs, subKey)
		return nil
	}

	return fmt.Errorf("pattern subscription %s not found", subKey)
}

// ListChannels lists all active channels
func (r *RedisPubSubOperator) ListChannels(connectionName, pattern string) ([]string, error) {
	r.mutex.RLock()
	client, exists := r.clients[connectionName]
	r.mutex.RUnlock()

	if !exists {
		return nil, fmt.Errorf("connection %s not found", connectionName)
	}

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	channels, err := client.PubSubChannels(ctx, pattern).Result()
	if err != nil {
		return nil, fmt.Errorf("failed to list channels: %v", err)
	}

	return channels, nil
}

// GetNumSubscribers gets the number of subscribers for a channel
func (r *RedisPubSubOperator) GetNumSubscribers(connectionName, channel string) (int64, error) {
	r.mutex.RLock()
	client, exists := r.clients[connectionName]
	r.mutex.RUnlock()

	if !exists {
		return 0, fmt.Errorf("connection %s not found", connectionName)
	}

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	result, err := client.PubSubNumSub(ctx, channel).Result()
	if err != nil {
		return 0, fmt.Errorf("failed to get subscriber count for channel %s: %v", channel, err)
	}

	if count, exists := result[channel]; exists {
		return count, nil
	}

	return 0, nil
}

// ListConnections returns a list of active connection names
func (r *RedisPubSubOperator) ListConnections() []string {
	r.mutex.RLock()
	defer r.mutex.RUnlock()

	names := make([]string, 0, len(r.clients))
	for name := range r.clients {
		names = append(names, name)
	}
	return names
}

// GetConnectionStatus returns the status of a connection
func (r *RedisPubSubOperator) GetConnectionStatus(name string) string {
	r.mutex.RLock()
	defer r.mutex.RUnlock()

	if client, exists := r.clients[name]; exists {
		ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
		defer cancel()

		if err := client.Ping(ctx).Err(); err != nil {
			return "disconnected"
		}
		return "connected"
	}
	return "not_found"
}

// Close closes all Redis connections
func (r *RedisPubSubOperator) Close() error {
	r.mutex.Lock()
	defer r.mutex.Unlock()

	for _, pubsub := range r.pubsubs {
		pubsub.Close()
	}
	r.pubsubs = make(map[string]*redis.PubSub)

	for name, client := range r.clients {
		client.Close()
		delete(r.clients, name)
	}

	return nil
} 