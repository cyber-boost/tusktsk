package communication

import (
	"encoding/json"
	"fmt"
	"sync"
	"time"

	"github.com/Shopify/sarama"
)

// KafkaOperator handles @kafka operations
type KafkaOperator struct {
	producers map[string]sarama.SyncProducer
	consumers map[string]sarama.Consumer
	mutex     sync.RWMutex
}

// KafkaMessage represents a Kafka message
type KafkaMessage struct {
	Topic     string                 `json:"topic"`
	Partition int32                  `json:"partition"`
	Offset    int64                  `json:"offset"`
	Key       string                 `json:"key"`
	Value     interface{}            `json:"value"`
	Headers   map[string]string      `json:"headers,omitempty"`
	Timestamp time.Time              `json:"timestamp,omitempty"`
}

// NewKafkaOperator creates a new Kafka operator
func NewKafkaOperator() *KafkaOperator {
	return &KafkaOperator{
		producers: make(map[string]sarama.SyncProducer),
		consumers: make(map[string]sarama.Consumer),
	}
}

// Execute handles @kafka operations
func (k *KafkaOperator) Execute(params string) interface{} {
	// Parse parameters (format: "action", "topic", "message")
	// Example: @kafka("produce", "user_events", '{"id": "123"}')
	
	return fmt.Sprintf("@kafka(%s)", params)
}

// ConnectProducer establishes a Kafka producer connection
func (k *KafkaOperator) ConnectProducer(name string, brokers []string) error {
	k.mutex.Lock()
	defer k.mutex.Unlock()

	config := sarama.NewConfig()
	config.Producer.Return.Successes = true
	config.Producer.RequiredAcks = sarama.WaitForAll
	config.Producer.Retry.Max = 5

	producer, err := sarama.NewSyncProducer(brokers, config)
	if err != nil {
		return fmt.Errorf("failed to create Kafka producer %s: %v", name, err)
	}

	k.producers[name] = producer
	return nil
}

// ConnectConsumer establishes a Kafka consumer connection
func (k *KafkaOperator) ConnectConsumer(name string, brokers []string) error {
	k.mutex.Lock()
	defer k.mutex.Unlock()

	config := sarama.NewConfig()
	config.Consumer.Return.Errors = true

	consumer, err := sarama.NewConsumer(brokers, config)
	if err != nil {
		return fmt.Errorf("failed to create Kafka consumer %s: %v", name, err)
	}

	k.consumers[name] = consumer
	return nil
}

// Produce sends a message to a Kafka topic
func (k *KafkaOperator) Produce(producerName, topic, key string, value interface{}) error {
	k.mutex.RLock()
	producer, exists := k.producers[producerName]
	k.mutex.RUnlock()

	if !exists {
		return fmt.Errorf("producer %s not found", producerName)
	}

	valueBytes, err := json.Marshal(value)
	if err != nil {
		return fmt.Errorf("failed to marshal value: %v", err)
	}

	msg := &sarama.ProducerMessage{
		Topic: topic,
		Key:   sarama.StringEncoder(key),
		Value: sarama.ByteEncoder(valueBytes),
	}

	partition, offset, err := producer.SendMessage(msg)
	if err != nil {
		return fmt.Errorf("failed to send message: %v", err)
	}

	fmt.Printf("Message sent to topic %s, partition %d, offset %d\n", topic, partition, offset)
	return nil
}

// Consume starts consuming messages from a Kafka topic
func (k *KafkaOperator) Consume(consumerName, topic string, handler func(*KafkaMessage)) error {
	k.mutex.RLock()
	consumer, exists := k.consumers[consumerName]
	k.mutex.RUnlock()

	if !exists {
		return fmt.Errorf("consumer %s not found", consumerName)
	}

	partitions, err := consumer.Partitions(topic)
	if err != nil {
		return fmt.Errorf("failed to get partitions for topic %s: %v", topic, err)
	}

	for _, partition := range partitions {
		pc, err := consumer.ConsumePartition(topic, partition, sarama.OffsetNewest)
		if err != nil {
			return fmt.Errorf("failed to start consuming partition %d: %v", partition, err)
		}

		go func(pc sarama.PartitionConsumer) {
			for msg := range pc.Messages() {
				var value interface{}
				if err := json.Unmarshal(msg.Value, &value); err != nil {
					value = string(msg.Value)
				}

				kafkaMessage := &KafkaMessage{
					Topic:     msg.Topic,
					Partition: msg.Partition,
					Offset:    msg.Offset,
					Key:       string(msg.Key),
					Value:     value,
					Timestamp: msg.Timestamp,
				}

				handler(kafkaMessage)
			}
		}(pc)
	}

	return nil
}

// GetMessage retrieves a single message from a Kafka topic
func (k *KafkaOperator) GetMessage(consumerName, topic string, partition int32, offset int64) (*KafkaMessage, error) {
	k.mutex.RLock()
	consumer, exists := k.consumers[consumerName]
	k.mutex.RUnlock()

	if !exists {
		return nil, fmt.Errorf("consumer %s not found", consumerName)
	}

	pc, err := consumer.ConsumePartition(topic, partition, offset)
	if err != nil {
		return nil, fmt.Errorf("failed to consume partition %d: %v", partition, err)
	}
	defer pc.Close()

	select {
	case msg := <-pc.Messages():
		var value interface{}
		if err := json.Unmarshal(msg.Value, &value); err != nil {
			value = string(msg.Value)
		}

		return &KafkaMessage{
			Topic:     msg.Topic,
			Partition: msg.Partition,
			Offset:    msg.Offset,
			Key:       string(msg.Key),
			Value:     value,
			Timestamp: msg.Timestamp,
		}, nil
	case <-time.After(5 * time.Second):
		return nil, fmt.Errorf("timeout waiting for message")
	}
}

// ListTopics lists all available topics
func (k *KafkaOperator) ListTopics(consumerName string) ([]string, error) {
	k.mutex.RLock()
	consumer, exists := k.consumers[consumerName]
	k.mutex.RUnlock()

	if !exists {
		return nil, fmt.Errorf("consumer %s not found", consumerName)
	}

	topics, err := consumer.Topics()
	if err != nil {
		return nil, fmt.Errorf("failed to list topics: %v", err)
	}

	return topics, nil
}

// GetPartitions gets partition information for a topic
func (k *KafkaOperator) GetPartitions(consumerName, topic string) ([]int32, error) {
	k.mutex.RLock()
	consumer, exists := k.consumers[consumerName]
	k.mutex.RUnlock()

	if !exists {
		return nil, fmt.Errorf("consumer %s not found", consumerName)
	}

	partitions, err := consumer.Partitions(topic)
	if err != nil {
		return nil, fmt.Errorf("failed to get partitions for topic %s: %v", topic, err)
	}

	return partitions, nil
}

// GetOffset gets the current offset for a topic partition
func (k *KafkaOperator) GetOffset(consumerName, topic string, partition int32) (int64, error) {
	k.mutex.RLock()
	_, exists := k.consumers[consumerName]
	k.mutex.RUnlock()

	if !exists {
		return 0, fmt.Errorf("consumer %s not found", consumerName)
	}

	// For now, return a placeholder offset
	// In a real implementation, you would use the Kafka admin client
	// or broker connection to get the actual offset
	return 0, fmt.Errorf("offset retrieval not implemented in this version")
}

// ListProducers returns a list of active producer names
func (k *KafkaOperator) ListProducers() []string {
	k.mutex.RLock()
	defer k.mutex.RUnlock()

	names := make([]string, 0, len(k.producers))
	for name := range k.producers {
		names = append(names, name)
	}
	return names
}

// ListConsumers returns a list of active consumer names
func (k *KafkaOperator) ListConsumers() []string {
	k.mutex.RLock()
	defer k.mutex.RUnlock()

	names := make([]string, 0, len(k.consumers))
	for name := range k.consumers {
		names = append(names, name)
	}
	return names
}

// Close closes all Kafka connections
func (k *KafkaOperator) Close() error {
	k.mutex.Lock()
	defer k.mutex.Unlock()

	for name, producer := range k.producers {
		producer.Close()
		delete(k.producers, name)
	}

	for name, consumer := range k.consumers {
		consumer.Close()
		delete(k.consumers, name)
	}

	return nil
} 