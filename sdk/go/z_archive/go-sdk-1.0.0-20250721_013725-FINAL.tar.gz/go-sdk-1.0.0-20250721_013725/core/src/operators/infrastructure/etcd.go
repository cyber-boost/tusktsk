package infrastructure

import (
	"context"
	"crypto/tls"
	"fmt"
	"log"
	"strings"
	"sync"
	"time"

	"go.etcd.io/etcd/clientv3"
	"go.etcd.io/etcd/clientv3/concurrency"
	"go.etcd.io/etcd/clientv3/namespace"
)

// EtcdOperator handles @etcd distributed key-value store operations
type EtcdOperator struct {
	client      *clientv3.Client
	session     *concurrency.Session
	mutex       sync.RWMutex
	watchers    map[string]clientv3.WatchChan
	config      *EtcdConfig
	isConnected bool
}

// EtcdConfig holds configuration for etcd connection
type EtcdConfig struct {
	Endpoints            []string      `json:"endpoints"`
	Username             string        `json:"username"`
	Password             string        `json:"password"`
	DialTimeout          time.Duration `json:"dial_timeout"`
	DialKeepAliveTimeout time.Duration `json:"dial_keepalive_timeout"`
	KeepAliveTimeout     time.Duration `json:"keepalive_timeout"`
	TLS                  *tls.Config   `json:"-"`
	Namespace            string        `json:"namespace"`
	MaxCallSendMsgSize   int           `json:"max_call_send_msg_size"`
	MaxCallRecvMsgSize   int           `json:"max_call_recv_msg_size"`
}

// DefaultEtcdConfig returns default configuration for etcd
func DefaultEtcdConfig() *EtcdConfig {
	return &EtcdConfig{
		Endpoints:            []string{"localhost:2379"},
		DialTimeout:          5 * time.Second,
		DialKeepAliveTimeout: 30 * time.Second,
		KeepAliveTimeout:     30 * time.Second,
		MaxCallSendMsgSize:   2 * 1024 * 1024,  // 2MB
		MaxCallRecvMsgSize:   4 * 1024 * 1024,  // 4MB
	}
}

// NewEtcdOperator creates a new etcd operator with production-ready configuration
func NewEtcdOperator(config *EtcdConfig) (*EtcdOperator, error) {
	if config == nil {
		config = DefaultEtcdConfig()
	}

	clientConfig := clientv3.Config{
		Endpoints:            config.Endpoints,
		DialTimeout:          config.DialTimeout,
		DialKeepAliveTimeout: config.DialKeepAliveTimeout,
		KeepAliveTimeout:     config.KeepAliveTimeout,
		Username:             config.Username,
		Password:             config.Password,
		TLS:                  config.TLS,
		MaxCallSendMsgSize:   config.MaxCallSendMsgSize,
		MaxCallRecvMsgSize:   config.MaxCallRecvMsgSize,
	}

	client, err := clientv3.New(clientConfig)
	if err != nil {
		return nil, fmt.Errorf("failed to create etcd client: %v", err)
	}

	// Test connection with timeout
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	_, err = client.Status(ctx, config.Endpoints[0])
	if err != nil {
		client.Close()
		return nil, fmt.Errorf("failed to connect to etcd: %v", err)
	}

	// Apply namespace if specified
	if config.Namespace != "" {
		client.KV = namespace.NewKV(client.KV, config.Namespace)
		client.Watcher = namespace.NewWatcher(client.Watcher, config.Namespace)
		client.Lease = namespace.NewLease(client.Lease, config.Namespace)
	}

	// Create session for leader election and distributed locks
	session, err := concurrency.NewSession(client, concurrency.WithTTL(30))
	if err != nil {
		client.Close()
		return nil, fmt.Errorf("failed to create etcd session: %v", err)
	}

	operator := &EtcdOperator{
		client:      client,
		session:     session,
		watchers:    make(map[string]clientv3.WatchChan),
		config:      config,
		isConnected: true,
	}

	return operator, nil
}

// Execute handles @etcd operations with parameter parsing
func (e *EtcdOperator) Execute(params string) interface{} {
	// Parse operation format: @etcd("operation", "key", "value", "options")
	parts := strings.Split(strings.Trim(params, "()\""), "\",\"")
	if len(parts) < 2 {
		return fmt.Errorf("invalid etcd operation format")
	}

	operation := strings.Trim(parts[0], "\"")
	key := strings.Trim(parts[1], "\"")

	switch operation {
	case "get":
		result, err := e.Get(key)
		if err != nil {
			return fmt.Errorf("etcd get failed: %v", err)
		}
		return result
	case "put":
		if len(parts) < 3 {
			return fmt.Errorf("put operation requires key and value")
		}
		value := strings.Trim(parts[2], "\"")
		err := e.Put(key, value)
		if err != nil {
			return fmt.Errorf("etcd put failed: %v", err)
		}
		return "success"
	case "delete":
		count, err := e.Delete(key)
		if err != nil {
			return fmt.Errorf("etcd delete failed: %v", err)
		}
		return fmt.Sprintf("deleted %d keys", count)
	case "list":
		results, err := e.List(key)
		if err != nil {
			return fmt.Errorf("etcd list failed: %v", err)
		}
		return results
	default:
		return fmt.Errorf("unsupported etcd operation: %s", operation)
	}
}

// Put stores a key-value pair in etcd with options
func (e *EtcdOperator) Put(key, value string, opts ...clientv3.OpOption) error {
	if !e.isConnected {
		return fmt.Errorf("etcd client not connected")
	}

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	_, err := e.client.Put(ctx, key, value, opts...)
	if err != nil {
		log.Printf("ETCD PUT ERROR: key=%s, error=%v", key, err)
		return fmt.Errorf("failed to put key %s: %v", key, err)
	}

	log.Printf("ETCD PUT SUCCESS: key=%s, value_length=%d", key, len(value))
	return nil
}

// Get retrieves a value from etcd by key
func (e *EtcdOperator) Get(key string, opts ...clientv3.OpOption) (*clientv3.GetResponse, error) {
	if !e.isConnected {
		return nil, fmt.Errorf("etcd client not connected")
	}

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	resp, err := e.client.Get(ctx, key, opts...)
	if err != nil {
		log.Printf("ETCD GET ERROR: key=%s, error=%v", key, err)
		return nil, fmt.Errorf("failed to get key %s: %v", key, err)
	}

	log.Printf("ETCD GET SUCCESS: key=%s, found=%d", key, len(resp.Kvs))
	return resp, nil
}

// GetValue retrieves just the value string from etcd
func (e *EtcdOperator) GetValue(key string) (string, error) {
	resp, err := e.Get(key)
	if err != nil {
		return "", err
	}

	if len(resp.Kvs) == 0 {
		return "", fmt.Errorf("key not found: %s", key)
	}

	return string(resp.Kvs[0].Value), nil
}

// Delete removes keys from etcd
func (e *EtcdOperator) Delete(key string, opts ...clientv3.OpOption) (int64, error) {
	if !e.isConnected {
		return 0, fmt.Errorf("etcd client not connected")
	}

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	resp, err := e.client.Delete(ctx, key, opts...)
	if err != nil {
		log.Printf("ETCD DELETE ERROR: key=%s, error=%v", key, err)
		return 0, fmt.Errorf("failed to delete key %s: %v", key, err)
	}

	log.Printf("ETCD DELETE SUCCESS: key=%s, deleted=%d", key, resp.Deleted)
	return resp.Deleted, nil
}

// List retrieves all keys with a prefix
func (e *EtcdOperator) List(prefix string) (map[string]string, error) {
	resp, err := e.Get(prefix, clientv3.WithPrefix())
	if err != nil {
		return nil, err
	}

	result := make(map[string]string)
	for _, kv := range resp.Kvs {
		result[string(kv.Key)] = string(kv.Value)
	}

	return result, nil
}

// Watch starts watching a key or prefix for changes
func (e *EtcdOperator) Watch(key string, handler func(clientv3.WatchResponse)) error {
	if !e.isConnected {
		return fmt.Errorf("etcd client not connected")
	}

	e.mutex.Lock()
	defer e.mutex.Unlock()

	// Close existing watcher if present
	if existingWatcher, exists := e.watchers[key]; exists {
		close(existingWatcher)
	}

	watchChan := e.client.Watch(context.Background(), key, clientv3.WithPrefix())
	e.watchers[key] = watchChan

	go func() {
		for watchResp := range watchChan {
			if watchResp.Err() != nil {
				log.Printf("ETCD WATCH ERROR: key=%s, error=%v", key, watchResp.Err())
				continue
			}
			handler(watchResp)
		}
	}()

	log.Printf("ETCD WATCH STARTED: key=%s", key)
	return nil
}

// StopWatch stops watching a key
func (e *EtcdOperator) StopWatch(key string) {
	e.mutex.Lock()
	defer e.mutex.Unlock()

	if watcher, exists := e.watchers[key]; exists {
		close(watcher)
		delete(e.watchers, key)
		log.Printf("ETCD WATCH STOPPED: key=%s", key)
	}
}

// Transaction executes a transaction with compare-and-swap operations
func (e *EtcdOperator) Transaction(cmps []clientv3.Cmp, thenOps []clientv3.Op, elseOps []clientv3.Op) (*clientv3.TxnResponse, error) {
	if !e.isConnected {
		return nil, fmt.Errorf("etcd client not connected")
	}

	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()

	txn := e.client.Txn(ctx).If(cmps...).Then(thenOps...).Else(elseOps...)
	resp, err := txn.Commit()
	if err != nil {
		return nil, fmt.Errorf("transaction failed: %v", err)
	}

	log.Printf("ETCD TRANSACTION: succeeded=%v, responses=%d", resp.Succeeded, len(resp.Responses))
	return resp, nil
}

// Lock acquires a distributed lock
func (e *EtcdOperator) Lock(key string, timeout time.Duration) (*concurrency.Mutex, error) {
	if !e.isConnected {
		return nil, fmt.Errorf("etcd client not connected")
	}

	mutex := concurrency.NewMutex(e.session, key)

	ctx, cancel := context.WithTimeout(context.Background(), timeout)
	defer cancel()

	err := mutex.Lock(ctx)
	if err != nil {
		return nil, fmt.Errorf("failed to acquire lock %s: %v", key, err)
	}

	log.Printf("ETCD LOCK ACQUIRED: key=%s", key)
	return mutex, nil
}

// Election performs leader election
func (e *EtcdOperator) Election(prefix string, candidate string) (*concurrency.Election, error) {
	if !e.isConnected {
		return nil, fmt.Errorf("etcd client not connected")
	}

	election := concurrency.NewElection(e.session, prefix)

	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()

	err := election.Campaign(ctx, candidate)
	if err != nil {
		return nil, fmt.Errorf("failed to campaign for election %s: %v", prefix, err)
	}

	log.Printf("ETCD ELECTION WON: prefix=%s, candidate=%s", prefix, candidate)
	return election, nil
}

// GetLeader retrieves the current leader
func (e *EtcdOperator) GetLeader(prefix string) (string, error) {
	election := concurrency.NewElection(e.session, prefix)

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	resp, err := election.Leader(ctx)
	if err != nil {
		return "", fmt.Errorf("failed to get leader for %s: %v", prefix, err)
	}

	if len(resp.Kvs) == 0 {
		return "", fmt.Errorf("no leader found for %s", prefix)
	}

	return string(resp.Kvs[0].Value), nil
}

// CreateLease creates a lease with TTL
func (e *EtcdOperator) CreateLease(ttl int64) (clientv3.LeaseID, error) {
	if !e.isConnected {
		return 0, fmt.Errorf("etcd client not connected")
	}

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	resp, err := e.client.Grant(ctx, ttl)
	if err != nil {
		return 0, fmt.Errorf("failed to create lease: %v", err)
	}

	log.Printf("ETCD LEASE CREATED: id=%x, ttl=%d", resp.ID, ttl)
	return resp.ID, nil
}

// KeepAlive keeps a lease alive
func (e *EtcdOperator) KeepAlive(leaseID clientv3.LeaseID) (<-chan *clientv3.LeaseKeepAliveResponse, error) {
	if !e.isConnected {
		return nil, fmt.Errorf("etcd client not connected")
	}

	ch, err := e.client.KeepAlive(context.Background(), leaseID)
	if err != nil {
		return nil, fmt.Errorf("failed to keep alive lease %x: %v", leaseID, err)
	}

	log.Printf("ETCD KEEPALIVE STARTED: lease=%x", leaseID)
	return ch, nil
}

// RevokeLease revokes a lease
func (e *EtcdOperator) RevokeLease(leaseID clientv3.LeaseID) error {
	if !e.isConnected {
		return fmt.Errorf("etcd client not connected")
	}

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	_, err := e.client.Revoke(ctx, leaseID)
	if err != nil {
		return fmt.Errorf("failed to revoke lease %x: %v", leaseID, err)
	}

	log.Printf("ETCD LEASE REVOKED: id=%x", leaseID)
	return nil
}

// Status retrieves cluster status information
func (e *EtcdOperator) Status() (map[string]*clientv3.StatusResponse, error) {
	if !e.isConnected {
		return nil, fmt.Errorf("etcd client not connected")
	}

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	status := make(map[string]*clientv3.StatusResponse)
	for _, endpoint := range e.config.Endpoints {
		resp, err := e.client.Status(ctx, endpoint)
		if err != nil {
			log.Printf("ETCD STATUS ERROR: endpoint=%s, error=%v", endpoint, err)
			continue
		}
		status[endpoint] = resp
	}

	return status, nil
}

// MemberList retrieves cluster member information
func (e *EtcdOperator) MemberList() (*clientv3.MemberListResponse, error) {
	if !e.isConnected {
		return nil, fmt.Errorf("etcd client not connected")
	}

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	resp, err := e.client.MemberList(ctx)
	if err != nil {
		return nil, fmt.Errorf("failed to get member list: %v", err)
	}

	log.Printf("ETCD MEMBERS: count=%d", len(resp.Members))
	return resp, nil
}

// Compact compacts the etcd keyspace
func (e *EtcdOperator) Compact(revision int64) error {
	if !e.isConnected {
		return fmt.Errorf("etcd client not connected")
	}

	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()

	_, err := e.client.Compact(ctx, revision, clientv3.WithCompactPhysical())
	if err != nil {
		return fmt.Errorf("failed to compact at revision %d: %v", revision, err)
	}

	log.Printf("ETCD COMPACTED: revision=%d", revision)
	return nil
}

// Defragment defragments etcd storage
func (e *EtcdOperator) Defragment() error {
	if !e.isConnected {
		return fmt.Errorf("etcd client not connected")
	}

	ctx, cancel := context.WithTimeout(context.Background(), 60*time.Second)
	defer cancel()

	for _, endpoint := range e.config.Endpoints {
		_, err := e.client.Defragment(ctx, endpoint)
		if err != nil {
			log.Printf("ETCD DEFRAG ERROR: endpoint=%s, error=%v", endpoint, err)
			continue
		}
		log.Printf("ETCD DEFRAGMENTED: endpoint=%s", endpoint)
	}

	return nil
}

// Health checks cluster health
func (e *EtcdOperator) Health() error {
	if !e.isConnected {
		return fmt.Errorf("etcd client not connected")
	}

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	for _, endpoint := range e.config.Endpoints {
		_, err := e.client.Status(ctx, endpoint)
		if err != nil {
			return fmt.Errorf("unhealthy endpoint %s: %v", endpoint, err)
		}
	}

	return nil
}

// Close closes the etcd connection and cleans up resources
func (e *EtcdOperator) Close() error {
	e.mutex.Lock()
	defer e.mutex.Unlock()

	if !e.isConnected {
		return nil
	}

	// Close all watchers
	for key, watcher := range e.watchers {
		close(watcher)
		log.Printf("ETCD WATCH CLOSED: key=%s", key)
	}
	e.watchers = make(map[string]clientv3.WatchChan)

	// Close session
	if e.session != nil {
		err := e.session.Close()
		if err != nil {
			log.Printf("ETCD SESSION CLOSE ERROR: %v", err)
		}
	}

	// Close client
	err := e.client.Close()
	e.isConnected = false

	log.Printf("ETCD CONNECTION CLOSED")
	return err
} 