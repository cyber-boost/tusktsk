package database

import (
	"context"
	"fmt"
	"time"

	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/bson/primitive"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
)

// MongoDBOperator handles @mongodb operations
type MongoDBOperator struct {
	client   *mongo.Client
	database string
}

// NewMongoDBOperator creates a new MongoDB operator
func NewMongoDBOperator(connectionString, database string) (*MongoDBOperator, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	client, err := mongo.Connect(ctx, options.Client().ApplyURI(connectionString))
	if err != nil {
		return nil, fmt.Errorf("failed to connect to MongoDB: %v", err)
	}

	// Test connection
	err = client.Ping(ctx, nil)
	if err != nil {
		return nil, fmt.Errorf("failed to ping MongoDB: %v", err)
	}

	return &MongoDBOperator{
		client:   client,
		database: database,
	}, nil
}

// Execute handles @mongodb operations
func (m *MongoDBOperator) Execute(params string) interface{} {
	// Parse parameters (format: "operation", "collection", "query")
	// Example: @mongodb("find", "users", {"status": "active"})
	
	return fmt.Sprintf("@mongodb(%s)", params)
}

// Find executes a find operation
func (m *MongoDBOperator) Find(collection string, filter interface{}, limit int64) ([]map[string]interface{}, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()

	coll := m.client.Database(m.database).Collection(collection)
	
	opts := options.Find()
	if limit > 0 {
		opts.SetLimit(limit)
	}

	cursor, err := coll.Find(ctx, filter, opts)
	if err != nil {
		return nil, fmt.Errorf("find operation failed: %v", err)
	}
	defer cursor.Close(ctx)

	var results []map[string]interface{}
	for cursor.Next(ctx) {
		var doc map[string]interface{}
		if err := cursor.Decode(&doc); err != nil {
			return nil, fmt.Errorf("failed to decode document: %v", err)
		}
		results = append(results, doc)
	}

	return results, nil
}

// FindOne executes a findOne operation
func (m *MongoDBOperator) FindOne(collection string, filter interface{}) (map[string]interface{}, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()

	coll := m.client.Database(m.database).Collection(collection)
	
	var result map[string]interface{}
	err := coll.FindOne(ctx, filter).Decode(&result)
	if err != nil {
		if err == mongo.ErrNoDocuments {
			return nil, nil
		}
		return nil, fmt.Errorf("findOne operation failed: %v", err)
	}

	return result, nil
}

// InsertOne executes an insertOne operation
func (m *MongoDBOperator) InsertOne(collection string, document interface{}) (string, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()

	coll := m.client.Database(m.database).Collection(collection)
	
	result, err := coll.InsertOne(ctx, document)
	if err != nil {
		return "", fmt.Errorf("insertOne operation failed: %v", err)
	}

	if oid, ok := result.InsertedID.(primitive.ObjectID); ok {
		return oid.Hex(), nil
	}
	return fmt.Sprintf("%v", result.InsertedID), nil
}

// InsertMany executes an insertMany operation
func (m *MongoDBOperator) InsertMany(collection string, documents []interface{}) ([]string, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()

	coll := m.client.Database(m.database).Collection(collection)
	
	result, err := coll.InsertMany(ctx, documents)
	if err != nil {
		return nil, fmt.Errorf("insertMany operation failed: %v", err)
	}

	var ids []string
	for _, id := range result.InsertedIDs {
		if oid, ok := id.(primitive.ObjectID); ok {
			ids = append(ids, oid.Hex())
		} else {
			ids = append(ids, fmt.Sprintf("%v", id))
		}
	}

	return ids, nil
}

// UpdateOne executes an updateOne operation
func (m *MongoDBOperator) UpdateOne(collection string, filter, update interface{}) (int64, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()

	coll := m.client.Database(m.database).Collection(collection)
	
	result, err := coll.UpdateOne(ctx, filter, update)
	if err != nil {
		return 0, fmt.Errorf("updateOne operation failed: %v", err)
	}

	return result.ModifiedCount, nil
}

// UpdateMany executes an updateMany operation
func (m *MongoDBOperator) UpdateMany(collection string, filter, update interface{}) (int64, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()

	coll := m.client.Database(m.database).Collection(collection)
	
	result, err := coll.UpdateMany(ctx, filter, update)
	if err != nil {
		return 0, fmt.Errorf("updateMany operation failed: %v", err)
	}

	return result.ModifiedCount, nil
}

// DeleteOne executes a deleteOne operation
func (m *MongoDBOperator) DeleteOne(collection string, filter interface{}) (int64, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()

	coll := m.client.Database(m.database).Collection(collection)
	
	result, err := coll.DeleteOne(ctx, filter)
	if err != nil {
		return 0, fmt.Errorf("deleteOne operation failed: %v", err)
	}

	return result.DeletedCount, nil
}

// DeleteMany executes a deleteMany operation
func (m *MongoDBOperator) DeleteMany(collection string, filter interface{}) (int64, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()

	coll := m.client.Database(m.database).Collection(collection)
	
	result, err := coll.DeleteMany(ctx, filter)
	if err != nil {
		return 0, fmt.Errorf("deleteMany operation failed: %v", err)
	}

	return result.DeletedCount, nil
}

// Count executes a count operation
func (m *MongoDBOperator) Count(collection string, filter interface{}) (int64, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()

	coll := m.client.Database(m.database).Collection(collection)
	
	count, err := coll.CountDocuments(ctx, filter)
	if err != nil {
		return 0, fmt.Errorf("count operation failed: %v", err)
	}

	return count, nil
}

// Aggregate executes an aggregation pipeline
func (m *MongoDBOperator) Aggregate(collection string, pipeline []interface{}) ([]map[string]interface{}, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()

	coll := m.client.Database(m.database).Collection(collection)
	
	cursor, err := coll.Aggregate(ctx, pipeline)
	if err != nil {
		return nil, fmt.Errorf("aggregate operation failed: %v", err)
	}
	defer cursor.Close(ctx)

	var results []map[string]interface{}
	for cursor.Next(ctx) {
		var doc map[string]interface{}
		if err := cursor.Decode(&doc); err != nil {
			return nil, fmt.Errorf("failed to decode aggregation result: %v", err)
		}
		results = append(results, doc)
	}

	return results, nil
}

// CreateIndex creates an index on a collection
func (m *MongoDBOperator) CreateIndex(collection string, keys interface{}, options *options.IndexOptions) (string, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()

	coll := m.client.Database(m.database).Collection(collection)
	
	indexModel := mongo.IndexModel{
		Keys:    keys,
		Options: options,
	}

	result, err := coll.Indexes().CreateOne(ctx, indexModel)
	if err != nil {
		return "", fmt.Errorf("createIndex operation failed: %v", err)
	}

	return result, nil
}

// ListCollections lists all collections in the database
func (m *MongoDBOperator) ListCollections() ([]string, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()

	db := m.client.Database(m.database)
	
	cursor, err := db.ListCollections(ctx, bson.M{})
	if err != nil {
		return nil, fmt.Errorf("listCollections operation failed: %v", err)
	}
	defer cursor.Close(ctx)

	var collections []string
	for cursor.Next(ctx) {
		var result map[string]interface{}
		if err := cursor.Decode(&result); err != nil {
			return nil, fmt.Errorf("failed to decode collection info: %v", err)
		}
		if name, ok := result["name"].(string); ok {
			collections = append(collections, name)
		}
	}

	return collections, nil
}

// DropCollection drops a collection
func (m *MongoDBOperator) DropCollection(collection string) error {
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()

	coll := m.client.Database(m.database).Collection(collection)
	
	err := coll.Drop(ctx)
	if err != nil {
		return fmt.Errorf("dropCollection operation failed: %v", err)
	}

	return nil
}

// Close closes the MongoDB connection
func (m *MongoDBOperator) Close() error {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	
	return m.client.Disconnect(ctx)
} 