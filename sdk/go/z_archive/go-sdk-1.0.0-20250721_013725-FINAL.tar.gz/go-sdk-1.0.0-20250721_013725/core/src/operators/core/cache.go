package core

import (
	"encoding/json"
	"fmt"
	"sync"
	"time"
)

// CacheEntry represents a cache entry
type CacheEntry struct {
	Value      interface{} `json:"value"`
	Expiration time.Time   `json:"expiration"`
	Created    time.Time   `json:"created"`
}

// CacheOperator handles @cache operations
type CacheOperator struct {
	cache map[string]CacheEntry
	mutex sync.RWMutex
}

// NewCacheOperator creates a new cache operator
func NewCacheOperator() *CacheOperator {
	return &CacheOperator{
		cache: make(map[string]CacheEntry),
	}
}

// Execute handles @cache operations
func (c *CacheOperator) Execute(params string) interface{} {
	// Parse parameters (format: "action,key,value,ttl")
	// Example: @cache("set", "user:123", '{"name": "John"}', "3600")
	
	if params == "" {
		return fmt.Sprintf("@cache(%s)", params)
	}
	
	// Remove quotes if present
	cleanParams := params
	if len(cleanParams) >= 2 && (cleanParams[0] == '"' || cleanParams[0] == '\'') {
		cleanParams = cleanParams[1 : len(cleanParams)-1]
	}
	
	parts := splitParams(cleanParams)
	if len(parts) == 0 {
		return fmt.Sprintf("@cache(%s) - Invalid parameters", params)
	}
	
	action := parts[0]
	
	switch action {
	case "get":
		if len(parts) < 2 {
			return fmt.Sprintf("@cache(%s) - Missing key for get", params)
		}
		return c.Get(parts[1])
	case "set":
		if len(parts) < 3 {
			return fmt.Sprintf("@cache(%s) - Missing key or value for set", params)
		}
		ttl := time.Hour // Default TTL
		if len(parts) >= 4 {
			if ttlSeconds, err := time.ParseDuration(parts[3] + "s"); err == nil {
				ttl = ttlSeconds
			}
		}
		return c.Set(parts[1], parts[2], ttl)
	case "delete":
		if len(parts) < 2 {
			return fmt.Sprintf("@cache(%s) - Missing key for delete", params)
		}
		return c.Delete(parts[1])
	case "clear":
		return c.Clear()
	case "keys":
		return c.Keys()
	default:
		return fmt.Sprintf("@cache(%s) - Unknown action: %s", params, action)
	}
}

// Get retrieves a value from cache
func (c *CacheOperator) Get(key string) interface{} {
	c.mutex.RLock()
	defer c.mutex.RUnlock()
	
	entry, exists := c.cache[key]
	if !exists {
		return nil
	}
	
	// Check if expired
	if !entry.Expiration.IsZero() && time.Now().After(entry.Expiration) {
		// Remove expired entry
		c.mutex.RUnlock()
		c.mutex.Lock()
		delete(c.cache, key)
		c.mutex.Unlock()
		c.mutex.RLock()
		return nil
	}
	
	return entry.Value
}

// Set stores a value in cache with TTL
func (c *CacheOperator) Set(key string, value interface{}, ttl time.Duration) interface{} {
	c.mutex.Lock()
	defer c.mutex.Unlock()
	
	var expiration time.Time
	if ttl > 0 {
		expiration = time.Now().Add(ttl)
	}
	
	c.cache[key] = CacheEntry{
		Value:      value,
		Expiration: expiration,
		Created:    time.Now(),
	}
	
	return fmt.Sprintf("Cached %s with TTL %v", key, ttl)
}

// Delete removes a value from cache
func (c *CacheOperator) Delete(key string) interface{} {
	c.mutex.Lock()
	defer c.mutex.Unlock()
	
	if _, exists := c.cache[key]; exists {
		delete(c.cache, key)
		return fmt.Sprintf("Deleted %s from cache", key)
	}
	
	return fmt.Sprintf("Key %s not found in cache", key)
}

// Clear removes all entries from cache
func (c *CacheOperator) Clear() interface{} {
	c.mutex.Lock()
	defer c.mutex.Unlock()
	
	count := len(c.cache)
	c.cache = make(map[string]CacheEntry)
	
	return fmt.Sprintf("Cleared %d entries from cache", count)
}

// Keys returns all cache keys
func (c *CacheOperator) Keys() interface{} {
	c.mutex.RLock()
	defer c.mutex.RUnlock()
	
	keys := make([]string, 0, len(c.cache))
	for key := range c.cache {
		keys = append(keys, key)
	}
	
	return keys
}

// Has checks if a key exists in cache
func (c *CacheOperator) Has(key string) bool {
	c.mutex.RLock()
	defer c.mutex.RUnlock()
	
	entry, exists := c.cache[key]
	if !exists {
		return false
	}
	
	// Check if expired
	if !entry.Expiration.IsZero() && time.Now().After(entry.Expiration) {
		return false
	}
	
	return true
}

// GetWithTTL retrieves a value and its remaining TTL
func (c *CacheOperator) GetWithTTL(key string) (interface{}, time.Duration) {
	c.mutex.RLock()
	defer c.mutex.RUnlock()
	
	entry, exists := c.cache[key]
	if !exists {
		return nil, 0
	}
	
	// Check if expired
	if !entry.Expiration.IsZero() && time.Now().After(entry.Expiration) {
		return nil, 0
	}
	
	var remainingTTL time.Duration
	if !entry.Expiration.IsZero() {
		remainingTTL = time.Until(entry.Expiration)
	}
	
	return entry.Value, remainingTTL
}

// SetJSON stores a JSON string in cache
func (c *CacheOperator) SetJSON(key, jsonStr string, ttl time.Duration) error {
	var value interface{}
	if err := json.Unmarshal([]byte(jsonStr), &value); err != nil {
		return fmt.Errorf("invalid JSON: %v", err)
	}
	
	c.Set(key, value, ttl)
	return nil
}

// GetJSON retrieves a value as JSON string
func (c *CacheOperator) GetJSON(key string) (string, error) {
	value := c.Get(key)
	if value == nil {
		return "", fmt.Errorf("key not found: %s", key)
	}
	
	jsonBytes, err := json.Marshal(value)
	if err != nil {
		return "", fmt.Errorf("failed to marshal to JSON: %v", err)
	}
	
	return string(jsonBytes), nil
}

// Stats returns cache statistics
func (c *CacheOperator) Stats() map[string]interface{} {
	c.mutex.RLock()
	defer c.mutex.RUnlock()
	
	total := len(c.cache)
	expired := 0
	
	now := time.Now()
	for _, entry := range c.cache {
		if !entry.Expiration.IsZero() && now.After(entry.Expiration) {
			expired++
		}
	}
	
	return map[string]interface{}{
		"total_entries": total,
		"expired":       expired,
		"active":        total - expired,
	}
}

// Cleanup removes expired entries
func (c *CacheOperator) Cleanup() int {
	c.mutex.Lock()
	defer c.mutex.Unlock()
	
	removed := 0
	now := time.Now()
	
	for key, entry := range c.cache {
		if !entry.Expiration.IsZero() && now.After(entry.Expiration) {
			delete(c.cache, key)
			removed++
		}
	}
	
	return removed
}

 