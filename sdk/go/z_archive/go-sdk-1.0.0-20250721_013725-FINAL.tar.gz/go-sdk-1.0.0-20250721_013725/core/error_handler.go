package main

import (
	"fmt"
	"strings"
	"time"
)

// Error types for TuskLang parsing
type TuskLangError struct {
	Type      string    `json:"type"`
	Message   string    `json:"message"`
	Line      int       `json:"line,omitempty"`
	Column    int       `json:"column,omitempty"`
	File      string    `json:"file,omitempty"`
	Context   string    `json:"context,omitempty"`
	Timestamp time.Time `json:"timestamp"`
	Severity  string    `json:"severity"`
}

func (e *TuskLangError) Error() string {
	if e.File != "" && e.Line > 0 {
		return fmt.Sprintf("[%s] %s at %s:%d:%d - %s", 
			e.Type, e.Message, e.File, e.Line, e.Column, e.Context)
	}
	return fmt.Sprintf("[%s] %s - %s", e.Type, e.Message, e.Context)
}

// ValidationError represents syntax or semantic validation errors
type ValidationError struct {
	TuskLangError
	Field   string `json:"field"`
	Value   string `json:"value"`
	Rule    string `json:"rule"`
}

// ParseError represents parsing-specific errors
type ParseError struct {
	TuskLangError
	Token     string `json:"token"`
	Expected  string `json:"expected"`
	Recovery  string `json:"recovery"`
}

// RuntimeError represents runtime execution errors
type RuntimeError struct {
	TuskLangError
	Operation string `json:"operation"`
	Resource  string `json:"resource"`
}

// ErrorHandler manages error collection and reporting
type ErrorHandler struct {
	errors    []*TuskLangError
	warnings  []*TuskLangError
	maxErrors int
	strict    bool
}

// NewErrorHandler creates a new error handler
func NewErrorHandler() *ErrorHandler {
	return &ErrorHandler{
		errors:    make([]*TuskLangError, 0),
		warnings:  make([]*TuskLangError, 0),
		maxErrors: 100,
		strict:    false,
	}
}

// SetStrict enables strict error handling (fail fast)
func (h *ErrorHandler) SetStrict(strict bool) {
	h.strict = strict
}

// SetMaxErrors sets the maximum number of errors to collect
func (h *ErrorHandler) SetMaxErrors(max int) {
	h.maxErrors = max
}

// AddError adds a new error
func (h *ErrorHandler) AddError(errType, message, context string, line, column int, file string) error {
	if len(h.errors) >= h.maxErrors {
		return fmt.Errorf("maximum error limit reached (%d)", h.maxErrors)
	}

	err := &TuskLangError{
		Type:      errType,
		Message:   message,
		Line:      line,
		Column:    column,
		File:      file,
		Context:   context,
		Timestamp: time.Now(),
		Severity:  "error",
	}

	h.errors = append(h.errors, err)

	if h.strict {
		return err
	}
	return nil
}

// AddWarning adds a new warning
func (h *ErrorHandler) AddWarning(errType, message, context string, line, column int, file string) {
	warning := &TuskLangError{
		Type:      errType,
		Message:   message,
		Line:      line,
		Column:    column,
		File:      file,
		Context:   context,
		Timestamp: time.Now(),
		Severity:  "warning",
	}

	h.warnings = append(h.warnings, warning)
}

// HasErrors returns true if there are any errors
func (h *ErrorHandler) HasErrors() bool {
	return len(h.errors) > 0
}

// HasWarnings returns true if there are any warnings
func (h *ErrorHandler) HasWarnings() bool {
	return len(h.warnings) > 0
}

// GetErrors returns all collected errors
func (h *ErrorHandler) GetErrors() []*TuskLangError {
	return h.errors
}

// GetWarnings returns all collected warnings
func (h *ErrorHandler) GetWarnings() []*TuskLangError {
	return h.warnings
}

// Clear clears all errors and warnings
func (h *ErrorHandler) Clear() {
	h.errors = make([]*TuskLangError, 0)
	h.warnings = make([]*TuskLangError, 0)
}

// Summary returns a summary of all errors and warnings
func (h *ErrorHandler) Summary() string {
	var sb strings.Builder
	
	if len(h.errors) > 0 {
		sb.WriteString(fmt.Sprintf("❌ %d errors:\n", len(h.errors)))
		for i, err := range h.errors {
			if i >= 10 { // Limit display
				sb.WriteString(fmt.Sprintf("... and %d more errors\n", len(h.errors)-10))
				break
			}
			sb.WriteString(fmt.Sprintf("  %s\n", err.Error()))
		}
	}
	
	if len(h.warnings) > 0 {
		sb.WriteString(fmt.Sprintf("⚠️  %d warnings:\n", len(h.warnings)))
		for i, warning := range h.warnings {
			if i >= 5 { // Limit display
				sb.WriteString(fmt.Sprintf("... and %d more warnings\n", len(h.warnings)-5))
				break
			}
			sb.WriteString(fmt.Sprintf("  %s\n", warning.Error()))
		}
	}
	
	if len(h.errors) == 0 && len(h.warnings) == 0 {
		sb.WriteString("✅ No errors or warnings")
	}
	
	return sb.String()
}

// Validation functions
func ValidateSyntax(line string, lineNum int) []*ValidationError {
	var errors []*ValidationError
	
	// Check for unmatched brackets
	brackets := map[rune]rune{
		'[': ']',
		'{': '}',
		'<': '>',
		'(': ')',
	}
	
	var stack []rune
	for i, char := range line {
		if char == '[' || char == '{' || char == '<' || char == '(' {
			stack = append(stack, char)
		} else if char == ']' || char == '}' || char == '>' || char == ')' {
			if len(stack) == 0 {
				errors = append(errors, &ValidationError{
					TuskLangError: TuskLangError{
						Type:      "syntax",
						Message:   "unmatched closing bracket",
						Line:      lineNum,
						Column:    i + 1,
						Timestamp: time.Now(),
						Severity:  "error",
					},
					Field: "brackets",
					Value: string(char),
					Rule:  "bracket_matching",
				})
			} else {
				last := stack[len(stack)-1]
				if brackets[last] != char {
					errors = append(errors, &ValidationError{
						TuskLangError: TuskLangError{
							Type:      "syntax",
							Message:   "mismatched brackets",
							Line:      lineNum,
							Column:    i + 1,
							Timestamp: time.Now(),
							Severity:  "error",
						},
						Field: "brackets",
						Value: string(last) + string(char),
						Rule:  "bracket_matching",
					})
				}
				stack = stack[:len(stack)-1]
			}
		}
	}
	
	// Check for unclosed brackets
	for _, char := range stack {
		errors = append(errors, &ValidationError{
			TuskLangError: TuskLangError{
				Type:      "syntax",
				Message:   "unclosed bracket",
				Line:      lineNum,
				Column:    len(line),
				Timestamp: time.Now(),
				Severity:  "error",
			},
			Field: "brackets",
			Value: string(char),
			Rule:  "bracket_matching",
		})
	}
	
	return errors
}

func ValidateVariableName(name string) error {
	if name == "" {
		return &ValidationError{
			TuskLangError: TuskLangError{
				Type:      "validation",
				Message:   "variable name cannot be empty",
				Timestamp: time.Now(),
				Severity:  "error",
			},
			Field: "variable_name",
			Value: name,
			Rule:  "non_empty",
		}
	}
	
	if !strings.HasPrefix(name, "$") && !strings.HasPrefix(name, "@") {
		return &ValidationError{
			TuskLangError: TuskLangError{
				Type:      "validation",
				Message:   "variable name must start with $ or @",
				Timestamp: time.Now(),
				Severity:  "error",
			},
			Field: "variable_name",
			Value: name,
			Rule:  "prefix_required",
		}
	}
	
	return nil
} 