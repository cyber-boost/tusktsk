package main

import (
	"fmt"
	"testing"
	"time"
)

// TestAuthenticationManagerBasic tests basic authentication functionality
func TestAuthenticationManagerBasic(t *testing.T) {
	config := AuthConfig{
		DefaultProvider:    "local",
		Providers:          []string{"local", "oauth", "ldap"},
		SessionTimeout:     30 * time.Minute,
		TokenExpiry:        1 * time.Hour,
		RefreshTokenExpiry: 7 * 24 * time.Hour,
		MaxLoginAttempts:   5,
		LockoutDuration:    15 * time.Minute,
		EnableMFA:          false,
		EnableAuditLog:     true,
		PasswordPolicy: PasswordPolicy{
			MinLength:        8,
			RequireUppercase: true,
			RequireLowercase: true,
			RequireNumbers:   true,
			RequireSymbols:   false,
			MaxAge:           90,
		},
	}

	am := NewAuthenticationManager(config)
	if am == nil {
		t.Fatal("Failed to create AuthenticationManager")
	}

	// Test user creation
	user := &User{
		ID:        "test-user-1",
		Username:  "testuser",
		Email:     "test@example.com",
		FirstName: "Test",
		LastName:  "User",
		Roles:     []string{"user"},
		Status:    "active",
		CreatedAt: time.Now(),
		Metadata:  make(map[string]string),
	}

	err := am.CreateUser(user, "SecurePass123!")
	if err != nil {
		t.Fatalf("Failed to create user: %v", err)
	}

	// Test authentication
	credentials := &Credentials{
		Username: "testuser",
		Password: "SecurePass123!",
		Provider: "local",
	}

	result, err := am.Authenticate(credentials)
	if err != nil {
		t.Fatalf("Failed to authenticate: %v", err)
	}

	if !result.Success {
		t.Fatal("Authentication should succeed")
	}

	if result.User.Username != "testuser" {
		t.Errorf("Expected username 'testuser', got '%s'", result.User.Username)
	}

	if result.Token == "" {
		t.Fatal("Token should not be empty")
	}

	// Test token validation
	validationResult, err := am.Validate(result.Token)
	if err != nil {
		t.Fatalf("Failed to validate token: %v", err)
	}

	if !validationResult.Success {
		t.Fatal("Token validation should succeed")
	}

	if validationResult.User.ID != user.ID {
		t.Errorf("Expected user ID %s, got %s", user.ID, validationResult.User.ID)
	}

	// Test logout
	err = am.Logout(result.Token)
	if err != nil {
		t.Fatalf("Failed to logout: %v", err)
	}

	// Test that token is no longer valid after logout
	_, err = am.Validate(result.Token)
	if err == nil {
		t.Fatal("Token should be invalid after logout")
	}
}

// TestAuthenticationManagerPasswordPolicy tests password policy enforcement
func TestAuthenticationManagerPasswordPolicy(t *testing.T) {
	config := AuthConfig{
		DefaultProvider: "local",
		Providers:       []string{"local"},
		PasswordPolicy: PasswordPolicy{
			MinLength:        8,
			RequireUppercase: true,
			RequireLowercase: true,
			RequireNumbers:   true,
			RequireSymbols:   true,
			MaxAge:           90,
		},
	}

	am := NewAuthenticationManager(config)

	user := &User{
		ID:        "test-user-2",
		Username:  "testuser2",
		Email:     "test2@example.com",
		FirstName: "Test",
		LastName:  "User",
		Status:    "active",
		CreatedAt: time.Now(),
		Metadata:  make(map[string]string),
	}

	// Test weak password rejection
	err := am.CreateUser(user, "weak")
	if err == nil {
		t.Fatal("Should reject weak password")
	}

	// Test password without uppercase
	err = am.CreateUser(user, "password123!")
	if err == nil {
		t.Fatal("Should reject password without uppercase")
	}

	// Test password without lowercase
	err = am.CreateUser(user, "PASSWORD123!")
	if err == nil {
		t.Fatal("Should reject password without lowercase")
	}

	// Test password without numbers
	err = am.CreateUser(user, "Password!")
	if err == nil {
		t.Fatal("Should reject password without numbers")
	}

	// Test password without symbols
	err = am.CreateUser(user, "Password123")
	if err == nil {
		t.Fatal("Should reject password without symbols")
	}

	// Test valid password
	err = am.CreateUser(user, "SecurePass123!")
	if err != nil {
		t.Fatalf("Should accept valid password: %v", err)
	}
}

// TestAuthenticationManagerSessionManagement tests session management
func TestAuthenticationManagerSessionManagement(t *testing.T) {
	config := AuthConfig{
		DefaultProvider: "local",
		Providers:       []string{"local"},
		SessionTimeout:  1 * time.Hour,
		TokenExpiry:     30 * time.Minute,
	}

	am := NewAuthenticationManager(config)

	// Create user
	user := &User{
		ID:        "test-user-3",
		Username:  "testuser3",
		Email:     "test3@example.com",
		FirstName: "Test",
		LastName:  "User",
		Status:    "active",
		CreatedAt: time.Now(),
		Metadata:  make(map[string]string),
	}

	err := am.CreateUser(user, "SecurePass123!")
	if err != nil {
		t.Fatalf("Failed to create user: %v", err)
	}

	// Create multiple sessions
	credentials := &Credentials{
		Username: "testuser3",
		Password: "SecurePass123!",
		Provider: "local",
	}

	session1, err := am.Authenticate(credentials)
	if err != nil {
		t.Fatalf("Failed to create first session: %v", err)
	}

	session2, err := am.Authenticate(credentials)
	if err != nil {
		t.Fatalf("Failed to create second session: %v", err)
	}

	// Both sessions should be valid
	_, err = am.Validate(session1.Token)
	if err != nil {
		t.Fatalf("First session should be valid: %v", err)
	}

	_, err = am.Validate(session2.Token)
	if err != nil {
		t.Fatalf("Second session should be valid: %v", err)
	}

	// Logout one session
	err = am.Logout(session1.Token)
	if err != nil {
		t.Fatalf("Failed to logout first session: %v", err)
	}

	// First session should be invalid, second should still be valid
	_, err = am.Validate(session1.Token)
	if err == nil {
		t.Fatal("First session should be invalid after logout")
	}

	_, err = am.Validate(session2.Token)
	if err != nil {
		t.Fatalf("Second session should still be valid: %v", err)
	}
}

// TestAuthenticationManagerUserManagement tests user management functionality
func TestAuthenticationManagerUserManagement(t *testing.T) {
	config := AuthConfig{
		DefaultProvider: "local",
		Providers:       []string{"local"},
	}

	am := NewAuthenticationManager(config)

	// Test user creation
	user := &User{
		ID:        "test-user-4",
		Username:  "testuser4",
		Email:     "test4@example.com",
		FirstName: "Test",
		LastName:  "User",
		Roles:     []string{"user"},
		Status:    "active",
		CreatedAt: time.Now(),
		Metadata:  make(map[string]string),
	}

	err := am.CreateUser(user, "SecurePass123!")
	if err != nil {
		t.Fatalf("Failed to create user: %v", err)
	}

	// Test user retrieval
	retrievedUser, err := am.GetUser("test-user-4")
	if err != nil {
		t.Fatalf("Failed to get user: %v", err)
	}

	if retrievedUser.Username != "testuser4" {
		t.Errorf("Expected username 'testuser4', got '%s'", retrievedUser.Username)
	}

	// Test user update
	retrievedUser.FirstName = "Updated"
	retrievedUser.Roles = []string{"user", "admin"}

	err = am.UpdateUser(retrievedUser)
	if err != nil {
		t.Fatalf("Failed to update user: %v", err)
	}

	// Verify update
	updatedUser, err := am.GetUser("test-user-4")
	if err != nil {
		t.Fatalf("Failed to get updated user: %v", err)
	}

	if updatedUser.FirstName != "Updated" {
		t.Errorf("Expected first name 'Updated', got '%s'", updatedUser.FirstName)
	}

	if len(updatedUser.Roles) != 2 {
		t.Errorf("Expected 2 roles, got %d", len(updatedUser.Roles))
	}

	// Test user listing
	users := am.ListUsers()
	if len(users) == 0 {
		t.Fatal("Should have at least one user")
	}

	found := false
	for _, u := range users {
		if u.ID == "test-user-4" {
			found = true
			break
		}
	}

	if !found {
		t.Fatal("Created user should be in user list")
	}

	// Test user deletion
	err = am.DeleteUser("test-user-4")
	if err != nil {
		t.Fatalf("Failed to delete user: %v", err)
	}

	// Verify deletion
	_, err = am.GetUser("test-user-4")
	if err == nil {
		t.Fatal("User should not exist after deletion")
	}
}

// TestAuthenticationManagerProviders tests different authentication providers
func TestAuthenticationManagerProviders(t *testing.T) {
	config := AuthConfig{
		DefaultProvider: "local",
		Providers:       []string{"local", "oauth", "ldap"},
	}

	am := NewAuthenticationManager(config)

	// Test that providers are initialized
	if len(am.providers) != 3 {
		t.Errorf("Expected 3 providers, got %d", len(am.providers))
	}

	// Test local provider
	if am.providers["local"] == nil {
		t.Fatal("Local provider should be initialized")
	}

	if am.providers["local"].GetName() != "local" {
		t.Errorf("Expected provider name 'local', got '%s'", am.providers["local"].GetName())
	}

	// Test OAuth provider
	if am.providers["oauth"] == nil {
		t.Fatal("OAuth provider should be initialized")
	}

	if am.providers["oauth"].GetName() != "oauth" {
		t.Errorf("Expected provider name 'oauth', got '%s'", am.providers["oauth"].GetName())
	}

	// Test LDAP provider
	if am.providers["ldap"] == nil {
		t.Fatal("LDAP provider should be initialized")
	}

	if am.providers["ldap"].GetName() != "ldap" {
		t.Errorf("Expected provider name 'ldap', got '%s'", am.providers["ldap"].GetName())
	}
}

// TestAuthenticationManagerTokenRefresh tests token refresh functionality
func TestAuthenticationManagerTokenRefresh(t *testing.T) {
	config := AuthConfig{
		DefaultProvider:    "local",
		Providers:          []string{"local"},
		TokenExpiry:        1 * time.Minute,
		RefreshTokenExpiry: 10 * time.Minute,
	}

	am := NewAuthenticationManager(config)

	// Create user
	user := &User{
		ID:        "test-user-5",
		Username:  "testuser5",
		Email:     "test5@example.com",
		FirstName: "Test",
		LastName:  "User",
		Status:    "active",
		CreatedAt: time.Now(),
		Metadata:  make(map[string]string),
	}

	err := am.CreateUser(user, "SecurePass123!")
	if err != nil {
		t.Fatalf("Failed to create user: %v", err)
	}

	// Authenticate to get tokens
	credentials := &Credentials{
		Username: "testuser5",
		Password: "SecurePass123!",
		Provider: "local",
	}

	result, err := am.Authenticate(credentials)
	if err != nil {
		t.Fatalf("Failed to authenticate: %v", err)
	}

	if result.RefreshToken == "" {
		t.Fatal("Refresh token should not be empty")
	}

	// Test token refresh
	refreshResult, err := am.Refresh(result.RefreshToken)
	if err != nil {
		t.Fatalf("Failed to refresh token: %v", err)
	}

	if !refreshResult.Success {
		t.Fatal("Token refresh should succeed")
	}

	if refreshResult.Token == result.Token {
		t.Fatal("New token should be different from old token")
	}

	if refreshResult.RefreshToken == result.RefreshToken {
		t.Fatal("New refresh token should be different from old refresh token")
	}

	// Test that new token is valid
	_, err = am.Validate(refreshResult.Token)
	if err != nil {
		t.Fatalf("New token should be valid: %v", err)
	}
}

// TestAuthenticationManagerAuditLogging tests audit logging functionality
func TestAuthenticationManagerAuditLogging(t *testing.T) {
	config := AuthConfig{
		DefaultProvider: "local",
		Providers:       []string{"local"},
		EnableAuditLog:  true,
	}

	am := NewAuthenticationManager(config)

	// Create user
	user := &User{
		ID:        "test-user-6",
		Username:  "testuser6",
		Email:     "test6@example.com",
		FirstName: "Test",
		LastName:  "User",
		Status:    "active",
		CreatedAt: time.Now(),
		Metadata:  make(map[string]string),
	}

	err := am.CreateUser(user, "SecurePass123!")
	if err != nil {
		t.Fatalf("Failed to create user: %v", err)
	}

	// Test successful authentication
	credentials := &Credentials{
		Username: "testuser6",
		Password: "SecurePass123!",
		Provider: "local",
	}

	result, err := am.Authenticate(credentials)
	if err != nil {
		t.Fatalf("Failed to authenticate: %v", err)
	}

	if !result.Success {
		t.Fatal("Authentication should succeed")
	}

	// Test failed authentication
	invalidCredentials := &Credentials{
		Username: "testuser6",
		Password: "WrongPassword123!",
		Provider: "local",
	}

	_, err = am.Authenticate(invalidCredentials)
	if err == nil {
		t.Fatal("Authentication should fail with wrong password")
	}

	// Test logout
	err = am.Logout(result.Token)
	if err != nil {
		t.Fatalf("Failed to logout: %v", err)
	}

	// Audit logging is internal, but we can verify the system works
	// without throwing errors when audit logging is enabled
}

// BenchmarkAuthenticationManagerAuthenticate benchmarks authentication
func BenchmarkAuthenticationManagerAuthenticate(b *testing.B) {
	config := AuthConfig{
		DefaultProvider: "local",
		Providers:       []string{"local"},
	}

	am := NewAuthenticationManager(config)

	// Create user
	user := &User{
		ID:        "benchmark-user",
		Username:  "benchmarkuser",
		Email:     "benchmark@example.com",
		FirstName: "Benchmark",
		LastName:  "User",
		Status:    "active",
		CreatedAt: time.Now(),
		Metadata:  make(map[string]string),
	}

	err := am.CreateUser(user, "SecurePass123!")
	if err != nil {
		b.Fatalf("Failed to create user: %v", err)
	}

	credentials := &Credentials{
		Username: "benchmarkuser",
		Password: "SecurePass123!",
		Provider: "local",
	}

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		_, err := am.Authenticate(credentials)
		if err != nil {
			b.Fatalf("Authentication failed: %v", err)
		}
	}
}

// BenchmarkAuthenticationManagerCreateUser benchmarks user creation
func BenchmarkAuthenticationManagerCreateUser(b *testing.B) {
	config := AuthConfig{
		DefaultProvider: "local",
		Providers:       []string{"local"},
	}

	am := NewAuthenticationManager(config)

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		user := &User{
			ID:        fmt.Sprintf("benchmark-user-%d", i),
			Username:  fmt.Sprintf("benchmarkuser%d", i),
			Email:     fmt.Sprintf("benchmark%d@example.com", i),
			FirstName: "Benchmark",
			LastName:  "User",
			Status:    "active",
			CreatedAt: time.Now(),
			Metadata:  make(map[string]string),
		}

		err := am.CreateUser(user, "SecurePass123!")
		if err != nil {
			b.Fatalf("Failed to create user: %v", err)
		}
	}
} 