package main

import (
	"fmt"
	"testing"
	"time"
)

// TestSecurityManagerBasic tests basic security functionality
func TestSecurityManagerBasic(t *testing.T) {
	config := SecurityConfig{
		DefaultAlgorithm:      "aes-256-gcm",
		KeyRotationPeriod:     30 * 24 * time.Hour, // 30 days
		EnableAudit:           true,
		EnableKeyRotation:     true,
		EnablePolicyEnforcement: true,
		MaxKeyAge:             90 * 24 * time.Hour, // 90 days
		MinKeyLength:          256,
	}

	sm := NewSecurityManager(config)
	if sm == nil {
		t.Fatal("Failed to create SecurityManager")
	}

	// Test key generation
	key, err := sm.GenerateKey("test-key", "aes", "aes-256-gcm")
	if err != nil {
		t.Fatalf("Failed to generate key: %v", err)
	}

	if key.Name != "test-key" {
		t.Errorf("Expected key name 'test-key', got '%s'", key.Name)
	}

	if key.Type != "aes" {
		t.Errorf("Expected key type 'aes', got '%s'", key.Type)
	}

	if key.Status != "active" {
		t.Errorf("Expected key status 'active', got '%s'", key.Status)
	}

	// Test encryption and decryption
	testData := []byte("Hello, World! This is a test message for encryption.")

	encrypted, err := sm.Encrypt(testData, "aes-256-gcm", key.ID)
	if err != nil {
		t.Fatalf("Failed to encrypt data: %v", err)
	}

	if len(encrypted) == 0 {
		t.Fatal("Encrypted data should not be empty")
	}

	decrypted, err := sm.Decrypt(encrypted, "aes-256-gcm", key.ID)
	if err != nil {
		t.Fatalf("Failed to decrypt data: %v", err)
	}

	if string(decrypted) != string(testData) {
		t.Errorf("Decrypted data does not match original. Expected '%s', got '%s'", string(testData), string(decrypted))
	}
}

// TestSecurityManagerKeyManagement tests key management functionality
func TestSecurityManagerKeyManagement(t *testing.T) {
	config := SecurityConfig{
		DefaultAlgorithm:      "aes-256-gcm",
		KeyRotationPeriod:     30 * 24 * time.Hour,
		EnableAudit:           true,
		EnableKeyRotation:     true,
		EnablePolicyEnforcement: true,
		MaxKeyAge:             90 * 24 * time.Hour,
		MinKeyLength:          256,
	}

	sm := NewSecurityManager(config)

	// Test key generation
	key, err := sm.GenerateKey("management-key", "aes", "aes-256-gcm")
	if err != nil {
		t.Fatalf("Failed to generate key: %v", err)
	}

	// Test key retrieval
	retrievedKey, err := sm.GetKey(key.ID)
	if err != nil {
		t.Fatalf("Failed to get key: %v", err)
	}

	if retrievedKey.ID != key.ID {
		t.Errorf("Expected key ID %s, got %s", key.ID, retrievedKey.ID)
	}

	// Test key listing
	keys := sm.ListKeys()
	if len(keys) == 0 {
		t.Fatal("Should have at least one key")
	}

	found := false
	for _, k := range keys {
		if k.ID == key.ID {
			found = true
			break
		}
	}

	if !found {
		t.Fatal("Generated key should be in key list")
	}

	// Test key rotation
	err = sm.RotateKey(key.ID)
	if err != nil {
		t.Fatalf("Failed to rotate key: %v", err)
	}

	// Verify key rotation
	rotatedKey, err := sm.GetKey(key.ID)
	if err != nil {
		t.Fatalf("Failed to get rotated key: %v", err)
	}

	if rotatedKey.Status != "active" {
		t.Errorf("Expected rotated key status 'active', got '%s'", rotatedKey.Status)
	}
}

// TestSecurityManagerPolicyManagement tests security policy management
func TestSecurityManagerPolicyManagement(t *testing.T) {
	config := SecurityConfig{
		DefaultAlgorithm:      "aes-256-gcm",
		KeyRotationPeriod:     30 * 24 * time.Hour,
		EnableAudit:           true,
		EnableKeyRotation:     true,
		EnablePolicyEnforcement: true,
		MaxKeyAge:             90 * 24 * time.Hour,
		MinKeyLength:          256,
	}

	sm := NewSecurityManager(config)

	// Test policy creation
	policy := &SecurityPolicy{
		ID:          "encryption-policy",
		Name:        "Encryption Policy",
		Description: "Policy for encryption operations",
		Type:        "encryption",
		Rules: []*SecurityRule{
			{
				ID:          "min-key-length",
				Name:        "Minimum Key Length",
				Type:        "min_key_length",
				Condition:   "key_length >= 256",
				Value:       256,
				Action:      "allow",
				Description: "Require minimum 256-bit key length",
			},
			{
				ID:          "algorithm-whitelist",
				Name:        "Algorithm Whitelist",
				Type:        "algorithm_whitelist",
				Condition:   "algorithm in ['aes-256-gcm', 'aes-256-cbc']",
				Value:       []string{"aes-256-gcm", "aes-256-cbc"},
				Action:      "allow",
				Description: "Only allow specific algorithms",
			},
		},
		Enabled:  true,
		Priority: 1,
		CreatedAt: time.Now(),
		UpdatedAt: time.Now(),
		Metadata:  make(map[string]string),
	}

	err := sm.CreatePolicy(policy)
	if err != nil {
		t.Fatalf("Failed to create policy: %v", err)
	}

	// Test policy retrieval
	retrievedPolicy, err := sm.GetPolicy("encryption-policy")
	if err != nil {
		t.Fatalf("Failed to get policy: %v", err)
	}

	if retrievedPolicy.Name != "Encryption Policy" {
		t.Errorf("Expected policy name 'Encryption Policy', got '%s'", retrievedPolicy.Name)
	}

	// Test policy listing
	policies := sm.ListPolicies()
	if len(policies) == 0 {
		t.Fatal("Should have at least one policy")
	}

	found := false
	for _, p := range policies {
		if p.ID == "encryption-policy" {
			found = true
			break
		}
	}

	if !found {
		t.Fatal("Created policy should be in policy list")
	}
}

// TestSecurityManagerEncryptionAlgorithms tests different encryption algorithms
func TestSecurityManagerEncryptionAlgorithms(t *testing.T) {
	config := SecurityConfig{
		DefaultAlgorithm:      "aes-256-gcm",
		KeyRotationPeriod:     30 * 24 * time.Hour,
		EnableAudit:           true,
		EnableKeyRotation:     false,
		EnablePolicyEnforcement: false,
		MaxKeyAge:             90 * 24 * time.Hour,
		MinKeyLength:          256,
	}

	sm := NewSecurityManager(config)

	testData := []byte("Test data for encryption algorithm testing")

	// Test AES encryption
	aesKey, err := sm.GenerateKey("aes-test-key", "aes", "aes-256-gcm")
	if err != nil {
		t.Fatalf("Failed to generate AES key: %v", err)
	}

	encryptedAES, err := sm.Encrypt(testData, "aes-256-gcm", aesKey.ID)
	if err != nil {
		t.Fatalf("Failed to encrypt with AES: %v", err)
	}

	decryptedAES, err := sm.Decrypt(encryptedAES, "aes-256-gcm", aesKey.ID)
	if err != nil {
		t.Fatalf("Failed to decrypt with AES: %v", err)
	}

	if string(decryptedAES) != string(testData) {
		t.Errorf("AES decryption failed. Expected '%s', got '%s'", string(testData), string(decryptedAES))
	}

	// Test RSA encryption
	rsaKey, err := sm.GenerateKey("rsa-test-key", "rsa", "rsa-2048")
	if err != nil {
		t.Fatalf("Failed to generate RSA key: %v", err)
	}

	encryptedRSA, err := sm.Encrypt(testData, "rsa-2048", rsaKey.ID)
	if err != nil {
		t.Fatalf("Failed to encrypt with RSA: %v", err)
	}

	decryptedRSA, err := sm.Decrypt(encryptedRSA, "rsa-2048", rsaKey.ID)
	if err != nil {
		t.Fatalf("Failed to decrypt with RSA: %v", err)
	}

	if string(decryptedRSA) != string(testData) {
		t.Errorf("RSA decryption failed. Expected '%s', got '%s'", string(testData), string(decryptedRSA))
	}
}

// TestSecurityManagerKeyRotation tests automatic key rotation
func TestSecurityManagerKeyRotation(t *testing.T) {
	config := SecurityConfig{
		DefaultAlgorithm:      "aes-256-gcm",
		KeyRotationPeriod:     1 * time.Second, // Very short for testing
		EnableAudit:           true,
		EnableKeyRotation:     true,
		EnablePolicyEnforcement: false,
		MaxKeyAge:             5 * time.Second,
		MinKeyLength:          256,
	}

	sm := NewSecurityManager(config)

	// Generate key
	key, err := sm.GenerateKey("rotation-test-key", "aes", "aes-256-gcm")
	if err != nil {
		t.Fatalf("Failed to generate key: %v", err)
	}

	// Encrypt some data
	testData := []byte("Data to test key rotation")
	encrypted, err := sm.Encrypt(testData, "aes-256-gcm", key.ID)
	if err != nil {
		t.Fatalf("Failed to encrypt data: %v", err)
	}

	// Wait for key rotation
	time.Sleep(2 * time.Second)

	// Decrypt data - should still work with rotated key
	decrypted, err := sm.Decrypt(encrypted, "aes-256-gcm", key.ID)
	if err != nil {
		t.Fatalf("Failed to decrypt data after rotation: %v", err)
	}

	if string(decrypted) != string(testData) {
		t.Errorf("Decryption failed after key rotation. Expected '%s', got '%s'", string(testData), string(decrypted))
	}

	// Check that key was rotated
	rotatedKey, err := sm.GetKey(key.ID)
	if err != nil {
		t.Fatalf("Failed to get rotated key: %v", err)
	}

	if rotatedKey.Status != "active" {
		t.Errorf("Expected rotated key status 'active', got '%s'", rotatedKey.Status)
	}
}

// TestSecurityManagerAuditLogging tests security audit logging
func TestSecurityManagerAuditLogging(t *testing.T) {
	config := SecurityConfig{
		DefaultAlgorithm:      "aes-256-gcm",
		KeyRotationPeriod:     30 * 24 * time.Hour,
		EnableAudit:           true,
		EnableKeyRotation:     false,
		EnablePolicyEnforcement: false,
		MaxKeyAge:             90 * 24 * time.Hour,
		MinKeyLength:          256,
	}

	sm := NewSecurityManager(config)

	// Perform various operations to generate audit events
	key, err := sm.GenerateKey("audit-test-key", "aes", "aes-256-gcm")
	if err != nil {
		t.Fatalf("Failed to generate key: %v", err)
	}

	testData := []byte("Audit test data")
	encrypted, err := sm.Encrypt(testData, "aes-256-gcm", key.ID)
	if err != nil {
		t.Fatalf("Failed to encrypt data: %v", err)
	}

	decrypted, err := sm.Decrypt(encrypted, "aes-256-gcm", key.ID)
	if err != nil {
		t.Fatalf("Failed to decrypt data: %v", err)
	}

	if string(decrypted) != string(testData) {
		t.Errorf("Decryption failed. Expected '%s', got '%s'", string(testData), string(decrypted))
	}

	// Get audit events
	events := sm.GetEvents()
	if len(events) == 0 {
		t.Fatal("Should have audit events")
	}

	// Verify audit events
	foundKeyGeneration := false
	foundEncryption := false
	foundDecryption := false

	for _, event := range events {
		switch event.Type {
		case "key_operation":
			if event.Action == "generate" {
				foundKeyGeneration = true
			}
		case "encryption":
			if event.Action == "encrypt" {
				foundEncryption = true
			}
			if event.Action == "decrypt" {
				foundDecryption = true
			}
		}
	}

	if !foundKeyGeneration {
		t.Fatal("Should have key generation audit event")
	}

	if !foundEncryption {
		t.Fatal("Should have encryption audit event")
	}

	if !foundDecryption {
		t.Fatal("Should have decryption audit event")
	}
}

// TestSecurityManagerPolicyEnforcement tests policy enforcement
func TestSecurityManagerPolicyEnforcement(t *testing.T) {
	config := SecurityConfig{
		DefaultAlgorithm:      "aes-256-gcm",
		KeyRotationPeriod:     30 * 24 * time.Hour,
		EnableAudit:           true,
		EnableKeyRotation:     false,
		EnablePolicyEnforcement: true,
		MaxKeyAge:             90 * 24 * time.Hour,
		MinKeyLength:          256,
	}

	sm := NewSecurityManager(config)

	// Create policy that requires minimum key length
	policy := &SecurityPolicy{
		ID:          "key-length-policy",
		Name:        "Key Length Policy",
		Description: "Enforce minimum key length",
		Type:        "encryption",
		Rules: []*SecurityRule{
			{
				ID:          "min-key-length",
				Name:        "Minimum Key Length",
				Type:        "min_key_length",
				Condition:   "key_length >= 256",
				Value:       256,
				Action:      "deny",
				Description: "Deny keys shorter than 256 bits",
			},
		},
		Enabled:  true,
		Priority: 1,
		CreatedAt: time.Now(),
		UpdatedAt: time.Now(),
		Metadata:  make(map[string]string),
	}

	err := sm.CreatePolicy(policy)
	if err != nil {
		t.Fatalf("Failed to create policy: %v", err)
	}

	// Test that valid key generation works
	validKey, err := sm.GenerateKey("valid-key", "aes", "aes-256-gcm")
	if err != nil {
		t.Fatalf("Failed to generate valid key: %v", err)
	}

	if validKey.Status != "active" {
		t.Errorf("Expected valid key status 'active', got '%s'", validKey.Status)
	}

	// Test encryption with valid key
	testData := []byte("Policy enforcement test")
	encrypted, err := sm.Encrypt(testData, "aes-256-gcm", validKey.ID)
	if err != nil {
		t.Fatalf("Failed to encrypt with valid key: %v", err)
	}

	decrypted, err := sm.Decrypt(encrypted, "aes-256-gcm", validKey.ID)
	if err != nil {
		t.Fatalf("Failed to decrypt with valid key: %v", err)
	}

	if string(decrypted) != string(testData) {
		t.Errorf("Decryption failed. Expected '%s', got '%s'", string(testData), string(decrypted))
	}
}

// TestSecurityManagerStatistics tests security statistics
func TestSecurityManagerStatistics(t *testing.T) {
	config := SecurityConfig{
		DefaultAlgorithm:      "aes-256-gcm",
		KeyRotationPeriod:     30 * 24 * time.Hour,
		EnableAudit:           true,
		EnableKeyRotation:     false,
		EnablePolicyEnforcement: false,
		MaxKeyAge:             90 * 24 * time.Hour,
		MinKeyLength:          256,
	}

	sm := NewSecurityManager(config)

	// Perform some operations
	key, err := sm.GenerateKey("stats-test-key", "aes", "aes-256-gcm")
	if err != nil {
		t.Fatalf("Failed to generate key: %v", err)
	}

	testData := []byte("Statistics test data")
	encrypted, err := sm.Encrypt(testData, "aes-256-gcm", key.ID)
	if err != nil {
		t.Fatalf("Failed to encrypt data: %v", err)
	}

	decrypted, err := sm.Decrypt(encrypted, "aes-256-gcm", key.ID)
	if err != nil {
		t.Fatalf("Failed to decrypt data: %v", err)
	}

	if string(decrypted) != string(testData) {
		t.Errorf("Decryption failed. Expected '%s', got '%s'", string(testData), string(decrypted))
	}

	// Get statistics
	stats := sm.GetStats()
	if stats == nil {
		t.Fatal("Statistics should not be nil")
	}

	// Verify statistics contain expected data
	if stats["total_keys"] == nil {
		t.Error("Statistics should contain total_keys")
	}

	if stats["total_encryptions"] == nil {
		t.Error("Statistics should contain total_encryptions")
	}

	if stats["total_decryptions"] == nil {
		t.Error("Statistics should contain total_decryptions")
	}

	if stats["audit_events"] == nil {
		t.Error("Statistics should contain audit_events")
	}
}

// BenchmarkSecurityManagerEncrypt benchmarks encryption
func BenchmarkSecurityManagerEncrypt(b *testing.B) {
	config := SecurityConfig{
		DefaultAlgorithm:      "aes-256-gcm",
		KeyRotationPeriod:     30 * 24 * time.Hour,
		EnableAudit:           false,
		EnableKeyRotation:     false,
		EnablePolicyEnforcement: false,
		MaxKeyAge:             90 * 24 * time.Hour,
		MinKeyLength:          256,
	}

	sm := NewSecurityManager(config)

	key, err := sm.GenerateKey("benchmark-key", "aes", "aes-256-gcm")
	if err != nil {
		b.Fatalf("Failed to generate key: %v", err)
	}

	testData := []byte("Benchmark test data for encryption performance testing")

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		_, err := sm.Encrypt(testData, "aes-256-gcm", key.ID)
		if err != nil {
			b.Fatalf("Encryption failed: %v", err)
		}
	}
}

// BenchmarkSecurityManagerDecrypt benchmarks decryption
func BenchmarkSecurityManagerDecrypt(b *testing.B) {
	config := SecurityConfig{
		DefaultAlgorithm:      "aes-256-gcm",
		KeyRotationPeriod:     30 * 24 * time.Hour,
		EnableAudit:           false,
		EnableKeyRotation:     false,
		EnablePolicyEnforcement: false,
		MaxKeyAge:             90 * 24 * time.Hour,
		MinKeyLength:          256,
	}

	sm := NewSecurityManager(config)

	key, err := sm.GenerateKey("benchmark-key", "aes", "aes-256-gcm")
	if err != nil {
		b.Fatalf("Failed to generate key: %v", err)
	}

	testData := []byte("Benchmark test data for decryption performance testing")
	encrypted, err := sm.Encrypt(testData, "aes-256-gcm", key.ID)
	if err != nil {
		b.Fatalf("Failed to encrypt test data: %v", err)
	}

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		_, err := sm.Decrypt(encrypted, "aes-256-gcm", key.ID)
		if err != nil {
			b.Fatalf("Decryption failed: %v", err)
		}
	}
}

// BenchmarkSecurityManagerGenerateKey benchmarks key generation
func BenchmarkSecurityManagerGenerateKey(b *testing.B) {
	config := SecurityConfig{
		DefaultAlgorithm:      "aes-256-gcm",
		KeyRotationPeriod:     30 * 24 * time.Hour,
		EnableAudit:           false,
		EnableKeyRotation:     false,
		EnablePolicyEnforcement: false,
		MaxKeyAge:             90 * 24 * time.Hour,
		MinKeyLength:          256,
	}

	sm := NewSecurityManager(config)

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		keyName := fmt.Sprintf("benchmark-key-%d", i)
		_, err := sm.GenerateKey(keyName, "aes", "aes-256-gcm")
		if err != nil {
			b.Fatalf("Key generation failed: %v", err)
		}
	}
} 