package main

import (
	"fmt"
	"log"

	"tusk-go-sdk/src/operators"
	"tusk-go-sdk/src/operators/core"
)

func main() {
	fmt.Println("🧪 Testing TuskLang Go SDK Operators")
	fmt.Println("=====================================")

	// Test core operators
	testMetricsOperator()
	testFeatureOperator()
	testRequestOperator()
	testConditionalOperator()
	testOutputOperator()
	testQueryShorthandOperator()

	// Test operator registry
	testOperatorRegistry()

	fmt.Println("\n✅ All operator tests completed!")
}

func testMetricsOperator() {
	fmt.Println("\n📊 Testing @metrics operator...")
	
	metrics := core.NewMetricsOperator()
	
	// Test basic operations
	metrics.Track("api_calls", 1)
	metrics.Gauge("memory_usage", 1024.5)
	metrics.Counter("errors", 1)
	
	// Get metrics
	allMetrics := metrics.GetMetrics()
	fmt.Printf("  - Collected metrics: %d\n", len(allMetrics))
	
	// Test export
	jsonMetrics, err := metrics.ExportMetrics("json")
	if err != nil {
		log.Printf("  - Error exporting JSON: %v", err)
	} else {
		fmt.Printf("  - JSON export length: %d chars\n", len(jsonMetrics))
	}
	
	// Test execution
	result := metrics.Execute("track,api_calls,1")
	fmt.Printf("  - Execute result: %v\n", result)
}

func testFeatureOperator() {
	fmt.Println("\n🚩 Testing @feature operator...")
	
	features := core.NewFeatureOperator()
	
	// Add a feature flag
	flag := &core.FeatureFlag{
		Name:       "new_ui",
		Enabled:    true,
		Percentage: 50,
		Users:      []string{"user1", "user2"},
		Groups:     []string{"beta_testers"},
	}
	features.AddFlag(flag)
	
	// Test feature checks
	enabled := features.IsEnabled("new_ui")
	fmt.Printf("  - Feature 'new_ui' enabled: %v\n", enabled)
	
	enabledForUser := features.IsEnabledForUser("new_ui", "user1")
	fmt.Printf("  - Feature 'new_ui' enabled for user1: %v\n", enabledForUser)
	
	// Test execution
	result := features.Execute("new_ui")
	fmt.Printf("  - Execute result: %v\n", result)
}

func testRequestOperator() {
	fmt.Println("\n🌐 Testing @request operator...")
	
	request := core.NewRequestOperator()
	
	// Test URL parsing
	urlParts, err := request.ParseURL("https://api.example.com/v1/users?page=1")
	if err != nil {
		log.Printf("  - Error parsing URL: %v", err)
	} else {
		fmt.Printf("  - URL scheme: %v\n", urlParts["scheme"])
		fmt.Printf("  - URL host: %v\n", urlParts["host"])
	}
	
	// Test URL building
	builtURL := request.BuildURL("https", "api.example.com", "/v1/users", map[string]string{"page": "1"})
	fmt.Printf("  - Built URL: %s\n", builtURL)
	
	// Test execution
	result := request.Execute("GET,https://api.example.com/test")
	fmt.Printf("  - Execute result: %v\n", result)
}

func testConditionalOperator() {
	fmt.Println("\n🔀 Testing @if operator...")
	
	conditional := core.NewIfOperator()
	
	// Set variables
	conditional.SetVariable("user_role", "admin")
	conditional.SetVariable("count", 15)
	conditional.SetVariable("name", "John")
	
	// Test various conditions
	tests := []struct {
		condition string
		expected  bool
	}{
		{"true", true},
		{"false", false},
		{"$user_role == 'admin'", true},
		{"$count > 10", true},
		{"$count < 5", false},
		{"$name contains 'Jo'", true},
		{"$name starts_with 'Jo'", true},
		{"$name ends_with 'hn'", true},
	}
	
	for _, test := range tests {
		result := conditional.Evaluate(test.condition)
		status := "✅"
		if result != test.expected {
			status = "❌"
		}
		fmt.Printf("  %s %s = %v\n", status, test.condition, result)
	}
	
	// Test if-then-else
	result := conditional.IfThenElse("$count > 10", "many", "few")
	fmt.Printf("  - If-then-else result: %v\n", result)
	
	// Test execution
	execResult := conditional.Execute("$count > 10,many,few")
	fmt.Printf("  - Execute result: %v\n", execResult)
}

func testOutputOperator() {
	fmt.Println("\n📤 Testing @output operator...")
	
	output := core.NewOutputOperator()
	
	// Test data
	testData := map[string]interface{}{
		"name":    "John Doe",
		"age":     30,
		"active":  true,
		"tags":    []string{"user", "admin"},
		"profile": map[string]interface{}{"email": "john@example.com"},
	}
	
	// Test different formats
	formats := []string{"json", "xml", "html", "csv", "yaml", "text"}
	
	for _, format := range formats {
		result, err := output.Format(format, testData)
		if err != nil {
			log.Printf("  - Error formatting %s: %v", format, err)
		} else {
			fmt.Printf("  - %s format length: %d chars\n", format, len(result))
		}
	}
	
	// Test string transformations
	transformTests := []struct {
		format string
		input  string
	}{
		{"uppercase", "hello world"},
		{"lowercase", "HELLO WORLD"},
		{"capitalize", "hello world"},
		{"trim", "  hello world  "},
	}
	
	for _, test := range transformTests {
		result, err := output.Format(test.format, test.input)
		if err != nil {
			log.Printf("  - Error in %s: %v", test.format, err)
		} else {
			fmt.Printf("  - %s: '%s' -> '%s'\n", test.format, test.input, result)
		}
	}
	
	// Test execution
	result := output.Execute("json,$data")
	fmt.Printf("  - Execute result: %v\n", result)
}

func testQueryShorthandOperator() {
	fmt.Println("\n🗄️ Testing @q operator...")
	
	query := core.NewQOperator()
	
	// Test execution without database
	result := query.Execute("SELECT * FROM users")
	fmt.Printf("  - Execute result: %v\n", result)
	
	// Test query execution
	queryResult := query.Execute("users,id=1,id,name")
	fmt.Printf("  - Query result: %v\n", queryResult)
}

func testOperatorRegistry() {
	fmt.Println("\n🏪 Testing Operator Registry...")
	
	registry := operators.NewOperatorRegistry()
	
	// List all operators
	operatorList := registry.ListOperators()
	fmt.Printf("  - Registered operators: %v\n", operatorList)
	
	// Test operator execution
	testOperators := []string{"@metrics", "@feature", "@request", "@if", "@output", "@q"}
	
	for _, opName := range testOperators {
		result, err := registry.ExecuteOperator(opName, "test_params")
		if err != nil {
			fmt.Printf("  - %s error: %v\n", opName, err)
		} else {
			fmt.Printf("  - %s result: %v\n", opName, result)
		}
	}
	
	// Test non-existent operator
	result, err := registry.ExecuteOperator("@nonexistent", "params")
	if err != nil {
		fmt.Printf("  - Non-existent operator error: %v\n", err)
	} else {
		fmt.Printf("  - Non-existent operator: %v\n", result)
	}
} 