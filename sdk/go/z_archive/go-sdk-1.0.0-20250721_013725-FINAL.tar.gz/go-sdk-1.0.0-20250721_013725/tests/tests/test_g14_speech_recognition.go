package main

import (
	"testing"
	"time"
	"fmt"
)

// TestSpeechRecognitionEngineBasic tests basic speech recognition functionality
func TestSpeechRecognitionEngineBasic(t *testing.T) {
	config := SRConfig{
		EnableTranscription: true,
		EnableDiarization:  true,
		EnableTranslation:   true,
		EnableMonitoring:    true,
		MonitorInterval:     30 * time.Second,
		EnablePersistence:   false,
		PersistencePath:     "",
		MaxModels:           50,
		DefaultLanguage:     "english",
		EnableMultilingual:  true,
		EnableRealtime:      true,
	}

	sre := NewSpeechRecognitionEngine(config)
	if sre == nil {
		t.Fatal("Failed to create SpeechRecognitionEngine")
	}

	// Simulated audio input
	audio := "simulated_audio_data"

	// Transcribe speech
	transcription, err := sre.Transcribe(audio, "english")
	if err != nil {
		t.Fatalf("Failed to transcribe: %v", err)
	}

	if transcription.Text == "" {
		t.Error("Transcription text should not be empty")
	}

	// Speaker diarization
	diarization, err := sre.Diarize(audio, map[string]interface{}{
		"num_speakers": 2,
	})
	if err != nil {
		t.Fatalf("Failed to diarize: %v", err)
	}

	if len(diarization.Segments) == 0 {
		t.Error("Diarization segments should not be empty")
	}

	// Translate transcription
	translation, err := sre.Translate(transcription.Text, "english", "spanish")
	if err != nil {
		t.Fatalf("Failed to translate: %v", err)
	}

	if translation.TranslatedText == "" {
		t.Error("Translated text should not be empty")
	}
}

// TestSpeechRecognitionEngineModelManagement tests model management
func TestSpeechRecognitionEngineModelManagement(t *testing.T) {
	config := SRConfig{
		EnableTranscription: true,
		EnableDiarization:  true,
		EnableTranslation:   true,
		EnableMonitoring:    true,
		MonitorInterval:     30 * time.Second,
		EnablePersistence:   false,
		PersistencePath:     "",
		MaxModels:           50,
		DefaultLanguage:     "english",
		EnableMultilingual:  true,
		EnableRealtime:      true,
	}

	sre := NewSpeechRecognitionEngine(config)

	// Create multiple models
	models := []*SRModel{
		{
			ID:          "sr-model-1",
			Name:        "SR Model 1",
			Description: "First SR model",
			Type:        "transcription",
			Language:    "english",
			Config: map[string]interface{}{
				"acoustic_model": "base",
			},
			Status:    "initialized",
			CreatedAt: time.Now(),
			UpdatedAt: time.Now(),
			Metadata:  make(map[string]string),
		},
		{
			ID:          "sr-model-2",
			Name:        "SR Model 2",
			Description: "Second SR model",
			Type:        "diarization",
			Language:    "spanish",
			Config: map[string]interface{}{
				"pretrained": true,
			},
			Status:    "initialized",
			CreatedAt: time.Now(),
			UpdatedAt: time.Now(),
			Metadata:  make(map[string]string),
		},
	}

	// Register models
	for _, model := range models {
		err := sre.RegisterModel(model)
		if err != nil {
			t.Fatalf("Failed to register model %s: %v", model.ID, err)
		}
	}

	// Get model
	retrievedModel, err := sre.GetModel("sr-model-1")
	if err != nil {
		t.Fatalf("Failed to get model: %v", err)
	}

	if retrievedModel.ID != "sr-model-1" {
		t.Errorf("Expected model ID 'sr-model-1', got '%s'", retrievedModel.ID)
	}

	// List models
	allModels := sre.ListModels()
	if len(allModels) < 2 {
		t.Fatalf("Expected at least 2 models, got %d", len(allModels))
	}

	found := make(map[string]bool)
	for _, model := range allModels {
		found[model.ID] = true
	}

	if !found["sr-model-1"] {
		t.Fatal("SR-model-1 should be in model list")
	}

	if !found["sr-model-2"] {
		t.Fatal("SR-model-2 should be in model list")
	}
}

// TestSpeechRecognitionEngineMultilingual tests multilingual support
func TestSpeechRecognitionEngineMultilingual(t *testing.T) {
	config := SRConfig{
		EnableTranscription: true,
		EnableDiarization:  true,
		EnableTranslation:   true,
		EnableMonitoring:    true,
		MonitorInterval:     30 * time.Second,
		EnablePersistence:   false,
		PersistencePath:     "",
		MaxModels:           50,
		DefaultLanguage:     "english",
		EnableMultilingual:  true,
		EnableRealtime:      true,
	}

	sre := NewSpeechRecognitionEngine(config)

	// Simulated audio in different languages
	audios := map[string]string{
		"english": "hello_world_english",
		"spanish": "hola_mundo_spanish",
		"french": "bonjour_monde_french",
	}

	for lang, audio := range audios {
		transcription, err := sre.Transcribe(audio, lang)
		if err != nil {
			t.Fatalf("Failed to transcribe %s: %v", lang, err)
		}

		if transcription.Language != lang {
			t.Errorf("Expected language %s, got %s", lang, transcription.Language)
		}

		if transcription.Text == "" {
			t.Errorf("Transcription text empty for %s", lang)
		}
	}
}

// TestSpeechRecognitionEngineRealtime tests realtime recognition
func TestSpeechRecognitionEngineRealtime(t *testing.T) {
	config := SRConfig{
		EnableTranscription: true,
		EnableDiarization:  true,
		EnableTranslation:   true,
		EnableMonitoring:    true,
		MonitorInterval:     30 * time.Second,
		EnablePersistence:   false,
		PersistencePath:     "",
		MaxModels:           50,
		DefaultLanguage:     "english",
		EnableMultilingual:  true,
		EnableRealtime:      true,
	}

	sre := NewSpeechRecognitionEngine(config)

	// Start realtime session
	sessionID, err := sre.StartRealtimeSession(map[string]interface{}{
		"language": "english",
		"sample_rate": 16000,
	})
	if err != nil {
		t.Fatalf("Failed to start realtime session: %v", err)
	}

	if sessionID == "" {
		t.Fatal("Session ID should not be empty")
	}

	// Process audio chunk (simulated)
	chunk := "simulated_audio_chunk"
	result, err := sre.ProcessRealtimeChunk(sessionID, chunk)
	if err != nil {
		t.Fatalf("Failed to process chunk: %v", err)
	}

	if result.SessionID != sessionID {
		t.Errorf("Expected session ID %s, got %s", sessionID, result.SessionID)
	}

	// End session
	finalResult, err := sre.EndRealtimeSession(sessionID)
	if err != nil {
		t.Fatalf("Failed to end session: %v", err)
	}

	if finalResult.SessionID != sessionID {
		t.Errorf("Expected session ID %s, got %s", sessionID, finalResult.SessionID)
	}
}

// BenchmarkSpeechRecognitionEngineTranscribe benchmarks transcription
func BenchmarkSpeechRecognitionEngineTranscribe(b *testing.B) {
	config := SRConfig{
		EnableTranscription: true,
		EnableDiarization:  false,
		EnableTranslation:   false,
		EnableMonitoring:    false,
		MonitorInterval:     30 * time.Second,
		EnablePersistence:   false,
		PersistencePath:     "",
		MaxModels:           50,
		DefaultLanguage:     "english",
		EnableMultilingual:  true,
		EnableRealtime:      false,
	}

	sre := NewSpeechRecognitionEngine(config)

	audio := "benchmark_audio_data_long_enough_for_testing_performance"

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		_, err := sre.Transcribe(audio, "english")
		if err != nil {
			b.Fatalf("Transcription failed: %v", err)
		}
	}
} 