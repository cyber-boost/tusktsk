package main

import (
	"fmt"
	"testing"
	"time"
)

// TestOrchestrationManagerBasic tests basic orchestration functionality
func TestOrchestrationManagerBasic(t *testing.T) {
	config := OrchestrationConfig{
		DefaultNamespace:    "default",
		EnableAutoScaling:   true,
		EnableHealthChecks:  true,
		EnableMonitoring:    true,
		MonitorInterval:     30 * time.Second,
		EnableLoadBalancing: true,
		MaxInstances:        10,
		DefaultResources: &ResourceLimits{
			CPU:    "100m",
			Memory: "128Mi",
			Storage: "1Gi",
		},
	}

	om := NewOrchestrationManager(config)
	if om == nil {
		t.Fatal("Failed to create OrchestrationManager")
	}

	// Create a simple service
	service := &Service{
		ID:          "test-service",
		Name:        "Test Service",
		Description: "A simple test service",
		Version:     "1.0.0",
		Image:       "test-image:latest",
		Ports: []*ServicePort{
			{
				Name:     "http",
				Port:     8080,
				Protocol: "tcp",
				External: true,
			},
		},
		Environment: map[string]string{
			"ENV": "test",
		},
		Resources: &ResourceLimits{
			CPU:    "200m",
			Memory: "256Mi",
			Storage: "2Gi",
		},
		HealthCheck: &HealthCheck{
			Type:     "http",
			Path:     "/health",
			Port:     8080,
			Interval: 30 * time.Second,
			Timeout:  5 * time.Second,
			Retries:  3,
		},
		Scaling: &ScalingPolicy{
			MinReplicas:     1,
			MaxReplicas:     5,
			TargetCPU:       70,
			TargetMemory:    80,
			ScaleUpDelay:    1 * time.Minute,
			ScaleDownDelay:  5 * time.Minute,
			EnableAutoScale: true,
		},
		CreatedAt: time.Now(),
		UpdatedAt: time.Now(),
		Metadata:  make(map[string]string),
	}

	// Register service
	err := om.RegisterService(service)
	if err != nil {
		t.Fatalf("Failed to register service: %v", err)
	}

	// Deploy service
	deployment, err := om.DeployService("test-service", 2)
	if err != nil {
		t.Fatalf("Failed to deploy service: %v", err)
	}

	if deployment.ServiceID != "test-service" {
		t.Errorf("Expected service ID 'test-service', got '%s'", deployment.ServiceID)
	}

	if deployment.Status != "running" {
		t.Errorf("Expected status 'running', got '%s'", deployment.Status)
	}

	if deployment.Replicas != 2 {
		t.Errorf("Expected 2 replicas, got %d", deployment.Replicas)
	}

	// Verify service instances
	instances := om.GetServiceInstances("test-service")
	if len(instances) != 2 {
		t.Errorf("Expected 2 instances, got %d", len(instances))
	}

	for _, instance := range instances {
		if instance.ServiceID != "test-service" {
			t.Errorf("Expected service ID 'test-service', got '%s'", instance.ServiceID)
		}

		if instance.Status != "running" {
			t.Errorf("Expected instance status 'running', got '%s'", instance.Status)
		}
	}
}

// TestOrchestrationManagerServiceManagement tests service management operations
func TestOrchestrationManagerServiceManagement(t *testing.T) {
	config := OrchestrationConfig{
		DefaultNamespace:    "default",
		EnableAutoScaling:   true,
		EnableHealthChecks:  true,
		EnableMonitoring:    true,
		MonitorInterval:     30 * time.Second,
		EnableLoadBalancing: true,
		MaxInstances:        10,
		DefaultResources: &ResourceLimits{
			CPU:    "100m",
			Memory: "128Mi",
			Storage: "1Gi",
		},
	}

	om := NewOrchestrationManager(config)

	// Create multiple services
	services := []*Service{
		{
			ID:          "service1",
			Name:        "Service 1",
			Description: "First test service",
			Version:     "1.0.0",
			Image:       "service1:latest",
			Ports: []*ServicePort{
				{
					Name:     "http",
					Port:     8080,
					Protocol: "tcp",
					External: true,
				},
			},
			Environment: make(map[string]string),
			Resources: &ResourceLimits{
				CPU:    "100m",
				Memory: "128Mi",
				Storage: "1Gi",
			},
			HealthCheck: &HealthCheck{
				Type:     "http",
				Path:     "/health",
				Port:     8080,
				Interval: 30 * time.Second,
				Timeout:  5 * time.Second,
				Retries:  3,
			},
			Scaling: &ScalingPolicy{
				MinReplicas:     1,
				MaxReplicas:     3,
				TargetCPU:       70,
				TargetMemory:    80,
				ScaleUpDelay:    1 * time.Minute,
				ScaleDownDelay:  5 * time.Minute,
				EnableAutoScale: true,
			},
			CreatedAt: time.Now(),
			UpdatedAt: time.Now(),
			Metadata:  make(map[string]string),
		},
		{
			ID:          "service2",
			Name:        "Service 2",
			Description: "Second test service",
			Version:     "1.0.0",
			Image:       "service2:latest",
			Ports: []*ServicePort{
				{
					Name:     "http",
					Port:     8081,
					Protocol: "tcp",
					External: true,
				},
			},
			Environment: make(map[string]string),
			Resources: &ResourceLimits{
				CPU:    "200m",
				Memory: "256Mi",
				Storage: "2Gi",
			},
			HealthCheck: &HealthCheck{
				Type:     "http",
				Path:     "/health",
				Port:     8081,
				Interval: 30 * time.Second,
				Timeout:  5 * time.Second,
				Retries:  3,
			},
			Scaling: &ScalingPolicy{
				MinReplicas:     1,
				MaxReplicas:     5,
				TargetCPU:       70,
				TargetMemory:    80,
				ScaleUpDelay:    1 * time.Minute,
				ScaleDownDelay:  5 * time.Minute,
				EnableAutoScale: true,
			},
			CreatedAt: time.Now(),
			UpdatedAt: time.Now(),
			Metadata:  make(map[string]string),
		},
	}

	// Register services
	for _, service := range services {
		err := om.RegisterService(service)
		if err != nil {
			t.Fatalf("Failed to register service %s: %v", service.ID, err)
		}
	}

	// Get service
	retrievedService, err := om.GetService("service1")
	if err != nil {
		t.Fatalf("Failed to get service: %v", err)
	}

	if retrievedService.ID != "service1" {
		t.Errorf("Expected service ID 'service1', got '%s'", retrievedService.ID)
	}

	// List services
	allServices := om.ListServices()
	if len(allServices) < 2 {
		t.Fatalf("Expected at least 2 services, got %d", len(allServices))
	}

	found := make(map[string]bool)
	for _, service := range allServices {
		found[service.ID] = true
	}

	if !found["service1"] {
		t.Fatal("Service1 should be in service list")
	}

	if !found["service2"] {
		t.Fatal("Service2 should be in service list")
	}
}

// TestOrchestrationManagerDeploymentManagement tests deployment management
func TestOrchestrationManagerDeploymentManagement(t *testing.T) {
	config := OrchestrationConfig{
		DefaultNamespace:    "default",
		EnableAutoScaling:   true,
		EnableHealthChecks:  true,
		EnableMonitoring:    true,
		MonitorInterval:     30 * time.Second,
		EnableLoadBalancing: true,
		MaxInstances:        10,
		DefaultResources: &ResourceLimits{
			CPU:    "100m",
			Memory: "128Mi",
			Storage: "1Gi",
		},
	}

	om := NewOrchestrationManager(config)

	// Create service
	service := &Service{
		ID:          "deployment-service",
		Name:        "Deployment Service",
		Description: "A service for deployment tests",
		Version:     "1.0.0",
		Image:       "deployment-service:latest",
		Ports: []*ServicePort{
			{
				Name:     "http",
				Port:     8080,
				Protocol: "tcp",
				External: true,
			},
		},
		Environment: make(map[string]string),
		Resources: &ResourceLimits{
			CPU:    "100m",
			Memory: "128Mi",
			Storage: "1Gi",
		},
		HealthCheck: &HealthCheck{
			Type:     "http",
			Path:     "/health",
			Port:     8080,
			Interval: 30 * time.Second,
			Timeout:  5 * time.Second,
			Retries:  3,
		},
		Scaling: &ScalingPolicy{
			MinReplicas:     1,
			MaxReplicas:     5,
			TargetCPU:       70,
			TargetMemory:    80,
			ScaleUpDelay:    1 * time.Minute,
			ScaleDownDelay:  5 * time.Minute,
			EnableAutoScale: true,
		},
		CreatedAt: time.Now(),
		UpdatedAt: time.Now(),
		Metadata:  make(map[string]string),
	}

	// Register service
	err := om.RegisterService(service)
	if err != nil {
		t.Fatalf("Failed to register service: %v", err)
	}

	// Deploy service
	deployment, err := om.DeployService("deployment-service", 3)
	if err != nil {
		t.Fatalf("Failed to deploy service: %v", err)
	}

	// Get deployment
	retrievedDeployment, err := om.GetDeployment(deployment.ID)
	if err != nil {
		t.Fatalf("Failed to get deployment: %v", err)
	}

	if retrievedDeployment.ID != deployment.ID {
		t.Errorf("Expected deployment ID %s, got %s", deployment.ID, retrievedDeployment.ID)
	}

	// List deployments
	deployments := om.ListDeployments()
	if len(deployments) == 0 {
		t.Fatal("Should have at least one deployment")
	}

	found := false
	for _, d := range deployments {
		if d.ID == deployment.ID {
			found = true
			break
		}
	}

	if !found {
		t.Fatal("Created deployment should be in deployment list")
	}

	// Scale service
	err = om.ScaleService("deployment-service", 5)
	if err != nil {
		t.Fatalf("Failed to scale service: %v", err)
	}

	// Verify scaling
	instances := om.GetServiceInstances("deployment-service")
	if len(instances) != 5 {
		t.Errorf("Expected 5 instances after scaling, got %d", len(instances))
	}

	// Stop service
	err = om.StopService("deployment-service")
	if err != nil {
		t.Fatalf("Failed to stop service: %v", err)
	}

	// Verify service is stopped
	stoppedInstances := om.GetServiceInstances("deployment-service")
	for _, instance := range stoppedInstances {
		if instance.Status != "stopped" {
			t.Errorf("Expected instance status 'stopped', got '%s'", instance.Status)
		}
	}
}

// TestOrchestrationManagerHealthChecks tests health check functionality
func TestOrchestrationManagerHealthChecks(t *testing.T) {
	config := OrchestrationConfig{
		DefaultNamespace:    "default",
		EnableAutoScaling:   false,
		EnableHealthChecks:  true,
		EnableMonitoring:    true,
		MonitorInterval:     30 * time.Second,
		EnableLoadBalancing: false,
		MaxInstances:        10,
		DefaultResources: &ResourceLimits{
			CPU:    "100m",
			Memory: "128Mi",
			Storage: "1Gi",
		},
	}

	om := NewOrchestrationManager(config)

	// Create service with health check
	service := &Service{
		ID:          "health-service",
		Name:        "Health Service",
		Description: "A service for health check tests",
		Version:     "1.0.0",
		Image:       "health-service:latest",
		Ports: []*ServicePort{
			{
				Name:     "http",
				Port:     8080,
				Protocol: "tcp",
				External: true,
			},
		},
		Environment: make(map[string]string),
		Resources: &ResourceLimits{
			CPU:    "100m",
			Memory: "128Mi",
			Storage: "1Gi",
		},
		HealthCheck: &HealthCheck{
			Type:     "http",
			Path:     "/health",
			Port:     8080,
			Interval: 10 * time.Second,
			Timeout:  5 * time.Second,
			Retries:  3,
		},
		Scaling: &ScalingPolicy{
			MinReplicas:     1,
			MaxReplicas:     3,
			TargetCPU:       70,
			TargetMemory:    80,
			ScaleUpDelay:    1 * time.Minute,
			ScaleDownDelay:  5 * time.Minute,
			EnableAutoScale: false,
		},
		CreatedAt: time.Now(),
		UpdatedAt: time.Now(),
		Metadata:  make(map[string]string),
	}

	// Register service
	err := om.RegisterService(service)
	if err != nil {
		t.Fatalf("Failed to register service: %v", err)
	}

	// Deploy service
	deployment, err := om.DeployService("health-service", 2)
	if err != nil {
		t.Fatalf("Failed to deploy service: %v", err)
	}

	// Wait for health checks to run
	time.Sleep(1 * time.Minute)

	// Check health status
	instances := om.GetServiceInstances("health-service")
	for _, instance := range instances {
		if instance.Health == "" {
			t.Errorf("Instance should have health status, got empty")
		}

		// Health should be one of: healthy, unhealthy, unknown
		validHealth := map[string]bool{
			"healthy":   true,
			"unhealthy": true,
			"unknown":   true,
		}

		if !validHealth[instance.Health] {
			t.Errorf("Invalid health status: %s", instance.Health)
		}
	}
}

// TestOrchestrationManagerAutoScaling tests auto-scaling functionality
func TestOrchestrationManagerAutoScaling(t *testing.T) {
	config := OrchestrationConfig{
		DefaultNamespace:    "default",
		EnableAutoScaling:   true,
		EnableHealthChecks:  true,
		EnableMonitoring:    true,
		MonitorInterval:     30 * time.Second,
		EnableLoadBalancing: true,
		MaxInstances:        10,
		DefaultResources: &ResourceLimits{
			CPU:    "100m",
			Memory: "128Mi",
			Storage: "1Gi",
		},
	}

	om := NewOrchestrationManager(config)

	// Create service with auto-scaling
	service := &Service{
		ID:          "scaling-service",
		Name:        "Scaling Service",
		Description: "A service for auto-scaling tests",
		Version:     "1.0.0",
		Image:       "scaling-service:latest",
		Ports: []*ServicePort{
			{
				Name:     "http",
				Port:     8080,
				Protocol: "tcp",
				External: true,
			},
		},
		Environment: make(map[string]string),
		Resources: &ResourceLimits{
			CPU:    "100m",
			Memory: "128Mi",
			Storage: "1Gi",
		},
		HealthCheck: &HealthCheck{
			Type:     "http",
			Path:     "/health",
			Port:     8080,
			Interval: 30 * time.Second,
			Timeout:  5 * time.Second,
			Retries:  3,
		},
		Scaling: &ScalingPolicy{
			MinReplicas:     1,
			MaxReplicas:     5,
			TargetCPU:       50, // Low threshold for testing
			TargetMemory:    60, // Low threshold for testing
			ScaleUpDelay:    30 * time.Second, // Short delay for testing
			ScaleDownDelay:  1 * time.Minute,
			EnableAutoScale: true,
		},
		CreatedAt: time.Now(),
		UpdatedAt: time.Now(),
		Metadata:  make(map[string]string),
	}

	// Register service
	err := om.RegisterService(service)
	if err != nil {
		t.Fatalf("Failed to register service: %v", err)
	}

	// Deploy service with initial replicas
	deployment, err := om.DeployService("scaling-service", 1)
	if err != nil {
		t.Fatalf("Failed to deploy service: %v", err)
	}

	initialReplicas := len(om.GetServiceInstances("scaling-service"))

	// Wait for auto-scaling to potentially trigger
	time.Sleep(2 * time.Minute)

	// Check if auto-scaling occurred
	finalReplicas := len(om.GetServiceInstances("scaling-service"))

	// Auto-scaling might have occurred based on simulated load
	if finalReplicas < initialReplicas {
		t.Errorf("Auto-scaling should not reduce replicas below initial count. Initial: %d, Final: %d", initialReplicas, finalReplicas)
	}

	if finalReplicas > 5 {
		t.Errorf("Auto-scaling should not exceed max replicas. Expected <= 5, got %d", finalReplicas)
	}
}

// TestOrchestrationManagerMonitoring tests monitoring functionality
func TestOrchestrationManagerMonitoring(t *testing.T) {
	config := OrchestrationConfig{
		DefaultNamespace:    "default",
		EnableAutoScaling:   false,
		EnableHealthChecks:  true,
		EnableMonitoring:    true,
		MonitorInterval:     30 * time.Second,
		EnableLoadBalancing: false,
		MaxInstances:        10,
		DefaultResources: &ResourceLimits{
			CPU:    "100m",
			Memory: "128Mi",
			Storage: "1Gi",
		},
	}

	om := NewOrchestrationManager(config)

	// Create and deploy multiple services to generate metrics
	for i := 0; i < 3; i++ {
		service := &Service{
			ID:          fmt.Sprintf("monitor-service-%d", i),
			Name:        fmt.Sprintf("Monitor Service %d", i),
			Description: "A service for monitoring tests",
			Version:     "1.0.0",
			Image:       fmt.Sprintf("monitor-service-%d:latest", i),
			Ports: []*ServicePort{
				{
					Name:     "http",
					Port:     8080 + i,
					Protocol: "tcp",
					External: true,
				},
			},
			Environment: make(map[string]string),
			Resources: &ResourceLimits{
				CPU:    "100m",
				Memory: "128Mi",
				Storage: "1Gi",
			},
			HealthCheck: &HealthCheck{
				Type:     "http",
				Path:     "/health",
				Port:     8080 + i,
				Interval: 30 * time.Second,
				Timeout:  5 * time.Second,
				Retries:  3,
			},
			Scaling: &ScalingPolicy{
				MinReplicas:     1,
				MaxReplicas:     3,
				TargetCPU:       70,
				TargetMemory:    80,
				ScaleUpDelay:    1 * time.Minute,
				ScaleDownDelay:  5 * time.Minute,
				EnableAutoScale: false,
			},
			CreatedAt: time.Now(),
			UpdatedAt: time.Now(),
			Metadata:  make(map[string]string),
		}

		err := om.RegisterService(service)
		if err != nil {
			t.Fatalf("Failed to register service %d: %v", i, err)
		}

		_, err = om.DeployService(service.ID, 1)
		if err != nil {
			t.Fatalf("Failed to deploy service %d: %v", i, err)
		}
	}

	// Wait for monitoring to collect metrics
	time.Sleep(1 * time.Minute)

	// Get statistics
	stats := om.GetStats()
	if stats == nil {
		t.Fatal("Statistics should not be nil")
	}

	// Verify statistics contain expected data
	if stats["total_services"] == nil {
		t.Error("Statistics should contain total_services")
	}

	if stats["total_deployments"] == nil {
		t.Error("Statistics should contain total_deployments")
	}

	if stats["total_instances"] == nil {
		t.Error("Statistics should contain total_instances")
	}

	if stats["healthy_instances"] == nil {
		t.Error("Statistics should contain healthy_instances")
	}
}

// BenchmarkOrchestrationManagerDeployService benchmarks service deployment
func BenchmarkOrchestrationManagerDeployService(b *testing.B) {
	config := OrchestrationConfig{
		DefaultNamespace:    "default",
		EnableAutoScaling:   false,
		EnableHealthChecks:  false,
		EnableMonitoring:    false,
		MonitorInterval:     30 * time.Second,
		EnableLoadBalancing: false,
		MaxInstances:        10,
		DefaultResources: &ResourceLimits{
			CPU:    "100m",
			Memory: "128Mi",
			Storage: "1Gi",
		},
	}

	om := NewOrchestrationManager(config)

	// Create service
	service := &Service{
		ID:          "benchmark-service",
		Name:        "Benchmark Service",
		Description: "A service for benchmarking",
		Version:     "1.0.0",
		Image:       "benchmark-service:latest",
		Ports: []*ServicePort{
			{
				Name:     "http",
				Port:     8080,
				Protocol: "tcp",
				External: true,
			},
		},
		Environment: make(map[string]string),
		Resources: &ResourceLimits{
			CPU:    "100m",
			Memory: "128Mi",
			Storage: "1Gi",
		},
		HealthCheck: &HealthCheck{
			Type:     "http",
			Path:     "/health",
			Port:     8080,
			Interval: 30 * time.Second,
			Timeout:  5 * time.Second,
			Retries:  3,
		},
		Scaling: &ScalingPolicy{
			MinReplicas:     1,
			MaxReplicas:     3,
			TargetCPU:       70,
			TargetMemory:    80,
			ScaleUpDelay:    1 * time.Minute,
			ScaleDownDelay:  5 * time.Minute,
			EnableAutoScale: false,
		},
		CreatedAt: time.Now(),
		UpdatedAt: time.Now(),
		Metadata:  make(map[string]string),
	}

	err := om.RegisterService(service)
	if err != nil {
		b.Fatalf("Failed to register service: %v", err)
	}

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		_, err := om.DeployService("benchmark-service", 1)
		if err != nil {
			b.Fatalf("Service deployment failed: %v", err)
		}
	}
} 