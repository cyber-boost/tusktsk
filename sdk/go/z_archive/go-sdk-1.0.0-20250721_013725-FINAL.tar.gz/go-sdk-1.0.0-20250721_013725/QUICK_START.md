# Go SDK Quick Start Guide

## Package Contents
- **Core SDK**: Main Go source files and operators
- **Production**: Production-ready build with optimizations
- **AA_GO**: Goal automation and planning files
- **TODO**: A-series automation components
- **Examples**: Comprehensive example implementations
- **Tests**: Complete test suite
- **Documentation**: API docs and guides
- **License**: Licensing components

## Quick Installation

```bash
# Extract the package
tar -xzf go-sdk-1.0.0-20250721_013725.tar.gz

# Navigate to the package
cd go-sdk-1.0.0-20250721_013725

# Install dependencies
go mod download

# Build the SDK
make build

# Run tests
make test
```

## Usage Examples

```go
package main

import (
    "github.com/tusklang/go-sdk/core"
    "github.com/tusklang/go-sdk/operators"
)

func main() {
    // Initialize the SDK
    sdk := core.NewSDK()
    
    // Use operators
    op := operators.NewOperator()
    
    // Your code here
}
```

## Package Statistics
- Total Files: 349
- Total Lines: 172168
- Created: Mon Jul 21 01:37:26 AM UTC 2025

## Support
For support and documentation, see the docs/ directory.
