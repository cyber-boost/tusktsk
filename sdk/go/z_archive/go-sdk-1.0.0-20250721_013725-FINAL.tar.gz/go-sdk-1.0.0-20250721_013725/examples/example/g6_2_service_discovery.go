package main

import (
	"context"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"
	"sync"
	"time"
)

// ServiceDiscovery manages service registration and discovery
type ServiceDiscovery struct {
	services    map[string]*ServiceInfo
	healthChecks map[string]*HealthCheck
	watchers    map[string][]ServiceWatcher
	mutex       sync.RWMutex
	config      DiscoveryConfig
	httpClient  *http.Client
}

// ServiceInfo represents service information
type ServiceInfo struct {
	ID          string            `json:"id"`
	Name        string            `json:"name"`
	Version     string            `json:"version"`
	Host        string            `json:"host"`
	Port        int               `json:"port"`
	Protocol    string            `json:"protocol"`
	HealthCheck string            `json:"health_check"`
	Metadata    map[string]string `json:"metadata"`
	Tags        []string          `json:"tags"`
	Status      string            `json:"status"` // healthy, unhealthy, unknown
	LastSeen    time.Time         `json:"last_seen"`
	TTL         time.Duration     `json:"ttl"`
}

// HealthCheck represents health check configuration
type HealthCheck struct {
	ServiceID   string        `json:"service_id"`
	URL         string        `json:"url"`
	Interval    time.Duration `json:"interval"`
	Timeout     time.Duration `json:"timeout"`
	Retries     int           `json:"retries"`
	Method      string        `json:"method"`
	Headers     map[string]string `json:"headers"`
	Body        string        `json:"body"`
	ExpectedStatus int        `json:"expected_status"`
	LastCheck   time.Time     `json:"last_check"`
	LastResult  bool          `json:"last_result"`
	Failures    int           `json:"failures"`
}

// ServiceWatcher interface for service change notifications
type ServiceWatcher interface {
	OnServiceRegistered(service *ServiceInfo)
	OnServiceDeregistered(serviceID string)
	OnServiceStatusChanged(serviceID string, status string)
}

// DiscoveryConfig represents discovery configuration
type DiscoveryConfig struct {
	RegistryURL     string        `json:"registry_url"`
	HeartbeatInterval time.Duration `json:"heartbeat_interval"`
	TTL             time.Duration `json:"ttl"`
	RetryInterval   time.Duration `json:"retry_interval"`
	MaxRetries      int           `json:"max_retries"`
	EnableCache     bool          `json:"enable_cache"`
	CacheTTL        time.Duration `json:"cache_ttl"`
}

// ServiceDiscovery creates a new service discovery instance
func NewServiceDiscovery(config DiscoveryConfig) *ServiceDiscovery {
	return &ServiceDiscovery{
		services:     make(map[string]*ServiceInfo),
		healthChecks: make(map[string]*HealthCheck),
		watchers:     make(map[string][]ServiceWatcher),
		config:       config,
		httpClient:   &http.Client{Timeout: 10 * time.Second},
	}
}

// RegisterService registers a service with the discovery system
func (sd *ServiceDiscovery) RegisterService(service *ServiceInfo) error {
	sd.mutex.Lock()
	defer sd.mutex.Unlock()

	// Validate service
	if err := sd.validateService(service); err != nil {
		return err
	}

	// Set default values
	if service.Status == "" {
		service.Status = "unknown"
	}
	if service.LastSeen.IsZero() {
		service.LastSeen = time.Now()
	}
	if service.TTL == 0 {
		service.TTL = sd.config.TTL
	}

	// Store service
	sd.services[service.ID] = service

	// Create health check if URL is provided
	if service.HealthCheck != "" {
		healthCheck := &HealthCheck{
			ServiceID:      service.ID,
			URL:            service.HealthCheck,
			Interval:       30 * time.Second,
			Timeout:        5 * time.Second,
			Retries:        3,
			Method:         "GET",
			Headers:        make(map[string]string),
			ExpectedStatus: 200,
		}
		sd.healthChecks[service.ID] = healthCheck

		// Start health check
		go sd.startHealthCheck(healthCheck)
	}

	// Notify watchers
	sd.notifyServiceRegistered(service)

	return nil
}

// validateService validates service information
func (sd *ServiceDiscovery) validateService(service *ServiceInfo) error {
	if service.ID == "" {
		return fmt.Errorf("service ID cannot be empty")
	}
	if service.Name == "" {
		return fmt.Errorf("service name cannot be empty")
	}
	if service.Host == "" {
		return fmt.Errorf("service host cannot be empty")
	}
	if service.Port <= 0 {
		return fmt.Errorf("service port must be positive")
	}
	if service.Protocol == "" {
		service.Protocol = "http"
	}
	return nil
}

// DeregisterService deregisters a service
func (sd *ServiceDiscovery) DeregisterService(serviceID string) error {
	sd.mutex.Lock()
	defer sd.mutex.Unlock()

	service, exists := sd.services[serviceID]
	if !exists {
		return fmt.Errorf("service %s not found", serviceID)
	}

	// Remove service
	delete(sd.services, serviceID)

	// Remove health check
	delete(sd.healthChecks, serviceID)

	// Notify watchers
	sd.notifyServiceDeregistered(serviceID)

	return nil
}

// GetService retrieves a service by ID
func (sd *ServiceDiscovery) GetService(serviceID string) (*ServiceInfo, error) {
	sd.mutex.RLock()
	defer sd.mutex.RUnlock()

	service, exists := sd.services[serviceID]
	if !exists {
		return nil, fmt.Errorf("service %s not found", serviceID)
	}

	return service, nil
}

// ListServices lists all services
func (sd *ServiceDiscovery) ListServices() []*ServiceInfo {
	sd.mutex.RLock()
	defer sd.mutex.RUnlock()

	services := make([]*ServiceInfo, 0, len(sd.services))
	for _, service := range sd.services {
		services = append(services, service)
	}

	return services
}

// FindServices finds services by criteria
func (sd *ServiceDiscovery) FindServices(criteria ServiceCriteria) []*ServiceInfo {
	sd.mutex.RLock()
	defer sd.mutex.RUnlock()

	var results []*ServiceInfo

	for _, service := range sd.services {
		if sd.matchesCriteria(service, criteria) {
			results = append(results, service)
		}
	}

	return results
}

// ServiceCriteria represents search criteria
type ServiceCriteria struct {
	Name     string            `json:"name"`
	Version  string            `json:"version"`
	Status   string            `json:"status"`
	Tags     []string          `json:"tags"`
	Metadata map[string]string `json:"metadata"`
}

// matchesCriteria checks if service matches criteria
func (sd *ServiceDiscovery) matchesCriteria(service *ServiceInfo, criteria ServiceCriteria) bool {
	if criteria.Name != "" && service.Name != criteria.Name {
		return false
	}
	if criteria.Version != "" && service.Version != criteria.Version {
		return false
	}
	if criteria.Status != "" && service.Status != criteria.Status {
		return false
	}
	if len(criteria.Tags) > 0 {
		found := false
		for _, tag := range criteria.Tags {
			for _, serviceTag := range service.Tags {
				if tag == serviceTag {
					found = true
					break
				}
			}
			if found {
				break
			}
		}
		if !found {
			return false
		}
	}
	if len(criteria.Metadata) > 0 {
		for key, value := range criteria.Metadata {
			if service.Metadata[key] != value {
				return false
			}
		}
	}
	return true
}

// Watch registers a watcher for service changes
func (sd *ServiceDiscovery) Watch(serviceID string, watcher ServiceWatcher) {
	sd.mutex.Lock()
	defer sd.mutex.Unlock()

	sd.watchers[serviceID] = append(sd.watchers[serviceID], watcher)
}

// Unwatch removes a watcher
func (sd *ServiceDiscovery) Unwatch(serviceID string, watcher ServiceWatcher) {
	sd.mutex.Lock()
	defer sd.mutex.Unlock()

	if watchers, exists := sd.watchers[serviceID]; exists {
		for i, w := range watchers {
			if w == watcher {
				sd.watchers[serviceID] = append(watchers[:i], watchers[i+1:]...)
				break
			}
		}
	}
}

// notifyServiceRegistered notifies watchers of service registration
func (sd *ServiceDiscovery) notifyServiceRegistered(service *ServiceInfo) {
	if watchers, exists := sd.watchers[service.ID]; exists {
		for _, watcher := range watchers {
			watcher.OnServiceRegistered(service)
		}
	}
}

// notifyServiceDeregistered notifies watchers of service deregistration
func (sd *ServiceDiscovery) notifyServiceDeregistered(serviceID string) {
	if watchers, exists := sd.watchers[serviceID]; exists {
		for _, watcher := range watchers {
			watcher.OnServiceDeregistered(serviceID)
		}
	}
}

// notifyServiceStatusChanged notifies watchers of status change
func (sd *ServiceDiscovery) notifyServiceStatusChanged(serviceID string, status string) {
	if watchers, exists := sd.watchers[serviceID]; exists {
		for _, watcher := range watchers {
			watcher.OnServiceStatusChanged(serviceID, status)
		}
	}
}

// startHealthCheck starts health check for a service
func (sd *ServiceDiscovery) startHealthCheck(healthCheck *HealthCheck) {
	ticker := time.NewTicker(healthCheck.Interval)
	defer ticker.Stop()

	for {
		select {
		case <-ticker.C:
			sd.performHealthCheck(healthCheck)
		}
	}
}

// performHealthCheck performs a health check
func (sd *ServiceDiscovery) performHealthCheck(healthCheck *HealthCheck) {
	// Create request
	req, err := http.NewRequest(healthCheck.Method, healthCheck.URL, nil)
	if err != nil {
		sd.recordHealthCheckFailure(healthCheck)
		return
	}

	// Add headers
	for key, value := range healthCheck.Headers {
		req.Header.Set(key, value)
	}

	// Set timeout
	ctx, cancel := context.WithTimeout(context.Background(), healthCheck.Timeout)
	defer cancel()
	req = req.WithContext(ctx)

	// Perform request
	resp, err := sd.httpClient.Do(req)
	if err != nil {
		sd.recordHealthCheckFailure(healthCheck)
		return
	}
	defer resp.Body.Close()

	// Check status code
	if resp.StatusCode == healthCheck.ExpectedStatus {
		sd.recordHealthCheckSuccess(healthCheck)
	} else {
		sd.recordHealthCheckFailure(healthCheck)
	}
}

// recordHealthCheckSuccess records successful health check
func (sd *ServiceDiscovery) recordHealthCheckSuccess(healthCheck *HealthCheck) {
	sd.mutex.Lock()
	defer sd.mutex.Unlock()

	healthCheck.LastCheck = time.Now()
	healthCheck.LastResult = true
	healthCheck.Failures = 0

	// Update service status
	if service, exists := sd.services[healthCheck.ServiceID]; exists {
		if service.Status != "healthy" {
			service.Status = "healthy"
			sd.notifyServiceStatusChanged(service.ID, "healthy")
		}
		service.LastSeen = time.Now()
	}
}

// recordHealthCheckFailure records failed health check
func (sd *ServiceDiscovery) recordHealthCheckFailure(healthCheck *HealthCheck) {
	sd.mutex.Lock()
	defer sd.mutex.Unlock()

	healthCheck.LastCheck = time.Now()
	healthCheck.LastResult = false
	healthCheck.Failures++

	// Update service status if too many failures
	if healthCheck.Failures >= healthCheck.Retries {
		if service, exists := sd.services[healthCheck.ServiceID]; exists {
			if service.Status != "unhealthy" {
				service.Status = "unhealthy"
				sd.notifyServiceStatusChanged(service.ID, "unhealthy")
			}
		}
	}
}

// UpdateService updates service information
func (sd *ServiceDiscovery) UpdateService(serviceID string, updates map[string]interface{}) error {
	sd.mutex.Lock()
	defer sd.mutex.Unlock()

	service, exists := sd.services[serviceID]
	if !exists {
		return fmt.Errorf("service %s not found", serviceID)
	}

	// Apply updates
	for key, value := range updates {
		switch key {
		case "name":
			if name, ok := value.(string); ok {
				service.Name = name
			}
		case "version":
			if version, ok := value.(string); ok {
				service.Version = version
			}
		case "host":
			if host, ok := value.(string); ok {
				service.Host = host
			}
		case "port":
			if port, ok := value.(int); ok {
				service.Port = port
			}
		case "protocol":
			if protocol, ok := value.(string); ok {
				service.Protocol = protocol
			}
		case "metadata":
			if metadata, ok := value.(map[string]string); ok {
				service.Metadata = metadata
			}
		case "tags":
			if tags, ok := value.([]string); ok {
				service.Tags = tags
			}
		}
	}

	service.LastSeen = time.Now()
	return nil
}

// GetHealthCheck retrieves health check information
func (sd *ServiceDiscovery) GetHealthCheck(serviceID string) (*HealthCheck, error) {
	sd.mutex.RLock()
	defer sd.mutex.RUnlock()

	healthCheck, exists := sd.healthChecks[serviceID]
	if !exists {
		return nil, fmt.Errorf("health check for service %s not found", serviceID)
	}

	return healthCheck, nil
}

// SetHealthCheck sets health check configuration
func (sd *ServiceDiscovery) SetHealthCheck(serviceID string, healthCheck *HealthCheck) error {
	sd.mutex.Lock()
	defer sd.mutex.Unlock()

	// Validate service exists
	if _, exists := sd.services[serviceID]; !exists {
		return fmt.Errorf("service %s not found", serviceID)
	}

	healthCheck.ServiceID = serviceID
	sd.healthChecks[serviceID] = healthCheck

	// Start health check
	go sd.startHealthCheck(healthCheck)

	return nil
}

// CleanupExpiredServices removes expired services
func (sd *ServiceDiscovery) CleanupExpiredServices() {
	sd.mutex.Lock()
	defer sd.mutex.Unlock()

	now := time.Now()
	for serviceID, service := range sd.services {
		if now.Sub(service.LastSeen) > service.TTL {
			delete(sd.services, serviceID)
			delete(sd.healthChecks, serviceID)
			sd.notifyServiceDeregistered(serviceID)
		}
	}
}

// GetStats returns discovery statistics
func (sd *ServiceDiscovery) GetStats() map[string]interface{} {
	sd.mutex.RLock()
	defer sd.mutex.RUnlock()

	healthy := 0
	unhealthy := 0
	unknown := 0

	for _, service := range sd.services {
		switch service.Status {
		case "healthy":
			healthy++
		case "unhealthy":
			unhealthy++
		case "unknown":
			unknown++
		}
	}

	return map[string]interface{}{
		"total_services": len(sd.services),
		"healthy":        healthy,
		"unhealthy":      unhealthy,
		"unknown":        unknown,
		"health_checks":  len(sd.healthChecks),
		"watchers":       len(sd.watchers),
	}
} 