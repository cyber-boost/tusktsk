package main

import (
	"context"
	"crypto/tls"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"
	"net/http/httputil"
	"net/url"
	"regexp"
	"strings"
	"sync"
	"time"

	"github.com/gorilla/mux"
)

// APIGateway manages API routing, authentication, and rate limiting
type APIGateway struct {
	router       *mux.Router
	services     map[string]*Service
	middleware   []Middleware
	config       GatewayConfig
	rateLimiter  *RateLimiter
	authManager  *AuthManager
	metrics      *MetricsCollector
	mutex        sync.RWMutex
	server       *http.Server
}

// Service represents a backend service
type Service struct {
	Name         string            `json:"name"`
	URL          string            `json:"url"`
	HealthCheck  string            `json:"health_check"`
	Timeout      time.Duration     `json:"timeout"`
	Retries      int               `json:"retries"`
	CircuitBreaker *CircuitBreaker `json:"circuit_breaker"`
	LoadBalancer *LoadBalancer     `json:"load_balancer"`
	Metadata     map[string]string `json:"metadata"`
}

// GatewayConfig represents gateway configuration
type GatewayConfig struct {
	Port            int               `json:"port"`
	Host            string            `json:"host"`
	ReadTimeout     time.Duration     `json:"read_timeout"`
	WriteTimeout    time.Duration     `json:"write_timeout"`
	IdleTimeout     time.Duration     `json:"idle_timeout"`
	MaxHeaderBytes  int               `json:"max_header_bytes"`
	TLSCert         string            `json:"tls_cert"`
	TLSKey          string            `json:"tls_key"`
	CORS            CORSConfig        `json:"cors"`
	RateLimit       RateLimitConfig   `json:"rate_limit"`
	Logging         LoggingConfig     `json:"logging"`
}

// CORSConfig represents CORS configuration
type CORSConfig struct {
	AllowedOrigins   []string `json:"allowed_origins"`
	AllowedMethods   []string `json:"allowed_methods"`
	AllowedHeaders   []string `json:"allowed_headers"`
	ExposedHeaders   []string `json:"exposed_headers"`
	AllowCredentials bool     `json:"allow_credentials"`
	MaxAge           int      `json:"max_age"`
}

// RateLimitConfig represents rate limiting configuration
type RateLimitConfig struct {
	Enabled     bool  `json:"enabled"`
	Requests    int   `json:"requests"`
	Window      int64 `json:"window"` // seconds
	Burst       int   `json:"burst"`
	PerIP       bool  `json:"per_ip"`
	PerUser     bool  `json:"per_user"`
}

// LoggingConfig represents logging configuration
type LoggingConfig struct {
	Level      string `json:"level"`
	Format     string `json:"format"`
	Output     string `json:"output"`
	RequestLog bool   `json:"request_log"`
	ResponseLog bool  `json:"response_log"`
}

// Middleware represents HTTP middleware
type Middleware func(http.Handler) http.Handler

// CircuitBreaker manages circuit breaker pattern
type CircuitBreaker struct {
	FailureThreshold int           `json:"failure_threshold"`
	Timeout          time.Duration `json:"timeout"`
	State            string        `json:"state"` // closed, open, half-open
	Failures         int           `json:"failures"`
	LastFailure      time.Time     `json:"last_failure"`
	mutex            sync.RWMutex
}

// LoadBalancer manages load balancing
type LoadBalancer struct {
	Strategy string   `json:"strategy"` // round-robin, least-connections, random
	Backends []string `json:"backends"`
	Current  int      `json:"current"`
	mutex    sync.RWMutex
}

// RateLimiter manages rate limiting
type RateLimiter struct {
	limits map[string]*TokenBucket
	mutex  sync.RWMutex
}

// TokenBucket implements token bucket algorithm
type TokenBucket struct {
	Tokens     int
	Capacity   int
	Rate       float64
	LastRefill time.Time
}

// AuthManager manages authentication and authorization
type AuthManager struct {
	providers map[string]AuthProvider
	config    AuthConfig
	mutex     sync.RWMutex
}

// AuthProvider interface for authentication providers
type AuthProvider interface {
	Authenticate(token string) (*User, error)
	Authorize(user *User, resource string, action string) bool
}

// User represents an authenticated user
type User struct {
	ID       string            `json:"id"`
	Username string            `json:"username"`
	Email    string            `json:"email"`
	Roles    []string          `json:"roles"`
	Claims   map[string]string `json:"claims"`
}

// AuthConfig represents authentication configuration
type AuthConfig struct {
	JWTSecret     string            `json:"jwt_secret"`
	JWTExpiration time.Duration     `json:"jwt_expiration"`
	APIKeys       map[string]string `json:"api_keys"`
	OAuth         OAuthConfig       `json:"oauth"`
}

// OAuthConfig represents OAuth configuration
type OAuthConfig struct {
	Providers map[string]OAuthProvider `json:"providers"`
}

// OAuthProvider represents an OAuth provider
type OAuthProvider struct {
	ClientID     string `json:"client_id"`
	ClientSecret string `json:"client_secret"`
	RedirectURL  string `json:"redirect_url"`
	AuthURL      string `json:"auth_url"`
	TokenURL     string `json:"token_url"`
	UserInfoURL  string `json:"user_info_url"`
}

// MetricsCollector collects and reports metrics
type MetricsCollector struct {
	requests   map[string]int64
	errors     map[string]int64
	latency    map[string][]time.Duration
	mutex      sync.RWMutex
}

// APIGateway creates a new API gateway
func NewAPIGateway(config GatewayConfig) *APIGateway {
	gateway := &APIGateway{
		router:      mux.NewRouter(),
		services:    make(map[string]*Service),
		middleware:  make([]Middleware, 0),
		config:      config,
		rateLimiter: NewRateLimiter(),
		authManager: NewAuthManager(config),
		metrics:     NewMetricsCollector(),
	}

	// Add default middleware
	gateway.addDefaultMiddleware()

	return gateway
}

// addDefaultMiddleware adds default middleware
func (apigw *APIGateway) addDefaultMiddleware() {
	// CORS middleware
	apigw.Use(apigw.corsMiddleware())

	// Logging middleware
	if apigw.config.Logging.RequestLog {
		apigw.Use(apigw.loggingMiddleware())
	}

	// Rate limiting middleware
	if apigw.config.RateLimit.Enabled {
		apigw.Use(apigw.rateLimitMiddleware())
	}

	// Authentication middleware
	apigw.Use(apigw.authMiddleware())

	// Metrics middleware
	apigw.Use(apigw.metricsMiddleware())
}

// Use adds middleware to the gateway
func (apigw *APIGateway) Use(middleware Middleware) {
	apigw.middleware = append(apigw.middleware, middleware)
}

// RegisterService registers a backend service
func (apigw *APIGateway) RegisterService(name string, service *Service) error {
	apigw.mutex.Lock()
	defer apigw.mutex.Unlock()

	// Validate service URL
	if _, err := url.Parse(service.URL); err != nil {
		return fmt.Errorf("invalid service URL: %v", err)
	}

	// Initialize circuit breaker
	if service.CircuitBreaker == nil {
		service.CircuitBreaker = &CircuitBreaker{
			FailureThreshold: 5,
			Timeout:          30 * time.Second,
			State:           "closed",
		}
	}

	// Initialize load balancer
	if service.LoadBalancer == nil {
		service.LoadBalancer = &LoadBalancer{
			Strategy: "round-robin",
			Backends: []string{service.URL},
		}
	}

	apigw.services[name] = service
	return nil
}

// Route registers a route with the gateway
func (apigw *APIGateway) Route(pattern string, serviceName string, methods ...string) error {
	apigw.mutex.RLock()
	service, exists := apigw.services[serviceName]
	apigw.mutex.RUnlock()

	if !exists {
		return fmt.Errorf("service %s not found", serviceName)
	}

	// Create reverse proxy
	proxy := httputil.NewSingleHostReverseProxy(&url.URL{
		Scheme: "http",
		Host:   service.URL,
	})

	// Customize proxy director
	originalDirector := proxy.Director
	proxy.Director = func(req *http.Request) {
		originalDirector(req)
		req.Host = service.URL
	}

	// Add service-specific middleware
	handler := apigw.wrapWithMiddleware(proxy, service)

	// Register route
	if len(methods) > 0 {
		apigw.router.Methods(methods...).Path(pattern).Handler(handler)
	} else {
		apigw.router.Path(pattern).Handler(handler)
	}

	return nil
}

// wrapWithMiddleware wraps handler with service-specific middleware
func (apigw *APIGateway) wrapWithMiddleware(handler http.Handler, service *Service) http.Handler {
	// Circuit breaker middleware
	handler = apigw.circuitBreakerMiddleware(service.CircuitBreaker)(handler)

	// Timeout middleware
	handler = apigw.timeoutMiddleware(service.Timeout)(handler)

	// Retry middleware
	handler = apigw.retryMiddleware(service.Retries)(handler)

	return handler
}

// corsMiddleware creates CORS middleware
func (apigw *APIGateway) corsMiddleware() Middleware {
	return func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			origin := r.Header.Get("Origin")
			if origin != "" {
				for _, allowedOrigin := range apigw.config.CORS.AllowedOrigins {
					if allowedOrigin == "*" || allowedOrigin == origin {
						w.Header().Set("Access-Control-Allow-Origin", origin)
						break
					}
				}
			}

			if r.Method == "OPTIONS" {
				w.Header().Set("Access-Control-Allow-Methods", strings.Join(apigw.config.CORS.AllowedMethods, ","))
				w.Header().Set("Access-Control-Allow-Headers", strings.Join(apigw.config.CORS.AllowedHeaders, ","))
				w.Header().Set("Access-Control-Expose-Headers", strings.Join(apigw.config.CORS.ExposedHeaders, ","))
				w.Header().Set("Access-Control-Max-Age", fmt.Sprintf("%d", apigw.config.CORS.MaxAge))
				
				if apigw.config.CORS.AllowCredentials {
					w.Header().Set("Access-Control-Allow-Credentials", "true")
				}
				
				w.WriteHeader(http.StatusOK)
				return
			}

			next.ServeHTTP(w, r)
		})
	}
}

// loggingMiddleware creates logging middleware
func (apigw *APIGateway) loggingMiddleware() Middleware {
	return func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			start := time.Now()
			
			// Log request
			fmt.Printf("[%s] %s %s %s\n", 
				start.Format("2006-01-02 15:04:05"),
				r.Method,
				r.URL.Path,
				r.RemoteAddr)

			// Create response writer wrapper
			wrapped := &responseWriter{ResponseWriter: w, statusCode: http.StatusOK}
			
			next.ServeHTTP(wrapped, r)
			
			// Log response
			duration := time.Since(start)
			fmt.Printf("[%s] %s %s %d %v\n",
				time.Now().Format("2006-01-02 15:04:05"),
				r.Method,
				r.URL.Path,
				wrapped.statusCode,
				duration)
		})
	}
}

// rateLimitMiddleware creates rate limiting middleware
func (apigw *APIGateway) rateLimitMiddleware() Middleware {
	return func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			key := apigw.getRateLimitKey(r)
			
			if !apigw.rateLimiter.Allow(key) {
				w.Header().Set("Content-Type", "application/json")
				w.WriteHeader(http.StatusTooManyRequests)
				json.NewEncoder(w).Encode(map[string]string{
					"error": "Rate limit exceeded",
				})
				return
			}
			
			next.ServeHTTP(w, r)
		})
	}
}

// authMiddleware creates authentication middleware
func (apigw *APIGateway) authMiddleware() Middleware {
	return func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			// Skip auth for certain paths
			if apigw.isPublicPath(r.URL.Path) {
				next.ServeHTTP(w, r)
				return
			}

			user, err := apigw.authManager.AuthenticateRequest(r)
			if err != nil {
				w.Header().Set("Content-Type", "application/json")
				w.WriteHeader(http.StatusUnauthorized)
				json.NewEncoder(w).Encode(map[string]string{
					"error": "Authentication failed",
				})
				return
			}

			// Add user to request context
			ctx := context.WithValue(r.Context(), "user", user)
			next.ServeHTTP(w, r.WithContext(ctx))
		})
	}
}

// metricsMiddleware creates metrics collection middleware
func (apigw *APIGateway) metricsMiddleware() Middleware {
	return func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			start := time.Now()
			
			next.ServeHTTP(w, r)
			
			duration := time.Since(start)
			apigw.metrics.RecordRequest(r.URL.Path, duration)
		})
	}
}

// circuitBreakerMiddleware creates circuit breaker middleware
func (apigw *APIGateway) circuitBreakerMiddleware(cb *CircuitBreaker) Middleware {
	return func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			if !cb.Allow() {
				w.Header().Set("Content-Type", "application/json")
				w.WriteHeader(http.StatusServiceUnavailable)
				json.NewEncoder(w).Encode(map[string]string{
					"error": "Service temporarily unavailable",
				})
				return
			}

			// Create response writer wrapper to detect errors
			wrapped := &responseWriter{ResponseWriter: w, statusCode: http.StatusOK}
			
			next.ServeHTTP(wrapped, r)
			
			// Record result
			if wrapped.statusCode >= 500 {
				cb.RecordFailure()
			} else {
				cb.RecordSuccess()
			}
		})
	}
}

// timeoutMiddleware creates timeout middleware
func (apigw *APIGateway) timeoutMiddleware(timeout time.Duration) Middleware {
	return func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			ctx, cancel := context.WithTimeout(r.Context(), timeout)
			defer cancel()
			
			r = r.WithContext(ctx)
			
			done := make(chan bool, 1)
			go func() {
				next.ServeHTTP(w, r)
				done <- true
			}()
			
			select {
			case <-done:
				return
			case <-ctx.Done():
				w.Header().Set("Content-Type", "application/json")
				w.WriteHeader(http.StatusRequestTimeout)
				json.NewEncoder(w).Encode(map[string]string{
					"error": "Request timeout",
				})
				return
			}
		})
	}
}

// retryMiddleware creates retry middleware
func (apigw *APIGateway) retryMiddleware(retries int) Middleware {
	return func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			var lastErr error
			
			for i := 0; i <= retries; i++ {
				// Create a copy of the request body for retries
				var body []byte
				if r.Body != nil {
					body, _ = ioutil.ReadAll(r.Body)
					r.Body = ioutil.NopCloser(strings.NewReader(string(body)))
				}
				
				// Create response writer wrapper
				wrapped := &responseWriter{ResponseWriter: w, statusCode: http.StatusOK}
				
				next.ServeHTTP(wrapped, r)
				
				// If successful, return
				if wrapped.statusCode < 500 {
					return
				}
				
				// If this is the last retry, return the error
				if i == retries {
					return
				}
				
				// Wait before retrying
				time.Sleep(time.Duration(i+1) * time.Second)
			}
		})
	}
}

// getRateLimitKey generates rate limit key
func (apigw *APIGateway) getRateLimitKey(r *http.Request) string {
	if apigw.config.RateLimit.PerIP {
		return r.RemoteAddr
	}
	
	if apigw.config.RateLimit.PerUser {
		if user := r.Context().Value("user"); user != nil {
			if u, ok := user.(*User); ok {
				return u.ID
			}
		}
	}
	
	return "global"
}

// isPublicPath checks if path is public (no auth required)
func (apigw *APIGateway) isPublicPath(path string) bool {
	publicPaths := []string{
		"/health",
		"/metrics",
		"/docs",
		"/swagger",
	}
	
	for _, publicPath := range publicPaths {
		if strings.HasPrefix(path, publicPath) {
			return true
		}
	}
	
	return false
}

// Start starts the API gateway
func (apigw *APIGateway) Start() error {
	apigw.server = &http.Server{
		Addr:           fmt.Sprintf("%s:%d", apigw.config.Host, apigw.config.Port),
		Handler:        apigw.router,
		ReadTimeout:    apigw.config.ReadTimeout,
		WriteTimeout:   apigw.config.WriteTimeout,
		IdleTimeout:    apigw.config.IdleTimeout,
		MaxHeaderBytes: apigw.config.MaxHeaderBytes,
	}

	// Add health check endpoint
	apigw.router.HandleFunc("/health", apigw.healthHandler).Methods("GET")
	
	// Add metrics endpoint
	apigw.router.HandleFunc("/metrics", apigw.metricsHandler).Methods("GET")

	fmt.Printf("API Gateway starting on %s:%d\n", apigw.config.Host, apigw.config.Port)
	
	if apigw.config.TLSCert != "" && apigw.config.TLSKey != "" {
		return apigw.server.ListenAndServeTLS(apigw.config.TLSCert, apigw.config.TLSKey)
	}
	
	return apigw.server.ListenAndServe()
}

// Stop stops the API gateway
func (apigw *APIGateway) Stop(ctx context.Context) error {
	if apigw.server != nil {
		return apigw.server.Shutdown(ctx)
	}
	return nil
}

// healthHandler handles health check requests
func (apigw *APIGateway) healthHandler(w http.ResponseWriter, r *http.Request) {
	status := map[string]interface{}{
		"status":    "healthy",
		"timestamp": time.Now().UTC(),
		"services":  len(apigw.services),
	}
	
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(status)
}

// metricsHandler handles metrics requests
func (apigw *APIGateway) metricsHandler(w http.ResponseWriter, r *http.Request) {
	metrics := apigw.metrics.GetMetrics()
	
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(metrics)
}

// responseWriter wraps http.ResponseWriter to capture status code
type responseWriter struct {
	http.ResponseWriter
	statusCode int
}

func (rw *responseWriter) WriteHeader(code int) {
	rw.statusCode = code
	rw.ResponseWriter.WriteHeader(code)
}

func (rw *responseWriter) Write(b []byte) (int, error) {
	return rw.ResponseWriter.Write(b)
} 