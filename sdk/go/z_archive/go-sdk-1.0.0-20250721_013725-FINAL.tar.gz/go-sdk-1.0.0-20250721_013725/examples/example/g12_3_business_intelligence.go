package main

import (
	"context"
	"fmt"
	"sync"
	"time"
)

// BusinessIntelligence provides business intelligence capabilities
type BusinessIntelligence struct {
	kpis        map[string]*KPI
	dashboards  map[string]*Dashboard
	alerts      map[string]*Alert
	config      BIConfig
	calculator  *KPICalculator
	monitor     *BIMonitor
	notifier    *AlertNotifier
	mutex       sync.RWMutex
}

// KPI represents a Key Performance Indicator
type KPI struct {
	ID          string            `json:"id"`
	Name        string            `json:"name"`
	Description string            `json:"description"`
	Category    string            `json:"category"`
	Formula     string            `json:"formula"`
	Target      float64           `json:"target"`
	Current     float64           `json:"current"`
	Unit        string            `json:"unit"`
	Frequency   string            `json:"frequency"` // daily, weekly, monthly, quarterly
	DataSource  string            `json:"data_source"`
	Thresholds  map[string]float64 `json:"thresholds"`
	Trend       string            `json:"trend"` // increasing, decreasing, stable
	CreatedAt   time.Time         `json:"created_at"`
	UpdatedAt   time.Time         `json:"updated_at"`
	Metadata    map[string]string `json:"metadata"`
}

// Dashboard represents a dashboard
type Dashboard struct {
	ID          string            `json:"id"`
	Name        string            `json:"name"`
	Description string            `json:"description"`
	Category    string            `json:"category"`
	Layout      map[string]interface{} `json:"layout"`
	Widgets     []*Widget         `json:"widgets"`
	KPIs        []string          `json:"kpis"`
	Filters     map[string]interface{} `json:"filters"`
	CreatedAt   time.Time         `json:"created_at"`
	UpdatedAt   time.Time         `json:"updated_at"`
	Metadata    map[string]string `json:"metadata"`
}

// Widget represents a dashboard widget
type Widget struct {
	ID          string            `json:"id"`
	Name        string            `json:"name"`
	Type        string            `json:"type"` // chart, table, metric, gauge
	Title       string            `json:"title"`
	Description string            `json:"description"`
	Data        map[string]interface{} `json:"data"`
	Config      map[string]interface{} `json:"config"`
	Position    map[string]int    `json:"position"`
	Size        map[string]int    `json:"size"`
	CreatedAt   time.Time         `json:"created_at"`
	Metadata    map[string]string `json:"metadata"`
}

// Alert represents an alert
type Alert struct {
	ID          string            `json:"id"`
	KPIID       string            `json:"kpi_id"`
	Type        string            `json:"type"` // threshold, trend, anomaly
	Condition   string            `json:"condition"`
	Value       float64           `json:"value"`
	Threshold   float64           `json:"threshold"`
	Severity    string            `json:"severity"` // low, medium, high, critical
	Message     string            `json:"message"`
	Status      string            `json:"status"` // active, resolved, acknowledged
	CreatedAt   time.Time         `json:"created_at"`
	ResolvedAt  *time.Time        `json:"resolved_at"`
	Metadata    map[string]string `json:"metadata"`
}

// BIConfig represents business intelligence configuration
type BIConfig struct {
	EnableRealTimeMonitoring bool          `json:"enable_real_time_monitoring"`
	EnableScheduledCalculation bool        `json:"enable_scheduled_calculation"`
	CalculationInterval      time.Duration `json:"calculation_interval"`
	EnableAlerting           bool          `json:"enable_alerting"`
	AlertCheckInterval       time.Duration `json:"alert_check_interval"`
	EnableNotifications      bool          `json:"enable_notifications"`
	MaxKPIs                  int           `json:"max_kpis"`
	MaxDashboards            int           `json:"max_dashboards"`
	EnableCaching            bool          `json:"enable_caching"`
	CacheTTL                 time.Duration `json:"cache_ttl"`
}

// KPICalculator manages KPI calculations
type KPICalculator struct {
	biSystem    *BusinessIntelligence
	calculators map[string]KPICalculatorFunc
	config      CalculatorConfig
	mutex       sync.RWMutex
}

// KPICalculatorFunc represents a KPI calculator function
type KPICalculatorFunc func(data []map[string]interface{}, config map[string]interface{}) (float64, error)

// CalculatorConfig represents calculator configuration
type CalculatorConfig struct {
	EnableParallel   bool          `json:"enable_parallel"`
	ParallelWorkers  int           `json:"parallel_workers"`
	EnableValidation bool          `json:"enable_validation"`
	EnableCaching    bool          `json:"enable_caching"`
}

// BIMonitor monitors business intelligence
type BIMonitor struct {
	biSystem *BusinessIntelligence
	metrics  map[string]*BIMetric
	config   MonitorConfig
	mutex    sync.RWMutex
}

// BIMetric represents a BI metric
type BIMetric struct {
	KPIID      string                 `json:"kpi_id"`
	Name       string                 `json:"name"`
	Value      float64                `json:"value"`
	Unit       string                 `json:"unit"`
	Timestamp  time.Time              `json:"timestamp"`
	History    []MetricPoint          `json:"history"`
	Thresholds map[string]float64     `json:"thresholds"`
	Metadata   map[string]interface{} `json:"metadata"`
}

// MonitorConfig represents monitor configuration
type MonitorConfig struct {
	EnablePerformanceMonitoring bool          `json:"enable_performance_monitoring"`
	EnableTrendAnalysis         bool          `json:"enable_trend_analysis"`
	EnableAnomalyDetection      bool          `json:"enable_anomaly_detection"`
	CheckInterval               time.Duration `json:"check_interval"`
}

// AlertNotifier manages alert notifications
type AlertNotifier struct {
	biSystem    *BusinessIntelligence
	notifiers   map[string]NotifierFunc
	config      NotifierConfig
	mutex       sync.RWMutex
}

// NotifierFunc represents a notifier function
type NotifierFunc func(alert *Alert, config map[string]interface{}) error

// NotifierConfig represents notifier configuration
type NotifierConfig struct {
	EnableEmailNotifications bool          `json:"enable_email_notifications"`
	EnableSMSNotifications   bool          `json:"enable_sms_notifications"`
	EnableWebhookNotifications bool        `json:"enable_webhook_notifications"`
	RetryAttempts            int           `json:"retry_attempts"`
	RetryDelay               time.Duration `json:"retry_delay"`
}

// BusinessIntelligence creates a new business intelligence system
func NewBusinessIntelligence(config BIConfig) *BusinessIntelligence {
	bi := &BusinessIntelligence{
		kpis:       make(map[string]*KPI),
		dashboards: make(map[string]*Dashboard),
		alerts:     make(map[string]*Alert),
		config:     config,
		calculator: &KPICalculator{
			calculators: make(map[string]KPICalculatorFunc),
			config: CalculatorConfig{
				EnableParallel:   true,
				ParallelWorkers:  5,
				EnableValidation: true,
				EnableCaching:    true,
			},
		},
		monitor: &BIMonitor{
			metrics: make(map[string]*BIMetric),
			config: MonitorConfig{
				EnablePerformanceMonitoring: true,
				EnableTrendAnalysis:         true,
				EnableAnomalyDetection:      true,
				CheckInterval:               30 * time.Second,
			},
		},
		notifier: &AlertNotifier{
			notifiers: make(map[string]NotifierFunc),
			config: NotifierConfig{
				EnableEmailNotifications: true,
				EnableSMSNotifications:   false,
				EnableWebhookNotifications: true,
				RetryAttempts:            3,
				RetryDelay:               5 * time.Second,
			},
		},
	}

	bi.calculator.biSystem = bi
	bi.monitor.biSystem = bi
	bi.notifier.biSystem = bi

	// Initialize calculators and notifiers
	bi.initializeComponents()

	// Start monitoring if enabled
	if config.EnableRealTimeMonitoring {
		go bi.startMonitoring()
	}

	// Start scheduled calculations if enabled
	if config.EnableScheduledCalculation {
		go bi.startScheduledCalculations()
	}

	// Start alert checking if enabled
	if config.EnableAlerting {
		go bi.startAlertChecking()
	}

	return bi
}

// initializeComponents initializes BI components
func (bi *BusinessIntelligence) initializeComponents() {
	// Register KPI calculators
	bi.calculator.calculators["sum"] = bi.calculateSum
	bi.calculator.calculators["average"] = bi.calculateAverage
	bi.calculator.calculators["count"] = bi.calculateCount
	bi.calculator.calculators["percentage"] = bi.calculatePercentage
	bi.calculator.calculators["growth_rate"] = bi.calculateGrowthRate

	// Register notifiers
	bi.notifier.notifiers["email"] = bi.sendEmailNotification
	bi.notifier.notifiers["sms"] = bi.sendSMSNotification
	bi.notifier.notifiers["webhook"] = bi.sendWebhookNotification
}

// CreateKPI creates a new KPI
func (bi *BusinessIntelligence) CreateKPI(kpi *KPI) error {
	bi.mutex.Lock()
	defer bi.mutex.Unlock()

	if _, exists := bi.kpis[kpi.ID]; exists {
		return fmt.Errorf("KPI %s already exists", kpi.ID)
	}

	kpi.CreatedAt = time.Now()
	kpi.UpdatedAt = time.Now()
	if kpi.Metadata == nil {
		kpi.Metadata = make(map[string]string)
	}
	if kpi.Thresholds == nil {
		kpi.Thresholds = make(map[string]float64)
	}

	bi.kpis[kpi.ID] = kpi
	return nil
}

// GetKPI returns a KPI by ID
func (bi *BusinessIntelligence) GetKPI(kpiID string) (*KPI, error) {
	bi.mutex.RLock()
	defer bi.mutex.RUnlock()

	kpi, exists := bi.kpis[kpiID]
	if !exists {
		return nil, fmt.Errorf("KPI %s not found", kpiID)
	}

	return kpi, nil
}

// ListKPIs lists all KPIs
func (bi *BusinessIntelligence) ListKPIs() []*KPI {
	bi.mutex.RLock()
	defer bi.mutex.RUnlock()

	kpis := make([]*KPI, 0, len(bi.kpis))
	for _, kpi := range bi.kpis {
		kpis = append(kpis, kpi)
	}

	return kpis
}

// CalculateKPI calculates a KPI value
func (bi *BusinessIntelligence) CalculateKPI(kpiID string) error {
	bi.mutex.RLock()
	kpi, exists := bi.kpis[kpiID]
	bi.mutex.RUnlock()

	if !exists {
		return fmt.Errorf("KPI %s not found", kpiID)
	}

	// Get data from data source
	data := bi.getDataFromSource(kpi.DataSource)

	// Calculate KPI value
	value, err := bi.calculator.CalculateKPI(kpi.Formula, data, kpi.Metadata)
	if err != nil {
		return err
	}

	// Update KPI
	bi.mutex.Lock()
	kpi.Current = value
	kpi.UpdatedAt = time.Now()
	kpi.Trend = bi.calculateTrend(kpi)
	bi.mutex.Unlock()

	// Check for alerts
	bi.checkKPIALerts(kpi)

	return nil
}

// getDataFromSource gets data from a data source
func (bi *BusinessIntelligence) getDataFromSource(dataSource string) []map[string]interface{} {
	// This would fetch data from the specified data source
	// For now, just return placeholder data
	return []map[string]interface{}{
		{"value": 100, "date": "2024-01-01"},
		{"value": 120, "date": "2024-01-02"},
		{"value": 110, "date": "2024-01-03"},
	}
}

// calculateTrend calculates the trend for a KPI
func (bi *BusinessIntelligence) calculateTrend(kpi *KPI) string {
	// This would calculate the trend based on historical data
	// For now, just return a placeholder trend
	if kpi.Current > kpi.Target {
		return "increasing"
	} else if kpi.Current < kpi.Target {
		return "decreasing"
	}
	return "stable"
}

// checkKPIALerts checks for KPI alerts
func (bi *BusinessIntelligence) checkKPIALerts(kpi *KPI) {
	// Check threshold alerts
	for thresholdType, thresholdValue := range kpi.Thresholds {
		var shouldAlert bool
		var condition string

		switch thresholdType {
		case "min":
			if kpi.Current < thresholdValue {
				shouldAlert = true
				condition = "below_minimum"
			}
		case "max":
			if kpi.Current > thresholdValue {
				shouldAlert = true
				condition = "above_maximum"
			}
		case "target":
			if kpi.Current < thresholdValue {
				shouldAlert = true
				condition = "below_target"
			}
		}

		if shouldAlert {
			bi.createAlert(kpi, "threshold", condition, kpi.Current, thresholdValue)
		}
	}
}

// createAlert creates an alert
func (bi *BusinessIntelligence) createAlert(kpi *KPI, alertType, condition string, value, threshold float64) {
	alert := &Alert{
		ID:        generateAlertID(),
		KPIID:     kpi.ID,
		Type:      alertType,
		Condition: condition,
		Value:     value,
		Threshold: threshold,
		Severity:  bi.calculateSeverity(value, threshold),
		Message:   fmt.Sprintf("KPI %s is %s (value: %.2f, threshold: %.2f)", kpi.Name, condition, value, threshold),
		Status:    "active",
		CreatedAt: time.Now(),
		Metadata:  make(map[string]string),
	}

	bi.mutex.Lock()
	bi.alerts[alert.ID] = alert
	bi.mutex.Unlock()

	// Send notification
	go bi.notifier.SendNotification(alert)
}

// calculateSeverity calculates alert severity
func (bi *BusinessIntelligence) calculateSeverity(value, threshold float64) string {
	deviation := math.Abs(value - threshold) / threshold
	if deviation > 0.5 {
		return "critical"
	} else if deviation > 0.3 {
		return "high"
	} else if deviation > 0.1 {
		return "medium"
	}
	return "low"
}

// CreateDashboard creates a new dashboard
func (bi *BusinessIntelligence) CreateDashboard(dashboard *Dashboard) error {
	bi.mutex.Lock()
	defer bi.mutex.Unlock()

	if _, exists := bi.dashboards[dashboard.ID]; exists {
		return fmt.Errorf("dashboard %s already exists", dashboard.ID)
	}

	dashboard.CreatedAt = time.Now()
	dashboard.UpdatedAt = time.Now()
	if dashboard.Metadata == nil {
		dashboard.Metadata = make(map[string]string)
	}
	if dashboard.Filters == nil {
		dashboard.Filters = make(map[string]interface{})
	}

	bi.dashboards[dashboard.ID] = dashboard
	return nil
}

// GetDashboard returns a dashboard by ID
func (bi *BusinessIntelligence) GetDashboard(dashboardID string) (*Dashboard, error) {
	bi.mutex.RLock()
	defer bi.mutex.RUnlock()

	dashboard, exists := bi.dashboards[dashboardID]
	if !exists {
		return nil, fmt.Errorf("dashboard %s not found", dashboardID)
	}

	return dashboard, nil
}

// ListDashboards lists all dashboards
func (bi *BusinessIntelligence) ListDashboards() []*Dashboard {
	bi.mutex.RLock()
	defer bi.mutex.RUnlock()

	dashboards := make([]*Dashboard, 0, len(bi.dashboards))
	for _, dashboard := range bi.dashboards {
		dashboards = append(dashboards, dashboard)
	}

	return dashboards
}

// AddWidget adds a widget to a dashboard
func (bi *BusinessIntelligence) AddWidget(dashboardID string, widget *Widget) error {
	bi.mutex.Lock()
	defer bi.mutex.Unlock()

	dashboard, exists := bi.dashboards[dashboardID]
	if !exists {
		return fmt.Errorf("dashboard %s not found", dashboardID)
	}

	widget.ID = generateWidgetID()
	widget.CreatedAt = time.Now()
	if widget.Metadata == nil {
		widget.Metadata = make(map[string]string)
	}

	dashboard.Widgets = append(dashboard.Widgets, widget)
	dashboard.UpdatedAt = time.Now()

	return nil
}

// GetAlerts returns alerts
func (bi *BusinessIntelligence) GetAlerts() []*Alert {
	bi.mutex.RLock()
	defer bi.mutex.RUnlock()

	alerts := make([]*Alert, 0, len(bi.alerts))
	for _, alert := range bi.alerts {
		alerts = append(alerts, alert)
	}

	return alerts
}

// AcknowledgeAlert acknowledges an alert
func (bi *BusinessIntelligence) AcknowledgeAlert(alertID string) error {
	bi.mutex.Lock()
	defer bi.mutex.Unlock()

	alert, exists := bi.alerts[alertID]
	if !exists {
		return fmt.Errorf("alert %s not found", alertID)
	}

	alert.Status = "acknowledged"
	return nil
}

// ResolveAlert resolves an alert
func (bi *BusinessIntelligence) ResolveAlert(alertID string) error {
	bi.mutex.Lock()
	defer bi.mutex.Unlock()

	alert, exists := bi.alerts[alertID]
	if !exists {
		return fmt.Errorf("alert %s not found", alertID)
	}

	alert.Status = "resolved"
	now := time.Now()
	alert.ResolvedAt = &now
	return nil
}

// startMonitoring starts BI monitoring
func (bi *BusinessIntelligence) startMonitoring() {
	ticker := time.NewTicker(bi.monitor.config.CheckInterval)
	defer ticker.Stop()

	for {
		select {
		case <-ticker.C:
			bi.collectMetrics()
		}
	}
}

// startScheduledCalculations starts scheduled KPI calculations
func (bi *BusinessIntelligence) startScheduledCalculations() {
	ticker := time.NewTicker(bi.config.CalculationInterval)
	defer ticker.Stop()

	for {
		select {
		case <-ticker.C:
			bi.calculateAllKPIs()
		}
	}
}

// startAlertChecking starts alert checking
func (bi *BusinessIntelligence) startAlertChecking() {
	ticker := time.NewTicker(bi.config.AlertCheckInterval)
	defer ticker.Stop()

	for {
		select {
		case <-ticker.C:
			bi.checkAllAlerts()
		}
	}
}

// calculateAllKPIs calculates all KPIs
func (bi *BusinessIntelligence) calculateAllKPIs() {
	bi.mutex.RLock()
	kpis := make([]*KPI, 0, len(bi.kpis))
	for _, kpi := range bi.kpis {
		kpis = append(kpis, kpi)
	}
	bi.mutex.RUnlock()

	for _, kpi := range kpis {
		go bi.CalculateKPI(kpi.ID)
	}
}

// checkAllAlerts checks all alerts
func (bi *BusinessIntelligence) checkAllAlerts() {
	bi.mutex.RLock()
	alerts := make([]*Alert, 0, len(bi.alerts))
	for _, alert := range bi.alerts {
		if alert.Status == "active" {
			alerts = append(alerts, alert)
		}
	}
	bi.mutex.RUnlock()

	for _, alert := range alerts {
		// Check if alert is still valid
		kpi, err := bi.GetKPI(alert.KPIID)
		if err != nil {
			continue
		}

		// Re-evaluate alert condition
		bi.checkKPIALerts(kpi)
	}
}

// collectMetrics collects BI metrics
func (bi *BusinessIntelligence) collectMetrics() {
	bi.mutex.RLock()
	defer bi.mutex.RUnlock()

	// Calculate KPI statistics
	totalKPIs := len(bi.kpis)
	totalDashboards := len(bi.dashboards)
	totalAlerts := len(bi.alerts)
	activeAlerts := 0

	for _, alert := range bi.alerts {
		if alert.Status == "active" {
			activeAlerts++
		}
	}

	// Update metrics
	bi.updateBIMetric("total_kpis", float64(totalKPIs), "kpis")
	bi.updateBIMetric("total_dashboards", float64(totalDashboards), "dashboards")
	bi.updateBIMetric("total_alerts", float64(totalAlerts), "alerts")
	bi.updateBIMetric("active_alerts", float64(activeAlerts), "alerts")

	if totalAlerts > 0 {
		alertRate := float64(activeAlerts) / float64(totalAlerts)
		bi.updateBIMetric("alert_rate", alertRate, "percentage")
	}
}

// updateBIMetric updates a BI metric
func (bi *BusinessIntelligence) updateBIMetric(name string, value float64, unit string) {
	metricKey := fmt.Sprintf("bi_%s", name)
	
	bi.monitor.mutex.Lock()
	defer bi.monitor.mutex.Unlock()

	metric, exists := bi.monitor.metrics[metricKey]
	if !exists {
		metric = &BIMetric{
			Name:       name,
			Unit:       unit,
			History:    make([]MetricPoint, 0),
			Thresholds: make(map[string]float64),
			Metadata:   make(map[string]interface{}),
		}
		bi.monitor.metrics[metricKey] = metric
	}

	metric.Value = value
	metric.Timestamp = time.Now()

	// Add to history (keep last 100 points)
	metric.History = append(metric.History, MetricPoint{
		Value:     value,
		Timestamp: time.Now(),
	})

	if len(metric.History) > 100 {
		metric.History = metric.History[1:]
	}
}

// KPICalculator implementation
func (kc *KPICalculator) CalculateKPI(formula string, data []map[string]interface{}, config map[string]interface{}) (float64, error) {
	// Parse formula and determine calculator
	// For now, just use a simple calculator based on formula
	switch formula {
	case "sum":
		return kc.calculators["sum"](data, config)
	case "average":
		return kc.calculators["average"](data, config)
	case "count":
		return kc.calculators["count"](data, config)
	case "percentage":
		return kc.calculators["percentage"](data, config)
	case "growth_rate":
		return kc.calculators["growth_rate"](data, config)
	default:
		return 0, fmt.Errorf("unknown formula: %s", formula)
	}
}

func (kc *KPICalculator) calculateSum(data []map[string]interface{}, config map[string]interface{}) (float64, error) {
	sum := 0.0
	for _, record := range data {
		if value, exists := record["value"]; exists {
			if num, ok := value.(float64); ok {
				sum += num
			}
		}
	}
	return sum, nil
}

func (kc *KPICalculator) calculateAverage(data []map[string]interface{}, config map[string]interface{}) (float64, error) {
	if len(data) == 0 {
		return 0, nil
	}

	sum := 0.0
	count := 0
	for _, record := range data {
		if value, exists := record["value"]; exists {
			if num, ok := value.(float64); ok {
				sum += num
				count++
			}
		}
	}

	if count == 0 {
		return 0, nil
	}

	return sum / float64(count), nil
}

func (kc *KPICalculator) calculateCount(data []map[string]interface{}, config map[string]interface{}) (float64, error) {
	return float64(len(data)), nil
}

func (kc *KPICalculator) calculatePercentage(data []map[string]interface{}, config map[string]interface{}) (float64, error) {
	// This would calculate percentage based on config
	// For now, just return a placeholder
	return 75.5, nil
}

func (kc *KPICalculator) calculateGrowthRate(data []map[string]interface{}, config map[string]interface{}) (float64, error) {
	// This would calculate growth rate
	// For now, just return a placeholder
	return 12.5, nil
}

// AlertNotifier implementation
func (an *AlertNotifier) SendNotification(alert *Alert) error {
	// Send notification based on severity
	switch alert.Severity {
	case "critical":
		return an.sendCriticalNotification(alert)
	case "high":
		return an.sendHighNotification(alert)
	case "medium":
		return an.sendMediumNotification(alert)
	case "low":
		return an.sendLowNotification(alert)
	default:
		return fmt.Errorf("unknown severity: %s", alert.Severity)
	}
}

func (an *AlertNotifier) sendCriticalNotification(alert *Alert) error {
	// Send all types of notifications for critical alerts
	if an.config.EnableEmailNotifications {
		an.sendEmailNotification(alert, make(map[string]interface{}))
	}
	if an.config.EnableSMSNotifications {
		an.sendSMSNotification(alert, make(map[string]interface{}))
	}
	if an.config.EnableWebhookNotifications {
		an.sendWebhookNotification(alert, make(map[string]interface{}))
	}
	return nil
}

func (an *AlertNotifier) sendHighNotification(alert *Alert) error {
	// Send email and webhook notifications for high alerts
	if an.config.EnableEmailNotifications {
		an.sendEmailNotification(alert, make(map[string]interface{}))
	}
	if an.config.EnableWebhookNotifications {
		an.sendWebhookNotification(alert, make(map[string]interface{}))
	}
	return nil
}

func (an *AlertNotifier) sendMediumNotification(alert *Alert) error {
	// Send email notification for medium alerts
	if an.config.EnableEmailNotifications {
		return an.sendEmailNotification(alert, make(map[string]interface{}))
	}
	return nil
}

func (an *AlertNotifier) sendLowNotification(alert *Alert) error {
	// Send webhook notification for low alerts
	if an.config.EnableWebhookNotifications {
		return an.sendWebhookNotification(alert, make(map[string]interface{}))
	}
	return nil
}

func (an *AlertNotifier) sendEmailNotification(alert *Alert, config map[string]interface{}) error {
	// This would send email notification
	// For now, just a placeholder
	return nil
}

func (an *AlertNotifier) sendSMSNotification(alert *Alert, config map[string]interface{}) error {
	// This would send SMS notification
	// For now, just a placeholder
	return nil
}

func (an *AlertNotifier) sendWebhookNotification(alert *Alert, config map[string]interface{}) error {
	// This would send webhook notification
	// For now, just a placeholder
	return nil
}

// generateAlertID generates a unique alert ID
func generateAlertID() string {
	return fmt.Sprintf("alert_%d", time.Now().UnixNano())
}

// generateWidgetID generates a unique widget ID
func generateWidgetID() string {
	return fmt.Sprintf("widget_%d", time.Now().UnixNano())
}

// GetStats returns business intelligence statistics
func (bi *BusinessIntelligence) GetStats() map[string]interface{} {
	bi.mutex.RLock()
	defer bi.mutex.RUnlock()

	stats := map[string]interface{}{
		"kpis":       len(bi.kpis),
		"dashboards": len(bi.dashboards),
		"alerts":     len(bi.alerts),
		"config":     bi.config,
	}

	// Calculate KPI statistics
	totalKPIs := len(bi.kpis)
	onTargetKPIs := 0
	belowTargetKPIs := 0

	for _, kpi := range bi.kpis {
		if kpi.Current >= kpi.Target {
			onTargetKPIs++
		} else {
			belowTargetKPIs++
		}
	}

	stats["total_kpis"] = totalKPIs
	stats["on_target_kpis"] = onTargetKPIs
	stats["below_target_kpis"] = belowTargetKPIs

	if totalKPIs > 0 {
		stats["target_achievement_rate"] = float64(onTargetKPIs) / float64(totalKPIs)
	}

	// Calculate alert statistics
	totalAlerts := len(bi.alerts)
	activeAlerts := 0
	resolvedAlerts := 0

	for _, alert := range bi.alerts {
		switch alert.Status {
		case "active":
			activeAlerts++
		case "resolved":
			resolvedAlerts++
		}
	}

	stats["total_alerts"] = totalAlerts
	stats["active_alerts"] = activeAlerts
	stats["resolved_alerts"] = resolvedAlerts

	if totalAlerts > 0 {
		stats["resolution_rate"] = float64(resolvedAlerts) / float64(totalAlerts)
	}

	return stats
} 