package main

import (
	"archive/tar"
	"archive/zip"
	"compress/gzip"
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"io/ioutil"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"
)

// PackageBuilder manages package building and distribution
type PackageBuilder struct {
	config       BuildConfig
	artifacts    map[string]*Artifact
	mutex        sync.RWMutex
	buildDir     string
	outputDir    string
	checksums    map[string]string
}

// BuildConfig represents build configuration
type BuildConfig struct {
	Name         string            `json:"name"`
	Version      string            `json:"version"`
	Description  string            `json:"description"`
	Author       string            `json:"author"`
	License      string            `json:"license"`
	Repository   string            `json:"repository"`
	Platforms    []string          `json:"platforms"`
	Architectures []string          `json:"architectures"`
	BuildTargets []BuildTarget     `json:"build_targets"`
	Metadata     map[string]string `json:"metadata"`
}

// BuildTarget represents a build target
type BuildTarget struct {
	Name         string            `json:"name"`
	Platform     string            `json:"platform"`
	Architecture string            `json:"architecture"`
	GoVersion    string            `json:"go_version"`
	Flags        []string          `json:"flags"`
	Tags         []string          `json:"tags"`
	Output       string            `json:"output"`
	LDFlags      []string          `json:"ldflags"`
}

// Artifact represents a build artifact
type Artifact struct {
	Name         string            `json:"name"`
	Path         string            `json:"path"`
	Size         int64             `json:"size"`
	Checksum     string            `json:"checksum"`
	Type         string            `json:"type"` // binary, archive, package
	Platform     string            `json:"platform"`
	Architecture string            `json:"architecture"`
	Created      time.Time         `json:"created"`
	Metadata     map[string]string `json:"metadata"`
}

// BuildResult represents the result of a build
type BuildResult struct {
	Success      bool               `json:"success"`
	Artifacts    []*Artifact        `json:"artifacts"`
	Errors       []string           `json:"errors"`
	Warnings     []string           `json:"warnings"`
	BuildTime    time.Duration      `json:"build_time"`
	TotalSize    int64              `json:"total_size"`
	Checksums    map[string]string  `json:"checksums"`
}

// PackageBuilder creates a new package builder
func NewPackageBuilder(config BuildConfig, buildDir, outputDir string) *PackageBuilder {
	return &PackageBuilder{
		config:    config,
		artifacts: make(map[string]*Artifact),
		buildDir:  buildDir,
		outputDir: outputDir,
		checksums: make(map[string]string),
	}
}

// Build builds the package for all targets
func (pb *PackageBuilder) Build(ctx context.Context) (*BuildResult, error) {
	startTime := time.Now()
	result := &BuildResult{
		Success:   true,
		Artifacts: make([]*Artifact, 0),
		Errors:    make([]string, 0),
		Warnings:  make([]string, 0),
	}

	// Create build and output directories
	if err := os.MkdirAll(pb.buildDir, 0755); err != nil {
		return nil, err
	}
	if err := os.MkdirAll(pb.outputDir, 0755); err != nil {
		return nil, err
	}

	// Build each target
	for _, target := range pb.config.BuildTargets {
		if err := pb.buildTarget(ctx, target, result); err != nil {
			result.Success = false
			result.Errors = append(result.Errors, fmt.Sprintf("Target %s failed: %v", target.Name, err))
		}
	}

	result.BuildTime = time.Since(startTime)
	result.TotalSize = pb.calculateTotalSize()
	result.Checksums = pb.checksums

	return result, nil
}

// buildTarget builds a single target
func (pb *PackageBuilder) buildTarget(ctx context.Context, target BuildTarget, result *BuildResult) error {
	// Set environment variables for cross-compilation
	env := pb.setBuildEnvironment(target)

	// Build command
	buildCmd := pb.createBuildCommand(target)
	
	// Execute build
	if err := pb.executeBuild(ctx, buildCmd, env); err != nil {
		return err
	}

	// Create artifact
	artifact, err := pb.createArtifact(target)
	if err != nil {
		return err
	}

	result.Artifacts = append(result.Artifacts, artifact)
	pb.artifacts[artifact.Name] = artifact

	return nil
}

// setBuildEnvironment sets environment variables for cross-compilation
func (pb *PackageBuilder) setBuildEnvironment(target BuildTarget) map[string]string {
	env := make(map[string]string)
	
	// Copy current environment
	for _, e := range os.Environ() {
		pair := strings.SplitN(e, "=", 2)
		if len(pair) == 2 {
			env[pair[0]] = pair[1]
		}
	}

	// Set cross-compilation variables
	switch target.Platform {
	case "linux":
		env["GOOS"] = "linux"
	case "windows":
		env["GOOS"] = "windows"
	case "darwin":
		env["GOOS"] = "darwin"
	}

	switch target.Architecture {
	case "amd64":
		env["GOARCH"] = "amd64"
	case "arm64":
		env["GOARCH"] = "arm64"
	case "386":
		env["GOARCH"] = "386"
	case "arm":
		env["GOARCH"] = "arm"
	}

	return env
}

// createBuildCommand creates the build command
func (pb *PackageBuilder) createBuildCommand(target BuildTarget) []string {
	cmd := []string{"go", "build"}

	// Add build flags
	for _, flag := range target.Flags {
		cmd = append(cmd, flag)
	}

	// Add build tags
	if len(target.Tags) > 0 {
		tags := strings.Join(target.Tags, ",")
		cmd = append(cmd, "-tags", tags)
	}

	// Add LDFlags
	if len(target.LDFlags) > 0 {
		ldflags := strings.Join(target.LDFlags, " ")
		cmd = append(cmd, "-ldflags", ldflags)
	}

	// Add output path
	outputPath := filepath.Join(pb.buildDir, target.Output)
	cmd = append(cmd, "-o", outputPath)

	// Add source directory
	cmd = append(cmd, ".")

	return cmd
}

// executeBuild executes the build command
func (pb *PackageBuilder) executeBuild(ctx context.Context, cmd []string, env map[string]string) error {
	// This would execute the actual build command
	// For now, create a placeholder implementation
	return nil
}

// createArtifact creates an artifact from the build output
func (pb *PackageBuilder) createArtifact(target BuildTarget) (*Artifact, error) {
	outputPath := filepath.Join(pb.buildDir, target.Output)
	
	// Get file info
	info, err := os.Stat(outputPath)
	if err != nil {
		return nil, err
	}

	// Calculate checksum
	checksum, err := pb.calculateChecksum(outputPath)
	if err != nil {
		return nil, err
	}

	// Create artifact name
	artifactName := fmt.Sprintf("%s-%s-%s-%s", 
		pb.config.Name, 
		pb.config.Version, 
		target.Platform, 
		target.Architecture)

	artifact := &Artifact{
		Name:         artifactName,
		Path:         outputPath,
		Size:         info.Size(),
		Checksum:     checksum,
		Type:         "binary",
		Platform:     target.Platform,
		Architecture: target.Architecture,
		Created:      time.Now(),
		Metadata:     make(map[string]string),
	}

	// Store checksum
	pb.checksums[artifactName] = checksum

	return artifact, nil
}

// calculateChecksum calculates SHA256 checksum of a file
func (pb *PackageBuilder) calculateChecksum(filePath string) (string, error) {
	file, err := os.Open(filePath)
	if err != nil {
		return "", err
	}
	defer file.Close()

	hash := sha256.New()
	if _, err := io.Copy(hash, file); err != nil {
		return "", err
	}

	return hex.EncodeToString(hash.Sum(nil)), nil
}

// calculateTotalSize calculates total size of all artifacts
func (pb *PackageBuilder) calculateTotalSize() int64 {
	var total int64
	for _, artifact := range pb.artifacts {
		total += artifact.Size
	}
	return total
}

// Package creates distribution packages
func (pb *PackageBuilder) Package(ctx context.Context, formats []string) error {
	for _, format := range formats {
		switch format {
		case "tar.gz":
			if err := pb.createTarGzPackage(); err != nil {
				return err
			}
		case "zip":
			if err := pb.createZipPackage(); err != nil {
				return err
			}
		case "deb":
			if err := pb.createDebPackage(); err != nil {
				return err
			}
		case "rpm":
			if err := pb.createRpmPackage(); err != nil {
				return err
			}
		default:
			return fmt.Errorf("unsupported package format: %s", format)
		}
	}
	return nil
}

// createTarGzPackage creates a tar.gz package
func (pb *PackageBuilder) createTarGzPackage() error {
	packageName := fmt.Sprintf("%s-%s.tar.gz", pb.config.Name, pb.config.Version)
	packagePath := filepath.Join(pb.outputDir, packageName)

	file, err := os.Create(packagePath)
	if err != nil {
		return err
	}
	defer file.Close()

	gw := gzip.NewWriter(file)
	defer gw.Close()

	tw := tar.NewWriter(gw)
	defer tw.Close()

	// Add artifacts to archive
	for _, artifact := range pb.artifacts {
		if err := pb.addFileToTar(tw, artifact.Path, artifact.Name); err != nil {
			return err
		}
	}

	// Add metadata
	metadata := pb.createMetadata()
	metadataBytes, err := json.MarshalIndent(metadata, "", "  ")
	if err != nil {
		return err
	}

	if err := pb.addBytesToTar(tw, metadataBytes, "metadata.json"); err != nil {
		return err
	}

	return nil
}

// createZipPackage creates a zip package
func (pb *PackageBuilder) createZipPackage() error {
	packageName := fmt.Sprintf("%s-%s.zip", pb.config.Name, pb.config.Version)
	packagePath := filepath.Join(pb.outputDir, packageName)

	file, err := os.Create(packagePath)
	if err != nil {
		return err
	}
	defer file.Close()

	zw := zip.NewWriter(file)
	defer zw.Close()

	// Add artifacts to archive
	for _, artifact := range pb.artifacts {
		if err := pb.addFileToZip(zw, artifact.Path, artifact.Name); err != nil {
			return err
		}
	}

	// Add metadata
	metadata := pb.createMetadata()
	metadataBytes, err := json.MarshalIndent(metadata, "", "  ")
	if err != nil {
		return err
	}

	if err := pb.addBytesToZip(zw, metadataBytes, "metadata.json"); err != nil {
		return err
	}

	return nil
}

// createDebPackage creates a Debian package (placeholder)
func (pb *PackageBuilder) createDebPackage() error {
	// Implementation would create Debian package structure
	// For now, return nil as placeholder
	return nil
}

// createRpmPackage creates an RPM package (placeholder)
func (pb *PackageBuilder) createRpmPackage() error {
	// Implementation would create RPM package structure
	// For now, return nil as placeholder
	return nil
}

// addFileToTar adds a file to tar archive
func (pb *PackageBuilder) addFileToTar(tw *tar.Writer, filePath, name string) error {
	file, err := os.Open(filePath)
	if err != nil {
		return err
	}
	defer file.Close()

	info, err := file.Stat()
	if err != nil {
		return err
	}

	header, err := tar.FileInfoHeader(info, "")
	if err != nil {
		return err
	}
	header.Name = name

	if err := tw.WriteHeader(header); err != nil {
		return err
	}

	_, err = io.Copy(tw, file)
	return err
}

// addBytesToTar adds bytes to tar archive
func (pb *PackageBuilder) addBytesToTar(tw *tar.Writer, data []byte, name string) error {
	header := &tar.Header{
		Name: name,
		Mode: 0644,
		Size: int64(len(data)),
	}

	if err := tw.WriteHeader(header); err != nil {
		return err
	}

	_, err := tw.Write(data)
	return err
}

// addFileToZip adds a file to zip archive
func (pb *PackageBuilder) addFileToZip(zw *zip.Writer, filePath, name string) error {
	file, err := os.Open(filePath)
	if err != nil {
		return err
	}
	defer file.Close()

	writer, err := zw.Create(name)
	if err != nil {
		return err
	}

	_, err = io.Copy(writer, file)
	return err
}

// addBytesToZip adds bytes to zip archive
func (pb *PackageBuilder) addBytesToZip(zw *zip.Writer, data []byte, name string) error {
	writer, err := zw.Create(name)
	if err != nil {
		return err
	}

	_, err = writer.Write(data)
	return err
}

// createMetadata creates package metadata
func (pb *PackageBuilder) createMetadata() map[string]interface{} {
	metadata := map[string]interface{}{
		"name":         pb.config.Name,
		"version":      pb.config.Version,
		"description":  pb.config.Description,
		"author":       pb.config.Author,
		"license":      pb.config.License,
		"repository":   pb.config.Repository,
		"created":      time.Now().UTC().Format(time.RFC3339),
		"artifacts":    pb.artifacts,
		"checksums":    pb.checksums,
		"build_config": pb.config,
	}

	// Add custom metadata
	for key, value := range pb.config.Metadata {
		metadata[key] = value
	}

	return metadata
}

// Clean cleans build artifacts
func (pb *PackageBuilder) Clean() error {
	// Remove build directory
	if err := os.RemoveAll(pb.buildDir); err != nil {
		return err
	}

	// Clear artifacts
	pb.mutex.Lock()
	pb.artifacts = make(map[string]*Artifact)
	pb.checksums = make(map[string]string)
	pb.mutex.Unlock()

	return nil
}

// GetStats returns build statistics
func (pb *PackageBuilder) GetStats() map[string]interface{} {
	pb.mutex.RLock()
	defer pb.mutex.RUnlock()

	totalSize := pb.calculateTotalSize()
	
	return map[string]interface{}{
		"name":           pb.config.Name,
		"version":        pb.config.Version,
		"artifacts":      len(pb.artifacts),
		"total_size":     totalSize,
		"build_dir":      pb.buildDir,
		"output_dir":     pb.outputDir,
		"platforms":      pb.config.Platforms,
		"architectures":  pb.config.Architectures,
		"build_targets":  len(pb.config.BuildTargets),
	}
} 