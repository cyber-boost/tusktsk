package main

import (
	"fmt"
	"strings"
	"time"
)

// QueryBuilder provides advanced SQL query building capabilities
type QueryBuilder struct {
	query     *Query
	config    QueryBuilderConfig
	optimizer *QueryOptimizer
}

// Query represents a SQL query
type Query struct {
	Type       string            `json:"type"` // SELECT, INSERT, UPDATE, DELETE
	Table      string            `json:"table"`
	Columns    []string          `json:"columns"`
	Values     []interface{}     `json:"values"`
	Where      []Condition       `json:"where"`
	OrderBy    []OrderBy         `json:"order_by"`
	GroupBy    []string          `json:"group_by"`
	Having     []Condition       `json:"having"`
	Limit      int               `json:"limit"`
	Offset     int               `json:"offset"`
	Joins      []Join            `json:"joins"`
	Subqueries []Subquery        `json:"subqueries"`
	Alias      string            `json:"alias"`
	Distinct   bool              `json:"distinct"`
	Aggregates []Aggregate       `json:"aggregates"`
	Metadata   map[string]string `json:"metadata"`
}

// Condition represents a WHERE condition
type Condition struct {
	Field    string      `json:"field"`
	Operator string      `json:"operator"` // =, !=, >, <, >=, <=, LIKE, IN, NOT IN, IS NULL, IS NOT NULL
	Value    interface{} `json:"value"`
	Logic    string      `json:"logic"` // AND, OR
	Group    int         `json:"group"`
}

// OrderBy represents an ORDER BY clause
type OrderBy struct {
	Field     string `json:"field"`
	Direction string `json:"direction"` // ASC, DESC
}

// Join represents a JOIN clause
type Join struct {
	Type      string     `json:"type"` // INNER, LEFT, RIGHT, FULL
	Table     string     `json:"table"`
	Alias     string     `json:"alias"`
	Condition Condition  `json:"condition"`
	On        []Condition `json:"on"`
}

// Subquery represents a subquery
type Subquery struct {
	Query *Query `json:"query"`
	Alias string `json:"alias"`
}

// Aggregate represents an aggregate function
type Aggregate struct {
	Function string `json:"function"` // COUNT, SUM, AVG, MIN, MAX
	Field    string `json:"field"`
	Alias    string `json:"alias"`
}

// QueryBuilderConfig represents query builder configuration
type QueryBuilderConfig struct {
	DefaultLimit     int           `json:"default_limit"`
	MaxLimit         int           `json:"max_limit"`
	EnableOptimization bool        `json:"enable_optimization"`
	EnableValidation bool          `json:"enable_validation"`
	Timeout          time.Duration `json:"timeout"`
	Dialect          string        `json:"dialect"` // mysql, postgres, sqlite
}

// QueryOptimizer provides query optimization capabilities
type QueryOptimizer struct {
	config OptimizerConfig
}

// OptimizerConfig represents optimizer configuration
type OptimizerConfig struct {
	EnableIndexHints    bool `json:"enable_index_hints"`
	EnableQueryRewriting bool `json:"enable_query_rewriting"`
	EnableSubqueryOptimization bool `json:"enable_subquery_optimization"`
	MaxJoins            int  `json:"max_joins"`
	MaxSubqueries       int  `json:"max_subqueries"`
}

// QueryBuilder creates a new query builder
func NewQueryBuilder(config QueryBuilderConfig) *QueryBuilder {
	return &QueryBuilder{
		query: &Query{
			Metadata: make(map[string]string),
		},
		config: config,
		optimizer: &QueryOptimizer{
			config: OptimizerConfig{
				EnableIndexHints:    true,
				EnableQueryRewriting: true,
				EnableSubqueryOptimization: true,
				MaxJoins:            10,
				MaxSubqueries:       5,
			},
		},
	}
}

// Select starts a SELECT query
func (qb *QueryBuilder) Select(columns ...string) *QueryBuilder {
	qb.query.Type = "SELECT"
	qb.query.Columns = columns
	return qb
}

// From sets the table for the query
func (qb *QueryBuilder) From(table string) *QueryBuilder {
	qb.query.Table = table
	return qb
}

// Where adds a WHERE condition
func (qb *QueryBuilder) Where(field, operator string, value interface{}) *QueryBuilder {
	condition := Condition{
		Field:    field,
		Operator: operator,
		Value:    value,
		Logic:    "AND",
	}
	qb.query.Where = append(qb.query.Where, condition)
	return qb
}

// OrWhere adds an OR WHERE condition
func (qb *QueryBuilder) OrWhere(field, operator string, value interface{}) *QueryBuilder {
	condition := Condition{
		Field:    field,
		Operator: operator,
		Value:    value,
		Logic:    "OR",
	}
	qb.query.Where = append(qb.query.Where, condition)
	return qb
}

// WhereIn adds a WHERE IN condition
func (qb *QueryBuilder) WhereIn(field string, values []interface{}) *QueryBuilder {
	condition := Condition{
		Field:    field,
		Operator: "IN",
		Value:    values,
		Logic:    "AND",
	}
	qb.query.Where = append(qb.query.Where, condition)
	return qb
}

// WhereNull adds a WHERE IS NULL condition
func (qb *QueryBuilder) WhereNull(field string) *QueryBuilder {
	condition := Condition{
		Field:    field,
		Operator: "IS NULL",
		Value:    nil,
		Logic:    "AND",
	}
	qb.query.Where = append(qb.query.Where, condition)
	return qb
}

// WhereNotNull adds a WHERE IS NOT NULL condition
func (qb *QueryBuilder) WhereNotNull(field string) *QueryBuilder {
	condition := Condition{
		Field:    field,
		Operator: "IS NOT NULL",
		Value:    nil,
		Logic:    "AND",
	}
	qb.query.Where = append(qb.query.Where, condition)
	return qb
}

// OrderBy adds an ORDER BY clause
func (qb *QueryBuilder) OrderBy(field, direction string) *QueryBuilder {
	orderBy := OrderBy{
		Field:     field,
		Direction: strings.ToUpper(direction),
	}
	qb.query.OrderBy = append(qb.query.OrderBy, orderBy)
	return qb
}

// GroupBy adds a GROUP BY clause
func (qb *QueryBuilder) GroupBy(fields ...string) *QueryBuilder {
	qb.query.GroupBy = append(qb.query.GroupBy, fields...)
	return qb
}

// Having adds a HAVING condition
func (qb *QueryBuilder) Having(field, operator string, value interface{}) *QueryBuilder {
	condition := Condition{
		Field:    field,
		Operator: operator,
		Value:    value,
		Logic:    "AND",
	}
	qb.query.Having = append(qb.query.Having, condition)
	return qb
}

// Limit sets the LIMIT clause
func (qb *QueryBuilder) Limit(limit int) *QueryBuilder {
	if limit > qb.config.MaxLimit {
		limit = qb.config.MaxLimit
	}
	qb.query.Limit = limit
	return qb
}

// Offset sets the OFFSET clause
func (qb *QueryBuilder) Offset(offset int) *QueryBuilder {
	qb.query.Offset = offset
	return qb
}

// Join adds a JOIN clause
func (qb *QueryBuilder) Join(joinType, table, alias string, conditions ...Condition) *QueryBuilder {
	join := Join{
		Type:      strings.ToUpper(joinType),
		Table:     table,
		Alias:     alias,
		On:        conditions,
	}
	qb.query.Joins = append(qb.query.Joins, join)
	return qb
}

// InnerJoin adds an INNER JOIN
func (qb *QueryBuilder) InnerJoin(table, alias string, conditions ...Condition) *QueryBuilder {
	return qb.Join("INNER", table, alias, conditions...)
}

// LeftJoin adds a LEFT JOIN
func (qb *QueryBuilder) LeftJoin(table, alias string, conditions ...Condition) *QueryBuilder {
	return qb.Join("LEFT", table, alias, conditions...)
}

// RightJoin adds a RIGHT JOIN
func (qb *QueryBuilder) RightJoin(table, alias string, conditions ...Condition) *QueryBuilder {
	return qb.Join("RIGHT", table, alias, conditions...)
}

// Distinct adds DISTINCT to the query
func (qb *QueryBuilder) Distinct() *QueryBuilder {
	qb.query.Distinct = true
	return qb
}

// Count adds a COUNT aggregate
func (qb *QueryBuilder) Count(field, alias string) *QueryBuilder {
	aggregate := Aggregate{
		Function: "COUNT",
		Field:    field,
		Alias:    alias,
	}
	qb.query.Aggregates = append(qb.query.Aggregates, aggregate)
	return qb
}

// Sum adds a SUM aggregate
func (qb *QueryBuilder) Sum(field, alias string) *QueryBuilder {
	aggregate := Aggregate{
		Function: "SUM",
		Field:    field,
		Alias:    alias,
	}
	qb.query.Aggregates = append(qb.query.Aggregates, aggregate)
	return qb
}

// Avg adds an AVG aggregate
func (qb *QueryBuilder) Avg(field, alias string) *QueryBuilder {
	aggregate := Aggregate{
		Function: "AVG",
		Field:    field,
		Alias:    alias,
	}
	qb.query.Aggregates = append(qb.query.Aggregates, aggregate)
	return qb
}

// Min adds a MIN aggregate
func (qb *QueryBuilder) Min(field, alias string) *QueryBuilder {
	aggregate := Aggregate{
		Function: "MIN",
		Field:    field,
		Alias:    alias,
	}
	qb.query.Aggregates = append(qb.query.Aggregates, aggregate)
	return qb
}

// Max adds a MAX aggregate
func (qb *QueryBuilder) Max(field, alias string) *QueryBuilder {
	aggregate := Aggregate{
		Function: "MAX",
		Field:    field,
		Alias:    alias,
	}
	qb.query.Aggregates = append(qb.query.Aggregates, aggregate)
	return qb
}

// Insert starts an INSERT query
func (qb *QueryBuilder) Insert(table string) *QueryBuilder {
	qb.query.Type = "INSERT"
	qb.query.Table = table
	return qb
}

// Values sets the values for INSERT
func (qb *QueryBuilder) Values(values ...interface{}) *QueryBuilder {
	qb.query.Values = values
	return qb
}

// Update starts an UPDATE query
func (qb *QueryBuilder) Update(table string) *QueryBuilder {
	qb.query.Type = "UPDATE"
	qb.query.Table = table
	return qb
}

// Set sets the values for UPDATE
func (qb *QueryBuilder) Set(values map[string]interface{}) *QueryBuilder {
	for field, value := range values {
		qb.query.Columns = append(qb.query.Columns, field)
		qb.query.Values = append(qb.query.Values, value)
	}
	return qb
}

// Delete starts a DELETE query
func (qb *QueryBuilder) Delete(table string) *QueryBuilder {
	qb.query.Type = "DELETE"
	qb.query.Table = table
	return qb
}

// Build builds the SQL query
func (qb *QueryBuilder) Build() (string, []interface{}, error) {
	// Validate query
	if qb.config.EnableValidation {
		if err := qb.validateQuery(); err != nil {
			return "", nil, err
		}
	}

	// Optimize query if enabled
	if qb.config.EnableOptimization {
		qb.optimizeQuery()
	}

	// Build SQL based on query type
	switch qb.query.Type {
	case "SELECT":
		return qb.buildSelectQuery()
	case "INSERT":
		return qb.buildInsertQuery()
	case "UPDATE":
		return qb.buildUpdateQuery()
	case "DELETE":
		return qb.buildDeleteQuery()
	default:
		return "", nil, fmt.Errorf("unsupported query type: %s", qb.query.Type)
	}
}

// buildSelectQuery builds a SELECT query
func (qb *QueryBuilder) buildSelectQuery() (string, []interface{}, error) {
	var sql strings.Builder
	var args []interface{}

	// SELECT clause
	sql.WriteString("SELECT ")
	if qb.query.Distinct {
		sql.WriteString("DISTINCT ")
	}

	// Columns
	if len(qb.query.Aggregates) > 0 {
		var aggregates []string
		for _, agg := range qb.query.Aggregates {
			aggregate := fmt.Sprintf("%s(%s)", agg.Function, agg.Field)
			if agg.Alias != "" {
				aggregate += fmt.Sprintf(" AS %s", agg.Alias)
			}
			aggregates = append(aggregates, aggregate)
		}
		sql.WriteString(strings.Join(aggregates, ", "))
	} else if len(qb.query.Columns) > 0 {
		sql.WriteString(strings.Join(qb.query.Columns, ", "))
	} else {
		sql.WriteString("*")
	}

	// FROM clause
	sql.WriteString(" FROM ")
	sql.WriteString(qb.query.Table)
	if qb.query.Alias != "" {
		sql.WriteString(" AS ")
		sql.WriteString(qb.query.Alias)
	}

	// JOIN clauses
	for _, join := range qb.query.Joins {
		sql.WriteString(" ")
		sql.WriteString(join.Type)
		sql.WriteString(" JOIN ")
		sql.WriteString(join.Table)
		if join.Alias != "" {
			sql.WriteString(" AS ")
			sql.WriteString(join.Alias)
		}
		sql.WriteString(" ON ")
		
		var conditions []string
		for _, condition := range join.On {
			conditionSQL, conditionArgs := qb.buildCondition(condition)
			conditions = append(conditions, conditionSQL)
			args = append(args, conditionArgs...)
		}
		sql.WriteString(strings.Join(conditions, " AND "))
	}

	// WHERE clause
	if len(qb.query.Where) > 0 {
		sql.WriteString(" WHERE ")
		whereSQL, whereArgs := qb.buildWhereClause(qb.query.Where)
		sql.WriteString(whereSQL)
		args = append(args, whereArgs...)
	}

	// GROUP BY clause
	if len(qb.query.GroupBy) > 0 {
		sql.WriteString(" GROUP BY ")
		sql.WriteString(strings.Join(qb.query.GroupBy, ", "))
	}

	// HAVING clause
	if len(qb.query.Having) > 0 {
		sql.WriteString(" HAVING ")
		havingSQL, havingArgs := qb.buildWhereClause(qb.query.Having)
		sql.WriteString(havingSQL)
		args = append(args, havingArgs...)
	}

	// ORDER BY clause
	if len(qb.query.OrderBy) > 0 {
		sql.WriteString(" ORDER BY ")
		var orders []string
		for _, order := range qb.query.OrderBy {
			orders = append(orders, fmt.Sprintf("%s %s", order.Field, order.Direction))
		}
		sql.WriteString(strings.Join(orders, ", "))
	}

	// LIMIT clause
	if qb.query.Limit > 0 {
		sql.WriteString(" LIMIT ")
		sql.WriteString(fmt.Sprintf("%d", qb.query.Limit))
	}

	// OFFSET clause
	if qb.query.Offset > 0 {
		sql.WriteString(" OFFSET ")
		sql.WriteString(fmt.Sprintf("%d", qb.query.Offset))
	}

	return sql.String(), args, nil
}

// buildInsertQuery builds an INSERT query
func (qb *QueryBuilder) buildInsertQuery() (string, []interface{}, error) {
	var sql strings.Builder
	var args []interface{}

	sql.WriteString("INSERT INTO ")
	sql.WriteString(qb.query.Table)

	if len(qb.query.Columns) > 0 {
		sql.WriteString(" (")
		sql.WriteString(strings.Join(qb.query.Columns, ", "))
		sql.WriteString(")")
	}

	sql.WriteString(" VALUES (")

	// Build placeholders
	var placeholders []string
	for i := 0; i < len(qb.query.Values); i++ {
		placeholders = append(placeholders, "?")
		args = append(args, qb.query.Values[i])
	}

	sql.WriteString(strings.Join(placeholders, ", "))
	sql.WriteString(")")

	return sql.String(), args, nil
}

// buildUpdateQuery builds an UPDATE query
func (qb *QueryBuilder) buildUpdateQuery() (string, []interface{}, error) {
	var sql strings.Builder
	var args []interface{}

	sql.WriteString("UPDATE ")
	sql.WriteString(qb.query.Table)
	sql.WriteString(" SET ")

	// Build SET clause
	var sets []string
	for i, column := range qb.query.Columns {
		if i < len(qb.query.Values) {
			sets = append(sets, fmt.Sprintf("%s = ?", column))
			args = append(args, qb.query.Values[i])
		}
	}
	sql.WriteString(strings.Join(sets, ", "))

	// WHERE clause
	if len(qb.query.Where) > 0 {
		sql.WriteString(" WHERE ")
		whereSQL, whereArgs := qb.buildWhereClause(qb.query.Where)
		sql.WriteString(whereSQL)
		args = append(args, whereArgs...)
	}

	return sql.String(), args, nil
}

// buildDeleteQuery builds a DELETE query
func (qb *QueryBuilder) buildDeleteQuery() (string, []interface{}, error) {
	var sql strings.Builder
	var args []interface{}

	sql.WriteString("DELETE FROM ")
	sql.WriteString(qb.query.Table)

	// WHERE clause
	if len(qb.query.Where) > 0 {
		sql.WriteString(" WHERE ")
		whereSQL, whereArgs := qb.buildWhereClause(qb.query.Where)
		sql.WriteString(whereSQL)
		args = append(args, whereArgs...)
	}

	return sql.String(), args, nil
}

// buildWhereClause builds a WHERE clause
func (qb *QueryBuilder) buildWhereClause(conditions []Condition) (string, []interface{}) {
	var sql strings.Builder
	var args []interface{}

	for i, condition := range conditions {
		if i > 0 {
			sql.WriteString(" ")
			sql.WriteString(condition.Logic)
			sql.WriteString(" ")
		}

		conditionSQL, conditionArgs := qb.buildCondition(condition)
		sql.WriteString(conditionSQL)
		args = append(args, conditionArgs...)
	}

	return sql.String(), args
}

// buildCondition builds a single condition
func (qb *QueryBuilder) buildCondition(condition Condition) (string, []interface{}) {
	var sql strings.Builder
	var args []interface{}

	sql.WriteString(condition.Field)
	sql.WriteString(" ")

	switch condition.Operator {
	case "IN":
		sql.WriteString("IN (")
		if values, ok := condition.Value.([]interface{}); ok {
			var placeholders []string
			for range values {
				placeholders = append(placeholders, "?")
				args = append(args, values...)
			}
			sql.WriteString(strings.Join(placeholders, ", "))
		}
		sql.WriteString(")")
	case "IS NULL":
		sql.WriteString("IS NULL")
	case "IS NOT NULL":
		sql.WriteString("IS NOT NULL")
	default:
		sql.WriteString(condition.Operator)
		sql.WriteString(" ?")
		if condition.Value != nil {
			args = append(args, condition.Value)
		}
	}

	return sql.String(), args
}

// validateQuery validates the query
func (qb *QueryBuilder) validateQuery() error {
	if qb.query.Type == "" {
		return fmt.Errorf("query type is required")
	}

	if qb.query.Table == "" {
		return fmt.Errorf("table is required")
	}

	// Validate joins
	if len(qb.query.Joins) > qb.optimizer.config.MaxJoins {
		return fmt.Errorf("too many joins: %d (max: %d)", len(qb.query.Joins), qb.optimizer.config.MaxJoins)
	}

	// Validate subqueries
	if len(qb.query.Subqueries) > qb.optimizer.config.MaxSubqueries {
		return fmt.Errorf("too many subqueries: %d (max: %d)", len(qb.query.Subqueries), qb.optimizer.config.MaxSubqueries)
	}

	return nil
}

// optimizeQuery optimizes the query
func (qb *QueryBuilder) optimizeQuery() {
	if !qb.config.EnableOptimization {
		return
	}

	// Remove duplicate conditions
	qb.removeDuplicateConditions()

	// Optimize WHERE clause
	qb.optimizeWhereClause()

	// Optimize ORDER BY
	qb.optimizeOrderBy()
}

// removeDuplicateConditions removes duplicate WHERE conditions
func (qb *QueryBuilder) removeDuplicateConditions() {
	seen := make(map[string]bool)
	var uniqueConditions []Condition

	for _, condition := range qb.query.Where {
		key := fmt.Sprintf("%s%s%v", condition.Field, condition.Operator, condition.Value)
		if !seen[key] {
			seen[key] = true
			uniqueConditions = append(uniqueConditions, condition)
		}
	}

	qb.query.Where = uniqueConditions
}

// optimizeWhereClause optimizes the WHERE clause
func (qb *QueryBuilder) optimizeWhereClause() {
	// Move indexed columns to the front
	var indexedConditions []Condition
	var otherConditions []Condition

	for _, condition := range qb.query.Where {
		// This is a simplified optimization - in practice, you'd check actual indexes
		if strings.Contains(condition.Field, "id") || strings.Contains(condition.Field, "key") {
			indexedConditions = append(indexedConditions, condition)
		} else {
			otherConditions = append(otherConditions, condition)
		}
	}

	qb.query.Where = append(indexedConditions, otherConditions...)
}

// optimizeOrderBy optimizes the ORDER BY clause
func (qb *QueryBuilder) optimizeOrderBy() {
	// Remove duplicate ORDER BY clauses
	seen := make(map[string]bool)
	var uniqueOrderBy []OrderBy

	for _, order := range qb.query.OrderBy {
		key := fmt.Sprintf("%s%s", order.Field, order.Direction)
		if !seen[key] {
			seen[key] = true
			uniqueOrderBy = append(uniqueOrderBy, order)
		}
	}

	qb.query.OrderBy = uniqueOrderBy
}

// Reset resets the query builder
func (qb *QueryBuilder) Reset() *QueryBuilder {
	qb.query = &Query{
		Metadata: make(map[string]string),
	}
	return qb
}

// GetQuery returns the current query
func (qb *QueryBuilder) GetQuery() *Query {
	return qb.query
}

// SetQuery sets the query
func (qb *QueryBuilder) SetQuery(query *Query) *QueryBuilder {
	qb.query = query
	return qb
} 