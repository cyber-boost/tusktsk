package main

import (
	"context"
	"fmt"
	"sync"
	"time"
)

// StreamProcessor provides real-time stream processing capabilities
type StreamProcessor struct {
	streams   map[string]*DataStream
	config    StreamConfig
	pipeline  *ProcessingPipeline
	monitor   *StreamMonitor
	mutex     sync.RWMutex
}

// DataStream represents a data stream
type DataStream struct {
	ID          string            `json:"id"`
	Name        string            `json:"name"`
	Source      string            `json:"source"`
	Schema      map[string]string `json:"schema"`
	Partitions  int               `json:"partitions"`
	Replicas    int               `json:"replicas"`
	Status      string            `json:"status"` // active, paused, stopped
	CreatedAt   time.Time         `json:"created_at"`
	LastEvent   *time.Time        `json:"last_event"`
	Stats       *StreamStats      `json:"stats"`
	Metadata    map[string]string `json:"metadata"`
}

// StreamConfig represents stream configuration
type StreamConfig struct {
	DefaultBufferSize    int           `json:"default_buffer_size"`
	MaxBufferSize        int           `json:"max_buffer_size"`
	ProcessingTimeout    time.Duration `json:"processing_timeout"`
	EnableBackpressure   bool          `json:"enable_backpressure"`
	BackpressureThreshold int          `json:"backpressure_threshold"`
	EnableCheckpointing  bool          `json:"enable_checkpointing"`
	CheckpointInterval   time.Duration `json:"checkpoint_interval"`
	EnableMonitoring     bool          `json:"enable_monitoring"`
	MonitorInterval      time.Duration `json:"monitor_interval"`
	EnableMetrics        bool          `json:"enable_metrics"`
}

// ProcessingPipeline manages stream processing pipeline
type ProcessingPipeline struct {
	streamProcessor *StreamProcessor
	operators       map[string]StreamOperator
	config          PipelineConfig
	mutex           sync.RWMutex
}

// StreamOperator interface for stream processing operators
type StreamOperator interface {
	Process(input *StreamRecord) (*StreamRecord, error)
	GetName() string
	GetConfig() map[string]interface{}
}

// PipelineConfig represents pipeline configuration
type PipelineConfig struct {
	MaxOperators     int           `json:"max_operators"`
	OperatorTimeout  time.Duration `json:"operator_timeout"`
	EnableParallel   bool          `json:"enable_parallel"`
	ParallelWorkers  int           `json:"parallel_workers"`
	EnableErrorHandling bool       `json:"enable_error_handling"`
}

// StreamMonitor monitors stream processing
type StreamMonitor struct {
	streamProcessor *StreamProcessor
	metrics         map[string]*StreamMetric
	alerts          []StreamAlert
	config          MonitorConfig
	mutex           sync.RWMutex
}

// StreamRecord represents a stream record
type StreamRecord struct {
	ID        string            `json:"id"`
	StreamID  string            `json:"stream_id"`
	Data      interface{}       `json:"data"`
	Timestamp time.Time         `json:"timestamp"`
	Partition int               `json:"partition"`
	Offset    int64             `json:"offset"`
	Headers   map[string]string `json:"headers"`
	Metadata  map[string]string `json:"metadata"`
}

// StreamStats represents stream statistics
type StreamStats struct {
	TotalRecords    int64         `json:"total_records"`
	ProcessedRecords int64        `json:"processed_records"`
	FailedRecords   int64         `json:"failed_records"`
	TotalLatency    time.Duration `json:"total_latency"`
	AverageLatency  time.Duration `json:"average_latency"`
	Throughput      float64       `json:"throughput"`
	LastProcessed   *time.Time    `json:"last_processed"`
	mutex           sync.RWMutex
}

// StreamMetric represents a stream metric
type StreamMetric struct {
	StreamID   string                 `json:"stream_id"`
	Name       string                 `json:"name"`
	Value      float64                `json:"value"`
	Unit       string                 `json:"unit"`
	Timestamp  time.Time              `json:"timestamp"`
	History    []MetricPoint          `json:"history"`
	Thresholds map[string]float64     `json:"thresholds"`
	Metadata   map[string]interface{} `json:"metadata"`
}

// StreamAlert represents a stream alert
type StreamAlert struct {
	StreamID  string    `json:"stream_id"`
	Type      string    `json:"type"`
	Message   string    `json:"message"`
	Severity  string    `json:"severity"`
	Timestamp time.Time `json:"timestamp"`
	Value     float64   `json:"value"`
	Threshold float64   `json:"threshold"`
}

// MonitorConfig represents monitor configuration
type MonitorConfig struct {
	EnableLatencyMonitoring bool          `json:"enable_latency_monitoring"`
	EnableThroughputMonitoring bool       `json:"enable_throughput_monitoring"`
	EnableErrorMonitoring   bool          `json:"enable_error_monitoring"`
	AlertThreshold          float64       `json:"alert_threshold"`
	CheckInterval           time.Duration `json:"check_interval"`
}

// FilterOperator implements filtering stream operator
type FilterOperator struct {
	name   string
	config map[string]interface{}
}

// TransformOperator implements transformation stream operator
type TransformOperator struct {
	name   string
	config map[string]interface{}
}

// AggregateOperator implements aggregation stream operator
type AggregateOperator struct {
	name   string
	config map[string]interface{}
}

// WindowOperator implements windowing stream operator
type WindowOperator struct {
	name   string
	config map[string]interface{}
}

// StreamProcessor creates a new stream processor
func NewStreamProcessor(config StreamConfig) *StreamProcessor {
	sp := &StreamProcessor{
		streams: make(map[string]*DataStream),
		config:  config,
		pipeline: &ProcessingPipeline{
			operators: make(map[string]StreamOperator),
			config: PipelineConfig{
				MaxOperators:      10,
				OperatorTimeout:   30 * time.Second,
				EnableParallel:    true,
				ParallelWorkers:   5,
				EnableErrorHandling: true,
			},
		},
		monitor: &StreamMonitor{
			metrics: make(map[string]*StreamMetric),
			alerts:  make([]StreamAlert, 0),
			config: MonitorConfig{
				EnableLatencyMonitoring: true,
				EnableThroughputMonitoring: true,
				EnableErrorMonitoring:   true,
				AlertThreshold:          0.8,
				CheckInterval:           30 * time.Second,
			},
		},
	}

	sp.pipeline.streamProcessor = sp
	sp.monitor.streamProcessor = sp

	// Start monitoring if enabled
	if config.EnableMonitoring {
		go sp.startMonitoring()
	}

	return sp
}

// CreateStream creates a new data stream
func (sp *StreamProcessor) CreateStream(id, name, source string, schema map[string]string) (*DataStream, error) {
	sp.mutex.Lock()
	defer sp.mutex.Unlock()

	if _, exists := sp.streams[id]; exists {
		return nil, fmt.Errorf("stream %s already exists", id)
	}

	stream := &DataStream{
		ID:         id,
		Name:       name,
		Source:     source,
		Schema:     schema,
		Partitions: 1,
		Replicas:   1,
		Status:     "active",
		CreatedAt:  time.Now(),
		Stats:      &StreamStats{},
		Metadata:   make(map[string]string),
	}

	sp.streams[id] = stream
	return stream, nil
}

// GetStream returns a stream by ID
func (sp *StreamProcessor) GetStream(id string) (*DataStream, error) {
	sp.mutex.RLock()
	defer sp.mutex.RUnlock()

	stream, exists := sp.streams[id]
	if !exists {
		return nil, fmt.Errorf("stream %s not found", id)
	}

	return stream, nil
}

// ListStreams lists all streams
func (sp *StreamProcessor) ListStreams() []*DataStream {
	sp.mutex.RLock()
	defer sp.mutex.RUnlock()

	streams := make([]*DataStream, 0, len(sp.streams))
	for _, stream := range sp.streams {
		streams = append(streams, stream)
	}

	return streams
}

// StartStream starts a stream
func (sp *StreamProcessor) StartStream(id string) error {
	sp.mutex.Lock()
	defer sp.mutex.Unlock()

	stream, exists := sp.streams[id]
	if !exists {
		return fmt.Errorf("stream %s not found", id)
	}

	stream.Status = "active"
	return nil
}

// StopStream stops a stream
func (sp *StreamProcessor) StopStream(id string) error {
	sp.mutex.Lock()
	defer sp.mutex.Unlock()

	stream, exists := sp.streams[id]
	if !exists {
		return fmt.Errorf("stream %s not found", id)
	}

	stream.Status = "stopped"
	return nil
}

// PauseStream pauses a stream
func (sp *StreamProcessor) PauseStream(id string) error {
	sp.mutex.Lock()
	defer sp.mutex.Unlock()

	stream, exists := sp.streams[id]
	if !exists {
		return fmt.Errorf("stream %s not found", id)
	}

	stream.Status = "paused"
	return nil
}

// ProcessRecord processes a stream record
func (sp *StreamProcessor) ProcessRecord(streamID string, data interface{}, headers map[string]string) error {
	sp.mutex.RLock()
	stream, exists := sp.streams[streamID]
	sp.mutex.RUnlock()

	if !exists {
		return fmt.Errorf("stream %s not found", streamID)
	}

	if stream.Status != "active" {
		return fmt.Errorf("stream %s is not active", streamID)
	}

	record := &StreamRecord{
		ID:        generateRecordID(),
		StreamID:  streamID,
		Data:      data,
		Timestamp: time.Now(),
		Partition: 0,
		Offset:    0,
		Headers:   headers,
		Metadata:  make(map[string]string),
	}

	// Process through pipeline
	return sp.pipeline.ProcessRecord(record)
}

// AddOperator adds a processing operator to the pipeline
func (sp *StreamProcessor) AddOperator(name string, operator StreamOperator) error {
	return sp.pipeline.AddOperator(name, operator)
}

// RemoveOperator removes a processing operator from the pipeline
func (sp *StreamProcessor) RemoveOperator(name string) error {
	return sp.pipeline.RemoveOperator(name)
}

// GetOperators returns all operators
func (sp *StreamProcessor) GetOperators() map[string]StreamOperator {
	return sp.pipeline.GetOperators()
}

// GetStats returns stream processor statistics
func (sp *StreamProcessor) GetStats() map[string]interface{} {
	sp.mutex.RLock()
	defer sp.mutex.RUnlock()

	stats := map[string]interface{}{
		"streams":   len(sp.streams),
		"operators": len(sp.pipeline.operators),
		"config":    sp.config,
	}

	// Calculate total statistics
	var totalRecords, processedRecords, failedRecords int64
	var totalLatency time.Duration

	for _, stream := range sp.streams {
		stream.Stats.mutex.RLock()
		totalRecords += stream.Stats.TotalRecords
		processedRecords += stream.Stats.ProcessedRecords
		failedRecords += stream.Stats.FailedRecords
		totalLatency += stream.Stats.TotalLatency
		stream.Stats.mutex.RUnlock()
	}

	stats["total_records"] = totalRecords
	stats["processed_records"] = processedRecords
	stats["failed_records"] = failedRecords
	stats["total_latency"] = totalLatency

	if totalRecords > 0 {
		stats["average_latency"] = totalLatency / time.Duration(totalRecords)
		stats["success_rate"] = float64(processedRecords) / float64(totalRecords)
	}

	return stats
}

// startMonitoring starts stream monitoring
func (sp *StreamProcessor) startMonitoring() {
	ticker := time.NewTicker(sp.config.MonitorInterval)
	defer ticker.Stop()

	for {
		select {
		case <-ticker.C:
			sp.collectMetrics()
			sp.checkAlerts()
		}
	}
}

// collectMetrics collects stream metrics
func (sp *StreamProcessor) collectMetrics() {
	sp.mutex.RLock()
	defer sp.mutex.RUnlock()

	for _, stream := range sp.streams {
		stream.Stats.mutex.RLock()
		
		// Update latency metric
		if sp.monitor.config.EnableLatencyMonitoring {
			sp.updateStreamMetric(stream.ID, "latency", float64(stream.Stats.AverageLatency), "milliseconds")
		}

		// Update throughput metric
		if sp.monitor.config.EnableThroughputMonitoring {
			sp.updateStreamMetric(stream.ID, "throughput", stream.Stats.Throughput, "records/second")
		}

		// Update error rate metric
		if sp.monitor.config.EnableErrorMonitoring && stream.Stats.TotalRecords > 0 {
			errorRate := float64(stream.Stats.FailedRecords) / float64(stream.Stats.TotalRecords)
			sp.updateStreamMetric(stream.ID, "error_rate", errorRate, "percentage")
		}

		stream.Stats.mutex.RUnlock()
	}
}

// updateStreamMetric updates a stream metric
func (sp *StreamProcessor) updateStreamMetric(streamID, name string, value float64, unit string) {
	metricKey := fmt.Sprintf("%s_%s", streamID, name)
	
	sp.monitor.mutex.Lock()
	defer sp.monitor.mutex.Unlock()

	metric, exists := sp.monitor.metrics[metricKey]
	if !exists {
		metric = &StreamMetric{
			StreamID:   streamID,
			Name:       name,
			Unit:       unit,
			History:    make([]MetricPoint, 0),
			Thresholds: make(map[string]float64),
			Metadata:   make(map[string]interface{}),
		}
		sp.monitor.metrics[metricKey] = metric
	}

	metric.Value = value
	metric.Timestamp = time.Now()

	// Add to history (keep last 100 points)
	metric.History = append(metric.History, MetricPoint{
		Value:     value,
		Timestamp: time.Now(),
	})

	if len(metric.History) > 100 {
		metric.History = metric.History[1:]
	}
}

// checkAlerts checks for stream alerts
func (sp *StreamProcessor) checkAlerts() {
	sp.monitor.mutex.RLock()
	defer sp.monitor.mutex.RUnlock()

	for _, metric := range sp.monitor.metrics {
		// Check error rate threshold
		if metric.Name == "error_rate" && metric.Value > sp.monitor.config.AlertThreshold {
			alert := StreamAlert{
				StreamID:  metric.StreamID,
				Type:      "high_error_rate",
				Message:   fmt.Sprintf("Stream %s has high error rate", metric.StreamID),
				Severity:  "warning",
				Timestamp: time.Now(),
				Value:     metric.Value,
				Threshold: sp.monitor.config.AlertThreshold,
			}

			sp.monitor.alerts = append(sp.monitor.alerts, alert)
		}
	}
}

// generateRecordID generates a unique record ID
func generateRecordID() string {
	return fmt.Sprintf("rec_%d", time.Now().UnixNano())
}

// ProcessingPipeline implementation
func (pp *ProcessingPipeline) ProcessRecord(record *StreamRecord) error {
	pp.mutex.RLock()
	defer pp.mutex.RUnlock()

	// Process through all operators
	currentRecord := record
	for _, operator := range pp.operators {
		var err error
		currentRecord, err = operator.Process(currentRecord)
		if err != nil {
			if pp.config.EnableErrorHandling {
				// Handle error (e.g., send to dead letter queue)
				continue
			}
			return err
		}

		if currentRecord == nil {
			// Record was filtered out
			return nil
		}
	}

	// Update stream statistics
	pp.updateStreamStats(record.StreamID, true, time.Since(record.Timestamp))

	return nil
}

// updateStreamStats updates stream statistics
func (pp *ProcessingPipeline) updateStreamStats(streamID string, success bool, latency time.Duration) {
	stream, err := pp.streamProcessor.GetStream(streamID)
	if err != nil {
		return
	}

	stream.Stats.mutex.Lock()
	defer stream.Stats.mutex.Unlock()

	stream.Stats.TotalRecords++
	stream.Stats.TotalLatency += latency
	stream.Stats.LastProcessed = &time.Time{}

	if success {
		stream.Stats.ProcessedRecords++
	} else {
		stream.Stats.FailedRecords++
	}

	// Calculate average latency
	if stream.Stats.TotalRecords > 0 {
		stream.Stats.AverageLatency = stream.Stats.TotalLatency / time.Duration(stream.Stats.TotalRecords)
	}

	// Calculate throughput (simplified)
	stream.Stats.Throughput = float64(stream.Stats.ProcessedRecords) / time.Since(stream.CreatedAt).Seconds()
}

func (pp *ProcessingPipeline) AddOperator(name string, operator StreamOperator) error {
	pp.mutex.Lock()
	defer pp.mutex.Unlock()

	if len(pp.operators) >= pp.config.MaxOperators {
		return fmt.Errorf("maximum number of operators reached")
	}

	pp.operators[name] = operator
	return nil
}

func (pp *ProcessingPipeline) RemoveOperator(name string) error {
	pp.mutex.Lock()
	defer pp.mutex.Unlock()

	if _, exists := pp.operators[name]; !exists {
		return fmt.Errorf("operator %s not found", name)
	}

	delete(pp.operators, name)
	return nil
}

func (pp *ProcessingPipeline) GetOperators() map[string]StreamOperator {
	pp.mutex.RLock()
	defer pp.mutex.RUnlock()

	operators := make(map[string]StreamOperator)
	for name, operator := range pp.operators {
		operators[name] = operator
	}

	return operators
}

// FilterOperator implementation
func (fo *FilterOperator) Process(input *StreamRecord) (*StreamRecord, error) {
	// Simple filter implementation
	// In practice, this would evaluate filter conditions
	return input, nil
}

func (fo *FilterOperator) GetName() string {
	return fo.name
}

func (fo *FilterOperator) GetConfig() map[string]interface{} {
	return fo.config
}

// TransformOperator implementation
func (to *TransformOperator) Process(input *StreamRecord) (*StreamRecord, error) {
	// Simple transform implementation
	// In practice, this would apply transformations
	return input, nil
}

func (to *TransformOperator) GetName() string {
	return to.name
}

func (to *TransformOperator) GetConfig() map[string]interface{} {
	return to.config
}

// AggregateOperator implementation
func (ao *AggregateOperator) Process(input *StreamRecord) (*StreamRecord, error) {
	// Simple aggregate implementation
	// In practice, this would perform aggregations
	return input, nil
}

func (ao *AggregateOperator) GetName() string {
	return ao.name
}

func (ao *AggregateOperator) GetConfig() map[string]interface{} {
	return ao.config
}

// WindowOperator implementation
func (wo *WindowOperator) Process(input *StreamRecord) (*StreamRecord, error) {
	// Simple window implementation
	// In practice, this would handle windowing
	return input, nil
}

func (wo *WindowOperator) GetName() string {
	return wo.name
}

func (wo *WindowOperator) GetConfig() map[string]interface{} {
	return wo.config
}

// GetMetrics returns all stream metrics
func (sp *StreamProcessor) GetMetrics() map[string]*StreamMetric {
	sp.monitor.mutex.RLock()
	defer sp.monitor.mutex.RUnlock()

	metrics := make(map[string]*StreamMetric)
	for key, metric := range sp.monitor.metrics {
		metrics[key] = metric
	}

	return metrics
}

// GetAlerts returns all stream alerts
func (sp *StreamProcessor) GetAlerts() []StreamAlert {
	sp.monitor.mutex.RLock()
	defer sp.monitor.mutex.RUnlock()

	alerts := make([]StreamAlert, len(sp.monitor.alerts))
	copy(alerts, sp.monitor.alerts)
	return alerts
}

// Close closes the stream processor
func (sp *StreamProcessor) Close() error {
	sp.mutex.Lock()
	defer sp.mutex.Unlock()

	// Stop all streams
	for _, stream := range sp.streams {
		stream.Status = "stopped"
	}

	return nil
} 