package main

import (
	"context"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"sync"
	"time"

	"golang.org/x/mod/semver"
)

// Dependency represents a package dependency
type Dependency struct {
	Name         string            `json:"name"`
	Version      string            `json:"version"`
	Source       string            `json:"source"`        // git, http, local
	URL          string            `json:"url,omitempty"`
	Branch       string            `json:"branch,omitempty"`
	Commit       string            `json:"commit,omitempty"`
	Checksum     string            `json:"checksum,omitempty"`
	Dependencies []string          `json:"dependencies,omitempty"`
	Metadata     map[string]string `json:"metadata,omitempty"`
	Installed    bool              `json:"installed"`
	Path         string            `json:"path,omitempty"`
}

// DependencyResolver manages dependency resolution and installation
type DependencyResolver struct {
	dependencies map[string]*Dependency
	cache        map[string]interface{}
	mutex        sync.RWMutex
	cacheDir     string
	installDir   string
	httpClient   *http.Client
}

// ResolutionResult represents the result of dependency resolution
type ResolutionResult struct {
	Dependencies []*Dependency `json:"dependencies"`
	Conflicts    []Conflict    `json:"conflicts"`
	Warnings     []string      `json:"warnings"`
	Errors       []string      `json:"errors"`
}

// Conflict represents a dependency version conflict
type Conflict struct {
	Package     string   `json:"package"`
	Requested   string   `json:"requested"`
	Conflicting string   `json:"conflicting"`
	Reason      string   `json:"reason"`
	Solutions   []string `json:"solutions"`
}

// DependencyManager creates a new dependency resolver
func NewDependencyResolver(cacheDir, installDir string) *DependencyResolver {
	return &DependencyResolver{
		dependencies: make(map[string]*Dependency),
		cache:        make(map[string]interface{}),
		cacheDir:     cacheDir,
		installDir:   installDir,
		httpClient:   &http.Client{Timeout: 30 * time.Second},
	}
}

// AddDependency adds a dependency to the resolver
func (dr *DependencyResolver) AddDependency(dep *Dependency) error {
	dr.mutex.Lock()
	defer dr.mutex.Unlock()

	// Validate dependency
	if err := dr.validateDependency(dep); err != nil {
		return err
	}

	dr.dependencies[dep.Name] = dep
	return nil
}

// validateDependency validates a dependency
func (dr *DependencyResolver) validateDependency(dep *Dependency) error {
	if dep.Name == "" {
		return fmt.Errorf("dependency name cannot be empty")
	}

	if dep.Version == "" && dep.Commit == "" {
		return fmt.Errorf("dependency must have either version or commit")
	}

	if dep.Source == "" {
		return fmt.Errorf("dependency source cannot be empty")
	}

	return nil
}

// Resolve resolves all dependencies and their conflicts
func (dr *DependencyResolver) Resolve() (*ResolutionResult, error) {
	dr.mutex.Lock()
	defer dr.mutex.Unlock()

	result := &ResolutionResult{
		Dependencies: make([]*Dependency, 0),
		Conflicts:    make([]Conflict, 0),
		Warnings:     make([]string, 0),
		Errors:       make([]string, 0),
	}

	// Build dependency graph
	graph := dr.buildDependencyGraph()
	
	// Detect cycles
	if cycles := dr.detectCycles(graph); len(cycles) > 0 {
		for _, cycle := range cycles {
			result.Errors = append(result.Errors, fmt.Sprintf("Circular dependency detected: %s", strings.Join(cycle, " -> ")))
		}
		return result, fmt.Errorf("circular dependencies detected")
	}

	// Resolve version conflicts
	conflicts := dr.resolveVersionConflicts(graph)
	result.Conflicts = conflicts

	// Sort dependencies topologically
	sorted := dr.topologicalSort(graph)
	
	// Add resolved dependencies to result
	for _, name := range sorted {
		if dep, exists := dr.dependencies[name]; exists {
			result.Dependencies = append(result.Dependencies, dep)
		}
	}

	return result, nil
}

// buildDependencyGraph builds a dependency graph
func (dr *DependencyResolver) buildDependencyGraph() map[string][]string {
	graph := make(map[string][]string)
	
	for name, dep := range dr.dependencies {
		graph[name] = dep.Dependencies
	}
	
	return graph
}

// detectCycles detects circular dependencies using DFS
func (dr *DependencyResolver) detectCycles(graph map[string][]string) [][]string {
	visited := make(map[string]bool)
	recStack := make(map[string]bool)
	cycles := make([][]string, 0)

	var dfs func(node string, path []string) bool
	dfs = func(node string, path []string) bool {
		if recStack[node] {
			// Found cycle
			cycle := make([]string, 0)
			for i, p := range path {
				if p == node {
					cycle = path[i:]
					break
				}
			}
			cycles = append(cycles, append(cycle, node))
			return true
		}

		if visited[node] {
			return false
		}

		visited[node] = true
		recStack[node] = true
		newPath := append(path, node)

		for _, neighbor := range graph[node] {
			if dfs(neighbor, newPath) {
				return true
			}
		}

		recStack[node] = false
		return false
	}

	for node := range graph {
		if !visited[node] {
			dfs(node, []string{})
		}
	}

	return cycles
}

// resolveVersionConflicts resolves version conflicts between dependencies
func (dr *DependencyResolver) resolveVersionConflicts(graph map[string][]string) []Conflict {
	conflicts := make([]Conflict, 0)
	versions := make(map[string]map[string]string) // package -> version -> source

	// Collect all version requirements
	for name, dep := range dr.dependencies {
		if versions[name] == nil {
			versions[name] = make(map[string]string)
		}
		versions[name][dep.Version] = name

		// Check dependencies
		for _, depName := range dep.Dependencies {
			if depDep, exists := dr.dependencies[depName]; exists {
				if versions[depName] == nil {
					versions[depName] = make(map[string]string)
				}
				versions[depName][depDep.Version] = name
			}
		}
	}

	// Detect conflicts
	for pkg, versionMap := range versions {
		if len(versionMap) > 1 {
			// Multiple versions requested
			var requestedVersions []string
			for version := range versionMap {
				requestedVersions = append(requestedVersions, version)
			}

			// Find best compatible version
			bestVersion := dr.findBestVersion(pkg, requestedVersions)
			
			conflict := Conflict{
				Package:     pkg,
				Requested:   strings.Join(requestedVersions, ", "),
				Conflicting: bestVersion,
				Reason:      "Multiple versions requested",
				Solutions:   dr.generateSolutions(pkg, requestedVersions, bestVersion),
			}
			conflicts = append(conflicts, conflict)
		}
	}

	return conflicts
}

// findBestVersion finds the best compatible version
func (dr *DependencyResolver) findBestVersion(pkg string, versions []string) string {
	if len(versions) == 0 {
		return ""
	}

	// Sort versions semantically
	sort.Slice(versions, func(i, j int) bool {
		return semver.Compare(versions[i], versions[j]) > 0
	})

	return versions[0]
}

// generateSolutions generates solutions for version conflicts
func (dr *DependencyResolver) generateSolutions(pkg string, versions []string, bestVersion string) []string {
	solutions := make([]string, 0)
	
	solutions = append(solutions, fmt.Sprintf("Use version %s (highest compatible)", bestVersion))
	solutions = append(solutions, fmt.Sprintf("Update all dependencies to use %s", bestVersion))
	solutions = append(solutions, "Use dependency overrides in configuration")
	
	return solutions
}

// topologicalSort performs topological sorting of dependencies
func (dr *DependencyResolver) topologicalSort(graph map[string][]string) []string {
	inDegree := make(map[string]int)
	
	// Calculate in-degrees
	for node := range graph {
		inDegree[node] = 0
	}
	
	for _, neighbors := range graph {
		for _, neighbor := range neighbors {
			inDegree[neighbor]++
		}
	}

	// Find nodes with no incoming edges
	queue := make([]string, 0)
	for node, degree := range inDegree {
		if degree == 0 {
			queue = append(queue, node)
		}
	}

	result := make([]string, 0)
	
	// Process queue
	for len(queue) > 0 {
		node := queue[0]
		queue = queue[1:]
		result = append(result, node)

		// Reduce in-degree of neighbors
		for _, neighbor := range graph[node] {
			inDegree[neighbor]--
			if inDegree[neighbor] == 0 {
				queue = append(queue, neighbor)
			}
		}
	}

	return result
}

// Install installs all resolved dependencies
func (dr *DependencyResolver) Install(ctx context.Context) error {
	dr.mutex.Lock()
	defer dr.mutex.Unlock()

	// Resolve dependencies first
	result, err := dr.Resolve()
	if err != nil {
		return err
	}

	// Install each dependency
	for _, dep := range result.Dependencies {
		if err := dr.installDependency(ctx, dep); err != nil {
			return fmt.Errorf("failed to install %s: %v", dep.Name, err)
		}
	}

	return nil
}

// installDependency installs a single dependency
func (dr *DependencyResolver) installDependency(ctx context.Context, dep *Dependency) error {
	// Check if already installed
	if dep.Installed {
		return nil
	}

	// Create installation directory
	installPath := filepath.Join(dr.installDir, dep.Name)
	if err := os.MkdirAll(installPath, 0755); err != nil {
		return err
	}

	// Install based on source type
	switch dep.Source {
	case "git":
		return dr.installFromGit(ctx, dep, installPath)
	case "http", "https":
		return dr.installFromHTTP(ctx, dep, installPath)
	case "local":
		return dr.installFromLocal(ctx, dep, installPath)
	default:
		return fmt.Errorf("unsupported source type: %s", dep.Source)
	}
}

// installFromGit installs dependency from Git repository
func (dr *DependencyResolver) installFromGit(ctx context.Context, dep *Dependency, installPath string) error {
	// This would use git commands to clone and checkout
	// For now, create a placeholder implementation
	dep.Installed = true
	dep.Path = installPath
	return nil
}

// installFromHTTP installs dependency from HTTP/HTTPS URL
func (dr *DependencyResolver) installFromHTTP(ctx context.Context, dep *Dependency, installPath string) error {
	// Download from URL
	resp, err := dr.httpClient.Get(dep.URL)
	if err != nil {
		return err
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return fmt.Errorf("HTTP error: %d", resp.StatusCode)
	}

	// Read and save content
	content, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		return err
	}

	// Save to file
	fileName := filepath.Base(dep.URL)
	if fileName == "" {
		fileName = dep.Name
	}
	
	filePath := filepath.Join(installPath, fileName)
	if err := ioutil.WriteFile(filePath, content, 0644); err != nil {
		return err
	}

	dep.Installed = true
	dep.Path = installPath
	return nil
}

// installFromLocal installs dependency from local path
func (dr *DependencyResolver) installFromLocal(ctx context.Context, dep *Dependency, installPath string) error {
	// Copy from local path
	if err := dr.copyDirectory(dep.URL, installPath); err != nil {
		return err
	}

	dep.Installed = true
	dep.Path = installPath
	return nil
}

// copyDirectory copies a directory recursively
func (dr *DependencyResolver) copyDirectory(src, dst string) error {
	// Implementation would copy directory contents
	// For now, create a placeholder
	return nil
}

// Update updates all dependencies to their latest versions
func (dr *DependencyResolver) Update(ctx context.Context) error {
	dr.mutex.Lock()
	defer dr.mutex.Unlock()

	for _, dep := range dr.dependencies {
		if err := dr.updateDependency(ctx, dep); err != nil {
			return fmt.Errorf("failed to update %s: %v", dep.Name, err)
		}
	}

	return nil
}

// updateDependency updates a single dependency
func (dr *DependencyResolver) updateDependency(ctx context.Context, dep *Dependency) error {
	// Implementation would check for updates and install them
	// For now, return nil as placeholder
	return nil
}

// Remove removes a dependency
func (dr *DependencyResolver) Remove(name string) error {
	dr.mutex.Lock()
	defer dr.mutex.Unlock()

	dep, exists := dr.dependencies[name]
	if !exists {
		return fmt.Errorf("dependency %s not found", name)
	}

	// Remove installation
	if dep.Installed && dep.Path != "" {
		if err := os.RemoveAll(dep.Path); err != nil {
			return err
		}
	}

	// Remove from dependencies
	delete(dr.dependencies, name)
	return nil
}

// List lists all dependencies
func (dr *DependencyResolver) List() []*Dependency {
	dr.mutex.RLock()
	defer dr.mutex.RUnlock()

	deps := make([]*Dependency, 0, len(dr.dependencies))
	for _, dep := range dr.dependencies {
		deps = append(deps, dep)
	}

	return deps
}

// GetStats returns dependency statistics
func (dr *DependencyResolver) GetStats() map[string]interface{} {
	dr.mutex.RLock()
	defer dr.mutex.RUnlock()

	total := len(dr.dependencies)
	installed := 0
	for _, dep := range dr.dependencies {
		if dep.Installed {
			installed++
		}
	}

	return map[string]interface{}{
		"total_dependencies": total,
		"installed":         installed,
		"pending":           total - installed,
		"cache_dir":         dr.cacheDir,
		"install_dir":       dr.installDir,
	}
} 