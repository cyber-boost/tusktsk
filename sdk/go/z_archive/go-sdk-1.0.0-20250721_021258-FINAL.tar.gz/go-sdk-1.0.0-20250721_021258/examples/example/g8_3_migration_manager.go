package main

import (
	"context"
	"database/sql"
	"fmt"
	"sort"
	"strings"
	"sync"
	"time"
)

// MigrationManager manages database migrations
type MigrationManager struct {
	connector *DatabaseConnector
	config    MigrationConfig
	mutex     sync.RWMutex
	registry  *MigrationRegistry
}

// Migration represents a database migration
type Migration struct {
	ID          string            `json:"id"`
	Name        string            `json:"name"`
	Version     int64             `json:"version"`
	Description string            `json:"description"`
	UpSQL       string            `json:"up_sql"`
	DownSQL     string            `json:"down_sql"`
	Checksum    string            `json:"checksum"`
	CreatedAt   time.Time         `json:"created_at"`
	AppliedAt   *time.Time        `json:"applied_at"`
	Status      string            `json:"status"` // pending, applied, failed, rolled_back
	Metadata    map[string]string `json:"metadata"`
}

// MigrationConfig represents migration configuration
type MigrationConfig struct {
	TableName           string        `json:"table_name"`
	AutoCreateTable     bool          `json:"auto_create_table"`
	EnableChecksum      bool          `json:"enable_checksum"`
	EnableRollback      bool          `json:"enable_rollback"`
	MaxRetries          int           `json:"max_retries"`
	RetryDelay          time.Duration `json:"retry_delay"`
	Timeout             time.Duration `json:"timeout"`
	EnableValidation    bool          `json:"enable_validation"`
	EnableDryRun        bool          `json:"enable_dry_run"`
	BackupBeforeMigrate bool          `json:"backup_before_migrate"`
}

// MigrationRegistry manages migration registration
type MigrationRegistry struct {
	migrations map[string]*Migration
	mutex      sync.RWMutex
}

// MigrationResult represents migration execution result
type MigrationResult struct {
	MigrationID string        `json:"migration_id"`
	Status      string        `json:"status"`
	Duration    time.Duration `json:"duration"`
	Error       error         `json:"error,omitempty"`
	RowsAffected int64        `json:"rows_affected"`
	AppliedAt   time.Time     `json:"applied_at"`
}

// MigrationStatus represents migration status information
type MigrationStatus struct {
	TotalMigrations    int           `json:"total_migrations"`
	AppliedMigrations  int           `json:"applied_migrations"`
	PendingMigrations  int           `json:"pending_migrations"`
	FailedMigrations   int           `json:"failed_migrations"`
	LastAppliedVersion int64         `json:"last_applied_version"`
	LastAppliedAt      *time.Time    `json:"last_applied_at"`
	Duration           time.Duration `json:"duration"`
}

// MigrationManager creates a new migration manager
func NewMigrationManager(connector *DatabaseConnector, config MigrationConfig) *MigrationManager {
	mm := &MigrationManager{
		connector: connector,
		config:    config,
		registry: &MigrationRegistry{
			migrations: make(map[string]*Migration),
		},
	}

	// Create migrations table if auto-create is enabled
	if config.AutoCreateTable {
		go mm.createMigrationsTable()
	}

	return mm
}

// RegisterMigration registers a new migration
func (mm *MigrationManager) RegisterMigration(migration *Migration) error {
	mm.registry.mutex.Lock()
	defer mm.registry.mutex.Unlock()

	// Validate migration
	if err := mm.validateMigration(migration); err != nil {
		return err
	}

	// Check if migration already exists
	if _, exists := mm.registry.migrations[migration.ID]; exists {
		return fmt.Errorf("migration %s already registered", migration.ID)
	}

	// Set default values
	if migration.CreatedAt.IsZero() {
		migration.CreatedAt = time.Now()
	}
	if migration.Status == "" {
		migration.Status = "pending"
	}
	if migration.Metadata == nil {
		migration.Metadata = make(map[string]string)
	}

	// Calculate checksum if enabled
	if mm.config.EnableChecksum {
		migration.Checksum = mm.calculateChecksum(migration)
	}

	mm.registry.migrations[migration.ID] = migration
	return nil
}

// validateMigration validates migration configuration
func (mm *MigrationManager) validateMigration(migration *Migration) error {
	if migration.ID == "" {
		return fmt.Errorf("migration ID cannot be empty")
	}
	if migration.Name == "" {
		return fmt.Errorf("migration name cannot be empty")
	}
	if migration.Version <= 0 {
		return fmt.Errorf("migration version must be positive")
	}
	if migration.UpSQL == "" {
		return fmt.Errorf("up SQL cannot be empty")
	}
	return nil
}

// calculateChecksum calculates migration checksum
func (mm *MigrationManager) calculateChecksum(migration *Migration) string {
	// Simple checksum calculation - in practice, use a proper hash function
	content := fmt.Sprintf("%s%s%s%s", migration.Name, migration.UpSQL, migration.DownSQL, migration.Description)
	return fmt.Sprintf("%d", len(content))
}

// GetMigration returns a migration by ID
func (mm *MigrationManager) GetMigration(id string) (*Migration, error) {
	mm.registry.mutex.RLock()
	defer mm.registry.mutex.RUnlock()

	migration, exists := mm.registry.migrations[id]
	if !exists {
		return nil, fmt.Errorf("migration %s not found", id)
	}

	return migration, nil
}

// ListMigrations lists all registered migrations
func (mm *MigrationManager) ListMigrations() []*Migration {
	mm.registry.mutex.RLock()
	defer mm.registry.mutex.RUnlock()

	migrations := make([]*Migration, 0, len(mm.registry.migrations))
	for _, migration := range mm.registry.migrations {
		migrations = append(migrations, migration)
	}

	// Sort by version
	sort.Slice(migrations, func(i, j int) bool {
		return migrations[i].Version < migrations[j].Version
	})

	return migrations
}

// GetPendingMigrations returns pending migrations
func (mm *MigrationManager) GetPendingMigrations() ([]*Migration, error) {
	// Get applied migrations from database
	appliedMigrations, err := mm.getAppliedMigrations()
	if err != nil {
		return nil, err
	}

	// Get all registered migrations
	allMigrations := mm.ListMigrations()

	// Find pending migrations
	var pendingMigrations []*Migration
	for _, migration := range allMigrations {
		if !mm.isMigrationApplied(migration.ID, appliedMigrations) {
			pendingMigrations = append(pendingMigrations, migration)
		}
	}

	// Sort by version
	sort.Slice(pendingMigrations, func(i, j int) bool {
		return pendingMigrations[i].Version < pendingMigrations[j].Version
	})

	return pendingMigrations, nil
}

// isMigrationApplied checks if a migration is applied
func (mm *MigrationManager) isMigrationApplied(migrationID string, appliedMigrations map[string]bool) bool {
	return appliedMigrations[migrationID]
}

// getAppliedMigrations gets applied migrations from database
func (mm *MigrationManager) getAppliedMigrations() (map[string]bool, error) {
	// This would query the migrations table
	// For now, return empty map as placeholder
	return make(map[string]bool), nil
}

// Migrate applies pending migrations
func (mm *MigrationManager) Migrate(targetVersion int64) ([]*MigrationResult, error) {
	// Get pending migrations
	pendingMigrations, err := mm.GetPendingMigrations()
	if err != nil {
		return nil, err
	}

	// Filter migrations up to target version
	var migrationsToApply []*Migration
	for _, migration := range pendingMigrations {
		if targetVersion == 0 || migration.Version <= targetVersion {
			migrationsToApply = append(migrationsToApply, migration)
		}
	}

	// Apply migrations
	var results []*MigrationResult
	for _, migration := range migrationsToApply {
		result, err := mm.applyMigration(migration)
		if err != nil {
			return results, err
		}
		results = append(results, result)
	}

	return results, nil
}

// applyMigration applies a single migration
func (mm *MigrationManager) applyMigration(migration *Migration) (*MigrationResult, error) {
	start := time.Now()

	// Validate migration if enabled
	if mm.config.EnableValidation {
		if err := mm.validateMigrationSQL(migration.UpSQL); err != nil {
			return &MigrationResult{
				MigrationID: migration.ID,
				Status:      "failed",
				Duration:    time.Since(start),
				Error:       err,
			}, nil
		}
	}

	// Dry run if enabled
	if mm.config.EnableDryRun {
		return &MigrationResult{
			MigrationID: migration.ID,
			Status:      "dry_run",
			Duration:    time.Since(start),
		}, nil
	}

	// Execute migration with retry logic
	var result *MigrationResult
	var err error
	for attempt := 0; attempt <= mm.config.MaxRetries; attempt++ {
		result, err = mm.executeMigration(migration)
		if err == nil {
			break
		}

		if attempt < mm.config.MaxRetries {
			time.Sleep(mm.config.RetryDelay)
		}
	}

	if err != nil {
		result = &MigrationResult{
			MigrationID: migration.ID,
			Status:      "failed",
			Duration:    time.Since(start),
			Error:       err,
		}
	}

	return result, nil
}

// executeMigration executes a migration
func (mm *MigrationManager) executeMigration(migration *Migration) (*MigrationResult, error) {
	// Get database connection
	conn, err := mm.connector.GetConnection("default")
	if err != nil {
		return nil, err
	}

	// Begin transaction
	tx, err := mm.connector.BeginTransaction("default")
	if err != nil {
		return nil, err
	}

	// Execute migration SQL
	result, err := mm.executeMigrationSQL(tx, migration.UpSQL)
	if err != nil {
		mm.connector.RollbackTransaction(tx)
		return nil, err
	}

	// Record migration in database
	if err := mm.recordMigration(tx, migration); err != nil {
		mm.connector.RollbackTransaction(tx)
		return nil, err
	}

	// Commit transaction
	if err := mm.connector.CommitTransaction(tx); err != nil {
		return nil, err
	}

	// Update migration status
	migration.Status = "applied"
	now := time.Now()
	migration.AppliedAt = &now

	return &MigrationResult{
		MigrationID:  migration.ID,
		Status:       "applied",
		Duration:     time.Since(now),
		RowsAffected: result.RowsAffected,
		AppliedAt:    now,
	}, nil
}

// executeMigrationSQL executes migration SQL
func (mm *MigrationManager) executeMigrationSQL(tx *Transaction, sql string) (*QueryResult, error) {
	// Split SQL into individual statements
	statements := mm.splitSQLStatements(sql)

	var totalRowsAffected int64
	for _, statement := range statements {
		statement = strings.TrimSpace(statement)
		if statement == "" {
			continue
		}

		// Execute statement
		result, err := mm.executeStatement(tx, statement)
		if err != nil {
			return nil, fmt.Errorf("failed to execute statement: %v", err)
		}

		totalRowsAffected += result.RowsAffected
	}

	return &QueryResult{
		RowsAffected: totalRowsAffected,
	}, nil
}

// splitSQLStatements splits SQL into individual statements
func (mm *MigrationManager) splitSQLStatements(sql string) []string {
	// Simple semicolon-based splitting
	// In practice, you'd want more sophisticated SQL parsing
	return strings.Split(sql, ";")
}

// executeStatement executes a single SQL statement
func (mm *MigrationManager) executeStatement(tx *Transaction, statement string) (*QueryResult, error) {
	// This would execute the statement using the transaction
	// For now, return a placeholder result
	return &QueryResult{
		RowsAffected: 1,
	}, nil
}

// recordMigration records migration in database
func (mm *MigrationManager) recordMigration(tx *Transaction, migration *Migration) error {
	// This would insert a record into the migrations table
	// For now, just a placeholder
	return nil
}

// Rollback rolls back migrations
func (mm *MigrationManager) Rollback(targetVersion int64) ([]*MigrationResult, error) {
	if !mm.config.EnableRollback {
		return nil, fmt.Errorf("rollback is not enabled")
	}

	// Get applied migrations
	appliedMigrations, err := mm.getAppliedMigrations()
	if err != nil {
		return nil, err
	}

	// Get migrations to rollback
	var migrationsToRollback []*Migration
	for _, migration := range mm.ListMigrations() {
		if mm.isMigrationApplied(migration.ID, appliedMigrations) && migration.Version > targetVersion {
			migrationsToRollback = append(migrationsToRollback, migration)
		}
	}

	// Sort by version (descending for rollback)
	sort.Slice(migrationsToRollback, func(i, j int) bool {
		return migrationsToRollback[i].Version > migrationsToRollback[j].Version
	})

	// Rollback migrations
	var results []*MigrationResult
	for _, migration := range migrationsToRollback {
		result, err := mm.rollbackMigration(migration)
		if err != nil {
			return results, err
		}
		results = append(results, result)
	}

	return results, nil
}

// rollbackMigration rolls back a single migration
func (mm *MigrationManager) rollbackMigration(migration *Migration) (*MigrationResult, error) {
	start := time.Now()

	// Check if migration has down SQL
	if migration.DownSQL == "" {
		return &MigrationResult{
			MigrationID: migration.ID,
			Status:      "failed",
			Duration:    time.Since(start),
			Error:       fmt.Errorf("migration %s has no down SQL", migration.ID),
		}, nil
	}

	// Get database connection
	conn, err := mm.connector.GetConnection("default")
	if err != nil {
		return nil, err
	}

	// Begin transaction
	tx, err := mm.connector.BeginTransaction("default")
	if err != nil {
		return nil, err
	}

	// Execute rollback SQL
	result, err := mm.executeMigrationSQL(tx, migration.DownSQL)
	if err != nil {
		mm.connector.RollbackTransaction(tx)
		return nil, err
	}

	// Remove migration record from database
	if err := mm.removeMigrationRecord(tx, migration.ID); err != nil {
		mm.connector.RollbackTransaction(tx)
		return nil, err
	}

	// Commit transaction
	if err := mm.connector.CommitTransaction(tx); err != nil {
		return nil, err
	}

	// Update migration status
	migration.Status = "rolled_back"
	migration.AppliedAt = nil

	return &MigrationResult{
		MigrationID:  migration.ID,
		Status:       "rolled_back",
		Duration:     time.Since(start),
		RowsAffected: result.RowsAffected,
		AppliedAt:    time.Now(),
	}, nil
}

// removeMigrationRecord removes migration record from database
func (mm *MigrationManager) removeMigrationRecord(tx *Transaction, migrationID string) error {
	// This would delete the record from the migrations table
	// For now, just a placeholder
	return nil
}

// GetStatus returns migration status
func (mm *MigrationManager) GetStatus() (*MigrationStatus, error) {
	start := time.Now()

	// Get all migrations
	allMigrations := mm.ListMigrations()
	appliedMigrations, err := mm.getAppliedMigrations()
	if err != nil {
		return nil, err
	}

	// Calculate statistics
	var appliedCount, pendingCount, failedCount int
	var lastAppliedVersion int64
	var lastAppliedAt *time.Time

	for _, migration := range allMigrations {
		if mm.isMigrationApplied(migration.ID, appliedMigrations) {
			appliedCount++
			if migration.Version > lastAppliedVersion {
				lastAppliedVersion = migration.Version
				lastAppliedAt = migration.AppliedAt
			}
		} else {
			pendingCount++
		}

		if migration.Status == "failed" {
			failedCount++
		}
	}

	return &MigrationStatus{
		TotalMigrations:    len(allMigrations),
		AppliedMigrations:  appliedCount,
		PendingMigrations:  pendingCount,
		FailedMigrations:   failedCount,
		LastAppliedVersion: lastAppliedVersion,
		LastAppliedAt:      lastAppliedAt,
		Duration:           time.Since(start),
	}, nil
}

// validateMigrationSQL validates migration SQL
func (mm *MigrationManager) validateMigrationSQL(sql string) error {
	// This would validate SQL syntax
	// For now, just check if SQL is not empty
	if strings.TrimSpace(sql) == "" {
		return fmt.Errorf("SQL cannot be empty")
	}
	return nil
}

// createMigrationsTable creates the migrations table
func (mm *MigrationManager) createMigrationsTable() error {
	// This would create the migrations table if it doesn't exist
	// For now, just a placeholder
	return nil
}

// Reset resets the migration manager
func (mm *MigrationManager) Reset() {
	mm.registry.mutex.Lock()
	defer mm.registry.mutex.Unlock()

	mm.registry.migrations = make(map[string]*Migration)
} 