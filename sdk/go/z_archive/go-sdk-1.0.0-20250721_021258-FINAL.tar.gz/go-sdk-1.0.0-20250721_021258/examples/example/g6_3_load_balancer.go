package main

import (
	"context"
	"fmt"
	"math/rand"
	"net/http"
	"net/http/httputil"
	"net/url"
	"sort"
	"sync"
	"time"
)

// LoadBalancer manages load balancing across multiple backends
type LoadBalancer struct {
	backends    []*Backend
	strategy    LoadBalancingStrategy
	healthCheck *HealthChecker
	mutex       sync.RWMutex
	config      LoadBalancerConfig
}

// Backend represents a backend server
type Backend struct {
	ID           string            `json:"id"`
	URL          string            `json:"url"`
	Weight       int               `json:"weight"`
	MaxConnections int             `json:"max_connections"`
	CurrentConnections int         `json:"current_connections"`
	HealthCheck  string            `json:"health_check"`
	Status       string            `json:"status"` // healthy, unhealthy, unknown
	LastCheck    time.Time         `json:"last_check"`
	ResponseTime time.Duration     `json:"response_time"`
	Failures     int               `json:"failures"`
	Successes    int               `json:"successes"`
	Metadata     map[string]string `json:"metadata"`
}

// LoadBalancingStrategy interface for different load balancing strategies
type LoadBalancingStrategy interface {
	SelectBackend(backends []*Backend) *Backend
}

// LoadBalancerConfig represents load balancer configuration
type LoadBalancerConfig struct {
	Strategy           string        `json:"strategy"`
	HealthCheckInterval time.Duration `json:"health_check_interval"`
	HealthCheckTimeout  time.Duration `json:"health_check_timeout"`
	MaxFailures        int           `json:"max_failures"`
	StickySession      bool          `json:"sticky_session"`
	SessionTimeout     time.Duration `json:"session_timeout"`
	RetryAttempts      int           `json:"retry_attempts"`
	RetryDelay         time.Duration `json:"retry_delay"`
}

// HealthChecker manages health checks for backends
type HealthChecker struct {
	interval time.Duration
	timeout  time.Duration
	client   *http.Client
}

// RoundRobinStrategy implements round-robin load balancing
type RoundRobinStrategy struct {
	current int
	mutex   sync.Mutex
}

// LeastConnectionsStrategy implements least connections load balancing
type LeastConnectionsStrategy struct{}

// WeightedRoundRobinStrategy implements weighted round-robin load balancing
type WeightedRoundRobinStrategy struct {
	current int
	mutex   sync.Mutex
}

// RandomStrategy implements random load balancing
type RandomStrategy struct{}

// IPHashStrategy implements IP hash load balancing
type IPHashStrategy struct{}

// LoadBalancer creates a new load balancer
func NewLoadBalancer(config LoadBalancerConfig) *LoadBalancer {
	lb := &LoadBalancer{
		backends: make([]*Backend, 0),
		config:   config,
		healthCheck: &HealthChecker{
			interval: config.HealthCheckInterval,
			timeout:  config.HealthCheckTimeout,
			client:   &http.Client{Timeout: config.HealthCheckTimeout},
		},
	}

	// Set strategy
	lb.SetStrategy(config.Strategy)

	return lb
}

// SetStrategy sets the load balancing strategy
func (lb *LoadBalancer) SetStrategy(strategy string) {
	lb.mutex.Lock()
	defer lb.mutex.Unlock()

	switch strategy {
	case "round-robin":
		lb.strategy = &RoundRobinStrategy{}
	case "least-connections":
		lb.strategy = &LeastConnectionsStrategy{}
	case "weighted-round-robin":
		lb.strategy = &WeightedRoundRobinStrategy{}
	case "random":
		lb.strategy = &RandomStrategy{}
	case "ip-hash":
		lb.strategy = &IPHashStrategy{}
	default:
		lb.strategy = &RoundRobinStrategy{}
	}
}

// AddBackend adds a backend to the load balancer
func (lb *LoadBalancer) AddBackend(backend *Backend) error {
	lb.mutex.Lock()
	defer lb.mutex.Unlock()

	// Validate backend
	if err := lb.validateBackend(backend); err != nil {
		return err
	}

	// Set default values
	if backend.Status == "" {
		backend.Status = "unknown"
	}
	if backend.Weight == 0 {
		backend.Weight = 1
	}
	if backend.MaxConnections == 0 {
		backend.MaxConnections = 1000
	}

	lb.backends = append(lb.backends, backend)

	// Start health check if URL is provided
	if backend.HealthCheck != "" {
		go lb.startHealthCheck(backend)
	}

	return nil
}

// validateBackend validates backend configuration
func (lb *LoadBalancer) validateBackend(backend *Backend) error {
	if backend.ID == "" {
		return fmt.Errorf("backend ID cannot be empty")
	}
	if backend.URL == "" {
		return fmt.Errorf("backend URL cannot be empty")
	}
	if _, err := url.Parse(backend.URL); err != nil {
		return fmt.Errorf("invalid backend URL: %v", err)
	}
	if backend.Weight < 0 {
		return fmt.Errorf("backend weight cannot be negative")
	}
	return nil
}

// RemoveBackend removes a backend from the load balancer
func (lb *LoadBalancer) RemoveBackend(backendID string) error {
	lb.mutex.Lock()
	defer lb.mutex.Unlock()

	for i, backend := range lb.backends {
		if backend.ID == backendID {
			lb.backends = append(lb.backends[:i], lb.backends[i+1:]...)
			return nil
		}
	}

	return fmt.Errorf("backend %s not found", backendID)
}

// GetBackend retrieves a backend by ID
func (lb *LoadBalancer) GetBackend(backendID string) (*Backend, error) {
	lb.mutex.RLock()
	defer lb.mutex.RUnlock()

	for _, backend := range lb.backends {
		if backend.ID == backendID {
			return backend, nil
		}
	}

	return nil, fmt.Errorf("backend %s not found", backendID)
}

// ListBackends lists all backends
func (lb *LoadBalancer) ListBackends() []*Backend {
	lb.mutex.RLock()
	defer lb.mutex.RUnlock()

	backends := make([]*Backend, len(lb.backends))
	copy(backends, lb.backends)
	return backends
}

// SelectBackend selects a backend using the current strategy
func (lb *LoadBalancer) SelectBackend() (*Backend, error) {
	lb.mutex.RLock()
	defer lb.mutex.RUnlock()

	// Filter healthy backends
	healthyBackends := make([]*Backend, 0)
	for _, backend := range lb.backends {
		if backend.Status == "healthy" && backend.CurrentConnections < backend.MaxConnections {
			healthyBackends = append(healthyBackends, backend)
		}
	}

	if len(healthyBackends) == 0 {
		return nil, fmt.Errorf("no healthy backends available")
	}

	// Select backend using strategy
	selected := lb.strategy.SelectBackend(healthyBackends)
	if selected == nil {
		return nil, fmt.Errorf("failed to select backend")
	}

	// Increment connection count
	selected.CurrentConnections++

	return selected, nil
}

// ReleaseBackend releases a backend connection
func (lb *LoadBalancer) ReleaseBackend(backendID string) {
	lb.mutex.Lock()
	defer lb.mutex.Unlock()

	for _, backend := range lb.backends {
		if backend.ID == backendID {
			if backend.CurrentConnections > 0 {
				backend.CurrentConnections--
			}
			break
		}
	}
}

// startHealthCheck starts health check for a backend
func (lb *LoadBalancer) startHealthCheck(backend *Backend) {
	ticker := time.NewTicker(lb.config.HealthCheckInterval)
	defer ticker.Stop()

	for {
		select {
		case <-ticker.C:
			lb.performHealthCheck(backend)
		}
	}
}

// performHealthCheck performs a health check
func (lb *LoadBalancer) performHealthCheck(backend *Backend) {
	start := time.Now()

	// Create request
	req, err := http.NewRequest("GET", backend.HealthCheck, nil)
	if err != nil {
		lb.recordHealthCheckFailure(backend)
		return
	}

	// Set timeout
	ctx, cancel := context.WithTimeout(context.Background(), lb.config.HealthCheckTimeout)
	defer cancel()
	req = req.WithContext(ctx)

	// Perform request
	resp, err := lb.healthCheck.client.Do(req)
	if err != nil {
		lb.recordHealthCheckFailure(backend)
		return
	}
	defer resp.Body.Close()

	// Record response time
	backend.ResponseTime = time.Since(start)

	// Check status code
	if resp.StatusCode >= 200 && resp.StatusCode < 400 {
		lb.recordHealthCheckSuccess(backend)
	} else {
		lb.recordHealthCheckFailure(backend)
	}
}

// recordHealthCheckSuccess records successful health check
func (lb *LoadBalancer) recordHealthCheckSuccess(backend *Backend) {
	lb.mutex.Lock()
	defer lb.mutex.Unlock()

	backend.LastCheck = time.Now()
	backend.Successes++
	backend.Failures = 0

	if backend.Status != "healthy" {
		backend.Status = "healthy"
	}
}

// recordHealthCheckFailure records failed health check
func (lb *LoadBalancer) recordHealthCheckFailure(backend *Backend) {
	lb.mutex.Lock()
	defer lb.mutex.Unlock()

	backend.LastCheck = time.Now()
	backend.Failures++

	if backend.Failures >= lb.config.MaxFailures {
		if backend.Status != "unhealthy" {
			backend.Status = "unhealthy"
		}
	}
}

// RoundRobinStrategy implementation
func (rr *RoundRobinStrategy) SelectBackend(backends []*Backend) *Backend {
	rr.mutex.Lock()
	defer rr.mutex.Unlock()

	if len(backends) == 0 {
		return nil
	}

	selected := backends[rr.current]
	rr.current = (rr.current + 1) % len(backends)

	return selected
}

// LeastConnectionsStrategy implementation
func (lc *LeastConnectionsStrategy) SelectBackend(backends []*Backend) *Backend {
	if len(backends) == 0 {
		return nil
	}

	selected := backends[0]
	minConnections := selected.CurrentConnections

	for _, backend := range backends[1:] {
		if backend.CurrentConnections < minConnections {
			selected = backend
			minConnections = backend.CurrentConnections
		}
	}

	return selected
}

// WeightedRoundRobinStrategy implementation
func (wrr *WeightedRoundRobinStrategy) SelectBackend(backends []*Backend) *Backend {
	wrr.mutex.Lock()
	defer wrr.mutex.Unlock()

	if len(backends) == 0 {
		return nil
	}

	// Calculate total weight
	totalWeight := 0
	for _, backend := range backends {
		totalWeight += backend.Weight
	}

	if totalWeight == 0 {
		return backends[0]
	}

	// Select based on weight
	currentWeight := 0
	for _, backend := range backends {
		currentWeight += backend.Weight
		if wrr.current < currentWeight {
			wrr.current = (wrr.current + 1) % totalWeight
			return backend
		}
	}

	// Fallback
	wrr.current = (wrr.current + 1) % totalWeight
	return backends[0]
}

// RandomStrategy implementation
func (r *RandomStrategy) SelectBackend(backends []*Backend) *Backend {
	if len(backends) == 0 {
		return nil
	}

	index := rand.Intn(len(backends))
	return backends[index]
}

// IPHashStrategy implementation
func (ih *IPHashStrategy) SelectBackend(backends []*Backend) *Backend {
	if len(backends) == 0 {
		return nil
	}

	// This would typically use the client's IP address
	// For now, use a simple hash
	hash := time.Now().UnixNano()
	index := int(hash) % len(backends)
	return backends[index]
}

// CreateReverseProxy creates a reverse proxy for the load balancer
func (lb *LoadBalancer) CreateReverseProxy() *httputil.ReverseProxy {
	return &httputil.ReverseProxy{
		Director: func(req *http.Request) {
			backend, err := lb.SelectBackend()
			if err != nil {
				// Return error response
				return
			}

			backendURL, _ := url.Parse(backend.URL)
			req.URL.Scheme = backendURL.Scheme
			req.URL.Host = backendURL.Host
			req.Host = backendURL.Host
		},
		ModifyResponse: func(resp *http.Response) error {
			// Add load balancer headers
			resp.Header.Set("X-Load-Balancer", "true")
			return nil
		},
		ErrorHandler: func(w http.ResponseWriter, r *http.Request, err error) {
			// Handle errors and retry if configured
			w.WriteHeader(http.StatusBadGateway)
			w.Write([]byte("Service temporarily unavailable"))
		},
	}
}

// GetStats returns load balancer statistics
func (lb *LoadBalancer) GetStats() map[string]interface{} {
	lb.mutex.RLock()
	defer lb.mutex.RUnlock()

	healthy := 0
	unhealthy := 0
	unknown := 0
	totalConnections := 0

	for _, backend := range lb.backends {
		switch backend.Status {
		case "healthy":
			healthy++
		case "unhealthy":
			unhealthy++
		case "unknown":
			unknown++
		}
		totalConnections += backend.CurrentConnections
	}

	return map[string]interface{}{
		"total_backends":     len(lb.backends),
		"healthy":           healthy,
		"unhealthy":         unhealthy,
		"unknown":           unknown,
		"total_connections": totalConnections,
		"strategy":          lb.config.Strategy,
	}
}

// UpdateBackend updates backend configuration
func (lb *LoadBalancer) UpdateBackend(backendID string, updates map[string]interface{}) error {
	lb.mutex.Lock()
	defer lb.mutex.Unlock()

	for _, backend := range lb.backends {
		if backend.ID == backendID {
			// Apply updates
			for key, value := range updates {
				switch key {
				case "url":
					if url, ok := value.(string); ok {
						backend.URL = url
					}
				case "weight":
					if weight, ok := value.(int); ok {
						backend.Weight = weight
					}
				case "max_connections":
					if maxConn, ok := value.(int); ok {
						backend.MaxConnections = maxConn
					}
				case "health_check":
					if healthCheck, ok := value.(string); ok {
						backend.HealthCheck = healthCheck
					}
				case "metadata":
					if metadata, ok := value.(map[string]string); ok {
						backend.Metadata = metadata
					}
				}
			}
			return nil
		}
	}

	return fmt.Errorf("backend %s not found", backendID)
} 