package main

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"math"
	"sync"
	"time"
)

// BlockchainEngine provides blockchain capabilities
type BlockchainEngine struct {
	chains      map[string]*Blockchain
	contracts   map[string]*SmartContract
	transactions map[string]*Transaction
	config      BlockchainConfig
	validator   *BlockValidator
	executor    *ContractExecutor
	network     *NetworkManager
	mutex       sync.RWMutex
}

// Blockchain represents a blockchain
type Blockchain struct {
	ID          string            `json:"id"`
	Name        string            `json:"name"`
	Description string            `json:"description"`
	Type        string            `json:"type"` // public, private, consortium
	Consensus   string            `json:"consensus"` // proof_of_work, proof_of_stake, pbft
	Blocks      []*Block          `json:"blocks"`
	Genesis     *Block            `json:"genesis"`
	Difficulty  int               `json:"difficulty"`
	BlockTime   time.Duration     `json:"block_time"`
	Status      string            `json:"status"` // active, inactive, forked
	CreatedAt   time.Time         `json:"created_at"`
	UpdatedAt   time.Time         `json:"updated_at"`
	Metadata    map[string]string `json:"metadata"`
}

// Block represents a blockchain block
type Block struct {
	ID              string            `json:"id"`
	Index           int               `json:"index"`
	Timestamp       time.Time         `json:"timestamp"`
	PreviousHash    string            `json:"previous_hash"`
	Hash            string            `json:"hash"`
	MerkleRoot      string            `json:"merkle_root"`
	Transactions    []*Transaction    `json:"transactions"`
	Nonce           int               `json:"nonce"`
	Difficulty      int               `json:"difficulty"`
	Miner           string            `json:"miner"`
	Size            int               `json:"size"`
	GasUsed         int               `json:"gas_used"`
	GasLimit        int               `json:"gas_limit"`
	Metadata        map[string]string `json:"metadata"`
}

// Transaction represents a blockchain transaction
type Transaction struct {
	ID          string            `json:"id"`
	Hash        string            `json:"hash"`
	From        string            `json:"from"`
	To          string            `json:"to"`
	Value       float64           `json:"value"`
	GasPrice    float64           `json:"gas_price"`
	GasLimit    int               `json:"gas_limit"`
	GasUsed     int               `json:"gas_used"`
	Nonce       int               `json:"nonce"`
	Data        []byte            `json:"data"`
	Signature   string            `json:"signature"`
	Status      string            `json:"status"` // pending, confirmed, failed
	BlockHash   string            `json:"block_hash"`
	BlockIndex  int               `json:"block_index"`
	CreatedAt   time.Time         `json:"created_at"`
	ConfirmedAt *time.Time        `json:"confirmed_at"`
	Metadata    map[string]string `json:"metadata"`
}

// SmartContract represents a smart contract
type SmartContract struct {
	ID          string            `json:"id"`
	Name        string            `json:"name"`
	Description string            `json:"description"`
	Address     string            `json:"address"`
	Bytecode    []byte            `json:"bytecode"`
	ABI         []byte            `json:"abi"`
	SourceCode  string            `json:"source_code"`
	Language    string            `json:"language"` // solidity, vyper, rust
	Version     string            `json:"version"`
	Creator     string            `json:"creator"`
	BlockHash   string            `json:"block_hash"`
	BlockIndex  int               `json:"block_index"`
	Status      string            `json:"status"` // deployed, active, paused, destroyed
	Balance     float64           `json:"balance"`
	GasUsed     int               `json:"gas_used"`
	CreatedAt   time.Time         `json:"created_at"`
	UpdatedAt   time.Time         `json:"updated_at"`
	Metadata    map[string]string `json:"metadata"`
}

// Wallet represents a blockchain wallet
type Wallet struct {
	ID          string            `json:"id"`
	Address     string            `json:"address"`
	PublicKey   string            `json:"public_key"`
	PrivateKey  string            `json:"private_key"`
	Balance     float64           `json:"balance"`
	Nonce       int               `json:"nonce"`
	Type        string            `json:"type"` // eoa, contract
	CreatedAt   time.Time         `json:"created_at"`
	UpdatedAt   time.Time         `json:"updated_at"`
	Metadata    map[string]string `json:"metadata"`
}

// BlockchainConfig represents blockchain configuration
type BlockchainConfig struct {
	EnableMining           bool          `json:"enable_mining"`
	EnableSmartContracts   bool          `json:"enable_smart_contracts"`
	EnableConsensus        bool          `json:"enable_consensus"`
	EnableNetworking       bool          `json:"enable_networking"`
	EnableMonitoring       bool          `json:"enable_monitoring"`
	MonitorInterval        time.Duration `json:"monitor_interval"`
	MaxBlocks              int           `json:"max_blocks"`
	MaxTransactions        int           `json:"max_transactions"`
	MaxContracts           int           `json:"max_contracts"`
	DefaultGasLimit        int           `json:"default_gas_limit"`
	DefaultGasPrice        float64       `json:"default_gas_price"`
}

// BlockValidator manages block validation
type BlockValidator struct {
	blockchainEngine *BlockchainEngine
	validators       map[string]ValidatorFunc
	config           ValidatorConfig
	mutex            sync.RWMutex
}

// ValidatorFunc represents a validator function
type ValidatorFunc func(block *Block, previousBlock *Block) error

// ValidatorConfig represents validator configuration
type ValidatorConfig struct {
	EnableHashValidation   bool          `json:"enable_hash_validation"`
	EnableMerkleValidation bool          `json:"enable_merkle_validation"`
	EnableTransactionValidation bool     `json:"enable_transaction_validation"`
	EnableDifficultyValidation bool      `json:"enable_difficulty_validation"`
}

// ContractExecutor manages smart contract execution
type ContractExecutor struct {
	blockchainEngine *BlockchainEngine
	executors        map[string]ExecutorFunc
	config           ExecutorConfig
	mutex            sync.RWMutex
}

// ExecutorFunc represents an executor function
type ExecutorFunc func(contract *SmartContract, transaction *Transaction) ([]byte, error)

// ExecutorConfig represents executor configuration
type ExecutorConfig struct {
	EnableGasMetering      bool          `json:"enable_gas_metering"`
	EnableStateManagement  bool          `json:"enable_state_management"`
	EnableEventLogging     bool          `json:"enable_event_logging"`
	MaxExecutionTime       time.Duration `json:"max_execution_time"`
}

// NetworkManager manages blockchain networking
type NetworkManager struct {
	blockchainEngine *BlockchainEngine
	peers            map[string]*Peer
	config           NetworkConfig
	mutex            sync.RWMutex
}

// Peer represents a network peer
type Peer struct {
	ID          string            `json:"id"`
	Address     string            `json:"address"`
	Port        int               `json:"port"`
	Version     string            `json:"version"`
	Status      string            `json:"status"` // connected, disconnected, syncing
	LastSeen    time.Time         `json:"last_seen"`
	BlockHeight int               `json:"block_height"`
	Metadata    map[string]string `json:"metadata"`
}

// NetworkConfig represents network configuration
type NetworkConfig struct {
	EnableP2P           bool          `json:"enable_p2p"`
	EnableDiscovery     bool          `json:"enable_discovery"`
	EnableSync          bool          `json:"enable_sync"`
	MaxPeers            int           `json:"max_peers"`
	SyncInterval        time.Duration `json:"sync_interval"`
}

// BlockchainEngine creates a new blockchain engine
func NewBlockchainEngine(config BlockchainConfig) *BlockchainEngine {
	bc := &BlockchainEngine{
		chains:       make(map[string]*Blockchain),
		contracts:    make(map[string]*SmartContract),
		transactions: make(map[string]*Transaction),
		config:       config,
		validator: &BlockValidator{
			validators: make(map[string]ValidatorFunc),
			config: ValidatorConfig{
				EnableHashValidation:        true,
				EnableMerkleValidation:      true,
				EnableTransactionValidation: true,
				EnableDifficultyValidation:  true,
			},
		},
		executor: &ContractExecutor{
			executors: make(map[string]ExecutorFunc),
			config: ExecutorConfig{
				EnableGasMetering:     true,
				EnableStateManagement: true,
				EnableEventLogging:    true,
				MaxExecutionTime:      30 * time.Second,
			},
		},
		network: &NetworkManager{
			peers: make(map[string]*Peer),
			config: NetworkConfig{
				EnableP2P:       true,
				EnableDiscovery: true,
				EnableSync:      true,
				MaxPeers:        50,
				SyncInterval:    10 * time.Second,
			},
		},
	}

	bc.validator.blockchainEngine = bc
	bc.executor.blockchainEngine = bc
	bc.network.blockchainEngine = bc

	// Initialize validators, executors, and network components
	bc.initializeComponents()

	// Start monitoring if enabled
	if config.EnableMonitoring {
		go bc.startMonitoring()
	}

	return bc
}

// initializeComponents initializes blockchain components
func (bc *BlockchainEngine) initializeComponents() {
	// Register validators
	bc.validator.validators["proof_of_work"] = bc.validateProofOfWork
	bc.validator.validators["proof_of_stake"] = bc.validateProofOfStake
	bc.validator.validators["pbft"] = bc.validatePBFT

	// Register executors
	bc.executor.executors["solidity"] = bc.executeSolidity
	bc.executor.executors["vyper"] = bc.executeVyper
	bc.executor.executors["rust"] = bc.executeRust

	// Initialize genesis block
	bc.createGenesisBlock()
}

// createGenesisBlock creates the genesis block
func (bc *BlockchainEngine) createGenesisBlock() {
	genesis := &Block{
		ID:           "genesis",
		Index:        0,
		Timestamp:    time.Now(),
		PreviousHash: "0000000000000000000000000000000000000000000000000000000000000000",
		Hash:         "0000000000000000000000000000000000000000000000000000000000000001",
		MerkleRoot:   "0000000000000000000000000000000000000000000000000000000000000000",
		Transactions: []*Transaction{},
		Nonce:        0,
		Difficulty:   1,
		Miner:        "genesis",
		Size:         0,
		GasUsed:      0,
		GasLimit:     0,
		Metadata:     make(map[string]string),
	}

	// Create default blockchain
	blockchain := &Blockchain{
		ID:         "default",
		Name:       "Default Blockchain",
		Description: "Default blockchain instance",
		Type:       "private",
		Consensus:  "proof_of_work",
		Blocks:     []*Block{genesis},
		Genesis:    genesis,
		Difficulty: 4,
		BlockTime:  10 * time.Second,
		Status:     "active",
		CreatedAt:  time.Now(),
		UpdatedAt:  time.Now(),
		Metadata:   make(map[string]string),
	}

	bc.chains["default"] = blockchain
}

// CreateBlockchain creates a new blockchain
func (bc *BlockchainEngine) CreateBlockchain(blockchain *Blockchain) error {
	bc.mutex.Lock()
	defer bc.mutex.Unlock()

	if _, exists := bc.chains[blockchain.ID]; exists {
		return fmt.Errorf("blockchain %s already exists", blockchain.ID)
	}

	blockchain.CreatedAt = time.Now()
	blockchain.UpdatedAt = time.Now()
	blockchain.Status = "active"
	if blockchain.Metadata == nil {
		blockchain.Metadata = make(map[string]string)
	}

	// Create genesis block for new blockchain
	genesis := &Block{
		ID:           fmt.Sprintf("genesis_%s", blockchain.ID),
		Index:        0,
		Timestamp:    time.Now(),
		PreviousHash: "0000000000000000000000000000000000000000000000000000000000000000",
		Hash:         bc.calculateHash("genesis"),
		MerkleRoot:   "0000000000000000000000000000000000000000000000000000000000000000",
		Transactions: []*Transaction{},
		Nonce:        0,
		Difficulty:   blockchain.Difficulty,
		Miner:        "genesis",
		Size:         0,
		GasUsed:      0,
		GasLimit:     0,
		Metadata:     make(map[string]string),
	}

	blockchain.Genesis = genesis
	blockchain.Blocks = []*Block{genesis}

	bc.chains[blockchain.ID] = blockchain
	return nil
}

// GetBlockchain returns a blockchain by ID
func (bc *BlockchainEngine) GetBlockchain(blockchainID string) (*Blockchain, error) {
	bc.mutex.RLock()
	defer bc.mutex.RUnlock()

	blockchain, exists := bc.chains[blockchainID]
	if !exists {
		return nil, fmt.Errorf("blockchain %s not found", blockchainID)
	}

	return blockchain, nil
}

// ListBlockchains lists all blockchains
func (bc *BlockchainEngine) ListBlockchains() []*Blockchain {
	bc.mutex.RLock()
	defer bc.mutex.RUnlock()

	blockchains := make([]*Blockchain, 0, len(bc.chains))
	for _, blockchain := range bc.chains {
		blockchains = append(blockchains, blockchain)
	}

	return blockchains
}

// CreateTransaction creates a new transaction
func (bc *BlockchainEngine) CreateTransaction(transaction *Transaction) error {
	bc.mutex.Lock()
	defer bc.mutex.Unlock()

	if _, exists := bc.transactions[transaction.ID]; exists {
		return fmt.Errorf("transaction %s already exists", transaction.ID)
	}

	transaction.CreatedAt = time.Now()
	transaction.Status = "pending"
	transaction.Hash = bc.calculateTransactionHash(transaction)
	if transaction.Metadata == nil {
		transaction.Metadata = make(map[string]string)
	}

	bc.transactions[transaction.ID] = transaction
	return nil
}

// GetTransaction returns a transaction by ID
func (bc *BlockchainEngine) GetTransaction(transactionID string) (*Transaction, error) {
	bc.mutex.RLock()
	defer bc.mutex.RUnlock()

	transaction, exists := bc.transactions[transactionID]
	if !exists {
		return nil, fmt.Errorf("transaction %s not found", transactionID)
	}

	return transaction, nil
}

// ListTransactions lists all transactions
func (bc *BlockchainEngine) ListTransactions() []*Transaction {
	bc.mutex.RLock()
	defer bc.mutex.RUnlock()

	transactions := make([]*Transaction, 0, len(bc.transactions))
	for _, transaction := range bc.transactions {
		transactions = append(transactions, transaction)
	}

	return transactions
}

// CreateSmartContract creates a new smart contract
func (bc *BlockchainEngine) CreateSmartContract(contract *SmartContract) error {
	bc.mutex.Lock()
	defer bc.mutex.Unlock()

	if _, exists := bc.contracts[contract.ID]; exists {
		return fmt.Errorf("contract %s already exists", contract.ID)
	}

	contract.CreatedAt = time.Now()
	contract.UpdatedAt = time.Now()
	contract.Status = "deployed"
	contract.Address = bc.generateContractAddress(contract)
	if contract.Metadata == nil {
		contract.Metadata = make(map[string]string)
	}

	bc.contracts[contract.ID] = contract
	return nil
}

// GetSmartContract returns a smart contract by ID
func (bc *BlockchainEngine) GetSmartContract(contractID string) (*SmartContract, error) {
	bc.mutex.RLock()
	defer bc.mutex.RUnlock()

	contract, exists := bc.contracts[contractID]
	if !exists {
		return nil, fmt.Errorf("contract %s not found", contractID)
	}

	return contract, nil
}

// ListSmartContracts lists all smart contracts
func (bc *BlockchainEngine) ListSmartContracts() []*SmartContract {
	bc.mutex.RLock()
	defer bc.mutex.RUnlock()

	contracts := make([]*SmartContract, 0, len(bc.contracts))
	for _, contract := range bc.contracts {
		contracts = append(contracts, contract)
	}

	return contracts
}

// MineBlock mines a new block
func (bc *BlockchainEngine) MineBlock(blockchainID string, transactions []*Transaction) (*Block, error) {
	bc.mutex.RLock()
	blockchain, exists := bc.chains[blockchainID]
	bc.mutex.RUnlock()

	if !exists {
		return nil, fmt.Errorf("blockchain %s not found", blockchainID)
	}

	// Get the latest block
	latestBlock := blockchain.Blocks[len(blockchain.Blocks)-1]

	// Create new block
	block := &Block{
		ID:           bc.generateBlockID(),
		Index:        latestBlock.Index + 1,
		Timestamp:    time.Now(),
		PreviousHash: latestBlock.Hash,
		Transactions: transactions,
		Nonce:        0,
		Difficulty:   blockchain.Difficulty,
		Miner:        "miner",
		Size:         0,
		GasUsed:      0,
		GasLimit:     bc.config.DefaultGasLimit,
		Metadata:     make(map[string]string),
	}

	// Calculate merkle root
	block.MerkleRoot = bc.calculateMerkleRoot(transactions)

	// Mine the block (find nonce)
	block.Hash = bc.mineBlock(block)

	// Validate the block
	err := bc.validateBlock(block, latestBlock)
	if err != nil {
		return nil, err
	}

	// Add block to blockchain
	bc.mutex.Lock()
	blockchain.Blocks = append(blockchain.Blocks, block)
	blockchain.UpdatedAt = time.Now()
	bc.mutex.Unlock()

	// Update transaction status
	for _, tx := range transactions {
		tx.Status = "confirmed"
		tx.BlockHash = block.Hash
		tx.BlockIndex = block.Index
		now := time.Now()
		tx.ConfirmedAt = &now
	}

	return block, nil
}

// ExecuteContract executes a smart contract
func (bc *BlockchainEngine) ExecuteContract(contractID string, transaction *Transaction) ([]byte, error) {
	bc.mutex.RLock()
	contract, exists := bc.contracts[contractID]
	bc.mutex.RUnlock()

	if !exists {
		return nil, fmt.Errorf("contract %s not found", contractID)
	}

	// Get executor function
	executor, exists := bc.executor.executors[contract.Language]
	if !exists {
		return nil, fmt.Errorf("executor for language %s not found", contract.Language)
	}

	return executor(contract, transaction)
}

// startMonitoring starts blockchain monitoring
func (bc *BlockchainEngine) startMonitoring() {
	ticker := time.NewTicker(bc.config.MonitorInterval)
	defer ticker.Stop()

	for {
		select {
		case <-ticker.C:
			bc.collectMetrics()
		}
	}
}

// collectMetrics collects blockchain metrics
func (bc *BlockchainEngine) collectMetrics() {
	bc.mutex.RLock()
	defer bc.mutex.RUnlock()

	// Calculate blockchain statistics
	totalChains := len(bc.chains)
	totalContracts := len(bc.contracts)
	totalTransactions := len(bc.transactions)
	totalBlocks := 0
	pendingTransactions := 0

	for _, blockchain := range bc.chains {
		totalBlocks += len(blockchain.Blocks)
	}

	for _, transaction := range bc.transactions {
		if transaction.Status == "pending" {
			pendingTransactions++
		}
	}

	// Update metrics
	bc.updateBlockchainMetric("total_chains", float64(totalChains), "chains")
	bc.updateBlockchainMetric("total_contracts", float64(totalContracts), "contracts")
	bc.updateBlockchainMetric("total_transactions", float64(totalTransactions), "transactions")
	bc.updateBlockchainMetric("total_blocks", float64(totalBlocks), "blocks")
	bc.updateBlockchainMetric("pending_transactions", float64(pendingTransactions), "transactions")

	if totalTransactions > 0 {
		confirmationRate := float64(totalTransactions-pendingTransactions) / float64(totalTransactions)
		bc.updateBlockchainMetric("confirmation_rate", confirmationRate, "percentage")
	}
}

// updateBlockchainMetric updates a blockchain metric
func (bc *BlockchainEngine) updateBlockchainMetric(name string, value float64, unit string) {
	// This would update metrics in a monitoring system
	// For now, just a placeholder
}

// Helper methods
func (bc *BlockchainEngine) calculateHash(data string) string {
	hash := sha256.Sum256([]byte(data))
	return hex.EncodeToString(hash[:])
}

func (bc *BlockchainEngine) calculateTransactionHash(transaction *Transaction) string {
	data := fmt.Sprintf("%s%s%s%f%d%d", transaction.From, transaction.To, transaction.Value, transaction.GasPrice, transaction.GasLimit, transaction.Nonce)
	return bc.calculateHash(data)
}

func (bc *BlockchainEngine) calculateMerkleRoot(transactions []*Transaction) string {
	if len(transactions) == 0 {
		return "0000000000000000000000000000000000000000000000000000000000000000"
	}

	var hashes []string
	for _, tx := range transactions {
		hashes = append(hashes, tx.Hash)
	}

	// Simple merkle root calculation
	for len(hashes) > 1 {
		var newHashes []string
		for i := 0; i < len(hashes); i += 2 {
			if i+1 < len(hashes) {
				newHashes = append(newHashes, bc.calculateHash(hashes[i]+hashes[i+1]))
			} else {
				newHashes = append(newHashes, bc.calculateHash(hashes[i]+hashes[i]))
			}
		}
		hashes = newHashes
	}

	return hashes[0]
}

func (bc *BlockchainEngine) generateBlockID() string {
	return fmt.Sprintf("block_%d", time.Now().UnixNano())
}

func (bc *BlockchainEngine) generateContractAddress(contract *SmartContract) string {
	data := fmt.Sprintf("%s%s%d", contract.Name, contract.Creator, time.Now().UnixNano())
	return bc.calculateHash(data)[:40] // Ethereum-style address
}

func (bc *BlockchainEngine) mineBlock(block *Block) string {
	target := strings.Repeat("0", block.Difficulty)
	
	for {
		block.Nonce++
		data := fmt.Sprintf("%d%s%s%s%d", block.Index, block.Timestamp, block.PreviousHash, block.MerkleRoot, block.Nonce)
		hash := bc.calculateHash(data)
		
		if strings.HasPrefix(hash, target) {
			return hash
		}
	}
}

func (bc *BlockchainEngine) validateBlock(block *Block, previousBlock *Block) error {
	// Get validator function
	validator, exists := bc.validator.validators["proof_of_work"]
	if !exists {
		return fmt.Errorf("validator not found")
	}

	return validator(block, previousBlock)
}

// BlockValidator implementation
func (bv *BlockValidator) validateProofOfWork(block *Block, previousBlock *Block) error {
	// Validate block hash
	data := fmt.Sprintf("%d%s%s%s%d", block.Index, block.Timestamp, block.PreviousHash, block.MerkleRoot, block.Nonce)
	expectedHash := bv.blockchainEngine.calculateHash(data)
	
	if block.Hash != expectedHash {
		return fmt.Errorf("invalid block hash")
	}

	// Validate previous hash
	if block.PreviousHash != previousBlock.Hash {
		return fmt.Errorf("invalid previous hash")
	}

	// Validate block index
	if block.Index != previousBlock.Index+1 {
		return fmt.Errorf("invalid block index")
	}

	// Validate difficulty
	target := strings.Repeat("0", block.Difficulty)
	if !strings.HasPrefix(block.Hash, target) {
		return fmt.Errorf("block does not meet difficulty requirement")
	}

	return nil
}

func (bv *BlockValidator) validateProofOfStake(block *Block, previousBlock *Block) error {
	// Proof of Stake validation - placeholder implementation
	return bv.validateProofOfWork(block, previousBlock)
}

func (bv *BlockValidator) validatePBFT(block *Block, previousBlock *Block) error {
	// PBFT validation - placeholder implementation
	return bv.validateProofOfWork(block, previousBlock)
}

// ContractExecutor implementation
func (ce *ContractExecutor) executeSolidity(contract *SmartContract, transaction *Transaction) ([]byte, error) {
	// Solidity contract execution - placeholder implementation
	return []byte("execution_result"), nil
}

func (ce *ContractExecutor) executeVyper(contract *SmartContract, transaction *Transaction) ([]byte, error) {
	// Vyper contract execution - placeholder implementation
	return []byte("execution_result"), nil
}

func (ce *ContractExecutor) executeRust(contract *SmartContract, transaction *Transaction) ([]byte, error) {
	// Rust contract execution - placeholder implementation
	return []byte("execution_result"), nil
}

// GetStats returns blockchain engine statistics
func (bc *BlockchainEngine) GetStats() map[string]interface{} {
	bc.mutex.RLock()
	defer bc.mutex.RUnlock()

	stats := map[string]interface{}{
		"chains":      len(bc.chains),
		"contracts":   len(bc.contracts),
		"transactions": len(bc.transactions),
		"config":      bc.config,
	}

	// Calculate blockchain statistics
	totalChains := len(bc.chains)
	totalContracts := len(bc.contracts)
	totalTransactions := len(bc.transactions)
	totalBlocks := 0
	pendingTransactions := 0
	confirmedTransactions := 0

	for _, blockchain := range bc.chains {
		totalBlocks += len(blockchain.Blocks)
	}

	for _, transaction := range bc.transactions {
		switch transaction.Status {
		case "pending":
			pendingTransactions++
		case "confirmed":
			confirmedTransactions++
		}
	}

	stats["total_chains"] = totalChains
	stats["total_contracts"] = totalContracts
	stats["total_transactions"] = totalTransactions
	stats["total_blocks"] = totalBlocks
	stats["pending_transactions"] = pendingTransactions
	stats["confirmed_transactions"] = confirmedTransactions

	if totalTransactions > 0 {
		stats["confirmation_rate"] = float64(confirmedTransactions) / float64(totalTransactions)
	}

	return stats
} 