package main

import (
	"context"
	"fmt"
	"sync"
	"time"
)

// AuthorizationManager provides comprehensive authorization capabilities
type AuthorizationManager struct {
	roles       map[string]*Role
	policies    map[string]*Policy
	permissions map[string]*Permission
	config      AuthzConfig
	enforcer    *PolicyEnforcer
	auditor     *AuthorizationAuditor
	mutex       sync.RWMutex
}

// Role represents a role
type Role struct {
	ID          string            `json:"id"`
	Name        string            `json:"name"`
	Description string            `json:"description"`
	Permissions []string          `json:"permissions"`
	Users       []string          `json:"users"`
	Groups      []string          `json:"groups"`
	CreatedAt   time.Time         `json:"created_at"`
	UpdatedAt   time.Time         `json:"updated_at"`
	Metadata    map[string]string `json:"metadata"`
}

// Policy represents an authorization policy
type Policy struct {
	ID          string            `json:"id"`
	Name        string            `json:"name"`
	Description string            `json:"description"`
	Type        string            `json:"type"` // allow, deny, conditional
	Resource    string            `json:"resource"`
	Action      string            `json:"action"`
	Roles       []string          `json:"roles"`
	Users       []string          `json:"users"`
	Groups      []string          `json:"groups"`
	Conditions  []*Condition      `json:"conditions"`
	Priority    int               `json:"priority"`
	Enabled     bool              `json:"enabled"`
	CreatedAt   time.Time         `json:"created_at"`
	UpdatedAt   time.Time         `json:"updated_at"`
	Metadata    map[string]string `json:"metadata"`
}

// Permission represents a permission
type Permission struct {
	ID          string            `json:"id"`
	Name        string            `json:"name"`
	Description string            `json:"description"`
	Resource    string            `json:"resource"`
	Action      string            `json:"action"`
	CreatedAt   time.Time         `json:"created_at"`
	UpdatedAt   time.Time         `json:"updated_at"`
	Metadata    map[string]string `json:"metadata"`
}

// Condition represents a policy condition
type Condition struct {
	Field    string      `json:"field"`
	Operator string      `json:"operator"` // eq, ne, gt, lt, gte, lte, in, not_in, contains
	Value    interface{} `json:"value"`
}

// AuthzConfig represents authorization configuration
type AuthzConfig struct {
	DefaultPolicy     string        `json:"default_policy"` // allow, deny
	EnableAudit       bool          `json:"enable_audit"`
	EnableCache       bool          `json:"enable_cache"`
	CacheTTL          time.Duration `json:"cache_ttl"`
	EnableHierarchy   bool          `json:"enable_hierarchy"`
	EnableInheritance bool          `json:"enable_inheritance"`
	MaxPolicyDepth    int           `json:"max_policy_depth"`
}

// PolicyEnforcer enforces authorization policies
type PolicyEnforcer struct {
	authzManager *AuthorizationManager
	cache        map[string]*AuthzResult
	config       EnforcerConfig
	mutex        sync.RWMutex
}

// EnforcerConfig represents enforcer configuration
type EnforcerConfig struct {
	EnableCache       bool          `json:"enable_cache"`
	CacheTTL          time.Duration `json:"cache_ttl"`
	EnableOptimization bool         `json:"enable_optimization"`
	MaxCacheSize      int           `json:"max_cache_size"`
}

// AuthorizationAuditor audits authorization decisions
type AuthorizationAuditor struct {
	authzManager *AuthorizationManager
	events       []*AuthzEvent
	config       AuditorConfig
	mutex        sync.RWMutex
}

// AuditorConfig represents auditor configuration
type AuditorConfig struct {
	EnableLogging     bool          `json:"enable_logging"`
	MaxEvents         int           `json:"max_events"`
	RetentionPeriod   time.Duration `json:"retention_period"`
	EnableCompression bool          `json:"enable_compression"`
}

// AuthzResult represents authorization result
type AuthzResult struct {
	Allowed   bool              `json:"allowed"`
	Reason    string            `json:"reason"`
	Policy    *Policy           `json:"policy"`
	Timestamp time.Time         `json:"timestamp"`
	Metadata  map[string]string `json:"metadata"`
}

// AuthzEvent represents an authorization event
type AuthzEvent struct {
	ID          string            `json:"id"`
	UserID      string            `json:"user_id"`
	Resource    string            `json:"resource"`
	Action      string            `json:"action"`
	Result      *AuthzResult      `json:"result"`
	Timestamp   time.Time         `json:"timestamp"`
	IPAddress   string            `json:"ip_address"`
	UserAgent   string            `json:"user_agent"`
	Metadata    map[string]string `json:"metadata"`
}

// AuthorizationRequest represents an authorization request
type AuthorizationRequest struct {
	UserID    string            `json:"user_id"`
	Resource  string            `json:"resource"`
	Action    string            `json:"action"`
	Context   map[string]string `json:"context"`
	Metadata  map[string]string `json:"metadata"`
}

// AuthorizationManager creates a new authorization manager
func NewAuthorizationManager(config AuthzConfig) *AuthorizationManager {
	am := &AuthorizationManager{
		roles:       make(map[string]*Role),
		policies:    make(map[string]*Policy),
		permissions: make(map[string]*Permission),
		config:      config,
		enforcer: &PolicyEnforcer{
			cache: make(map[string]*AuthzResult),
			config: EnforcerConfig{
				EnableCache:       config.EnableCache,
				CacheTTL:          config.CacheTTL,
				EnableOptimization: true,
				MaxCacheSize:      1000,
			},
		},
		auditor: &AuthorizationAuditor{
			events: make([]*AuthzEvent, 0),
			config: AuditorConfig{
				EnableLogging:   config.EnableAudit,
				MaxEvents:       10000,
				RetentionPeriod: 30 * 24 * time.Hour, // 30 days
			},
		},
	}

	am.enforcer.authzManager = am
	am.auditor.authzManager = am

	// Initialize default roles and permissions
	am.initializeDefaults()

	// Start cleanup if enabled
	if config.EnableCache {
		go am.startCacheCleanup()
	}

	return am
}

// initializeDefaults initializes default roles and permissions
func (am *AuthorizationManager) initializeDefaults() {
	// Create default permissions
	defaultPermissions := []*Permission{
		{ID: "read", Name: "Read", Description: "Read access", Resource: "*", Action: "read"},
		{ID: "write", Name: "Write", Description: "Write access", Resource: "*", Action: "write"},
		{ID: "delete", Name: "Delete", Description: "Delete access", Resource: "*", Action: "delete"},
		{ID: "admin", Name: "Admin", Description: "Administrative access", Resource: "*", Action: "*"},
	}

	for _, perm := range defaultPermissions {
		perm.CreatedAt = time.Now()
		perm.UpdatedAt = time.Now()
		perm.Metadata = make(map[string]string)
		am.permissions[perm.ID] = perm
	}

	// Create default roles
	defaultRoles := []*Role{
		{
			ID:          "admin",
			Name:        "Administrator",
			Description: "Full system access",
			Permissions: []string{"admin"},
			Users:       []string{},
			Groups:      []string{},
		},
		{
			ID:          "user",
			Name:        "User",
			Description: "Standard user access",
			Permissions: []string{"read", "write"},
			Users:       []string{},
			Groups:      []string{},
		},
		{
			ID:          "guest",
			Name:        "Guest",
			Description: "Read-only access",
			Permissions: []string{"read"},
			Users:       []string{},
			Groups:      []string{},
		},
	}

	for _, role := range defaultRoles {
		role.CreatedAt = time.Now()
		role.UpdatedAt = time.Now()
		role.Metadata = make(map[string]string)
		am.roles[role.ID] = role
	}

	// Create default policies
	defaultPolicies := []*Policy{
		{
			ID:          "admin_all",
			Name:        "Admin All Access",
			Description: "Administrators have full access",
			Type:        "allow",
			Resource:    "*",
			Action:      "*",
			Roles:       []string{"admin"},
			Priority:    100,
			Enabled:     true,
		},
		{
			ID:          "user_limited",
			Name:        "User Limited Access",
			Description: "Users have limited access",
			Type:        "allow",
			Resource:    "user.*",
			Action:      "read,write",
			Roles:       []string{"user"},
			Priority:    50,
			Enabled:     true,
		},
		{
			ID:          "guest_readonly",
			Name:        "Guest Read Only",
			Description: "Guests have read-only access",
			Type:        "allow",
			Resource:    "public.*",
			Action:      "read",
			Roles:       []string{"guest"},
			Priority:    25,
			Enabled:     true,
		},
	}

	for _, policy := range defaultPolicies {
		policy.CreatedAt = time.Now()
		policy.UpdatedAt = time.Now()
		policy.Metadata = make(map[string]string)
		am.policies[policy.ID] = policy
	}
}

// Authorize authorizes a request
func (am *AuthorizationManager) Authorize(request *AuthorizationRequest) (*AuthzResult, error) {
	// Check cache first
	if am.config.EnableCache {
		cacheKey := am.generateCacheKey(request)
		if cached := am.enforcer.getCachedResult(cacheKey); cached != nil {
			return cached, nil
		}
	}

	// Get user roles
	userRoles, err := am.getUserRoles(request.UserID)
	if err != nil {
		return nil, err
	}

	// Evaluate policies
	result := am.enforcer.evaluatePolicies(request, userRoles)

	// Cache result if enabled
	if am.config.EnableCache {
		cacheKey := am.generateCacheKey(request)
		am.enforcer.cacheResult(cacheKey, result)
	}

	// Log audit event if enabled
	if am.config.EnableAudit {
		am.auditor.logEvent(request, result)
	}

	return result, nil
}

// CreateRole creates a new role
func (am *AuthorizationManager) CreateRole(role *Role) error {
	am.mutex.Lock()
	defer am.mutex.Unlock()

	if _, exists := am.roles[role.ID]; exists {
		return fmt.Errorf("role %s already exists", role.ID)
	}

	role.CreatedAt = time.Now()
	role.UpdatedAt = time.Now()
	if role.Metadata == nil {
		role.Metadata = make(map[string]string)
	}

	am.roles[role.ID] = role
	return nil
}

// UpdateRole updates a role
func (am *AuthorizationManager) UpdateRole(role *Role) error {
	am.mutex.Lock()
	defer am.mutex.Unlock()

	if _, exists := am.roles[role.ID]; !exists {
		return fmt.Errorf("role %s not found", role.ID)
	}

	role.UpdatedAt = time.Now()
	am.roles[role.ID] = role
	return nil
}

// DeleteRole deletes a role
func (am *AuthorizationManager) DeleteRole(roleID string) error {
	am.mutex.Lock()
	defer am.mutex.Unlock()

	if _, exists := am.roles[roleID]; !exists {
		return fmt.Errorf("role %s not found", roleID)
	}

	delete(am.roles, roleID)
	return nil
}

// GetRole returns a role by ID
func (am *AuthorizationManager) GetRole(roleID string) (*Role, error) {
	am.mutex.RLock()
	defer am.mutex.RUnlock()

	role, exists := am.roles[roleID]
	if !exists {
		return nil, fmt.Errorf("role %s not found", roleID)
	}

	return role, nil
}

// ListRoles lists all roles
func (am *AuthorizationManager) ListRoles() []*Role {
	am.mutex.RLock()
	defer am.mutex.RUnlock()

	roles := make([]*Role, 0, len(am.roles))
	for _, role := range am.roles {
		roles = append(roles, role)
	}

	return roles
}

// CreatePolicy creates a new policy
func (am *AuthorizationManager) CreatePolicy(policy *Policy) error {
	am.mutex.Lock()
	defer am.mutex.Unlock()

	if _, exists := am.policies[policy.ID]; exists {
		return fmt.Errorf("policy %s already exists", policy.ID)
	}

	policy.CreatedAt = time.Now()
	policy.UpdatedAt = time.Now()
	if policy.Metadata == nil {
		policy.Metadata = make(map[string]string)
	}

	am.policies[policy.ID] = policy
	return nil
}

// UpdatePolicy updates a policy
func (am *AuthorizationManager) UpdatePolicy(policy *Policy) error {
	am.mutex.Lock()
	defer am.mutex.Unlock()

	if _, exists := am.policies[policy.ID]; !exists {
		return fmt.Errorf("policy %s not found", policy.ID)
	}

	policy.UpdatedAt = time.Now()
	am.policies[policy.ID] = policy
	return nil
}

// DeletePolicy deletes a policy
func (am *AuthorizationManager) DeletePolicy(policyID string) error {
	am.mutex.Lock()
	defer am.mutex.Unlock()

	if _, exists := am.policies[policyID]; !exists {
		return fmt.Errorf("policy %s not found", policyID)
	}

	delete(am.policies, policyID)
	return nil
}

// GetPolicy returns a policy by ID
func (am *AuthorizationManager) GetPolicy(policyID string) (*Policy, error) {
	am.mutex.RLock()
	defer am.mutex.RUnlock()

	policy, exists := am.policies[policyID]
	if !exists {
		return nil, fmt.Errorf("policy %s not found", policyID)
	}

	return policy, nil
}

// ListPolicies lists all policies
func (am *AuthorizationManager) ListPolicies() []*Policy {
	am.mutex.RLock()
	defer am.mutex.RUnlock()

	policies := make([]*Policy, 0, len(am.policies))
	for _, policy := range am.policies {
		policies = append(policies, policy)
	}

	return policies
}

// AssignRole assigns a role to a user
func (am *AuthorizationManager) AssignRole(userID, roleID string) error {
	am.mutex.Lock()
	defer am.mutex.Unlock()

	role, exists := am.roles[roleID]
	if !exists {
		return fmt.Errorf("role %s not found", roleID)
	}

	// Check if user already has role
	for _, user := range role.Users {
		if user == userID {
			return fmt.Errorf("user %s already has role %s", userID, roleID)
		}
	}

	role.Users = append(role.Users, userID)
	role.UpdatedAt = time.Now()

	return nil
}

// RemoveRole removes a role from a user
func (am *AuthorizationManager) RemoveRole(userID, roleID string) error {
	am.mutex.Lock()
	defer am.mutex.Unlock()

	role, exists := am.roles[roleID]
	if !exists {
		return fmt.Errorf("role %s not found", roleID)
	}

	// Remove user from role
	for i, user := range role.Users {
		if user == userID {
			role.Users = append(role.Users[:i], role.Users[i+1:]...)
			role.UpdatedAt = time.Now()
			return nil
		}
	}

	return fmt.Errorf("user %s does not have role %s", userID, roleID)
}

// getUserRoles gets roles for a user
func (am *AuthorizationManager) getUserRoles(userID string) ([]string, error) {
	am.mutex.RLock()
	defer am.mutex.RUnlock()

	var userRoles []string
	for _, role := range am.roles {
		for _, user := range role.Users {
			if user == userID {
				userRoles = append(userRoles, role.ID)
				break
			}
		}
	}

	return userRoles, nil
}

// generateCacheKey generates a cache key for a request
func (am *AuthorizationManager) generateCacheKey(request *AuthorizationRequest) string {
	return fmt.Sprintf("%s:%s:%s", request.UserID, request.Resource, request.Action)
}

// startCacheCleanup starts cache cleanup
func (am *AuthorizationManager) startCacheCleanup() {
	ticker := time.NewTicker(am.config.CacheTTL)
	defer ticker.Stop()

	for {
		select {
		case <-ticker.C:
			am.enforcer.cleanupCache()
		}
	}
}

// GetStats returns authorization manager statistics
func (am *AuthorizationManager) GetStats() map[string]interface{} {
	am.mutex.RLock()
	defer am.mutex.RUnlock()

	stats := map[string]interface{}{
		"roles":    len(am.roles),
		"policies": len(am.policies),
		"config":   am.config,
	}

	// Calculate cache statistics
	if am.config.EnableCache {
		stats["cache_size"] = len(am.enforcer.cache)
		stats["cache_hit_rate"] = am.enforcer.getCacheHitRate()
	}

	// Calculate audit statistics
	if am.config.EnableAudit {
		stats["audit_events"] = len(am.auditor.events)
	}

	return stats
}

// PolicyEnforcer implementation
func (pe *PolicyEnforcer) evaluatePolicies(request *AuthorizationRequest, userRoles []string) *AuthzResult {
	pe.authzManager.mutex.RLock()
	defer pe.authzManager.mutex.RUnlock()

	// Get applicable policies
	var applicablePolicies []*Policy
	for _, policy := range pe.authzManager.policies {
		if !policy.Enabled {
			continue
		}

		// Check if policy applies to user roles
		if pe.policyAppliesToRoles(policy, userRoles) {
			applicablePolicies = append(applicablePolicies, policy)
		}
	}

	// Sort policies by priority (highest first)
	pe.sortPoliciesByPriority(applicablePolicies)

	// Evaluate policies
	for _, policy := range applicablePolicies {
		if pe.policyMatches(policy, request) {
			// Check conditions
			if pe.evaluateConditions(policy.Conditions, request) {
				return &AuthzResult{
					Allowed:   policy.Type == "allow",
					Reason:    fmt.Sprintf("Policy %s", policy.ID),
					Policy:    policy,
					Timestamp: time.Now(),
					Metadata:  make(map[string]string),
				}
			}
		}
	}

	// Default policy
	return &AuthzResult{
		Allowed:   pe.authzManager.config.DefaultPolicy == "allow",
		Reason:    "Default policy",
		Policy:    nil,
		Timestamp: time.Now(),
		Metadata:  make(map[string]string),
	}
}

// policyAppliesToRoles checks if policy applies to user roles
func (pe *PolicyEnforcer) policyAppliesToRoles(policy *Policy, userRoles []string) bool {
	for _, policyRole := range policy.Roles {
		for _, userRole := range userRoles {
			if policyRole == userRole {
				return true
			}
		}
	}
	return false
}

// policyMatches checks if policy matches request
func (pe *PolicyEnforcer) policyMatches(policy *Policy, request *AuthorizationRequest) bool {
	// Check resource pattern
	if !pe.matchesPattern(request.Resource, policy.Resource) {
		return false
	}

	// Check action pattern
	if !pe.matchesPattern(request.Action, policy.Action) {
		return false
	}

	return true
}

// matchesPattern checks if value matches pattern
func (pe *PolicyEnforcer) matchesPattern(value, pattern string) bool {
	if pattern == "*" {
		return true
	}

	// Simple pattern matching
	// In practice, this would use regex or more sophisticated matching
	return value == pattern
}

// evaluateConditions evaluates policy conditions
func (pe *PolicyEnforcer) evaluateConditions(conditions []*Condition, request *AuthorizationRequest) bool {
	if len(conditions) == 0 {
		return true
	}

	for _, condition := range conditions {
		if !pe.evaluateCondition(condition, request) {
			return false
		}
	}

	return true
}

// evaluateCondition evaluates a single condition
func (pe *PolicyEnforcer) evaluateCondition(condition *Condition, request *AuthorizationRequest) bool {
	// Get field value from context
	fieldValue, exists := request.Context[condition.Field]
	if !exists {
		return false
	}

	// Evaluate based on operator
	switch condition.Operator {
	case "eq":
		return fieldValue == condition.Value
	case "ne":
		return fieldValue != condition.Value
	case "contains":
		return pe.contains(fieldValue, condition.Value)
	default:
		return false
	}
}

// contains checks if value contains substring
func (pe *PolicyEnforcer) contains(value, substring interface{}) bool {
	// Simple string contains check
	// In practice, this would handle different types
	return fmt.Sprintf("%v", value) == fmt.Sprintf("%v", substring)
}

// sortPoliciesByPriority sorts policies by priority
func (pe *PolicyEnforcer) sortPoliciesByPriority(policies []*Policy) {
	// Sort in descending order (highest priority first)
	for i := 0; i < len(policies)-1; i++ {
		for j := i + 1; j < len(policies); j++ {
			if policies[i].Priority < policies[j].Priority {
				policies[i], policies[j] = policies[j], policies[i]
			}
		}
	}
}

// getCachedResult gets cached result
func (pe *PolicyEnforcer) getCachedResult(key string) *AuthzResult {
	pe.mutex.RLock()
	defer pe.mutex.RUnlock()

	result, exists := pe.cache[key]
	if !exists {
		return nil
	}

	// Check if result is expired
	if time.Since(result.Timestamp) > pe.config.CacheTTL {
		delete(pe.cache, key)
		return nil
	}

	return result
}

// cacheResult caches result
func (pe *PolicyEnforcer) cacheResult(key string, result *AuthzResult) {
	pe.mutex.Lock()
	defer pe.mutex.Unlock()

	// Check cache size limit
	if len(pe.cache) >= pe.config.MaxCacheSize {
		// Remove oldest entry
		var oldestKey string
		var oldestTime time.Time
		for k, v := range pe.cache {
			if oldestKey == "" || v.Timestamp.Before(oldestTime) {
				oldestKey = k
				oldestTime = v.Timestamp
			}
		}
		if oldestKey != "" {
			delete(pe.cache, oldestKey)
		}
	}

	pe.cache[key] = result
}

// cleanupCache cleans up expired cache entries
func (pe *PolicyEnforcer) cleanupCache() {
	pe.mutex.Lock()
	defer pe.mutex.Unlock()

	now := time.Now()
	for key, result := range pe.cache {
		if now.Sub(result.Timestamp) > pe.config.CacheTTL {
			delete(pe.cache, key)
		}
	}
}

// getCacheHitRate gets cache hit rate
func (pe *PolicyEnforcer) getCacheHitRate() float64 {
	// This would calculate actual hit rate
	// For now, just return a placeholder
	return 0.85
}

// AuthorizationAuditor implementation
func (aa *AuthorizationAuditor) logEvent(request *AuthorizationRequest, result *AuthzResult) {
	aa.mutex.Lock()
	defer aa.mutex.Unlock()

	event := &AuthzEvent{
		ID:        generateEventID(),
		UserID:    request.UserID,
		Resource:  request.Resource,
		Action:    request.Action,
		Result:    result,
		Timestamp: time.Now(),
		Metadata:  request.Metadata,
	}

	aa.events = append(aa.events, event)

	// Limit events if configured
	if len(aa.events) > aa.config.MaxEvents {
		aa.events = aa.events[1:]
	}
}

// GetEvents returns audit events
func (aa *AuthorizationAuditor) GetEvents() []*AuthzEvent {
	aa.mutex.RLock()
	defer aa.mutex.RUnlock()

	events := make([]*AuthzEvent, len(aa.events))
	copy(events, aa.events)
	return events
}

// generateEventID generates a unique event ID
func generateEventID() string {
	return fmt.Sprintf("evt_%d", time.Now().UnixNano())
} 