package operators

import (
	"context"
	"crypto/rand"
	"encoding/hex"
	"fmt"
	"math"
	"strconv"
	"strings"
	"time"
)

// UtilityOperator handles @utility operations
type UtilityOperator struct {
	*BaseOperator
}

// NewUtilityOperator creates a new utility operator
func NewUtilityOperator() *UtilityOperator {
	return &UtilityOperator{
		BaseOperator: NewBaseOperator(),
	}
}

// Execute handles @utility operations
func (u *UtilityOperator) Execute(ctx context.Context, params map[string]interface{}) OperatorResult {
	u.Log("Executing @utility operator with params: %v", params)
	
	operation := u.GetStringParam(params, "operation", "generate_id")
	
	switch operation {
	case "generate_id":
		return u.generateId()
	case "validate_email":
		email := u.GetStringParam(params, "email", "")
		return u.validateEmail(email)
	case "format_number":
		number := u.GetFloatParam(params, "number", 0)
		decimals := u.GetIntParam(params, "decimals", 2)
		return u.formatNumber(number, decimals)
	case "calculate_percentage":
		value := u.GetFloatParam(params, "value", 0)
		total := u.GetFloatParam(params, "total", 1)
		return u.calculatePercentage(value, total)
	case "generate_password":
		length := u.GetIntParam(params, "length", 12)
		return u.generatePassword(length)
	default:
		return u.CreateErrorResult(fmt.Sprintf("unknown utility operation: %s", operation))
	}
}

// generateId generates a unique identifier
func (u *UtilityOperator) generateId() OperatorResult {
	bytes := make([]byte, 16)
	rand.Read(bytes)
	id := hex.EncodeToString(bytes)
	
	result := map[string]interface{}{
		"operation": "generate_id",
		"id":        id,
		"response":  fmt.Sprintf("[Generated unique ID: %s]", id),
	}
	
	return u.CreateSuccessResult(result)
}

// validateEmail validates email format
func (u *UtilityOperator) validateEmail(email string) OperatorResult {
	if email == "" {
		return u.CreateErrorResult("email address is required")
	}
	
	// Simple email validation
	valid := strings.Contains(email, "@") && strings.Contains(email, ".")
	
	result := map[string]interface{}{
		"operation": "validate_email",
		"email":     email,
		"valid":     valid,
		"response":  fmt.Sprintf("[Email validation: %s is %s]", email, map[bool]string{true: "valid", false: "invalid"}[valid]),
	}
	
	return u.CreateSuccessResult(result)
}

// formatNumber formats a number with specified decimal places
func (u *UtilityOperator) formatNumber(number float64, decimals int) OperatorResult {
	formatted := fmt.Sprintf("%.*f", decimals, number)
	
	result := map[string]interface{}{
		"operation": "format_number",
		"number":    number,
		"decimals":  decimals,
		"formatted": formatted,
		"response":  fmt.Sprintf("[Number formatted: %s]", formatted),
	}
	
	return u.CreateSuccessResult(result)
}

// calculatePercentage calculates percentage of a value relative to total
func (u *UtilityOperator) calculatePercentage(value, total float64) OperatorResult {
	if total == 0 {
		return u.CreateErrorResult("total cannot be zero")
	}
	
	percentage := (value / total) * 100
	
	result := map[string]interface{}{
		"operation":  "calculate_percentage",
		"value":      value,
		"total":      total,
		"percentage": percentage,
		"response":   fmt.Sprintf("[Percentage calculated: %.2f%%]", percentage),
	}
	
	return u.CreateSuccessResult(result)
}

// generatePassword generates a secure password
func (u *UtilityOperator) generatePassword(length int) OperatorResult {
	if length < 8 {
		length = 8
	}
	
	const charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*"
	password := make([]byte, length)
	
	for i := range password {
		password[i] = charset[rand.Intn(len(charset))]
	}
	
	result := map[string]interface{}{
		"operation": "generate_password",
		"length":    length,
		"password":  string(password),
		"response":  fmt.Sprintf("[Generated secure password: %s]", string(password)),
	}
	
	return u.CreateSuccessResult(result)
}

// MathOperator handles @math operations
type MathOperator struct {
	*BaseOperator
}

// NewMathOperator creates a new math operator
func NewMathOperator() *MathOperator {
	return &MathOperator{
		BaseOperator: NewBaseOperator(),
	}
}

// Execute handles @math operations
func (m *MathOperator) Execute(ctx context.Context, params map[string]interface{}) OperatorResult {
	m.Log("Executing @math operator with params: %v", params)
	
	operation := m.GetStringParam(params, "operation", "add")
	
	switch operation {
	case "add":
		a := m.GetFloatParam(params, "a", 0)
		b := m.GetFloatParam(params, "b", 0)
		return m.add(a, b)
	case "subtract":
		a := m.GetFloatParam(params, "a", 0)
		b := m.GetFloatParam(params, "b", 0)
		return m.subtract(a, b)
	case "multiply":
		a := m.GetFloatParam(params, "a", 0)
		b := m.GetFloatParam(params, "b", 0)
		return m.multiply(a, b)
	case "divide":
		a := m.GetFloatParam(params, "a", 0)
		b := m.GetFloatParam(params, "b", 1)
		return m.divide(a, b)
	case "power":
		base := m.GetFloatParam(params, "base", 0)
		exponent := m.GetFloatParam(params, "exponent", 1)
		return m.power(base, exponent)
	default:
		return m.CreateErrorResult(fmt.Sprintf("unknown math operation: %s", operation))
	}
}

func (m *MathOperator) add(a, b float64) OperatorResult {
	result := a + b
	return m.CreateSuccessResult(map[string]interface{}{
		"operation": "add",
		"a":         a,
		"b":         b,
		"result":    result,
		"response":  fmt.Sprintf("[Math operation: %f + %f = %f]", a, b, result),
	})
}

func (m *MathOperator) subtract(a, b float64) OperatorResult {
	result := a - b
	return m.CreateSuccessResult(map[string]interface{}{
		"operation": "subtract",
		"a":         a,
		"b":         b,
		"result":    result,
		"response":  fmt.Sprintf("[Math operation: %f - %f = %f]", a, b, result),
	})
}

func (m *MathOperator) multiply(a, b float64) OperatorResult {
	result := a * b
	return m.CreateSuccessResult(map[string]interface{}{
		"operation": "multiply",
		"a":         a,
		"b":         b,
		"result":    result,
		"response":  fmt.Sprintf("[Math operation: %f * %f = %f]", a, b, result),
	})
}

func (m *MathOperator) divide(a, b float64) OperatorResult {
	if b == 0 {
		return m.CreateErrorResult("division by zero is not allowed")
	}
	
	result := a / b
	return m.CreateSuccessResult(map[string]interface{}{
		"operation": "divide",
		"a":         a,
		"b":         b,
		"result":    result,
		"response":  fmt.Sprintf("[Math operation: %f / %f = %f]", a, b, result),
	})
}

func (m *MathOperator) power(base, exponent float64) OperatorResult {
	result := math.Pow(base, exponent)
	return m.CreateSuccessResult(map[string]interface{}{
		"operation": "power",
		"base":      base,
		"exponent":  exponent,
		"result":    result,
		"response":  fmt.Sprintf("[Math operation: %f ^ %f = %f]", base, exponent, result),
	})
} 