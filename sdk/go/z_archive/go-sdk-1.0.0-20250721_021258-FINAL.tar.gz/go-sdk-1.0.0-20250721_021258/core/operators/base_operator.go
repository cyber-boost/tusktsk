package operators

import (
	"context"
	"fmt"
	"log"
	"time"
)

// OperatorConfig represents the configuration for any operator
type OperatorConfig struct {
	Timeout time.Duration `json:"timeout"`
	Retry   int           `json:"retry"`
	Logging bool          `json:"logging"`
}

// OperatorResult represents the result of an operator execution
type OperatorResult struct {
	Success bool        `json:"success"`
	Data    interface{} `json:"data"`
	Error   string      `json:"error,omitempty"`
	Metrics map[string]interface{} `json:"metrics,omitempty"`
}

// BaseOperator provides common functionality for all operators
type BaseOperator struct {
	config OperatorConfig
	logger *log.Logger
}

// NewBaseOperator creates a new base operator with default configuration
func NewBaseOperator() *BaseOperator {
	return &BaseOperator{
		config: OperatorConfig{
			Timeout: 30 * time.Second,
			Retry:   3,
			Logging: true,
		},
		logger: log.New(log.Writer(), "[OPERATOR] ", log.LstdFlags),
	}
}

// SetConfig updates the operator configuration
func (b *BaseOperator) SetConfig(config OperatorConfig) {
	b.config = config
}

// GetConfig returns the current configuration
func (b *BaseOperator) GetConfig() OperatorConfig {
	return b.config
}

// Log logs a message if logging is enabled
func (b *BaseOperator) Log(format string, args ...interface{}) {
	if b.config.Logging {
		b.logger.Printf(format, args...)
	}
}

// ExecuteWithRetry executes an operation with retry logic
func (b *BaseOperator) ExecuteWithRetry(ctx context.Context, operation func() (interface{}, error)) (interface{}, error) {
	var lastErr error
	
	for attempt := 0; attempt <= b.config.Retry; attempt++ {
		if attempt > 0 {
			b.Log("Retry attempt %d/%d", attempt, b.config.Retry)
			time.Sleep(time.Duration(attempt) * time.Second) // Exponential backoff
		}
		
		// Create timeout context
		timeoutCtx, cancel := context.WithTimeout(ctx, b.config.Timeout)
		defer cancel()
		
		// Execute operation
		result, err := operation()
		if err == nil {
			return result, nil
		}
		
		lastErr = err
		b.Log("Operation failed (attempt %d): %v", attempt+1, err)
		
		// Check if context was cancelled
		select {
		case <-timeoutCtx.Done():
			return nil, fmt.Errorf("operation timed out after %v", b.config.Timeout)
		default:
			continue
		}
	}
	
	return nil, fmt.Errorf("operation failed after %d attempts: %v", b.config.Retry+1, lastErr)
}

// CreateSuccessResult creates a successful operator result
func (b *BaseOperator) CreateSuccessResult(data interface{}) OperatorResult {
	return OperatorResult{
		Success: true,
		Data:    data,
		Metrics: make(map[string]interface{}),
	}
}

// CreateErrorResult creates an error operator result
func (b *BaseOperator) CreateErrorResult(err string) OperatorResult {
	return OperatorResult{
		Success: false,
		Error:   err,
		Metrics: make(map[string]interface{}),
	}
}

// ValidateRequiredParams validates that required parameters are present
func (b *BaseOperator) ValidateRequiredParams(params map[string]interface{}, required []string) error {
	for _, param := range required {
		if _, exists := params[param]; !exists {
			return fmt.Errorf("required parameter '%s' is missing", param)
		}
	}
	return nil
}

// GetStringParam safely extracts a string parameter
func (b *BaseOperator) GetStringParam(params map[string]interface{}, key string, defaultValue string) string {
	if val, exists := params[key]; exists {
		if str, ok := val.(string); ok {
			return str
		}
	}
	return defaultValue
}

// GetIntParam safely extracts an integer parameter
func (b *BaseOperator) GetIntParam(params map[string]interface{}, key string, defaultValue int) int {
	if val, exists := params[key]; exists {
		switch v := val.(type) {
		case int:
			return v
		case float64:
			return int(v)
		case string:
			if i, err := fmt.Sscanf(v, "%d", &defaultValue); err == nil && i == 1 {
				return defaultValue
			}
		}
	}
	return defaultValue
}

// GetBoolParam safely extracts a boolean parameter
func (b *BaseOperator) GetBoolParam(params map[string]interface{}, key string, defaultValue bool) bool {
	if val, exists := params[key]; exists {
		if b, ok := val.(bool); ok {
			return b
		}
		if str, ok := val.(string); ok {
			return str == "true" || str == "1" || str == "yes"
		}
	}
	return defaultValue
} 