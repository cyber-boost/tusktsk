package monitoring

import (
	"fmt"

	"github.com/prometheus/client_golang/prometheus"
	"github.com/prometheus/client_golang/prometheus/push"
)

// PrometheusOperator handles @prometheus operations
type PrometheusOperator struct {
	registry    *prometheus.Registry
	counters    map[string]*prometheus.CounterVec
	gauges      map[string]*prometheus.GaugeVec
	histograms  map[string]*prometheus.HistogramVec
	summaries   map[string]*prometheus.SummaryVec
	pushGateway string
}

// PrometheusMetric represents a Prometheus metric
type PrometheusMetric struct {
	Name   string            `json:"name"`
	Type   string            `json:"type"`
	Value  float64           `json:"value"`
	Labels map[string]string `json:"labels"`
	Help   string            `json:"help"`
}

// NewPrometheusOperator creates a new Prometheus operator
func NewPrometheusOperator(pushGateway string) *PrometheusOperator {
	return &PrometheusOperator{
		registry:    prometheus.NewRegistry(),
		counters:    make(map[string]*prometheus.CounterVec),
		gauges:      make(map[string]*prometheus.GaugeVec),
		histograms:  make(map[string]*prometheus.HistogramVec),
		summaries:   make(map[string]*prometheus.SummaryVec),
		pushGateway: pushGateway,
	}
}

// Execute handles @prometheus operations
func (p *PrometheusOperator) Execute(params string) interface{} {
	// Parse parameters (format: "action", "metric_name", "value", "labels")
	// Example: @prometheus("counter", "http_requests_total", "1", '{"method": "GET"}')
	
	return fmt.Sprintf("@prometheus(%s)", params)
}

// CreateCounter creates a new Prometheus counter
func (p *PrometheusOperator) CreateCounter(name, help string, labels []string) error {
	if _, exists := p.counters[name]; exists {
		return fmt.Errorf("counter %s already exists", name)
	}

	counter := prometheus.NewCounterVec(
		prometheus.CounterOpts{
			Name: name,
			Help: help,
		},
		labels,
	)

	p.counters[name] = counter
	return p.registry.Register(counter)
}

// CreateGauge creates a new Prometheus gauge
func (p *PrometheusOperator) CreateGauge(name, help string, labels []string) error {
	if _, exists := p.gauges[name]; exists {
		return fmt.Errorf("gauge %s already exists", name)
	}

	gauge := prometheus.NewGaugeVec(
		prometheus.GaugeOpts{
			Name: name,
			Help: help,
		},
		labels,
	)

	p.gauges[name] = gauge
	return p.registry.Register(gauge)
}

// CreateHistogram creates a new Prometheus histogram
func (p *PrometheusOperator) CreateHistogram(name, help string, labels []string, buckets []float64) error {
	if _, exists := p.histograms[name]; exists {
		return fmt.Errorf("histogram %s already exists", name)
	}

	if buckets == nil {
		buckets = prometheus.DefBuckets
	}

	histogram := prometheus.NewHistogramVec(
		prometheus.HistogramOpts{
			Name:    name,
			Help:    help,
			Buckets: buckets,
		},
		labels,
	)

	p.histograms[name] = histogram
	return p.registry.Register(histogram)
}

// CreateSummary creates a new Prometheus summary
func (p *PrometheusOperator) CreateSummary(name, help string, labels []string, objectives map[float64]float64) error {
	if _, exists := p.summaries[name]; exists {
		return fmt.Errorf("summary %s already exists", name)
	}

	if objectives == nil {
		objectives = map[float64]float64{0.5: 0.05, 0.9: 0.01, 0.99: 0.001}
	}

	summary := prometheus.NewSummaryVec(
		prometheus.SummaryOpts{
			Name:       name,
			Help:       help,
			Objectives: objectives,
		},
		labels,
	)

	p.summaries[name] = summary
	return p.registry.Register(summary)
}

// IncrementCounter increments a counter by the specified value
func (p *PrometheusOperator) IncrementCounter(name string, value float64, labels map[string]string) error {
	counter, exists := p.counters[name]
	if !exists {
		return fmt.Errorf("counter %s not found", name)
	}

	labelValues := make([]string, 0, len(labels))
	for _, value := range labels {
		labelValues = append(labelValues, value)
	}

	counter.WithLabelValues(labelValues...).Add(value)
	return nil
}

// SetGauge sets a gauge to the specified value
func (p *PrometheusOperator) SetGauge(name string, value float64, labels map[string]string) error {
	gauge, exists := p.gauges[name]
	if !exists {
		return fmt.Errorf("gauge %s not found", name)
	}

	labelValues := make([]string, 0, len(labels))
	for _, value := range labels {
		labelValues = append(labelValues, value)
	}

	gauge.WithLabelValues(labelValues...).Set(value)
	return nil
}

// ObserveHistogram observes a value in a histogram
func (p *PrometheusOperator) ObserveHistogram(name string, value float64, labels map[string]string) error {
	histogram, exists := p.histograms[name]
	if !exists {
		return fmt.Errorf("histogram %s not found", name)
	}

	labelValues := make([]string, 0, len(labels))
	for _, value := range labels {
		labelValues = append(labelValues, value)
	}

	histogram.WithLabelValues(labelValues...).Observe(value)
	return nil
}

// ObserveSummary observes a value in a summary
func (p *PrometheusOperator) ObserveSummary(name string, value float64, labels map[string]string) error {
	summary, exists := p.summaries[name]
	if !exists {
		return fmt.Errorf("summary %s not found", name)
	}

	labelValues := make([]string, 0, len(labels))
	for _, value := range labels {
		labelValues = append(labelValues, value)
	}

	summary.WithLabelValues(labelValues...).Observe(value)
	return nil
}

// PushMetrics pushes metrics to a Prometheus Pushgateway
func (p *PrometheusOperator) PushMetrics(jobName string) error {
	if p.pushGateway == "" {
		return fmt.Errorf("push gateway not configured")
	}

	pusher := push.New(p.pushGateway, jobName).Gatherer(p.registry)
	return pusher.Push()
}

// PushMetricsWithLabels pushes metrics with custom labels
func (p *PrometheusOperator) PushMetricsWithLabels(jobName string, labels map[string]string) error {
	if p.pushGateway == "" {
		return fmt.Errorf("push gateway not configured")
	}

	pusher := push.New(p.pushGateway, jobName).Gatherer(p.registry)
	
	// Add labels
	for key, value := range labels {
		pusher = pusher.Grouping(key, value)
	}

	return pusher.Push()
}

// GetMetricValue gets the current value of a metric
func (p *PrometheusOperator) GetMetricValue(name string, labels map[string]string) (float64, error) {
	// Check counters
	if counter, exists := p.counters[name]; exists {
		labelValues := make([]string, 0, len(labels))
		for _, value := range labels {
			labelValues = append(labelValues, value)
		}
		_ = counter.WithLabelValues(labelValues...)
		// For now, return 0 since we can't easily get the current value
		return 0, nil
	}

	// Check gauges
	if gauge, exists := p.gauges[name]; exists {
		labelValues := make([]string, 0, len(labels))
		for _, value := range labels {
			labelValues = append(labelValues, value)
		}
		_ = gauge.WithLabelValues(labelValues...)
		// For now, return 0 since we can't easily get the current value
		return 0, nil
	}

	return 0, fmt.Errorf("metric %s not found", name)
}

// ResetMetric resets a metric to zero
func (p *PrometheusOperator) ResetMetric(name string) error {
	// Reset counter
	if counter, exists := p.counters[name]; exists {
		counter.Reset()
		return nil
	}

	// Reset gauge
	if gauge, exists := p.gauges[name]; exists {
		gauge.Reset()
		return nil
	}

	// Reset histogram
	if histogram, exists := p.histograms[name]; exists {
		histogram.Reset()
		return nil
	}

	// Reset summary
	if summary, exists := p.summaries[name]; exists {
		summary.Reset()
		return nil
	}

	return fmt.Errorf("metric %s not found", name)
}

// ListMetrics returns a list of all registered metrics
func (p *PrometheusOperator) ListMetrics() []string {
	var metrics []string

	for name := range p.counters {
		metrics = append(metrics, "counter:"+name)
	}

	for name := range p.gauges {
		metrics = append(metrics, "gauge:"+name)
	}

	for name := range p.histograms {
		metrics = append(metrics, "histogram:"+name)
	}

	for name := range p.summaries {
		metrics = append(metrics, "summary:"+name)
	}

	return metrics
}

// GetRegistry returns the Prometheus registry
func (p *PrometheusOperator) GetRegistry() *prometheus.Registry {
	return p.registry
}

// SetPushGateway sets the Pushgateway URL
func (p *PrometheusOperator) SetPushGateway(url string) {
	p.pushGateway = url
}

// Close closes the Prometheus operator
func (p *PrometheusOperator) Close() error {
	// Prometheus registry doesn't need explicit cleanup
	return nil
} 