package infrastructure

import (
	"context"
	"fmt"
	"log"
	"net/http"
	"strings"
	"sync"
	"time"

	"github.com/hashicorp/consul/api"
)

// ConsulOperator handles @consul service discovery and health checking operations
type ConsulOperator struct {
	client      *api.Client
	kv          *api.KV
	agent       *api.Agent
	catalog     *api.Catalog
	health      *api.Health
	session     *api.Session
	config      *ConsulConfig
	mutex       sync.RWMutex
	isConnected bool
	watches     map[string]context.CancelFunc
}

// ConsulConfig holds configuration for Consul connection
type ConsulConfig struct {
	Address    string        `json:"address"`
	Scheme     string        `json:"scheme"`
	Datacenter string        `json:"datacenter"`
	Token      string        `json:"token"`
	TokenFile  string        `json:"token_file"`
	Namespace  string        `json:"namespace"`
	Partition  string        `json:"partition"`
	WaitTime   time.Duration `json:"wait_time"`
	TLSConfig  *api.TLSConfig `json:"tls_config"`
	HttpAuth   *api.HttpBasicAuth `json:"http_auth"`
	Transport  *http.Transport `json:"-"`
}

// DefaultConsulConfig returns default configuration for Consul
func DefaultConsulConfig() *ConsulConfig {
	return &ConsulConfig{
		Address:    "127.0.0.1:8500",
		Scheme:     "http",
		WaitTime:   60 * time.Second,
		TLSConfig:  &api.TLSConfig{},
		Transport: &http.Transport{
			MaxIdleConnsPerHost: 10,
			DisableKeepAlives:   false,
			IdleConnTimeout:     30 * time.Second,
		},
	}
}

// ServiceRegistration represents a service to register
type ServiceRegistration struct {
	ID                string              `json:"id"`
	Name              string              `json:"name"`
	Tags              []string            `json:"tags"`
	Address           string              `json:"address"`
	Port              int                 `json:"port"`
	Meta              map[string]string   `json:"meta"`
	EnableTagOverride bool                `json:"enable_tag_override"`
	Check             *api.AgentServiceCheck `json:"check,omitempty"`
	Checks            []*api.AgentServiceCheck `json:"checks,omitempty"`
	Weights           *api.AgentWeights   `json:"weights,omitempty"`
}

// HealthCheck represents a health check configuration
type HealthCheck struct {
	ID                string            `json:"id"`
	Name              string            `json:"name"`
	ServiceID         string            `json:"service_id"`
	HTTP              string            `json:"http"`
	TCP               string            `json:"tcp"`
	Script            string            `json:"script"`
	DockerContainerID string            `json:"docker_container_id"`
	Shell             string            `json:"shell"`
	Interval          string            `json:"interval"`
	Timeout           string            `json:"timeout"`
	TTL               string            `json:"ttl"`
	Notes             string            `json:"notes"`
	Status            string            `json:"status"`
	TLSSkipVerify     bool              `json:"tls_skip_verify"`
}

// NewConsulOperator creates a new Consul operator
func NewConsulOperator(config *ConsulConfig) (*ConsulOperator, error) {
	if config == nil {
		config = DefaultConsulConfig()
	}

	consulConfig := &api.Config{
		Address:    config.Address,
		Scheme:     config.Scheme,
		Datacenter: config.Datacenter,
		Token:      config.Token,
		TokenFile:  config.TokenFile,
		Namespace:  config.Namespace,
		Partition:  config.Partition,
		WaitTime:   config.WaitTime,
		TLSConfig:  config.TLSConfig,
		HttpAuth:   config.HttpAuth,
		Transport:  config.Transport,
	}

	client, err := api.NewClient(consulConfig)
	if err != nil {
		return nil, fmt.Errorf("failed to create Consul client: %v", err)
	}

	// Test connection
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	_, _, err = client.Status().Leader()
	if err != nil {
		return nil, fmt.Errorf("failed to connect to Consul: %v", err)
	}

	operator := &ConsulOperator{
		client:      client,
		kv:          client.KV(),
		agent:       client.Agent(),
		catalog:     client.Catalog(),
		health:      client.Health(),
		session:     client.Session(),
		config:      config,
		isConnected: true,
		watches:     make(map[string]context.CancelFunc),
	}

	log.Printf("CONSUL CONNECTED: %s", config.Address)
	return operator, nil
}

// Execute handles @consul operations with parameter parsing
func (c *ConsulOperator) Execute(params string) interface{} {
	// Parse operation format: @consul("operation", "key", "value", "options")
	parts := strings.Split(strings.Trim(params, "()\""), "\",\"")
	if len(parts) < 2 {
		return fmt.Errorf("invalid consul operation format")
	}

	operation := strings.Trim(parts[0], "\"")
	key := strings.Trim(parts[1], "\"")

	switch operation {
	case "kv_get":
		result, err := c.KVGet(key)
		if err != nil {
			return fmt.Errorf("consul kv get failed: %v", err)
		}
		return result
	case "kv_put":
		if len(parts) < 3 {
			return fmt.Errorf("kv_put operation requires key and value")
		}
		value := strings.Trim(parts[2], "\"")
		err := c.KVPut(key, value)
		if err != nil {
			return fmt.Errorf("consul kv put failed: %v", err)
		}
		return "success"
	case "kv_delete":
		err := c.KVDelete(key)
		if err != nil {
			return fmt.Errorf("consul kv delete failed: %v", err)
		}
		return "success"
	case "service_register":
		// Parse service registration JSON from key parameter
		return fmt.Errorf("use RegisterService method for service registration")
	case "service_discover":
		services, err := c.DiscoverService(key)
		if err != nil {
			return fmt.Errorf("consul service discover failed: %v", err)
		}
		return services
	case "health_check":
		health, err := c.GetServiceHealth(key)
		if err != nil {
			return fmt.Errorf("consul health check failed: %v", err)
		}
		return health
	default:
		return fmt.Errorf("unsupported consul operation: %s", operation)
	}
}

// KVGet retrieves a value from Consul KV store
func (c *ConsulOperator) KVGet(key string) (string, error) {
	if !c.isConnected {
		return "", fmt.Errorf("Consul client not connected")
	}

	pair, _, err := c.kv.Get(key, nil)
	if err != nil {
		log.Printf("CONSUL KV GET ERROR: key=%s, error=%v", key, err)
		return "", fmt.Errorf("failed to get key %s: %v", key, err)
	}

	if pair == nil {
		return "", fmt.Errorf("key not found: %s", key)
	}

	log.Printf("CONSUL KV GET SUCCESS: key=%s, value_length=%d", key, len(pair.Value))
	return string(pair.Value), nil
}

// KVPut stores a key-value pair in Consul KV store
func (c *ConsulOperator) KVPut(key, value string) error {
	if !c.isConnected {
		return fmt.Errorf("Consul client not connected")
	}

	pair := &api.KVPair{
		Key:   key,
		Value: []byte(value),
	}

	_, err := c.kv.Put(pair, nil)
	if err != nil {
		log.Printf("CONSUL KV PUT ERROR: key=%s, error=%v", key, err)
		return fmt.Errorf("failed to put key %s: %v", key, err)
	}

	log.Printf("CONSUL KV PUT SUCCESS: key=%s, value_length=%d", key, len(value))
	return nil
}

// KVDelete removes a key from Consul KV store
func (c *ConsulOperator) KVDelete(key string) error {
	if !c.isConnected {
		return fmt.Errorf("Consul client not connected")
	}

	_, err := c.kv.Delete(key, nil)
	if err != nil {
		log.Printf("CONSUL KV DELETE ERROR: key=%s, error=%v", key, err)
		return fmt.Errorf("failed to delete key %s: %v", key, err)
	}

	log.Printf("CONSUL KV DELETE SUCCESS: key=%s", key)
	return nil
}

// KVList lists keys with a prefix
func (c *ConsulOperator) KVList(prefix string) ([]string, error) {
	if !c.isConnected {
		return nil, fmt.Errorf("Consul client not connected")
	}

	keys, _, err := c.kv.Keys(prefix, "", nil)
	if err != nil {
		return nil, fmt.Errorf("failed to list keys with prefix %s: %v", prefix, err)
	}

	return keys, nil
}

// KVWatch watches a key for changes
func (c *ConsulOperator) KVWatch(key string, handler func(string, []byte)) error {
	if !c.isConnected {
		return fmt.Errorf("Consul client not connected")
	}

	c.mutex.Lock()
	// Cancel existing watch if present
	if cancel, exists := c.watches[key]; exists {
		cancel()
	}

	ctx, cancel := context.WithCancel(context.Background())
	c.watches[key] = cancel
	c.mutex.Unlock()

	go func() {
		var lastIndex uint64
		for {
			select {
			case <-ctx.Done():
				return
			default:
				opts := &api.QueryOptions{
					WaitIndex: lastIndex,
					WaitTime:  c.config.WaitTime,
				}

				pair, meta, err := c.kv.Get(key, opts)
				if err != nil {
					log.Printf("CONSUL KV WATCH ERROR: key=%s, error=%v", key, err)
					time.Sleep(5 * time.Second)
					continue
				}

				if meta.LastIndex != lastIndex {
					lastIndex = meta.LastIndex
					if pair != nil {
						handler(key, pair.Value)
					} else {
						handler(key, nil)
					}
				}
			}
		}
	}()

	log.Printf("CONSUL KV WATCH STARTED: key=%s", key)
	return nil
}

// StopKVWatch stops watching a key
func (c *ConsulOperator) StopKVWatch(key string) {
	c.mutex.Lock()
	defer c.mutex.Unlock()

	if cancel, exists := c.watches[key]; exists {
		cancel()
		delete(c.watches, key)
		log.Printf("CONSUL KV WATCH STOPPED: key=%s", key)
	}
}

// RegisterService registers a service with Consul
func (c *ConsulOperator) RegisterService(reg *ServiceRegistration) error {
	if !c.isConnected {
		return fmt.Errorf("Consul client not connected")
	}

	serviceDef := &api.AgentServiceRegistration{
		ID:                reg.ID,
		Name:              reg.Name,
		Tags:              reg.Tags,
		Address:           reg.Address,
		Port:              reg.Port,
		Meta:              reg.Meta,
		EnableTagOverride: reg.EnableTagOverride,
		Check:             reg.Check,
		Checks:            reg.Checks,
		Weights:           reg.Weights,
	}

	err := c.agent.ServiceRegister(serviceDef)
	if err != nil {
		log.Printf("CONSUL SERVICE REGISTER ERROR: service=%s, error=%v", reg.Name, err)
		return fmt.Errorf("failed to register service %s: %v", reg.Name, err)
	}

	log.Printf("CONSUL SERVICE REGISTERED: id=%s, name=%s, address=%s:%d", 
		reg.ID, reg.Name, reg.Address, reg.Port)
	return nil
}

// DeregisterService removes a service registration
func (c *ConsulOperator) DeregisterService(serviceID string) error {
	if !c.isConnected {
		return fmt.Errorf("Consul client not connected")
	}

	err := c.agent.ServiceDeregister(serviceID)
	if err != nil {
		log.Printf("CONSUL SERVICE DEREGISTER ERROR: service=%s, error=%v", serviceID, err)
		return fmt.Errorf("failed to deregister service %s: %v", serviceID, err)
	}

	log.Printf("CONSUL SERVICE DEREGISTERED: id=%s", serviceID)
	return nil
}

// DiscoverService discovers services by name
func (c *ConsulOperator) DiscoverService(serviceName string) ([]*api.ServiceEntry, error) {
	if !c.isConnected {
		return nil, fmt.Errorf("Consul client not connected")
	}

	services, _, err := c.health.Service(serviceName, "", true, nil)
	if err != nil {
		log.Printf("CONSUL SERVICE DISCOVER ERROR: service=%s, error=%v", serviceName, err)
		return nil, fmt.Errorf("failed to discover service %s: %v", serviceName, err)
	}

	log.Printf("CONSUL SERVICE DISCOVERED: service=%s, instances=%d", serviceName, len(services))
	return services, nil
}

// GetAllServices retrieves all registered services
func (c *ConsulOperator) GetAllServices() (map[string]*api.AgentService, error) {
	if !c.isConnected {
		return nil, fmt.Errorf("Consul client not connected")
	}

	services, err := c.agent.Services()
	if err != nil {
		return nil, fmt.Errorf("failed to get services: %v", err)
	}

	return services, nil
}

// RegisterHealthCheck registers a health check
func (c *ConsulOperator) RegisterHealthCheck(check *HealthCheck) error {
	if !c.isConnected {
		return fmt.Errorf("Consul client not connected")
	}

	healthCheck := &api.AgentCheckRegistration{
		ID:        check.ID,
		Name:      check.Name,
		ServiceID: check.ServiceID,
		Notes:     check.Notes,
		Status:    check.Status,
		AgentServiceCheck: api.AgentServiceCheck{
			HTTP:              check.HTTP,
			TCP:               check.TCP,
			Script:            check.Script,
			DockerContainerID: check.DockerContainerID,
			Shell:             check.Shell,
			Interval:          check.Interval,
			Timeout:           check.Timeout,
			TTL:               check.TTL,
			TLSSkipVerify:     check.TLSSkipVerify,
		},
	}

	err := c.agent.CheckRegister(healthCheck)
	if err != nil {
		log.Printf("CONSUL HEALTH CHECK REGISTER ERROR: check=%s, error=%v", check.ID, err)
		return fmt.Errorf("failed to register health check %s: %v", check.ID, err)
	}

	log.Printf("CONSUL HEALTH CHECK REGISTERED: id=%s, name=%s", check.ID, check.Name)
	return nil
}

// DeregisterHealthCheck removes a health check
func (c *ConsulOperator) DeregisterHealthCheck(checkID string) error {
	if !c.isConnected {
		return fmt.Errorf("Consul client not connected")
	}

	err := c.agent.CheckDeregister(checkID)
	if err != nil {
		log.Printf("CONSUL HEALTH CHECK DEREGISTER ERROR: check=%s, error=%v", checkID, err)
		return fmt.Errorf("failed to deregister health check %s: %v", checkID, err)
	}

	log.Printf("CONSUL HEALTH CHECK DEREGISTERED: id=%s", checkID)
	return nil
}

// GetServiceHealth retrieves health status for a service
func (c *ConsulOperator) GetServiceHealth(serviceName string) ([]*api.ServiceEntry, error) {
	if !c.isConnected {
		return nil, fmt.Errorf("Consul client not connected")
	}

	// Get all instances (healthy and unhealthy)
	services, _, err := c.health.Service(serviceName, "", false, nil)
	if err != nil {
		return nil, fmt.Errorf("failed to get service health for %s: %v", serviceName, err)
	}

	return services, nil
}

// GetHealthyServices retrieves only healthy service instances
func (c *ConsulOperator) GetHealthyServices(serviceName string) ([]*api.ServiceEntry, error) {
	if !c.isConnected {
		return nil, fmt.Errorf("Consul client not connected")
	}

	// Get only healthy instances
	services, _, err := c.health.Service(serviceName, "", true, nil)
	if err != nil {
		return nil, fmt.Errorf("failed to get healthy services for %s: %v", serviceName, err)
	}

	return services, nil
}

// CheckTTL updates TTL for a health check
func (c *ConsulOperator) CheckTTL(checkID, status, note string) error {
	if !c.isConnected {
		return fmt.Errorf("Consul client not connected")
	}

	var err error
	switch status {
	case "pass":
		err = c.agent.PassTTL(checkID, note)
	case "warn":
		err = c.agent.WarnTTL(checkID, note)
	case "fail":
		err = c.agent.FailTTL(checkID, note)
	default:
		return fmt.Errorf("invalid TTL status: %s (must be pass, warn, or fail)", status)
	}

	if err != nil {
		return fmt.Errorf("failed to update TTL for check %s: %v", checkID, err)
	}

	log.Printf("CONSUL TTL UPDATED: check=%s, status=%s", checkID, status)
	return nil
}

// CreateSession creates a new session for distributed locking
func (c *ConsulOperator) CreateSession(name string, ttl time.Duration) (string, error) {
	if !c.isConnected {
		return "", fmt.Errorf("Consul client not connected")
	}

	sessionEntry := &api.SessionEntry{
		Name:      name,
		TTL:       ttl.String(),
		Behavior:  "release",
		LockDelay: 15 * time.Second,
	}

	sessionID, _, err := c.session.Create(sessionEntry, nil)
	if err != nil {
		return "", fmt.Errorf("failed to create session %s: %v", name, err)
	}

	log.Printf("CONSUL SESSION CREATED: id=%s, name=%s, ttl=%v", sessionID, name, ttl)
	return sessionID, nil
}

// AcquireLock acquires a distributed lock using a session
func (c *ConsulOperator) AcquireLock(key, sessionID string) (bool, error) {
	if !c.isConnected {
		return false, fmt.Errorf("Consul client not connected")
	}

	pair := &api.KVPair{
		Key:     key,
		Value:   []byte(sessionID),
		Session: sessionID,
	}

	acquired, _, err := c.kv.Acquire(pair, nil)
	if err != nil {
		return false, fmt.Errorf("failed to acquire lock %s: %v", key, err)
	}

	if acquired {
		log.Printf("CONSUL LOCK ACQUIRED: key=%s, session=%s", key, sessionID)
	} else {
		log.Printf("CONSUL LOCK FAILED: key=%s, session=%s", key, sessionID)
	}

	return acquired, nil
}

// ReleaseLock releases a distributed lock
func (c *ConsulOperator) ReleaseLock(key, sessionID string) (bool, error) {
	if !c.isConnected {
		return false, fmt.Errorf("Consul client not connected")
	}

	pair := &api.KVPair{
		Key:     key,
		Value:   []byte(sessionID),
		Session: sessionID,
	}

	released, _, err := c.kv.Release(pair, nil)
	if err != nil {
		return false, fmt.Errorf("failed to release lock %s: %v", key, err)
	}

	if released {
		log.Printf("CONSUL LOCK RELEASED: key=%s, session=%s", key, sessionID)
	}

	return released, nil
}

// DestroySession destroys a session
func (c *ConsulOperator) DestroySession(sessionID string) error {
	if !c.isConnected {
		return fmt.Errorf("Consul client not connected")
	}

	_, err := c.session.Destroy(sessionID, nil)
	if err != nil {
		return fmt.Errorf("failed to destroy session %s: %v", sessionID, err)
	}

	log.Printf("CONSUL SESSION DESTROYED: id=%s", sessionID)
	return nil
}

// GetDatacenters retrieves list of datacenters
func (c *ConsulOperator) GetDatacenters() ([]string, error) {
	if !c.isConnected {
		return nil, fmt.Errorf("Consul client not connected")
	}

	datacenters, err := c.catalog.Datacenters()
	if err != nil {
		return nil, fmt.Errorf("failed to get datacenters: %v", err)
	}

	return datacenters, nil
}

// GetNodes retrieves list of nodes in the catalog
func (c *ConsulOperator) GetNodes() ([]*api.Node, error) {
	if !c.isConnected {
		return nil, fmt.Errorf("Consul client not connected")
	}

	nodes, _, err := c.catalog.Nodes(nil)
	if err != nil {
		return nil, fmt.Errorf("failed to get nodes: %v", err)
	}

	return nodes, nil
}

// GetLeader retrieves the cluster leader
func (c *ConsulOperator) GetLeader() (string, error) {
	if !c.isConnected {
		return "", fmt.Errorf("Consul client not connected")
	}

	leader, err := c.client.Status().Leader()
	if err != nil {
		return "", fmt.Errorf("failed to get leader: %v", err)
	}

	return leader, nil
}

// GetPeers retrieves the cluster peers
func (c *ConsulOperator) GetPeers() ([]string, error) {
	if !c.isConnected {
		return nil, fmt.Errorf("Consul client not connected")
	}

	peers, err := c.client.Status().Peers()
	if err != nil {
		return nil, fmt.Errorf("failed to get peers: %v", err)
	}

	return peers, nil
}

// Close closes the Consul connection and cleans up resources
func (c *ConsulOperator) Close() error {
	c.mutex.Lock()
	defer c.mutex.Unlock()

	if !c.isConnected {
		return nil
	}

	// Stop all watches
	for key, cancel := range c.watches {
		cancel()
		log.Printf("CONSUL WATCH STOPPED: key=%s", key)
	}
	c.watches = make(map[string]context.CancelFunc)

	c.isConnected = false
	log.Printf("CONSUL CONNECTION CLOSED")
	return nil
} 