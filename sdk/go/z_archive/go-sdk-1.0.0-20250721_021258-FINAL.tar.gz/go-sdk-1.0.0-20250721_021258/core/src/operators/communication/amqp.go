package communication

import (
	"encoding/json"
	"fmt"
	"sync"
	"time"

	amqp "github.com/rabbitmq/amqp091-go"
)

// AMQPOperator handles @amqp operations
type AMQPOperator struct {
	connections map[string]*amqp.Connection
	channels    map[string]*amqp.Channel
	mutex       sync.RWMutex
}

// AMQPMessage represents an AMQP message
type AMQPMessage struct {
	Exchange   string                 `json:"exchange"`
	RoutingKey string                 `json:"routing_key"`
	Data       interface{}            `json:"data"`
	Headers    map[string]interface{} `json:"headers,omitempty"`
	Priority   uint8                  `json:"priority,omitempty"`
	Timestamp  time.Time              `json:"timestamp,omitempty"`
}

// NewAMQPOperator creates a new AMQP operator
func NewAMQPOperator() *AMQPOperator {
	return &AMQPOperator{
		connections: make(map[string]*amqp.Connection),
		channels:    make(map[string]*amqp.Channel),
	}
}

// Execute handles @amqp operations
func (a *AMQPOperator) Execute(params string) interface{} {
	// Parse parameters (format: "action", "exchange", "routing_key", "message")
	// Example: @amqp("publish", "user_events", "user.created", '{"id": "123"}')
	
	return fmt.Sprintf("@amqp(%s)", params)
}

// Connect establishes an AMQP connection
func (a *AMQPOperator) Connect(name, url string) error {
	a.mutex.Lock()
	defer a.mutex.Unlock()

	conn, err := amqp.Dial(url)
	if err != nil {
		return fmt.Errorf("failed to connect to AMQP %s at %s: %v", name, url, err)
	}

	ch, err := conn.Channel()
	if err != nil {
		conn.Close()
		return fmt.Errorf("failed to create channel for %s: %v", name, err)
	}

	a.connections[name] = conn
	a.channels[name] = ch
	return nil
}

// Disconnect closes an AMQP connection
func (a *AMQPOperator) Disconnect(name string) error {
	a.mutex.Lock()
	defer a.mutex.Unlock()

	if ch, exists := a.channels[name]; exists {
		ch.Close()
		delete(a.channels, name)
	}

	if conn, exists := a.connections[name]; exists {
		conn.Close()
		delete(a.connections, name)
		return nil
	}

	return fmt.Errorf("connection %s not found", name)
}

// Publish publishes a message to an exchange
func (a *AMQPOperator) Publish(connectionName, exchange, routingKey string, data interface{}, headers map[string]interface{}) error {
	a.mutex.RLock()
	ch, exists := a.channels[connectionName]
	a.mutex.RUnlock()

	if !exists {
		return fmt.Errorf("connection %s not found", connectionName)
	}

	messageBytes, err := json.Marshal(data)
	if err != nil {
		return fmt.Errorf("failed to marshal message: %v", err)
	}

	// Convert headers to amqp.Table
	amqpHeaders := amqp.Table{}
	for key, value := range headers {
		amqpHeaders[key] = value
	}

	msg := amqp.Publishing{
		ContentType:  "application/json",
		Body:         messageBytes,
		Headers:      amqpHeaders,
		Timestamp:    time.Now(),
		DeliveryMode: amqp.Persistent,
	}

	return ch.Publish(exchange, routingKey, false, false, msg)
}

// DeclareExchange declares an exchange
func (a *AMQPOperator) DeclareExchange(connectionName, name, kind string, durable, autoDelete, internal, noWait bool) error {
	a.mutex.RLock()
	ch, exists := a.channels[connectionName]
	a.mutex.RUnlock()

	if !exists {
		return fmt.Errorf("connection %s not found", connectionName)
	}

	return ch.ExchangeDeclare(name, kind, durable, autoDelete, internal, noWait, nil)
}

// DeclareQueue declares a queue
func (a *AMQPOperator) DeclareQueue(connectionName, name string, durable, autoDelete, exclusive, noWait bool) error {
	a.mutex.RLock()
	ch, exists := a.channels[connectionName]
	a.mutex.RUnlock()

	if !exists {
		return fmt.Errorf("connection %s not found", connectionName)
	}

	_, err := ch.QueueDeclare(name, durable, autoDelete, exclusive, noWait, nil)
	return err
}

// BindQueue binds a queue to an exchange
func (a *AMQPOperator) BindQueue(connectionName, queueName, routingKey, exchangeName string) error {
	a.mutex.RLock()
	ch, exists := a.channels[connectionName]
	a.mutex.RUnlock()

	if !exists {
		return fmt.Errorf("connection %s not found", connectionName)
	}

	return ch.QueueBind(queueName, routingKey, exchangeName, false, nil)
}

// Consume starts consuming messages from a queue
func (a *AMQPOperator) Consume(connectionName, queueName string, handler func(*AMQPMessage)) error {
	a.mutex.RLock()
	ch, exists := a.channels[connectionName]
	a.mutex.RUnlock()

	if !exists {
		return fmt.Errorf("connection %s not found", connectionName)
	}

	msgs, err := ch.Consume(queueName, "", true, false, false, false, nil)
	if err != nil {
		return fmt.Errorf("failed to start consuming from %s: %v", queueName, err)
	}

	go func() {
		for msg := range msgs {
			var data interface{}
			if err := json.Unmarshal(msg.Body, &data); err != nil {
				data = string(msg.Body)
			}

			amqpMessage := &AMQPMessage{
				Exchange:   msg.Exchange,
				RoutingKey: msg.RoutingKey,
				Data:       data,
				Headers:    msg.Headers,
				Priority:   msg.Priority,
				Timestamp:  msg.Timestamp,
			}

			handler(amqpMessage)
		}
	}()

	return nil
}

// Get retrieves a single message from a queue
func (a *AMQPOperator) Get(connectionName, queueName string) (*AMQPMessage, error) {
	a.mutex.RLock()
	ch, exists := a.channels[connectionName]
	a.mutex.RUnlock()

	if !exists {
		return nil, fmt.Errorf("connection %s not found", connectionName)
	}

	msg, ok, err := ch.Get(queueName, false)
	if err != nil {
		return nil, fmt.Errorf("failed to get message from %s: %v", queueName, err)
	}

	if !ok {
		return nil, fmt.Errorf("no message available in queue %s", queueName)
	}

	var data interface{}
	if err := json.Unmarshal(msg.Body, &data); err != nil {
		data = string(msg.Body)
	}

	return &AMQPMessage{
		Exchange:   msg.Exchange,
		RoutingKey: msg.RoutingKey,
		Data:       data,
		Headers:    msg.Headers,
		Priority:   msg.Priority,
		Timestamp:  msg.Timestamp,
	}, nil
}

// PurgeQueue purges all messages from a queue
func (a *AMQPOperator) PurgeQueue(connectionName, queueName string) error {
	a.mutex.RLock()
	ch, exists := a.channels[connectionName]
	a.mutex.RUnlock()

	if !exists {
		return fmt.Errorf("connection %s not found", connectionName)
	}

	_, err := ch.QueuePurge(queueName, false)
	return err
}

// DeleteQueue deletes a queue
func (a *AMQPOperator) DeleteQueue(connectionName, queueName string) error {
	a.mutex.RLock()
	ch, exists := a.channels[connectionName]
	a.mutex.RUnlock()

	if !exists {
		return fmt.Errorf("connection %s not found", connectionName)
	}

	_, err := ch.QueueDelete(queueName, false, false, false)
	return err
}

// ListConnections returns a list of active connection names
func (a *AMQPOperator) ListConnections() []string {
	a.mutex.RLock()
	defer a.mutex.RUnlock()

	names := make([]string, 0, len(a.connections))
	for name := range a.connections {
		names = append(names, name)
	}
	return names
}

// GetConnectionStatus returns the status of a connection
func (a *AMQPOperator) GetConnectionStatus(name string) string {
	a.mutex.RLock()
	defer a.mutex.RUnlock()

	if conn, exists := a.connections[name]; exists {
		if !conn.IsClosed() {
			return "connected"
		}
		return "disconnected"
	}
	return "not_found"
}

// Close closes all AMQP connections
func (a *AMQPOperator) Close() error {
	a.mutex.Lock()
	defer a.mutex.Unlock()

	for name, ch := range a.channels {
		ch.Close()
		delete(a.channels, name)
	}

	for name, conn := range a.connections {
		conn.Close()
		delete(a.connections, name)
	}

	return nil
} 