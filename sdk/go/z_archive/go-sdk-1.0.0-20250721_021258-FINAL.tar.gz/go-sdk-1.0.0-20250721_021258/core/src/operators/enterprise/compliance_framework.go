package enterprise

import (
	"context"
	"crypto/sha256"
	"database/sql"
	"encoding/json"
	"fmt"
	"log"
	"strings"
	"time"
)

// ComplianceOperator handles enterprise compliance frameworks
type ComplianceOperator struct {
	db                 *sql.DB
	auditLogger        *AuditLogger
	dataClassifier     *DataClassifier
	policyEngine       *PolicyEngine
	evidenceCollector  *EvidenceCollector
	reportGenerator    *ReportGenerator
}

// ComplianceFramework represents supported compliance standards
type ComplianceFramework string

const (
	SOC2   ComplianceFramework = "SOC2"
	HIPAA  ComplianceFramework = "HIPAA"
	GDPR   ComplianceFramework = "GDPR"
	ISO27001 ComplianceFramework = "ISO27001"
	PCI    ComplianceFramework = "PCI"
)

// ComplianceControl represents a compliance control
type ComplianceControl struct {
	ID                string                 `json:"id"`
	Framework         ComplianceFramework    `json:"framework"`
	ControlFamily     string                 `json:"control_family"`
	ControlTitle      string                 `json:"control_title"`
	Description       string                 `json:"description"`
	Requirements      []string               `json:"requirements"`
	Implementation    string                 `json:"implementation"`
	AutomatedChecks   []AutomatedCheck       `json:"automated_checks"`
	EvidenceTypes     []string               `json:"evidence_types"`
	RiskLevel         string                 `json:"risk_level"`
	Status            string                 `json:"status"`
	LastAssessed      time.Time              `json:"last_assessed"`
	NextAssessment    time.Time              `json:"next_assessment"`
	ResponsibleParty  string                 `json:"responsible_party"`
	Metadata          map[string]interface{} `json:"metadata"`
}

// AutomatedCheck represents an automated compliance check
type AutomatedCheck struct {
	ID          string                 `json:"id"`
	CheckType   string                 `json:"check_type"`
	Parameters  map[string]interface{} `json:"parameters"`
	Frequency   string                 `json:"frequency"`
	Severity    string                 `json:"severity"`
	LastRun     time.Time              `json:"last_run"`
	NextRun     time.Time              `json:"next_run"`
	Status      string                 `json:"status"`
	Results     map[string]interface{} `json:"results"`
}

// ComplianceViolation represents a compliance violation
type ComplianceViolation struct {
	ID             string                 `json:"id"`
	ControlID      string                 `json:"control_id"`
	ViolationType  string                 `json:"violation_type"`
	Severity       string                 `json:"severity"`
	Description    string                 `json:"description"`
	DetectedAt     time.Time              `json:"detected_at"`
	ResolvedAt     *time.Time             `json:"resolved_at,omitempty"`
	Status         string                 `json:"status"`
	Evidence       []Evidence             `json:"evidence"`
	Impact         string                 `json:"impact"`
	Remediation    string                 `json:"remediation"`
	ResponsibleParty string               `json:"responsible_party"`
	Metadata       map[string]interface{} `json:"metadata"`
}

// Evidence represents compliance evidence
type Evidence struct {
	ID           string                 `json:"id"`
	Type         string                 `json:"type"`
	Description  string                 `json:"description"`
	CollectedAt  time.Time              `json:"collected_at"`
	Source       string                 `json:"source"`
	Hash         string                 `json:"hash"`
	Metadata     map[string]interface{} `json:"metadata"`
	Attachments  []Attachment           `json:"attachments"`
}

// Attachment represents an evidence attachment
type Attachment struct {
	ID       string    `json:"id"`
	Filename string    `json:"filename"`
	Size     int64     `json:"size"`
	MimeType string    `json:"mime_type"`
	Hash     string    `json:"hash"`
	URL      string    `json:"url"`
	UploadedAt time.Time `json:"uploaded_at"`
}

// DataClassification represents data classification levels
type DataClassification struct {
	Level       string                 `json:"level"`        // public, internal, confidential, restricted
	Category    string                 `json:"category"`     // pii, phi, financial, etc.
	Retention   time.Duration          `json:"retention"`
	Encryption  bool                   `json:"encryption"`
	Access      []string               `json:"access"`
	Geographic  []string               `json:"geographic"`   // data residency requirements
	Metadata    map[string]interface{} `json:"metadata"`
}

// AuditEvent represents an audit event
type AuditEvent struct {
	ID          string                 `json:"id"`
	EventType   string                 `json:"event_type"`
	Timestamp   time.Time              `json:"timestamp"`
	UserID      string                 `json:"user_id"`
	Action      string                 `json:"action"`
	Resource    string                 `json:"resource"`
	Status      string                 `json:"status"`
	IPAddress   string                 `json:"ip_address"`
	UserAgent   string                 `json:"user_agent"`
	Metadata    map[string]interface{} `json:"metadata"`
	Hash        string                 `json:"hash"`
}

// NewComplianceOperator creates a new compliance operator
func NewComplianceOperator(db *sql.DB) (*ComplianceOperator, error) {
	co := &ComplianceOperator{
		db: db,
	}

	var err error
	co.auditLogger, err = NewAuditLogger(db)
	if err != nil {
		return nil, fmt.Errorf("failed to initialize audit logger: %v", err)
	}

	co.dataClassifier = NewDataClassifier()
	co.policyEngine = NewPolicyEngine(db)
	co.evidenceCollector = NewEvidenceCollector(db)
	co.reportGenerator = NewReportGenerator(db)

	if err := co.initDatabase(); err != nil {
		return nil, fmt.Errorf("failed to initialize compliance database: %v", err)
	}

	// Initialize compliance controls
	if err := co.initializeControls(); err != nil {
		return nil, fmt.Errorf("failed to initialize compliance controls: %v", err)
	}

	return co, nil
}

// initDatabase creates necessary tables for compliance
func (co *ComplianceOperator) initDatabase() error {
	queries := []string{
		`CREATE TABLE IF NOT EXISTS compliance_controls (
			id VARCHAR(255) PRIMARY KEY,
			framework VARCHAR(50) NOT NULL,
			control_family VARCHAR(100) NOT NULL,
			control_title VARCHAR(255) NOT NULL,
			description TEXT,
			requirements JSON,
			implementation TEXT,
			automated_checks JSON,
			evidence_types JSON,
			risk_level VARCHAR(20),
			status VARCHAR(50) DEFAULT 'pending',
			last_assessed TIMESTAMP,
			next_assessment TIMESTAMP,
			responsible_party VARCHAR(255),
			metadata JSON,
			created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
			updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
			INDEX idx_framework (framework),
			INDEX idx_status (status),
			INDEX idx_next_assessment (next_assessment)
		)`,
		`CREATE TABLE IF NOT EXISTS compliance_violations (
			id VARCHAR(255) PRIMARY KEY,
			control_id VARCHAR(255) NOT NULL,
			violation_type VARCHAR(100) NOT NULL,
			severity VARCHAR(20) NOT NULL,
			description TEXT,
			detected_at TIMESTAMP NOT NULL,
			resolved_at TIMESTAMP,
			status VARCHAR(50) DEFAULT 'open',
			evidence JSON,
			impact TEXT,
			remediation TEXT,
			responsible_party VARCHAR(255),
			metadata JSON,
			created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
			updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
			INDEX idx_control_id (control_id),
			INDEX idx_severity (severity),
			INDEX idx_status (status),
			INDEX idx_detected_at (detected_at),
			FOREIGN KEY (control_id) REFERENCES compliance_controls(id)
		)`,
		`CREATE TABLE IF NOT EXISTS compliance_evidence (
			id VARCHAR(255) PRIMARY KEY,
			type VARCHAR(100) NOT NULL,
			description TEXT,
			collected_at TIMESTAMP NOT NULL,
			source VARCHAR(255),
			hash VARCHAR(255),
			metadata JSON,
			attachments JSON,
			created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
			INDEX idx_type (type),
			INDEX idx_collected_at (collected_at),
			INDEX idx_source (source)
		)`,
		`CREATE TABLE IF NOT EXISTS audit_events (
			id VARCHAR(255) PRIMARY KEY,
			event_type VARCHAR(100) NOT NULL,
			timestamp TIMESTAMP NOT NULL,
			user_id VARCHAR(255),
			action VARCHAR(255) NOT NULL,
			resource VARCHAR(255),
			status VARCHAR(50),
			ip_address VARCHAR(45),
			user_agent TEXT,
			metadata JSON,
			hash VARCHAR(255) NOT NULL,
			created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
			INDEX idx_event_type (event_type),
			INDEX idx_timestamp (timestamp),
			INDEX idx_user_id (user_id),
			INDEX idx_action (action),
			INDEX idx_hash (hash)
		)`,
		`CREATE TABLE IF NOT EXISTS data_classifications (
			id VARCHAR(255) PRIMARY KEY,
			resource_type VARCHAR(100) NOT NULL,
			resource_id VARCHAR(255) NOT NULL,
			classification_level VARCHAR(50) NOT NULL,
			classification_category VARCHAR(100),
			retention_period INT,
			requires_encryption BOOLEAN DEFAULT FALSE,
			access_groups JSON,
			geographic_restrictions JSON,
			metadata JSON,
			classified_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
			expires_at TIMESTAMP,
			INDEX idx_resource (resource_type, resource_id),
			INDEX idx_level (classification_level),
			INDEX idx_category (classification_category)
		)`,
	}

	for _, query := range queries {
		if _, err := co.db.Exec(query); err != nil {
			return fmt.Errorf("failed to create table: %v", err)
		}
	}

	return nil
}

// initializeControls initializes predefined compliance controls
func (co *ComplianceOperator) initializeControls() error {
	controls := []*ComplianceControl{
		// SOC2 Type II Controls
		{
			ID:            "SOC2-CC1.1",
			Framework:     SOC2,
			ControlFamily: "Common Criteria",
			ControlTitle:  "Control Environment",
			Description:   "The entity demonstrates a commitment to integrity and ethical values",
			Requirements: []string{
				"Code of conduct established and communicated",
				"Disciplinary actions for violations",
				"Background checks for personnel",
				"Ongoing ethics training",
			},
			AutomatedChecks: []AutomatedCheck{
				{
					ID:        "SOC2-CC1.1-AC1",
					CheckType: "policy_verification",
					Parameters: map[string]interface{}{
						"policy_name": "code_of_conduct",
						"min_version": "1.0",
					},
					Frequency: "monthly",
					Severity:  "high",
				},
			},
			EvidenceTypes: []string{"policies", "training_records", "background_checks"},
			RiskLevel:     "high",
			Status:        "active",
		},
		{
			ID:            "SOC2-CC6.1",
			Framework:     SOC2,
			ControlFamily: "Logical and Physical Access Controls",
			ControlTitle:  "Logical Access Security Software",
			Description:   "The entity implements logical access security software",
			Requirements: []string{
				"Multi-factor authentication implemented",
				"Regular access reviews conducted",
				"Privileged access management",
				"Session timeout configurations",
			},
			AutomatedChecks: []AutomatedCheck{
				{
					ID:        "SOC2-CC6.1-AC1",
					CheckType: "mfa_enforcement",
					Parameters: map[string]interface{}{
						"min_mfa_coverage": 100,
						"excluded_roles":   []string{},
					},
					Frequency: "daily",
					Severity:  "critical",
				},
			},
			EvidenceTypes: []string{"access_logs", "mfa_enrollment", "access_reviews"},
			RiskLevel:     "critical",
			Status:        "active",
		},

		// HIPAA Controls
		{
			ID:            "HIPAA-164.312-a-1",
			Framework:     HIPAA,
			ControlFamily: "Access Control",
			ControlTitle:  "Assigned Security Responsibility",
			Description:   "Assign a unique name and/or number for identifying and tracking user identity",
			Requirements: []string{
				"Unique user identification for each person",
				"Emergency access procedure",
				"Automatic logoff",
				"Encryption and decryption",
			},
			AutomatedChecks: []AutomatedCheck{
				{
					ID:        "HIPAA-164.312-a-1-AC1",
					CheckType: "unique_user_id",
					Parameters: map[string]interface{}{
						"check_duplicates": true,
						"min_complexity":   8,
					},
					Frequency: "daily",
					Severity:  "high",
				},
			},
			EvidenceTypes: []string{"user_management", "access_logs", "encryption_status"},
			RiskLevel:     "high",
			Status:        "active",
		},
		{
			ID:            "HIPAA-164.312-e-1",
			Framework:     HIPAA,
			ControlFamily: "Transmission Security",
			ControlTitle:  "Integrity",
			Description:   "Implement security measures to ensure that ePHI is not improperly altered or destroyed",
			Requirements: []string{
				"Data integrity controls",
				"Transmission encryption",
				"End-to-end encryption",
				"Digital signatures",
			},
			AutomatedChecks: []AutomatedCheck{
				{
					ID:        "HIPAA-164.312-e-1-AC1",
					CheckType: "transmission_encryption",
					Parameters: map[string]interface{}{
						"min_tls_version": "1.3",
						"cipher_strength": 256,
					},
					Frequency: "continuous",
					Severity:  "critical",
				},
			},
			EvidenceTypes: []string{"encryption_logs", "transmission_logs", "integrity_checks"},
			RiskLevel:     "critical",
			Status:        "active",
		},

		// GDPR Controls
		{
			ID:            "GDPR-Art25",
			Framework:     GDPR,
			ControlFamily: "Data Protection by Design and by Default",
			ControlTitle:  "Data Protection by Design and by Default",
			Description:   "The controller shall implement appropriate technical and organisational measures",
			Requirements: []string{
				"Privacy by design implementation",
				"Data minimization principles",
				"Purpose limitation",
				"Storage limitation",
			},
			AutomatedChecks: []AutomatedCheck{
				{
					ID:        "GDPR-Art25-AC1",
					CheckType: "data_minimization",
					Parameters: map[string]interface{}{
						"max_retention_days": 2555, // 7 years
						"data_categories":    []string{"pii", "personal"},
					},
					Frequency: "weekly",
					Severity:  "high",
				},
			},
			EvidenceTypes: []string{"data_mapping", "retention_policies", "privacy_assessments"},
			RiskLevel:     "high",
			Status:        "active",
		},
		{
			ID:            "GDPR-Art32",
			Framework:     GDPR,
			ControlFamily: "Security of Processing",
			ControlTitle:  "Security of Processing",
			Description:   "Implement appropriate technical and organisational measures to ensure security",
			Requirements: []string{
				"Pseudonymisation and encryption of personal data",
				"Ongoing confidentiality, integrity, availability",
				"Regular testing and evaluation",
				"Process for restoring availability",
			},
			AutomatedChecks: []AutomatedCheck{
				{
					ID:        "GDPR-Art32-AC1",
					CheckType: "encryption_coverage",
					Parameters: map[string]interface{}{
						"min_coverage":   100,
						"data_at_rest":   true,
						"data_in_transit": true,
					},
					Frequency: "daily",
					Severity:  "critical",
				},
			},
			EvidenceTypes: []string{"encryption_reports", "security_assessments", "incident_reports"},
			RiskLevel:     "critical",
			Status:        "active",
		},
	}

	for _, control := range controls {
		control.NextAssessment = time.Now().Add(30 * 24 * time.Hour) // 30 days
		if err := co.saveControl(control); err != nil {
			log.Printf("Failed to save control %s: %v", control.ID, err)
		}
	}

	return nil
}

// RunComplianceAssessment runs a comprehensive compliance assessment
func (co *ComplianceOperator) RunComplianceAssessment(ctx context.Context, framework ComplianceFramework) (*ComplianceAssessmentResult, error) {
	controls, err := co.getControlsByFramework(framework)
	if err != nil {
		return nil, fmt.Errorf("failed to get controls: %v", err)
	}

	result := &ComplianceAssessmentResult{
		Framework:      framework,
		AssessmentDate: time.Now(),
		TotalControls:  len(controls),
	}

	for _, control := range controls {
		controlResult := co.assessControl(ctx, control)
		result.ControlResults = append(result.ControlResults, controlResult)
		
		switch controlResult.Status {
		case "compliant":
			result.CompliantControls++
		case "non_compliant":
			result.NonCompliantControls++
		case "partially_compliant":
			result.PartiallyCompliantControls++
		}
	}

	result.ComplianceScore = float64(result.CompliantControls) / float64(result.TotalControls) * 100
	
	// Generate evidence for assessment
	evidence := &Evidence{
		ID:          co.generateID("evidence"),
		Type:        "compliance_assessment",
		Description: fmt.Sprintf("%s compliance assessment results", framework),
		CollectedAt: time.Now(),
		Source:      "compliance_operator",
		Metadata: map[string]interface{}{
			"framework":         framework,
			"compliance_score":  result.ComplianceScore,
			"total_controls":    result.TotalControls,
			"compliant":         result.CompliantControls,
			"non_compliant":     result.NonCompliantControls,
		},
	}
	evidence.Hash = co.calculateHash(evidence)
	
	co.evidenceCollector.StoreEvidence(evidence)

	return result, nil
}

// assessControl assesses a single compliance control
func (co *ComplianceOperator) assessControl(ctx context.Context, control *ComplianceControl) *ControlAssessmentResult {
	result := &ControlAssessmentResult{
		ControlID:      control.ID,
		ControlTitle:   control.ControlTitle,
		AssessmentDate: time.Now(),
		Status:         "compliant",
		Issues:         []string{},
		Evidence:       []string{},
	}

	// Run automated checks
	for _, check := range control.AutomatedChecks {
		checkResult := co.runAutomatedCheck(ctx, &check)
		
		if !checkResult.Passed {
			result.Status = "non_compliant"
			result.Issues = append(result.Issues, checkResult.Issues...)
			
			// Create violation record
			violation := &ComplianceViolation{
				ID:             co.generateID("violation"),
				ControlID:      control.ID,
				ViolationType:  check.CheckType,
				Severity:       check.Severity,
				Description:    fmt.Sprintf("Automated check failed: %s", checkResult.Message),
				DetectedAt:     time.Now(),
				Status:         "open",
				Evidence:       []Evidence{},
				ResponsibleParty: control.ResponsibleParty,
			}
			
			co.recordViolation(violation)
		} else {
			result.Evidence = append(result.Evidence, checkResult.Evidence...)
		}
	}

	// Update control assessment timestamp
	control.LastAssessed = time.Now()
	control.NextAssessment = time.Now().Add(30 * 24 * time.Hour)
	co.saveControl(control)

	return result
}

// runAutomatedCheck executes an automated compliance check
func (co *ComplianceOperator) runAutomatedCheck(ctx context.Context, check *AutomatedCheck) *CheckResult {
	result := &CheckResult{
		CheckID:   check.ID,
		CheckType: check.CheckType,
		Timestamp: time.Now(),
		Passed:    true,
		Issues:    []string{},
		Evidence:  []string{},
	}

	switch check.CheckType {
	case "mfa_enforcement":
		result = co.checkMFAEnforcement(check)
	case "encryption_coverage":
		result = co.checkEncryptionCoverage(check)
	case "data_minimization":
		result = co.checkDataMinimization(check)
	case "unique_user_id":
		result = co.checkUniqueUserIDs(check)
	case "transmission_encryption":
		result = co.checkTransmissionEncryption(check)
	case "policy_verification":
		result = co.checkPolicyCompliance(check)
	default:
		result.Passed = false
		result.Issues = append(result.Issues, fmt.Sprintf("Unknown check type: %s", check.CheckType))
	}

	// Update check status
	check.LastRun = time.Now()
	check.Status = "completed"
	check.Results = map[string]interface{}{
		"passed":    result.Passed,
		"issues":    result.Issues,
		"evidence":  result.Evidence,
		"timestamp": result.Timestamp,
	}

	return result
}

// Automated check implementations
func (co *ComplianceOperator) checkMFAEnforcement(check *AutomatedCheck) *CheckResult {
	result := &CheckResult{
		CheckID:   check.ID,
		CheckType: check.CheckType,
		Timestamp: time.Now(),
		Passed:    true,
	}

	minCoverage := check.Parameters["min_mfa_coverage"].(float64)
	
	// Query MFA enrollment
	query := `SELECT 
		COUNT(DISTINCT u.id) as total_users,
		COUNT(DISTINCT CASE WHEN m.user_id IS NOT NULL THEN u.id END) as mfa_users
		FROM users u
		LEFT JOIN mfa_devices m ON u.id = m.user_id AND m.is_active = TRUE`
	
	var totalUsers, mfaUsers int
	row := co.db.QueryRow(query)
	if err := row.Scan(&totalUsers, &mfaUsers); err != nil {
		result.Passed = false
		result.Issues = append(result.Issues, fmt.Sprintf("Failed to check MFA enrollment: %v", err))
		return result
	}

	coverage := float64(mfaUsers) / float64(totalUsers) * 100
	if coverage < minCoverage {
		result.Passed = false
		result.Issues = append(result.Issues, 
			fmt.Sprintf("MFA coverage %.1f%% below required %.1f%%", coverage, minCoverage))
	}

	result.Evidence = append(result.Evidence, 
		fmt.Sprintf("MFA coverage: %.1f%% (%d/%d users)", coverage, mfaUsers, totalUsers))

	return result
}

func (co *ComplianceOperator) checkEncryptionCoverage(check *AutomatedCheck) *CheckResult {
	result := &CheckResult{
		CheckID:   check.ID,
		CheckType: check.CheckType,
		Timestamp: time.Now(),
		Passed:    true,
	}

	minCoverage := check.Parameters["min_coverage"].(float64)
	
	// Check data at rest encryption
	if check.Parameters["data_at_rest"].(bool) {
		coverage := co.calculateEncryptionCoverage("at_rest")
		if coverage < minCoverage {
			result.Passed = false
			result.Issues = append(result.Issues, 
				fmt.Sprintf("Data-at-rest encryption coverage %.1f%% below required %.1f%%", coverage, minCoverage))
		}
		result.Evidence = append(result.Evidence, 
			fmt.Sprintf("Data-at-rest encryption: %.1f%%", coverage))
	}

	// Check data in transit encryption
	if check.Parameters["data_in_transit"].(bool) {
		coverage := co.calculateEncryptionCoverage("in_transit")
		if coverage < minCoverage {
			result.Passed = false
			result.Issues = append(result.Issues, 
				fmt.Sprintf("Data-in-transit encryption coverage %.1f%% below required %.1f%%", coverage, minCoverage))
		}
		result.Evidence = append(result.Evidence, 
			fmt.Sprintf("Data-in-transit encryption: %.1f%%", coverage))
	}

	return result
}

func (co *ComplianceOperator) checkDataMinimization(check *AutomatedCheck) *CheckResult {
	result := &CheckResult{
		CheckID:   check.ID,
		CheckType: check.CheckType,
		Timestamp: time.Now(),
		Passed:    true,
	}

	maxRetention := check.Parameters["max_retention_days"].(float64)
	categories := check.Parameters["data_categories"].([]interface{})
	
	for _, cat := range categories {
		category := cat.(string)
		
		// Check for data exceeding retention period
		query := `SELECT COUNT(*) FROM data_classifications 
			WHERE classification_category = ? 
			AND created_at < DATE_SUB(NOW(), INTERVAL ? DAY)
			AND expires_at IS NULL`
		
		var count int
		row := co.db.QueryRow(query, category, int(maxRetention))
		if err := row.Scan(&count); err != nil {
			result.Issues = append(result.Issues, 
				fmt.Sprintf("Failed to check retention for %s: %v", category, err))
			continue
		}
		
		if count > 0 {
			result.Passed = false
			result.Issues = append(result.Issues, 
				fmt.Sprintf("%d records in category %s exceed retention period", count, category))
		}
		
		result.Evidence = append(result.Evidence, 
			fmt.Sprintf("Category %s: %d records beyond retention", category, count))
	}

	return result
}

func (co *ComplianceOperator) checkUniqueUserIDs(check *AutomatedCheck) *CheckResult {
	result := &CheckResult{
		CheckID:   check.ID,
		CheckType: check.CheckType,
		Timestamp: time.Now(),
		Passed:    true,
	}

	// Check for duplicate user IDs
	query := `SELECT username, COUNT(*) as count 
		FROM users 
		GROUP BY username 
		HAVING count > 1`
	
	rows, err := co.db.Query(query)
	if err != nil {
		result.Passed = false
		result.Issues = append(result.Issues, fmt.Sprintf("Failed to check unique user IDs: %v", err))
		return result
	}
	defer rows.Close()

	duplicates := 0
	for rows.Next() {
		var username string
		var count int
		if err := rows.Scan(&username, &count); err != nil {
			continue
		}
		duplicates++
		result.Issues = append(result.Issues, 
			fmt.Sprintf("Duplicate username: %s (%d occurrences)", username, count))
	}

	if duplicates > 0 {
		result.Passed = false
	}

	result.Evidence = append(result.Evidence, 
		fmt.Sprintf("Duplicate usernames found: %d", duplicates))

	return result
}

func (co *ComplianceOperator) checkTransmissionEncryption(check *AutomatedCheck) *CheckResult {
	result := &CheckResult{
		CheckID:   check.ID,
		CheckType: check.CheckType,
		Timestamp: time.Now(),
		Passed:    true,
	}

	minTLS := check.Parameters["min_tls_version"].(string)
	minCipher := check.Parameters["cipher_strength"].(float64)

	// Check TLS configuration (would integrate with actual infrastructure)
	currentTLS := "1.3" // Would be queried from actual systems
	currentCipher := 256.0

	if currentTLS < minTLS {
		result.Passed = false
		result.Issues = append(result.Issues, 
			fmt.Sprintf("TLS version %s below required %s", currentTLS, minTLS))
	}

	if currentCipher < minCipher {
		result.Passed = false
		result.Issues = append(result.Issues, 
			fmt.Sprintf("Cipher strength %.0f below required %.0f", currentCipher, minCipher))
	}

	result.Evidence = append(result.Evidence, 
		fmt.Sprintf("TLS: %s, Cipher: %.0f bits", currentTLS, currentCipher))

	return result
}

func (co *ComplianceOperator) checkPolicyCompliance(check *AutomatedCheck) *CheckResult {
	result := &CheckResult{
		CheckID:   check.ID,
		CheckType: check.CheckType,
		Timestamp: time.Now(),
		Passed:    true,
	}

	policyName := check.Parameters["policy_name"].(string)
	minVersion := check.Parameters["min_version"].(string)

	// Check policy existence and version
	exists := co.policyEngine.PolicyExists(policyName)
	if !exists {
		result.Passed = false
		result.Issues = append(result.Issues, fmt.Sprintf("Policy %s not found", policyName))
		return result
	}

	version := co.policyEngine.GetPolicyVersion(policyName)
	if version < minVersion {
		result.Passed = false
		result.Issues = append(result.Issues, 
			fmt.Sprintf("Policy %s version %s below required %s", policyName, version, minVersion))
	}

	result.Evidence = append(result.Evidence, 
		fmt.Sprintf("Policy %s version %s", policyName, version))

	return result
}

// Helper methods and types
type ComplianceAssessmentResult struct {
	Framework                  ComplianceFramework      `json:"framework"`
	AssessmentDate             time.Time                `json:"assessment_date"`
	TotalControls              int                      `json:"total_controls"`
	CompliantControls          int                      `json:"compliant_controls"`
	NonCompliantControls       int                      `json:"non_compliant_controls"`
	PartiallyCompliantControls int                      `json:"partially_compliant_controls"`
	ComplianceScore            float64                  `json:"compliance_score"`
	ControlResults             []*ControlAssessmentResult `json:"control_results"`
}

type ControlAssessmentResult struct {
	ControlID      string    `json:"control_id"`
	ControlTitle   string    `json:"control_title"`
	AssessmentDate time.Time `json:"assessment_date"`
	Status         string    `json:"status"`
	Issues         []string  `json:"issues"`
	Evidence       []string  `json:"evidence"`
}

type CheckResult struct {
	CheckID   string    `json:"check_id"`
	CheckType string    `json:"check_type"`
	Timestamp time.Time `json:"timestamp"`
	Passed    bool      `json:"passed"`
	Message   string    `json:"message"`
	Issues    []string  `json:"issues"`
	Evidence  []string  `json:"evidence"`
}

// Database operations
func (co *ComplianceOperator) saveControl(control *ComplianceControl) error {
	requirementsJSON, _ := json.Marshal(control.Requirements)
	checksJSON, _ := json.Marshal(control.AutomatedChecks)
	evidenceJSON, _ := json.Marshal(control.EvidenceTypes)
	metadataJSON, _ := json.Marshal(control.Metadata)

	query := `INSERT INTO compliance_controls 
		(id, framework, control_family, control_title, description, requirements, implementation, 
		automated_checks, evidence_types, risk_level, status, last_assessed, next_assessment, 
		responsible_party, metadata)
		VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
		ON DUPLICATE KEY UPDATE
		control_title = VALUES(control_title),
		description = VALUES(description),
		requirements = VALUES(requirements),
		implementation = VALUES(implementation),
		automated_checks = VALUES(automated_checks),
		evidence_types = VALUES(evidence_types),
		risk_level = VALUES(risk_level),
		status = VALUES(status),
		last_assessed = VALUES(last_assessed),
		next_assessment = VALUES(next_assessment),
		responsible_party = VALUES(responsible_party),
		metadata = VALUES(metadata)`

	_, err := co.db.Exec(query, control.ID, control.Framework, control.ControlFamily,
		control.ControlTitle, control.Description, requirementsJSON, control.Implementation,
		checksJSON, evidenceJSON, control.RiskLevel, control.Status, control.LastAssessed,
		control.NextAssessment, control.ResponsibleParty, metadataJSON)

	return err
}

func (co *ComplianceOperator) getControlsByFramework(framework ComplianceFramework) ([]*ComplianceControl, error) {
	query := `SELECT id, framework, control_family, control_title, description, requirements, 
		implementation, automated_checks, evidence_types, risk_level, status, last_assessed, 
		next_assessment, responsible_party, metadata
		FROM compliance_controls 
		WHERE framework = ? AND status = 'active'`

	rows, err := co.db.Query(query, framework)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var controls []*ComplianceControl
	for rows.Next() {
		control := &ComplianceControl{}
		var requirementsJSON, checksJSON, evidenceJSON, metadataJSON []byte

		err := rows.Scan(&control.ID, &control.Framework, &control.ControlFamily,
			&control.ControlTitle, &control.Description, &requirementsJSON,
			&control.Implementation, &checksJSON, &evidenceJSON, &control.RiskLevel,
			&control.Status, &control.LastAssessed, &control.NextAssessment,
			&control.ResponsibleParty, &metadataJSON)

		if err != nil {
			continue
		}

		json.Unmarshal(requirementsJSON, &control.Requirements)
		json.Unmarshal(checksJSON, &control.AutomatedChecks)
		json.Unmarshal(evidenceJSON, &control.EvidenceTypes)
		json.Unmarshal(metadataJSON, &control.Metadata)

		controls = append(controls, control)
	}

	return controls, nil
}

func (co *ComplianceOperator) recordViolation(violation *ComplianceViolation) error {
	evidenceJSON, _ := json.Marshal(violation.Evidence)
	metadataJSON, _ := json.Marshal(violation.Metadata)

	query := `INSERT INTO compliance_violations 
		(id, control_id, violation_type, severity, description, detected_at, status, 
		evidence, impact, remediation, responsible_party, metadata)
		VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`

	_, err := co.db.Exec(query, violation.ID, violation.ControlID, violation.ViolationType,
		violation.Severity, violation.Description, violation.DetectedAt, violation.Status,
		evidenceJSON, violation.Impact, violation.Remediation, violation.ResponsibleParty,
		metadataJSON)

	return err
}

func (co *ComplianceOperator) calculateEncryptionCoverage(encryptionType string) float64 {
	// This would integrate with actual systems to check encryption status
	// For now, returning a mock value
	switch encryptionType {
	case "at_rest":
		return 95.0
	case "in_transit":
		return 98.0
	default:
		return 0.0
	}
}

func (co *ComplianceOperator) generateID(prefix string) string {
	return fmt.Sprintf("%s_%d_%s", prefix, time.Now().Unix(), co.generateRandomString(8))
}

func (co *ComplianceOperator) generateRandomString(length int) string {
	const chars = "abcdefghijklmnopqrstuvwxyz0123456789"
	result := make([]byte, length)
	for i := range result {
		result[i] = chars[i%len(chars)]
	}
	return string(result)
}

func (co *ComplianceOperator) calculateHash(data interface{}) string {
	jsonData, _ := json.Marshal(data)
	hash := sha256.Sum256(jsonData)
	return fmt.Sprintf("%x", hash)
}

// Placeholder implementations for supporting components
type AuditLogger struct {
	db *sql.DB
}

func NewAuditLogger(db *sql.DB) (*AuditLogger, error) {
	return &AuditLogger{db: db}, nil
}

type DataClassifier struct{}

func NewDataClassifier() *DataClassifier {
	return &DataClassifier{}
}

type PolicyEngine struct {
	db *sql.DB
}

func NewPolicyEngine(db *sql.DB) *PolicyEngine {
	return &PolicyEngine{db: db}
}

func (pe *PolicyEngine) PolicyExists(name string) bool {
	return true // Mock implementation
}

func (pe *PolicyEngine) GetPolicyVersion(name string) string {
	return "1.0" // Mock implementation
}

type EvidenceCollector struct {
	db *sql.DB
}

func NewEvidenceCollector(db *sql.DB) *EvidenceCollector {
	return &EvidenceCollector{db: db}
}

func (ec *EvidenceCollector) StoreEvidence(evidence *Evidence) error {
	attachmentsJSON, _ := json.Marshal(evidence.Attachments)
	metadataJSON, _ := json.Marshal(evidence.Metadata)

	query := `INSERT INTO compliance_evidence 
		(id, type, description, collected_at, source, hash, metadata, attachments)
		VALUES (?, ?, ?, ?, ?, ?, ?, ?)`

	_, err := ec.db.Exec(query, evidence.ID, evidence.Type, evidence.Description,
		evidence.CollectedAt, evidence.Source, evidence.Hash, metadataJSON, attachmentsJSON)

	return err
}

type ReportGenerator struct {
	db *sql.DB
}

func NewReportGenerator(db *sql.DB) *ReportGenerator {
	return &ReportGenerator{db: db}
} 