package core

import (
	"encoding/json"
	"fmt"
	"sync"
	"time"
)

// MetricsOperator handles @metrics operations
type MetricsOperator struct {
	metrics map[string]interface{}
	mutex   sync.RWMutex
	startTime time.Time
}

// NewMetricsOperator creates a new metrics operator
func NewMetricsOperator() *MetricsOperator {
	return &MetricsOperator{
		metrics:   make(map[string]interface{}),
		startTime: time.Now(),
	}
}

// Execute handles @metrics operations
func (m *MetricsOperator) Execute(params string) interface{} {
	m.mutex.Lock()
	defer m.mutex.Unlock()

	// Parse parameters (format: "operation", "metric_name", "value")
	// Example: @metrics("track", "api_calls", 1)
	// Example: @metrics("gauge", "memory_usage", 1024)
	// Example: @metrics("counter", "errors", 1)
	
	// For now, return a placeholder that matches PHP behavior
	// In a real implementation, this would integrate with Prometheus, StatsD, etc.
	
	return fmt.Sprintf("@metrics(%s)", params)
}

// Track adds a metric value
func (m *MetricsOperator) Track(name string, value interface{}) {
	m.mutex.Lock()
	defer m.mutex.Unlock()
	
	m.metrics[name] = map[string]interface{}{
		"value":     value,
		"timestamp": time.Now().Unix(),
		"type":      "track",
	}
}

// Gauge sets a gauge metric
func (m *MetricsOperator) Gauge(name string, value float64) {
	m.mutex.Lock()
	defer m.mutex.Unlock()
	
	m.metrics[name] = map[string]interface{}{
		"value":     value,
		"timestamp": time.Now().Unix(),
		"type":      "gauge",
	}
}

// Counter increments a counter
func (m *MetricsOperator) Counter(name string, increment int64) {
	m.mutex.Lock()
	defer m.mutex.Unlock()
	
	if existing, exists := m.metrics[name]; exists {
		if counter, ok := existing.(map[string]interface{}); ok {
			if currentValue, ok := counter["value"].(int64); ok {
				counter["value"] = currentValue + increment
				counter["timestamp"] = time.Now().Unix()
				return
			}
		}
	}
	
	m.metrics[name] = map[string]interface{}{
		"value":     increment,
		"timestamp": time.Now().Unix(),
		"type":      "counter",
	}
}

// GetMetrics returns all collected metrics
func (m *MetricsOperator) GetMetrics() map[string]interface{} {
	m.mutex.RLock()
	defer m.mutex.RUnlock()
	
	result := make(map[string]interface{})
	for key, value := range m.metrics {
		result[key] = value
	}
	
	// Add system metrics
	result["system"] = map[string]interface{}{
		"uptime":    time.Since(m.startTime).Seconds(),
		"start_time": m.startTime.Unix(),
	}
	
	return result
}

// ExportMetrics exports metrics in various formats
func (m *MetricsOperator) ExportMetrics(format string) (string, error) {
	metrics := m.GetMetrics()
	
	switch format {
	case "json":
		data, err := json.MarshalIndent(metrics, "", "  ")
		return string(data), err
	case "prometheus":
		return m.toPrometheusFormat(metrics), nil
	case "statsd":
		return m.toStatsdFormat(metrics), nil
	default:
		return fmt.Sprintf("%v", metrics), nil
	}
}

// toPrometheusFormat converts metrics to Prometheus format
func (m *MetricsOperator) toPrometheusFormat(metrics map[string]interface{}) string {
	var result string
	
	for name, data := range metrics {
		if metricData, ok := data.(map[string]interface{}); ok {
			if value, exists := metricData["value"]; exists {
				result += fmt.Sprintf("# HELP %s %s metric\n", name, name)
				result += fmt.Sprintf("# TYPE %s %s\n", name, metricData["type"])
				result += fmt.Sprintf("%s %v\n", name, value)
			}
		}
	}
	
	return result
}

// toStatsdFormat converts metrics to StatsD format
func (m *MetricsOperator) toStatsdFormat(metrics map[string]interface{}) string {
	var result string
	
	for name, data := range metrics {
		if metricData, ok := data.(map[string]interface{}); ok {
			if value, exists := metricData["value"]; exists {
				metricType := metricData["type"]
				switch metricType {
				case "counter":
					result += fmt.Sprintf("%s:%v|c\n", name, value)
				case "gauge":
					result += fmt.Sprintf("%s:%v|g\n", name, value)
				case "track":
					result += fmt.Sprintf("%s:%v|ms\n", name, value)
				}
			}
		}
	}
	
	return result
}

// Reset clears all metrics
func (m *MetricsOperator) Reset() {
	m.mutex.Lock()
	defer m.mutex.Unlock()
	
	m.metrics = make(map[string]interface{})
	m.startTime = time.Now()
} 