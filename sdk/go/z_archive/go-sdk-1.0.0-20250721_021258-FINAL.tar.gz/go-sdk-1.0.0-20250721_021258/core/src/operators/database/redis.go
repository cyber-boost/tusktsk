package database

import (
	"context"
	"encoding/json"
	"fmt"
	"time"

	"github.com/redis/go-redis/v9"
)

// RedisOperator handles @redis operations
type RedisOperator struct {
	client *redis.Client
}

// NewRedisOperator creates a new Redis operator
func NewRedisOperator(addr, password string, db int) (*RedisOperator, error) {
	client := redis.NewClient(&redis.Options{
		Addr:     addr,
		Password: password,
		DB:       db,
		PoolSize: 10,
	})

	// Test connection
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	
	if err := client.Ping(ctx).Err(); err != nil {
		return nil, fmt.Errorf("failed to ping Redis: %v", err)
	}

	return &RedisOperator{client: client}, nil
}

// Execute handles @redis operations
func (r *RedisOperator) Execute(params string) interface{} {
	// Parse parameters (format: "operation", "key", "value")
	// Example: @redis("set", "user:123", "John Doe")
	
	return fmt.Sprintf("@redis(%s)", params)
}

// Set sets a key-value pair
func (r *RedisOperator) Set(key string, value interface{}, expiration time.Duration) error {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	return r.client.Set(ctx, key, value, expiration).Err()
}

// Get gets a value by key
func (r *RedisOperator) Get(key string) (string, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	return r.client.Get(ctx, key).Result()
}

// Del deletes one or more keys
func (r *RedisOperator) Del(keys ...string) (int64, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	return r.client.Del(ctx, keys...).Result()
}

// Exists checks if keys exist
func (r *RedisOperator) Exists(keys ...string) (int64, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	return r.client.Exists(ctx, keys...).Result()
}

// Expire sets expiration time for a key
func (r *RedisOperator) Expire(key string, expiration time.Duration) (bool, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	return r.client.Expire(ctx, key, expiration).Result()
}

// TTL gets time to live for a key
func (r *RedisOperator) TTL(key string) (time.Duration, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	return r.client.TTL(ctx, key).Result()
}

// Incr increments a key by 1
func (r *RedisOperator) Incr(key string) (int64, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	return r.client.Incr(ctx, key).Result()
}

// IncrBy increments a key by a specified amount
func (r *RedisOperator) IncrBy(key string, value int64) (int64, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	return r.client.IncrBy(ctx, key, value).Result()
}

// Decr decrements a key by 1
func (r *RedisOperator) Decr(key string) (int64, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	return r.client.Decr(ctx, key).Result()
}

// DecrBy decrements a key by a specified amount
func (r *RedisOperator) DecrBy(key string, value int64) (int64, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	return r.client.DecrBy(ctx, key, value).Result()
}

// HSet sets a field in a hash
func (r *RedisOperator) HSet(key string, field string, value interface{}) error {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	return r.client.HSet(ctx, key, field, value).Err()
}

// HGet gets a field from a hash
func (r *RedisOperator) HGet(key, field string) (string, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	return r.client.HGet(ctx, key, field).Result()
}

// HGetAll gets all fields from a hash
func (r *RedisOperator) HGetAll(key string) (map[string]string, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	return r.client.HGetAll(ctx, key).Result()
}

// HDel deletes fields from a hash
func (r *RedisOperator) HDel(key string, fields ...string) (int64, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	return r.client.HDel(ctx, key, fields...).Result()
}

// LPush pushes values to the left of a list
func (r *RedisOperator) LPush(key string, values ...interface{}) (int64, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	return r.client.LPush(ctx, key, values...).Result()
}

// RPush pushes values to the right of a list
func (r *RedisOperator) RPush(key string, values ...interface{}) (int64, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	return r.client.RPush(ctx, key, values...).Result()
}

// LPop pops a value from the left of a list
func (r *RedisOperator) LPop(key string) (string, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	return r.client.LPop(ctx, key).Result()
}

// RPop pops a value from the right of a list
func (r *RedisOperator) RPop(key string) (string, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	return r.client.RPop(ctx, key).Result()
}

// LRange gets a range of elements from a list
func (r *RedisOperator) LRange(key string, start, stop int64) ([]string, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	return r.client.LRange(ctx, key, start, stop).Result()
}

// SAdd adds members to a set
func (r *RedisOperator) SAdd(key string, members ...interface{}) (int64, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	return r.client.SAdd(ctx, key, members...).Result()
}

// SMembers gets all members of a set
func (r *RedisOperator) SMembers(key string) ([]string, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	return r.client.SMembers(ctx, key).Result()
}

// SRem removes members from a set
func (r *RedisOperator) SRem(key string, members ...interface{}) (int64, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	return r.client.SRem(ctx, key, members...).Result()
}

// ZAdd adds members to a sorted set
func (r *RedisOperator) ZAdd(key string, score float64, member string) (int64, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	return r.client.ZAdd(ctx, key, redis.Z{Score: score, Member: member}).Result()
}

// ZRange gets a range of members from a sorted set
func (r *RedisOperator) ZRange(key string, start, stop int64) ([]string, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	return r.client.ZRange(ctx, key, start, stop).Result()
}

// ZRangeWithScores gets a range of members with scores from a sorted set
func (r *RedisOperator) ZRangeWithScores(key string, start, stop int64) ([]redis.Z, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	return r.client.ZRangeWithScores(ctx, key, start, stop).Result()
}

// Publish publishes a message to a channel
func (r *RedisOperator) Publish(channel string, message interface{}) (int64, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	return r.client.Publish(ctx, channel, message).Result()
}

// Subscribe subscribes to channels
func (r *RedisOperator) Subscribe(channels ...string) *redis.PubSub {
	return r.client.Subscribe(context.Background(), channels...)
}

// PSubscribe subscribes to patterns
func (r *RedisOperator) PSubscribe(patterns ...string) *redis.PubSub {
	return r.client.PSubscribe(context.Background(), patterns...)
}

// SetJSON sets a JSON value
func (r *RedisOperator) SetJSON(key string, value interface{}, expiration time.Duration) error {
	jsonData, err := json.Marshal(value)
	if err != nil {
		return fmt.Errorf("failed to marshal JSON: %v", err)
	}

	return r.Set(key, string(jsonData), expiration)
}

// GetJSON gets and unmarshals a JSON value
func (r *RedisOperator) GetJSON(key string, dest interface{}) error {
	data, err := r.Get(key)
	if err != nil {
		return err
	}

	return json.Unmarshal([]byte(data), dest)
}

// Keys gets keys matching a pattern
func (r *RedisOperator) Keys(pattern string) ([]string, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	return r.client.Keys(ctx, pattern).Result()
}

// Scan scans keys matching a pattern
func (r *RedisOperator) Scan(cursor uint64, match string, count int64) ([]string, uint64, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	return r.client.Scan(ctx, cursor, match, count).Result()
}

// FlushDB flushes the current database
func (r *RedisOperator) FlushDB() error {
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	return r.client.FlushDB(ctx).Err()
}

// FlushAll flushes all databases
func (r *RedisOperator) FlushAll() error {
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	return r.client.FlushAll(ctx).Err()
}

// Info gets Redis server information
func (r *RedisOperator) Info(section ...string) (string, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	return r.client.Info(ctx, section...).Result()
}

// Close closes the Redis connection
func (r *RedisOperator) Close() error {
	return r.client.Close()
} 