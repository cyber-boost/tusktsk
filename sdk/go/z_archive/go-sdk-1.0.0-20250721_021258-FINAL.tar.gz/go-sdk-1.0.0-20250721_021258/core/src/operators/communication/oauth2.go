package communication

import (
	"context"
	"encoding/json"
	"fmt"
	"sync"
	"time"

	"golang.org/x/oauth2"
)

// OAuth2Operator handles @oauth2 operations
type OAuth2Operator struct {
	configs map[string]*oauth2.Config
	tokens  map[string]*oauth2.Token
	mutex   sync.RWMutex
}

// OAuth2Config represents OAuth2 configuration
type OAuth2Config struct {
	ClientID     string   `json:"client_id"`
	ClientSecret string   `json:"client_secret"`
	RedirectURL  string   `json:"redirect_url"`
	Scopes       []string `json:"scopes"`
	AuthURL      string   `json:"auth_url"`
	TokenURL     string   `json:"token_url"`
}

// NewOAuth2Operator creates a new OAuth2 operator
func NewOAuth2Operator() *OAuth2Operator {
	return &OAuth2Operator{
		configs: make(map[string]*oauth2.Config),
		tokens:  make(map[string]*oauth2.Token),
	}
}

// Execute handles @oauth2 operations
func (o *OAuth2Operator) Execute(params string) interface{} {
	// Parse parameters (format: "action,provider,config")
	// Example: @oauth2("configure", "google", '{"client_id":"...","client_secret":"..."}')
	
	if params == "" {
		return fmt.Sprintf("@oauth2(%s)", params)
	}
	
	// Remove quotes if present
	cleanParams := params
	if len(cleanParams) >= 2 && (cleanParams[0] == '"' || cleanParams[0] == '\'') {
		cleanParams = cleanParams[1 : len(cleanParams)-1]
	}
	
	parts := splitParams(cleanParams)
	if len(parts) == 0 {
		return fmt.Sprintf("@oauth2(%s) - Invalid parameters", params)
	}
	
	action := parts[0]
	
	switch action {
	case "configure":
		if len(parts) < 3 {
			return fmt.Sprintf("@oauth2(%s) - Missing provider or config for configure", params)
		}
		return o.Configure(parts[1], parts[2])
	case "auth_url":
		if len(parts) < 2 {
			return fmt.Sprintf("@oauth2(%s) - Missing provider for auth_url", params)
		}
		return o.GetAuthURL(parts[1])
	case "token":
		if len(parts) < 3 {
			return fmt.Sprintf("@oauth2(%s) - Missing provider or code for token", params)
		}
		return o.ExchangeCode(parts[1], parts[2])
	case "refresh":
		if len(parts) < 2 {
			return fmt.Sprintf("@oauth2(%s) - Missing provider for refresh", params)
		}
		return o.RefreshToken(parts[1])
	case "user_info":
		if len(parts) < 2 {
			return fmt.Sprintf("@oauth2(%s) - Missing provider for user_info", params)
		}
		return o.GetUserInfo(parts[1])
	case "list":
		return o.ListProviders()
	default:
		return fmt.Sprintf("@oauth2(%s) - Unknown action: %s", params, action)
	}
}

// Configure sets up OAuth2 configuration for a provider
func (o *OAuth2Operator) Configure(provider, configJSON string) interface{} {
	o.mutex.Lock()
	defer o.mutex.Unlock()
	
	var config OAuth2Config
	if err := json.Unmarshal([]byte(configJSON), &config); err != nil {
		return fmt.Sprintf("Failed to parse OAuth2 config: %v", err)
	}
	
	oauth2Config := &oauth2.Config{
		ClientID:     config.ClientID,
		ClientSecret: config.ClientSecret,
		RedirectURL:  config.RedirectURL,
		Scopes:       config.Scopes,
		Endpoint: oauth2.Endpoint{
			AuthURL:  config.AuthURL,
			TokenURL: config.TokenURL,
		},
	}
	
	o.configs[provider] = oauth2Config
	
	return fmt.Sprintf("Configured OAuth2 for provider: %s", provider)
}

// GetAuthURL generates an authorization URL
func (o *OAuth2Operator) GetAuthURL(provider string) interface{} {
	o.mutex.RLock()
	config, exists := o.configs[provider]
	o.mutex.RUnlock()
	
	if !exists {
		return fmt.Sprintf("OAuth2 provider %s not configured", provider)
	}
	
	authURL := config.AuthCodeURL("state", oauth2.AccessTypeOffline)
	
	return map[string]interface{}{
		"auth_url": authURL,
		"provider": provider,
	}
}

// ExchangeCode exchanges authorization code for access token
func (o *OAuth2Operator) ExchangeCode(provider, code string) interface{} {
	o.mutex.RLock()
	config, exists := o.configs[provider]
	o.mutex.RUnlock()
	
	if !exists {
		return fmt.Sprintf("OAuth2 provider %s not configured", provider)
	}
	
	ctx := context.Background()
	token, err := config.Exchange(ctx, code)
	if err != nil {
		return fmt.Sprintf("Failed to exchange code for token: %v", err)
	}
	
	o.mutex.Lock()
	o.tokens[provider] = token
	o.mutex.Unlock()
	
	return map[string]interface{}{
		"access_token":  token.AccessToken,
		"token_type":    token.TokenType,
		"expires_at":    token.Expiry,
		"refresh_token": token.RefreshToken,
		"provider":      provider,
	}
}

// RefreshToken refreshes an access token
func (o *OAuth2Operator) RefreshToken(provider string) interface{} {
	o.mutex.RLock()
	config, exists := o.configs[provider]
	o.mutex.RUnlock()
	
	if !exists {
		return fmt.Sprintf("OAuth2 provider %s not configured", provider)
	}
	
	o.mutex.RLock()
	token, exists := o.tokens[provider]
	o.mutex.RUnlock()
	
	if !exists {
		return fmt.Sprintf("No token found for provider %s", provider)
	}
	
	ctx := context.Background()
	newToken, err := config.TokenSource(ctx, token).Token()
	if err != nil {
		return fmt.Sprintf("Failed to refresh token: %v", err)
	}
	
	o.mutex.Lock()
	o.tokens[provider] = newToken
	o.mutex.Unlock()
	
	return map[string]interface{}{
		"access_token":  newToken.AccessToken,
		"token_type":    newToken.TokenType,
		"expires_at":    newToken.Expiry,
		"refresh_token": newToken.RefreshToken,
		"provider":      provider,
	}
}

// GetUserInfo retrieves user information using the access token
func (o *OAuth2Operator) GetUserInfo(provider string) interface{} {
	o.mutex.RLock()
	token, exists := o.tokens[provider]
	o.mutex.RUnlock()
	
	if !exists {
		return fmt.Sprintf("No token found for provider %s", provider)
	}
	
	// This is a simplified implementation
	// In a real implementation, you would make API calls to the provider's user info endpoint
	
	client := oauth2.NewClient(context.Background(), oauth2.StaticTokenSource(token))
	
	// Example for Google
	if provider == "google" {
		resp, err := client.Get("https://www.googleapis.com/oauth2/v2/userinfo")
		if err != nil {
			return fmt.Sprintf("Failed to get user info: %v", err)
		}
		defer resp.Body.Close()
		
		var userInfo map[string]interface{}
		if err := json.NewDecoder(resp.Body).Decode(&userInfo); err != nil {
			return fmt.Sprintf("Failed to decode user info: %v", err)
		}
		
		return userInfo
	}
	
	// Generic response for other providers
	return map[string]interface{}{
		"provider":    provider,
		"access_token": token.AccessToken,
		"expires_at":   token.Expiry,
		"message":      "User info endpoint not implemented for this provider",
	}
}

// ListProviders returns all configured OAuth2 providers
func (o *OAuth2Operator) ListProviders() interface{} {
	o.mutex.RLock()
	defer o.mutex.RUnlock()
	
	providers := make([]string, 0, len(o.configs))
	for provider := range o.configs {
		providers = append(providers, provider)
	}
	
	return map[string]interface{}{
		"providers": providers,
		"count":     len(providers),
	}
}

// GetToken retrieves a token for a provider
func (o *OAuth2Operator) GetToken(provider string) (*oauth2.Token, bool) {
	o.mutex.RLock()
	defer o.mutex.RUnlock()
	
	token, exists := o.tokens[provider]
	return token, exists
}

// SetToken sets a token for a provider
func (o *OAuth2Operator) SetToken(provider string, token *oauth2.Token) {
	o.mutex.Lock()
	defer o.mutex.Unlock()
	
	o.tokens[provider] = token
}

// RemoveProvider removes OAuth2 configuration for a provider
func (o *OAuth2Operator) RemoveProvider(provider string) interface{} {
	o.mutex.Lock()
	defer o.mutex.Unlock()
	
	if _, exists := o.configs[provider]; exists {
		delete(o.configs, provider)
		delete(o.tokens, provider)
		return fmt.Sprintf("Removed OAuth2 provider %s", provider)
	}
	
	return fmt.Sprintf("OAuth2 provider %s not found", provider)
}

// ClearProviders removes all OAuth2 configurations
func (o *OAuth2Operator) ClearProviders() interface{} {
	o.mutex.Lock()
	defer o.mutex.Unlock()
	
	count := len(o.configs)
	o.configs = make(map[string]*oauth2.Config)
	o.tokens = make(map[string]*oauth2.Token)
	
	return fmt.Sprintf("Cleared %d OAuth2 providers", count)
}

// IsTokenValid checks if a token is valid
func (o *OAuth2Operator) IsTokenValid(provider string) bool {
	o.mutex.RLock()
	defer o.mutex.RUnlock()
	
	token, exists := o.tokens[provider]
	if !exists {
		return false
	}
	
	return token.Valid()
}

// GetTokenExpiry returns the token expiry time
func (o *OAuth2Operator) GetTokenExpiry(provider string) (time.Time, bool) {
	o.mutex.RLock()
	defer o.mutex.RUnlock()
	
	token, exists := o.tokens[provider]
	if !exists {
		return time.Time{}, false
	}
	
	return token.Expiry, true
}

 