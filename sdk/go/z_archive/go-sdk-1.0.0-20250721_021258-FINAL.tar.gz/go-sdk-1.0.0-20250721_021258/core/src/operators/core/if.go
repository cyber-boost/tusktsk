package core

import (
	"fmt"
	"regexp"
	"strconv"
	"strings"
	"sync"
)

// IfOperator handles @if operations
type IfOperator struct {
	variables map[string]interface{}
	mutex     sync.RWMutex
}

// NewIfOperator creates a new conditional operator
func NewIfOperator() *IfOperator {
	return &IfOperator{
		variables: make(map[string]interface{}),
	}
}

// Execute handles @if operations
func (i *IfOperator) Execute(params string) interface{} {
	// Parse parameters (format: "condition,then_value,else_value")
	// Example: @if("$count > 10", "many", "few")
	
	if params == "" {
		return fmt.Sprintf("@if(%s)", params)
	}
	
	// Remove quotes if present
	cleanParams := params
	if len(cleanParams) >= 2 && (cleanParams[0] == '"' || cleanParams[0] == '\'') {
		cleanParams = cleanParams[1 : len(cleanParams)-1]
	}
	
	parts := splitParams(cleanParams)
	if len(parts) == 0 {
		return fmt.Sprintf("@if(%s) - Invalid parameters", params)
	}
	
	condition := parts[0]
	thenValue := ""
	if len(parts) > 1 {
		thenValue = parts[1]
	}
	
	elseValue := ""
	if len(parts) > 2 {
		elseValue = parts[2]
	}
	
	return i.IfThenElse(condition, thenValue, elseValue)
}

// SetVariable sets a variable for conditional evaluation
func (i *IfOperator) SetVariable(name string, value interface{}) {
	i.mutex.Lock()
	defer i.mutex.Unlock()
	
	i.variables[name] = value
}

// GetVariable gets a variable value
func (i *IfOperator) GetVariable(name string) interface{} {
	i.mutex.RLock()
	defer i.mutex.RUnlock()
	
	return i.variables[name]
}

// Evaluate evaluates a condition
func (i *IfOperator) Evaluate(condition string) bool {
	condition = strings.TrimSpace(condition)
	
	// Handle basic boolean values
	switch strings.ToLower(condition) {
	case "true":
		return true
	case "false":
		return false
	}
	
	// Handle variable references
	if strings.HasPrefix(condition, "$") {
		varName := condition[1:]
		value := i.GetVariable(varName)
		if value == nil {
			return false
		}
		return i.isTruthy(value)
	}
	
	// Handle comparisons
	if strings.Contains(condition, "==") {
		return i.evaluateEquality(condition)
	}
	
	if strings.Contains(condition, "!=") {
		return i.evaluateInequality(condition)
	}
	
	if strings.Contains(condition, ">") {
		return i.evaluateGreaterThan(condition)
	}
	
	if strings.Contains(condition, "<") {
		return i.evaluateLessThan(condition)
	}
	
	if strings.Contains(condition, ">=") {
		return i.evaluateGreaterEqual(condition)
	}
	
	if strings.Contains(condition, "<=") {
		return i.evaluateLessEqual(condition)
	}
	
	// Handle string operations
	if strings.Contains(condition, "contains") {
		return i.evaluateContains(condition)
	}
	
	if strings.Contains(condition, "starts_with") {
		return i.evaluateStartsWith(condition)
	}
	
	if strings.Contains(condition, "ends_with") {
		return i.evaluateEndsWith(condition)
	}
	
	// Default: treat as truthy check
	return i.isTruthy(condition)
}

// IfThenElse evaluates condition and returns appropriate value
func (i *IfOperator) IfThenElse(condition string, thenValue, elseValue interface{}) interface{} {
	if i.Evaluate(condition) {
		return thenValue
	}
	return elseValue
}

// isTruthy checks if a value is truthy
func (i *IfOperator) isTruthy(value interface{}) bool {
	if value == nil {
		return false
	}
	
	switch v := value.(type) {
	case bool:
		return v
	case string:
		return v != "" && strings.ToLower(v) != "false" && strings.ToLower(v) != "0"
	case int:
		return v != 0
	case float64:
		return v != 0
	case []interface{}:
		return len(v) > 0
	case map[string]interface{}:
		return len(v) > 0
	default:
		return true
	}
}

// evaluateEquality evaluates == comparisons
func (i *IfOperator) evaluateEquality(condition string) bool {
	parts := strings.Split(condition, "==")
	if len(parts) != 2 {
		return false
	}
	
	left := strings.TrimSpace(parts[0])
	right := strings.TrimSpace(parts[1])
	
	leftValue := i.resolveValue(left)
	rightValue := i.resolveValue(right)
	
	return leftValue == rightValue
}

// evaluateInequality evaluates != comparisons
func (i *IfOperator) evaluateInequality(condition string) bool {
	parts := strings.Split(condition, "!=")
	if len(parts) != 2 {
		return false
	}
	
	left := strings.TrimSpace(parts[0])
	right := strings.TrimSpace(parts[1])
	
	leftValue := i.resolveValue(left)
	rightValue := i.resolveValue(right)
	
	return leftValue != rightValue
}

// evaluateGreaterThan evaluates > comparisons
func (i *IfOperator) evaluateGreaterThan(condition string) bool {
	parts := strings.Split(condition, ">")
	if len(parts) != 2 {
		return false
	}
	
	left := strings.TrimSpace(parts[0])
	right := strings.TrimSpace(parts[1])
	
	leftNum, leftOk := i.resolveNumber(left)
	rightNum, rightOk := i.resolveNumber(right)
	
	if !leftOk || !rightOk {
		return false
	}
	
	return leftNum > rightNum
}

// evaluateLessThan evaluates < comparisons
func (i *IfOperator) evaluateLessThan(condition string) bool {
	parts := strings.Split(condition, "<")
	if len(parts) != 2 {
		return false
	}
	
	left := strings.TrimSpace(parts[0])
	right := strings.TrimSpace(parts[1])
	
	leftNum, leftOk := i.resolveNumber(left)
	rightNum, rightOk := i.resolveNumber(right)
	
	if !leftOk || !rightOk {
		return false
	}
	
	return leftNum < rightNum
}

// evaluateGreaterEqual evaluates >= comparisons
func (i *IfOperator) evaluateGreaterEqual(condition string) bool {
	parts := strings.Split(condition, ">=")
	if len(parts) != 2 {
		return false
	}
	
	left := strings.TrimSpace(parts[0])
	right := strings.TrimSpace(parts[1])
	
	leftNum, leftOk := i.resolveNumber(left)
	rightNum, rightOk := i.resolveNumber(right)
	
	if !leftOk || !rightOk {
		return false
	}
	
	return leftNum >= rightNum
}

// evaluateLessEqual evaluates <= comparisons
func (i *IfOperator) evaluateLessEqual(condition string) bool {
	parts := strings.Split(condition, "<=")
	if len(parts) != 2 {
		return false
	}
	
	left := strings.TrimSpace(parts[0])
	right := strings.TrimSpace(parts[1])
	
	leftNum, leftOk := i.resolveNumber(left)
	rightNum, rightOk := i.resolveNumber(right)
	
	if !leftOk || !rightOk {
		return false
	}
	
	return leftNum <= rightNum
}

// evaluateContains evaluates contains operations
func (i *IfOperator) evaluateContains(condition string) bool {
	re := regexp.MustCompile(`(.+)\s+contains\s+(.+)`)
	matches := re.FindStringSubmatch(condition)
	if len(matches) != 3 {
		return false
	}
	
	container := strings.TrimSpace(matches[1])
	item := strings.TrimSpace(matches[2])
	
	containerValue := i.resolveValue(container)
	itemValue := i.resolveValue(item)
	
	containerStr, ok := containerValue.(string)
	if !ok {
		return false
	}
	
	itemStr, ok := itemValue.(string)
	if !ok {
		return false
	}
	
	return strings.Contains(containerStr, itemStr)
}

// evaluateStartsWith evaluates starts_with operations
func (i *IfOperator) evaluateStartsWith(condition string) bool {
	re := regexp.MustCompile(`(.+)\s+starts_with\s+(.+)`)
	matches := re.FindStringSubmatch(condition)
	if len(matches) != 3 {
		return false
	}
	
	text := strings.TrimSpace(matches[1])
	prefix := strings.TrimSpace(matches[2])
	
	textValue := i.resolveValue(text)
	prefixValue := i.resolveValue(prefix)
	
	textStr, ok := textValue.(string)
	if !ok {
		return false
	}
	
	prefixStr, ok := prefixValue.(string)
	if !ok {
		return false
	}
	
	return strings.HasPrefix(textStr, prefixStr)
}

// evaluateEndsWith evaluates ends_with operations
func (i *IfOperator) evaluateEndsWith(condition string) bool {
	re := regexp.MustCompile(`(.+)\s+ends_with\s+(.+)`)
	matches := re.FindStringSubmatch(condition)
	if len(matches) != 3 {
		return false
	}
	
	text := strings.TrimSpace(matches[1])
	suffix := strings.TrimSpace(matches[2])
	
	textValue := i.resolveValue(text)
	suffixValue := i.resolveValue(suffix)
	
	textStr, ok := textValue.(string)
	if !ok {
		return false
	}
	
	suffixStr, ok := suffixValue.(string)
	if !ok {
		return false
	}
	
	return strings.HasSuffix(textStr, suffixStr)
}

// resolveValue resolves a value (variable or literal)
func (i *IfOperator) resolveValue(value string) interface{} {
	value = strings.TrimSpace(value)
	
	// Remove quotes if present
	if len(value) >= 2 && (value[0] == '"' || value[0] == '\'') {
		return value[1 : len(value)-1]
	}
	
	// Check if it's a variable
	if strings.HasPrefix(value, "$") {
		varName := value[1:]
		return i.GetVariable(varName)
	}
	
	// Try to parse as number
	if num, err := strconv.Atoi(value); err == nil {
		return num
	}
	
	if num, err := strconv.ParseFloat(value, 64); err == nil {
		return num
	}
	
	// Try to parse as boolean
	if value == "true" || value == "false" {
		return value == "true"
	}
	
	// Return as string
	return value
}

// resolveNumber resolves a value as a number
func (i *IfOperator) resolveNumber(value string) (float64, bool) {
	value = strings.TrimSpace(value)
	
	// Remove quotes if present
	if len(value) >= 2 && (value[0] == '"' || value[0] == '\'') {
		value = value[1 : len(value)-1]
	}
	
	// Check if it's a variable
	if strings.HasPrefix(value, "$") {
		varName := value[1:]
		varValue := i.GetVariable(varName)
		
		switch v := varValue.(type) {
		case int:
			return float64(v), true
		case float64:
			return v, true
		case string:
			if num, err := strconv.ParseFloat(v, 64); err == nil {
				return num, true
			}
		}
		return 0, false
	}
	
	// Try to parse as number
	if num, err := strconv.ParseFloat(value, 64); err == nil {
		return num, true
	}
	
	return 0, false
}

 