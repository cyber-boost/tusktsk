package core

import (
	"encoding/json"
	"fmt"
	"sync"
	"time"
)

// LearningPattern represents a learned pattern
type LearningPattern struct {
	Input     interface{} `json:"input"`
	Output    interface{} `json:"output"`
	Frequency int         `json:"frequency"`
	LastUsed  time.Time   `json:"last_used"`
	Created   time.Time   `json:"created"`
	Accuracy  float64     `json:"accuracy"`
}

// LearnOperator handles @learn operations
type LearnOperator struct {
	patterns map[string]LearningPattern
	mutex    sync.RWMutex
}

// NewLearnOperator creates a new learning operator
func NewLearnOperator() *LearnOperator {
	return &LearnOperator{
		patterns: make(map[string]LearningPattern),
	}
}

// Execute handles @learn operations
func (l *LearnOperator) Execute(params string) interface{} {
	// Parse parameters (format: "action,input,output")
	// Example: @learn("add", "user_login", "success")
	
	if params == "" {
		return fmt.Sprintf("@learn(%s)", params)
	}
	
	// Remove quotes if present
	cleanParams := params
	if len(cleanParams) >= 2 && (cleanParams[0] == '"' || cleanParams[0] == '\'') {
		cleanParams = cleanParams[1 : len(cleanParams)-1]
	}
	
	parts := splitParams(cleanParams)
	if len(parts) == 0 {
		return fmt.Sprintf("@learn(%s) - Invalid parameters", params)
	}
	
	action := parts[0]
	
	switch action {
	case "add":
		if len(parts) < 3 {
			return fmt.Sprintf("@learn(%s) - Missing input or output for add", params)
		}
		return l.AddPattern(parts[1], parts[2])
	case "get":
		if len(parts) < 2 {
			return fmt.Sprintf("@learn(%s) - Missing input for get", params)
		}
		return l.GetPattern(parts[1])
	case "predict":
		if len(parts) < 2 {
			return fmt.Sprintf("@learn(%s) - Missing input for predict", params)
		}
		return l.Predict(parts[1])
	case "list":
		return l.ListPatterns()
	case "clear":
		return l.ClearPatterns()
	default:
		return fmt.Sprintf("@learn(%s) - Unknown action: %s", params, action)
	}
}

// AddPattern adds a new learning pattern
func (l *LearnOperator) AddPattern(input, output interface{}) interface{} {
	l.mutex.Lock()
	defer l.mutex.Unlock()
	
	inputKey := fmt.Sprintf("%v", input)
	
	pattern, exists := l.patterns[inputKey]
	if exists {
		// Update existing pattern
		pattern.Frequency++
		pattern.LastUsed = time.Now()
		
		// Update accuracy based on consistency
		if pattern.Output == output {
			pattern.Accuracy = 1.0
		} else {
			pattern.Accuracy = 0.5 // Reduce accuracy for inconsistent patterns
		}
	} else {
		// Create new pattern
		pattern = LearningPattern{
			Input:     input,
			Output:    output,
			Frequency: 1,
			LastUsed:  time.Now(),
			Created:   time.Now(),
			Accuracy:  1.0,
		}
	}
	
	l.patterns[inputKey] = pattern
	
	return fmt.Sprintf("Learned pattern: %v -> %v (frequency: %d, accuracy: %.2f)", 
		input, output, pattern.Frequency, pattern.Accuracy)
}

// GetPattern retrieves a learned pattern
func (l *LearnOperator) GetPattern(input interface{}) interface{} {
	l.mutex.RLock()
	defer l.mutex.RUnlock()
	
	inputKey := fmt.Sprintf("%v", input)
	pattern, exists := l.patterns[inputKey]
	
	if !exists {
		return nil
	}
	
	return pattern
}

// Predict predicts output based on learned patterns
func (l *LearnOperator) Predict(input interface{}) interface{} {
	l.mutex.RLock()
	defer l.mutex.RUnlock()
	
	inputKey := fmt.Sprintf("%v", input)
	pattern, exists := l.patterns[inputKey]
	
	if !exists {
		return fmt.Sprintf("No pattern found for input: %v", input)
	}
	
	// Update last used time
	l.mutex.RUnlock()
	l.mutex.Lock()
	pattern.LastUsed = time.Now()
	l.patterns[inputKey] = pattern
	l.mutex.Unlock()
	l.mutex.RLock()
	
	return map[string]interface{}{
		"prediction": pattern.Output,
		"confidence": pattern.Accuracy,
		"frequency":  pattern.Frequency,
	}
}

// ListPatterns returns all learned patterns
func (l *LearnOperator) ListPatterns() interface{} {
	l.mutex.RLock()
	defer l.mutex.RUnlock()
	
	patterns := make([]LearningPattern, 0, len(l.patterns))
	for _, pattern := range l.patterns {
		patterns = append(patterns, pattern)
	}
	
	return patterns
}

// ClearPatterns removes all learned patterns
func (l *LearnOperator) ClearPatterns() interface{} {
	l.mutex.Lock()
	defer l.mutex.Unlock()
	
	count := len(l.patterns)
	l.patterns = make(map[string]LearningPattern)
	
	return fmt.Sprintf("Cleared %d learned patterns", count)
}

// GetPatternsByFrequency returns patterns sorted by frequency
func (l *LearnOperator) GetPatternsByFrequency() []LearningPattern {
	l.mutex.RLock()
	defer l.mutex.RUnlock()
	
	patterns := make([]LearningPattern, 0, len(l.patterns))
	for _, pattern := range l.patterns {
		patterns = append(patterns, pattern)
	}
	
	// Sort by frequency (descending)
	for i := 0; i < len(patterns)-1; i++ {
		for j := i + 1; j < len(patterns); j++ {
			if patterns[i].Frequency < patterns[j].Frequency {
				patterns[i], patterns[j] = patterns[j], patterns[i]
			}
		}
	}
	
	return patterns
}

// GetPatternsByAccuracy returns patterns sorted by accuracy
func (l *LearnOperator) GetPatternsByAccuracy() []LearningPattern {
	l.mutex.RLock()
	defer l.mutex.RUnlock()
	
	patterns := make([]LearningPattern, 0, len(l.patterns))
	for _, pattern := range l.patterns {
		patterns = append(patterns, pattern)
	}
	
	// Sort by accuracy (descending)
	for i := 0; i < len(patterns)-1; i++ {
		for j := i + 1; j < len(patterns); j++ {
			if patterns[i].Accuracy < patterns[j].Accuracy {
				patterns[i], patterns[j] = patterns[j], patterns[i]
			}
		}
	}
	
	return patterns
}

// GetPatternsByRecency returns patterns sorted by last used time
func (l *LearnOperator) GetPatternsByRecency() []LearningPattern {
	l.mutex.RLock()
	defer l.mutex.RUnlock()
	
	patterns := make([]LearningPattern, 0, len(l.patterns))
	for _, pattern := range l.patterns {
		patterns = append(patterns, pattern)
	}
	
	// Sort by last used time (descending)
	for i := 0; i < len(patterns)-1; i++ {
		for j := i + 1; j < len(patterns); j++ {
			if patterns[i].LastUsed.Before(patterns[j].LastUsed) {
				patterns[i], patterns[j] = patterns[j], patterns[i]
			}
		}
	}
	
	return patterns
}

// Stats returns learning statistics
func (l *LearnOperator) Stats() map[string]interface{} {
	l.mutex.RLock()
	defer l.mutex.RUnlock()
	
	total := len(l.patterns)
	totalFrequency := 0
	avgAccuracy := 0.0
	
	for _, pattern := range l.patterns {
		totalFrequency += pattern.Frequency
		avgAccuracy += pattern.Accuracy
	}
	
	if total > 0 {
		avgAccuracy /= float64(total)
	}
	
	return map[string]interface{}{
		"total_patterns":  total,
		"total_frequency": totalFrequency,
		"avg_accuracy":    avgAccuracy,
		"avg_frequency":   float64(totalFrequency) / float64(total),
	}
}

// ExportPatterns exports patterns as JSON
func (l *LearnOperator) ExportPatterns() (string, error) {
	l.mutex.RLock()
	defer l.mutex.RUnlock()
	
	jsonBytes, err := json.MarshalIndent(l.patterns, "", "  ")
	if err != nil {
		return "", fmt.Errorf("failed to marshal patterns: %v", err)
	}
	
	return string(jsonBytes), nil
}

// ImportPatterns imports patterns from JSON
func (l *LearnOperator) ImportPatterns(jsonStr string) error {
	var patterns map[string]LearningPattern
	if err := json.Unmarshal([]byte(jsonStr), &patterns); err != nil {
		return fmt.Errorf("failed to unmarshal patterns: %v", err)
	}
	
	l.mutex.Lock()
	defer l.mutex.Unlock()
	
	l.patterns = patterns
	return nil
}

 