package communication

import (
	"fmt"
	"time"

	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials/insecure"
)

// GRPCOperator handles @grpc operations
type GRPCOperator struct {
	connections map[string]*grpc.ClientConn
	timeout     time.Duration
}

// GRPCRequest represents a gRPC request
type GRPCRequest struct {
	Service   string                 `json:"service"`
	Method    string                 `json:"method"`
	Data      map[string]interface{} `json:"data"`
	Metadata  map[string]string      `json:"metadata"`
	Timeout   time.Duration          `json:"timeout"`
}

// GRPCResponse represents a gRPC response
type GRPCResponse struct {
	Data     interface{}            `json:"data"`
	Metadata map[string]string      `json:"metadata"`
	Error    string                 `json:"error,omitempty"`
	Status   string                 `json:"status"`
}

// NewGRPCOperator creates a new gRPC operator
func NewGRPCOperator() *GRPCOperator {
	return &GRPCOperator{
		connections: make(map[string]*grpc.ClientConn),
		timeout:     30 * time.Second,
	}
}

// Execute handles @grpc operations
func (g *GRPCOperator) Execute(params string) interface{} {
	// Parse parameters (format: "service", "method", "data", "metadata")
	// Example: @grpc("user.UserService", "GetUser", '{"id": "123"}', '{"auth": "token"}')
	
	return fmt.Sprintf("@grpc(%s)", params)
}

// Connect establishes a gRPC connection to a server
func (g *GRPCOperator) Connect(name, address string) error {
	conn, err := grpc.Dial(address, grpc.WithTransportCredentials(insecure.NewCredentials()))
	if err != nil {
		return fmt.Errorf("failed to connect to gRPC server %s at %s: %v", name, address, err)
	}

	g.connections[name] = conn
	return nil
}

// Disconnect closes a gRPC connection
func (g *GRPCOperator) Disconnect(name string) error {
	if conn, exists := g.connections[name]; exists {
		err := conn.Close()
		delete(g.connections, name)
		return err
	}
	return fmt.Errorf("connection %s not found", name)
}

// Call executes a gRPC method call
func (g *GRPCOperator) Call(connectionName, service, method string, data map[string]interface{}, metadata map[string]string) (*GRPCResponse, error) {
	conn, exists := g.connections[connectionName]
	if !exists {
		return nil, fmt.Errorf("connection %s not found", connectionName)
	}

	// For now, return a placeholder response since we need protobuf definitions
	// In a real implementation, this would use reflection or generated code
	response := &GRPCResponse{
		Data:     data,
		Metadata: metadata,
		Status:   "success",
		Error:    "gRPC implementation requires protobuf definitions",
	}

	// Use conn to avoid unused variable error
	_ = conn

	return response, nil
}

// SetTimeout sets the default timeout for gRPC calls
func (g *GRPCOperator) SetTimeout(timeout time.Duration) {
	g.timeout = timeout
}

// ListConnections returns a list of active connection names
func (g *GRPCOperator) ListConnections() []string {
	names := make([]string, 0, len(g.connections))
	for name := range g.connections {
		names = append(names, name)
	}
	return names
}

// GetConnectionStatus returns the status of a connection
func (g *GRPCOperator) GetConnectionStatus(name string) string {
	if conn, exists := g.connections[name]; exists {
		if conn.GetState().String() == "READY" {
			return "connected"
		}
		return conn.GetState().String()
	}
	return "not_found"
}

// HealthCheck performs a health check on a connection
func (g *GRPCOperator) HealthCheck(name string) error {
	if conn, exists := g.connections[name]; exists {
		// Try to get connection state
		state := conn.GetState()
		if state.String() != "READY" {
			return fmt.Errorf("connection not ready: %s", state.String())
		}
		
		return nil
	}
	return fmt.Errorf("connection %s not found", name)
}

// Close closes all gRPC connections
func (g *GRPCOperator) Close() error {
	var lastError error
	for name, conn := range g.connections {
		if err := conn.Close(); err != nil {
			lastError = fmt.Errorf("failed to close connection %s: %v", name, err)
		}
	}
	g.connections = make(map[string]*grpc.ClientConn)
	return lastError
} 