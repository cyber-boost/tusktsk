package main

import (
	"sync"
	"time"
	"runtime"
	"runtime/pprof"
	"os"
	"fmt"
	"encoding/json"
)

// CacheEntry represents a cached item with expiration
type CacheEntry struct {
	Value      interface{}
	Expiration time.Time
	AccessCount int64
	LastAccess  time.Time
}

// PerformanceMonitor tracks performance metrics
type PerformanceMonitor struct {
	mu              sync.RWMutex
	parseTimes      []time.Duration
	queryTimes      []time.Duration
	cacheHits       int64
	cacheMisses     int64
	memoryUsage     []uint64
	startTime       time.Time
	profilingActive bool
}

// CacheManager provides intelligent caching for parsed configurations
type CacheManager struct {
	mu       sync.RWMutex
	cache    map[string]*CacheEntry
	maxSize  int
	ttl      time.Duration
	monitor  *PerformanceMonitor
}

// NewCacheManager creates a new cache manager
func NewCacheManager(maxSize int, ttl time.Duration) *CacheManager {
	cm := &CacheManager{
		cache:   make(map[string]*CacheEntry),
		maxSize: maxSize,
		ttl:     ttl,
		monitor: &PerformanceMonitor{
			startTime: time.Now(),
		},
	}
	
	// Start cleanup goroutine
	go cm.cleanup()
	
	return cm
}

// Get retrieves a value from cache
func (cm *CacheManager) Get(key string) (interface{}, bool) {
	cm.mu.RLock()
	defer cm.mu.RUnlock()
	
	entry, exists := cm.cache[key]
	if !exists {
		cm.monitor.cacheMisses++
		return nil, false
	}
	
	// Check expiration
	if time.Now().After(entry.Expiration) {
		cm.mu.RUnlock()
		cm.mu.Lock()
		delete(cm.cache, key)
		cm.mu.Unlock()
		cm.mu.RLock()
		cm.monitor.cacheMisses++
		return nil, false
	}
	
	// Update access statistics
	entry.AccessCount++
	entry.LastAccess = time.Now()
	cm.monitor.cacheHits++
	
	return entry.Value, true
}

// Set stores a value in cache
func (cm *CacheManager) Set(key string, value interface{}) {
	cm.mu.Lock()
	defer cm.mu.Unlock()
	
	// Check if we need to evict items
	if len(cm.cache) >= cm.maxSize {
		cm.evictLRU()
	}
	
	cm.cache[key] = &CacheEntry{
		Value:      value,
		Expiration: time.Now().Add(cm.ttl),
		AccessCount: 0,
		LastAccess:  time.Now(),
	}
}

// cleanup removes expired entries
func (cm *CacheManager) cleanup() {
	ticker := time.NewTicker(cm.ttl / 2)
	defer ticker.Stop()
	
	for range ticker.C {
		cm.mu.Lock()
		now := time.Now()
		for key, entry := range cm.cache {
			if now.After(entry.Expiration) {
				delete(cm.cache, key)
			}
		}
		cm.mu.Unlock()
	}
}

// evictLRU removes the least recently used entry
func (cm *CacheManager) evictLRU() {
	var oldestKey string
	var oldestTime time.Time
	
	for key, entry := range cm.cache {
		if oldestKey == "" || entry.LastAccess.Before(oldestTime) {
			oldestKey = key
			oldestTime = entry.LastAccess
		}
	}
	
	if oldestKey != "" {
		delete(cm.cache, oldestKey)
	}
}

// GetStats returns cache statistics
func (cm *CacheManager) GetStats() map[string]interface{} {
	cm.mu.RLock()
	defer cm.mu.RUnlock()
	
	totalRequests := cm.monitor.cacheHits + cm.monitor.cacheMisses
	hitRate := 0.0
	if totalRequests > 0 {
		hitRate = float64(cm.monitor.cacheHits) / float64(totalRequests) * 100
	}
	
	return map[string]interface{}{
		"size":           len(cm.cache),
		"max_size":       cm.maxSize,
		"hits":           cm.monitor.cacheHits,
		"misses":         cm.monitor.cacheMisses,
		"hit_rate":       hitRate,
		"total_requests": totalRequests,
	}
}

// PerformanceOptimizer provides various optimization strategies
type PerformanceOptimizer struct {
	cacheManager *CacheManager
	monitor      *PerformanceMonitor
	config       *OptimizationConfig
}

// OptimizationConfig holds optimization settings
type OptimizationConfig struct {
	EnableCaching     bool          `json:"enable_caching"`
	CacheSize         int           `json:"cache_size"`
	CacheTTL          time.Duration `json:"cache_ttl"`
	EnableProfiling   bool          `json:"enable_profiling"`
	MemoryThreshold   uint64        `json:"memory_threshold"`
	ParseConcurrency  int           `json:"parse_concurrency"`
	EnableCompression bool          `json:"enable_compression"`
}

// NewPerformanceOptimizer creates a new performance optimizer
func NewPerformanceOptimizer(config *OptimizationConfig) *PerformanceOptimizer {
	if config == nil {
		config = &OptimizationConfig{
			EnableCaching:    true,
			CacheSize:        1000,
			CacheTTL:         5 * time.Minute,
			EnableProfiling:  false,
			MemoryThreshold:  100 * 1024 * 1024, // 100MB
			ParseConcurrency: runtime.NumCPU(),
		}
	}
	
	po := &PerformanceOptimizer{
		config: config,
		monitor: &PerformanceMonitor{
			startTime: time.Now(),
		},
	}
	
	if config.EnableCaching {
		po.cacheManager = NewCacheManager(config.CacheSize, config.CacheTTL)
	}
	
	return po
}

// StartProfiling begins performance profiling
func (po *PerformanceOptimizer) StartProfiling(profileType string) error {
	if !po.config.EnableProfiling {
		return fmt.Errorf("profiling is disabled")
	}
	
	po.monitor.mu.Lock()
	defer po.monitor.mu.Unlock()
	
	if po.monitor.profilingActive {
		return fmt.Errorf("profiling already active")
	}
	
	switch profileType {
	case "cpu":
		file, err := os.Create("tusklang_cpu.prof")
		if err != nil {
			return err
		}
		pprof.StartCPUProfile(file)
	case "memory":
		_ = pprof.Lookup("heap")
	case "goroutine":
		_ = pprof.Lookup("goroutine")
	default:
		return fmt.Errorf("unknown profile type: %s", profileType)
	}
	
	po.monitor.profilingActive = true
	return nil
}

// StopProfiling stops performance profiling
func (po *PerformanceOptimizer) StopProfiling(profileType string) error {
	po.monitor.mu.Lock()
	defer po.monitor.mu.Unlock()
	
	if !po.monitor.profilingActive {
		return fmt.Errorf("profiling not active")
	}
	
	switch profileType {
	case "cpu":
		pprof.StopCPUProfile()
	case "memory", "goroutine":
		file, err := os.Create(fmt.Sprintf("tusklang_%s.prof", profileType))
		if err != nil {
			return err
		}
		defer file.Close()
		profile := pprof.Lookup(profileType)
		if profile != nil {
			profile.WriteTo(file, 0)
		}
	}
	
	po.monitor.profilingActive = false
	return nil
}

// RecordParseTime records the time taken for parsing
func (po *PerformanceOptimizer) RecordParseTime(duration time.Duration) {
	po.monitor.mu.Lock()
	defer po.monitor.mu.Unlock()
	
	po.monitor.parseTimes = append(po.monitor.parseTimes, duration)
	
	// Keep only last 1000 measurements
	if len(po.monitor.parseTimes) > 1000 {
		po.monitor.parseTimes = po.monitor.parseTimes[1:]
	}
}

// RecordQueryTime records the time taken for database queries
func (po *PerformanceOptimizer) RecordQueryTime(duration time.Duration) {
	po.monitor.mu.Lock()
	defer po.monitor.mu.Unlock()
	
	po.monitor.queryTimes = append(po.monitor.queryTimes, duration)
	
	// Keep only last 1000 measurements
	if len(po.monitor.queryTimes) > 1000 {
		po.monitor.queryTimes = po.monitor.queryTimes[1:]
	}
}

// GetMemoryUsage returns current memory usage
func (po *PerformanceOptimizer) GetMemoryUsage() uint64 {
	var m runtime.MemStats
	runtime.ReadMemStats(&m)
	return m.Alloc
}

// CheckMemoryThreshold checks if memory usage exceeds threshold
func (po *PerformanceOptimizer) CheckMemoryThreshold() bool {
	usage := po.GetMemoryUsage()
	return usage > po.config.MemoryThreshold
}

// ForceGC forces garbage collection
func (po *PerformanceOptimizer) ForceGC() {
	runtime.GC()
}

// GetPerformanceReport returns a comprehensive performance report
func (po *PerformanceOptimizer) GetPerformanceReport() map[string]interface{} {
	po.monitor.mu.RLock()
	defer po.monitor.mu.RUnlock()
	
	// Calculate average parse time
	var avgParseTime time.Duration
	if len(po.monitor.parseTimes) > 0 {
		total := time.Duration(0)
		for _, t := range po.monitor.parseTimes {
			total += t
		}
		avgParseTime = total / time.Duration(len(po.monitor.parseTimes))
	}
	
	// Calculate average query time
	var avgQueryTime time.Duration
	if len(po.monitor.queryTimes) > 0 {
		total := time.Duration(0)
		for _, t := range po.monitor.queryTimes {
			total += t
		}
		avgQueryTime = total / time.Duration(len(po.monitor.queryTimes))
	}
	
	report := map[string]interface{}{
		"uptime":           time.Since(po.monitor.startTime).String(),
		"parse_count":      len(po.monitor.parseTimes),
		"avg_parse_time":   avgParseTime.String(),
		"query_count":      len(po.monitor.queryTimes),
		"avg_query_time":   avgQueryTime.String(),
		"memory_usage":     po.GetMemoryUsage(),
		"memory_threshold": po.config.MemoryThreshold,
		"profiling_active": po.monitor.profilingActive,
	}
	
	if po.cacheManager != nil {
		report["cache_stats"] = po.cacheManager.GetStats()
	}
	
	return report
}

// OptimizeParser applies performance optimizations to a parser
func (po *PerformanceOptimizer) OptimizeParser(parser *EnhancedParser) {
	if po.cacheManager != nil {
		// Add caching to parser operations
		// Note: This is a simplified implementation for demonstration
		// In a real implementation, we would integrate caching more deeply
	}
	
	// Set concurrency limits
	if po.config.ParseConcurrency > 0 {
		// This would be implemented in the parser itself
		// For now, we just store the setting
	}
}

// SavePerformanceReport saves the performance report to a file
func (po *PerformanceOptimizer) SavePerformanceReport(filename string) error {
	report := po.GetPerformanceReport()
	
	file, err := os.Create(filename)
	if err != nil {
		return err
	}
	defer file.Close()
	
	encoder := json.NewEncoder(file)
	encoder.SetIndent("", "  ")
	return encoder.Encode(report)
} 