package main


func main() {
	tusklanggo.RunCLI()
} 