package main

import (
	"testing"
	"time"
	"fmt"
)

// TestDeepLearningEngineBasic tests basic deep learning functionality
func TestDeepLearningEngineBasic(t *testing.T) {
	config := DLConfig{
		EnableTraining:      true,
		EnableInference:     true,
		EnableAutoDL:        true,
		EnableMonitoring:    true,
		MonitorInterval:     30 * time.Second,
		EnablePersistence:   false,
		PersistencePath:     "",
		MaxModels:           50,
		RetentionPeriod:     365 * 24 * time.Hour, // 1 year
		DefaultFramework:    "tensorflow",
		EnableDistributedTraining: true,
	}

	dle := NewDeepLearningEngine(config)
	if dle == nil {
		t.Fatal("Failed to create DeepLearningEngine")
	}

	// Create a dataset
	dataset := &DLDataset{
		ID:          "test-dl-dataset",
		Name:        "Test DL Dataset",
		Description: "A test dataset for deep learning",
		Type:        "image",
		Features: []*DLFeature{
			{
				Name:     "image",
				Type:     "tensor",
				Shape:    []int{224, 224, 3},
				Required: true,
			},
		},
		Labels: &DLFeature{
			Name:     "label",
			Type:     "categorical",
				Shape:    []int{10},
				Required: true,
		},
		Data: [][]interface{}{
			// Simplified data representation
			{"image_data_1", 0},
			{"image_data_2", 1},
			{"image_data_3", 0},
			{"image_data_4", 1},
			{"image_data_5", 0},
		},
		CreatedAt: time.Now(),
		UpdatedAt: time.Now(),
		Metadata:  make(map[string]string),
	}

	// Register dataset
	err := dle.RegisterDataset(dataset)
	if err != nil {
		t.Fatalf("Failed to register dataset: %v", err)
	}

	// Create a neural network model
	model := &NeuralNetworkModel{
		ID:          "test-dl-model",
		Name:        "Test DL Model",
		Description: "A test deep learning model",
		Framework:   "tensorflow",
		DatasetID:   "test-dl-dataset",
		Type:        "classification",
		Layers: []*Layer{
			{
				Type:       "conv2d",
				Parameters: map[string]interface{}{
					"filters": 32,
					"kernel_size": []int{3, 3},
					"activation": "relu",
				},
			},
			{
				Type:       "dense",
				Parameters: map[string]interface{}{
					"units": 10,
					"activation": "softmax",
				},
			},
		},
		Config: map[string]interface{}{
			"optimizer": "adam",
			"loss": "categorical_crossentropy",
			"metrics": []string{"accuracy"},
		},
		Status:    "untrained",
		CreatedAt: time.Now(),
		UpdatedAt: time.Now(),
		Metadata:  make(map[string]string),
	}

	// Register model
	err = dle.RegisterModel(model)
	if err != nil {
		t.Fatalf("Failed to register model: %v", err)
	}

	// Train model
	result, err := dle.TrainModel("test-dl-model", map[string]interface{}{
		"epochs": 5,
		"batch_size": 32,
		"validation_split": 0.2,
	})
	if err != nil {
		t.Fatalf("Failed to train model: %v", err)
	}

	if result.ModelID != "test-dl-model" {
		t.Errorf("Expected model ID 'test-dl-model', got '%s'", result.ModelID)
	}

	if result.Status != "completed" {
		t.Errorf("Expected status 'completed', got '%s'", result.Status)
	}

	if result.Accuracy <= 0 {
		t.Errorf("Expected positive accuracy, got %f", result.Accuracy)
	}

	// Make prediction
	prediction, err := dle.Predict("test-dl-model", map[string]interface{}{
		"input": "test_image_data",
	})
	if err != nil {
		t.Fatalf("Failed to make prediction: %v", err)
	}

	if prediction.ModelID != "test-dl-model" {
		t.Errorf("Expected model ID 'test-dl-model', got '%s'", prediction.ModelID)
	}

	if prediction.Prediction == nil {
		t.Fatal("Prediction should not be nil")
	}
}

// TestDeepLearningEngineLayerManagement tests layer management
func TestDeepLearningEngineLayerManagement(t *testing.T) {
	config := DLConfig{
		EnableTraining:      true,
		EnableInference:     true,
		EnableAutoDL:        true,
		EnableMonitoring:    true,
		MonitorInterval:     30 * time.Second,
		EnablePersistence:   false,
		PersistencePath:     "",
		MaxModels:           50,
		RetentionPeriod:     365 * 24 * time.Hour,
		DefaultFramework:    "tensorflow",
		EnableDistributedTraining: true,
	}

	dle := NewDeepLearningEngine(config)

	// Create multiple models with different layers
	models := []*NeuralNetworkModel{
		{
			ID:          "layer-model-1",
			Name:        "Layer Model 1",
			Description: "First layer model",
			Framework:   "tensorflow",
			DatasetID:   "test-dataset",
			Type:        "classification",
			Layers: []*Layer{
				{
					Type:       "dense",
					Parameters: map[string]interface{}{
						"units": 128,
						"activation": "relu",
					},
				},
			},
			Config:    make(map[string]interface{}),
			Status:    "untrained",
			CreatedAt: time.Now(),
			UpdatedAt: time.Now(),
			Metadata:  make(map[string]string),
		},
		{
			ID:          "layer-model-2",
			Name:        "Layer Model 2",
			Description: "Second layer model",
			Framework:   "pytorch",
			DatasetID:   "test-dataset",
			Type:        "classification",
			Layers: []*Layer{
				{
					Type:       "conv2d",
					Parameters: map[string]interface{}{
						"out_channels": 64,
						"kernel_size": 3,
					},
				},
				{
					Type:       "linear",
					Parameters: map[string]interface{}{
						"out_features": 10,
					},
				},
			},
			Config:    make(map[string]interface{}),
			Status:    "untrained",
			CreatedAt: time.Now(),
			UpdatedAt: time.Now(),
			Metadata:  make(map[string]string),
		},
	}

	// Register models
	for _, model := range models {
		err := dle.RegisterModel(model)
		if err != nil {
			t.Fatalf("Failed to register model %s: %v", model.ID, err)
		}
	}

	// Verify layer configurations
	for _, model := range models {
		retrievedModel, err := dle.GetModel(model.ID)
		if err != nil {
			t.Fatalf("Failed to get model %s: %v", model.ID, err)
		}

		if len(retrievedModel.Layers) != len(model.Layers) {
			t.Errorf("Expected %d layers for model %s, got %d", len(model.Layers), model.ID, len(retrievedModel.Layers))
		}
	}
}

// TestDeepLearningEngineTrainingAndEvaluation tests training and evaluation
func TestDeepLearningEngineTrainingAndEvaluation(t *testing.T) {
	config := DLConfig{
		EnableTraining:      true,
		EnableInference:     true,
		EnableAutoDL:        true,
		EnableMonitoring:    true,
		MonitorInterval:     30 * time.Second,
		EnablePersistence:   false,
		PersistencePath:     "",
		MaxModels:           50,
		RetentionPeriod:     365 * 24 * time.Hour,
		DefaultFramework:    "tensorflow",
		EnableDistributedTraining: true,
	}

	dle := NewDeepLearningEngine(config)

	// Create a dataset for training
	dataset := &DLDataset{
		ID:          "training-dl-dataset",
		Name:        "Training DL Dataset",
		Description: "A dataset for DL training tests",
		Type:        "tabular",
		Features: []*DLFeature{
			{
				Name:     "input",
				Type:     "numeric",
				Shape:    []int{10},
				Required: true,
			},
		},
		Labels: &DLFeature{
			Name:     "output",
			Type:     "numeric",
			Shape:    []int{1},
			Required: true,
		},
		Data: [][]interface{}{
			// Simplified data
			{[]float64{1,2,3,4,5,6,7,8,9,10}, 55.0},
			{[]float64{2,3,4,5,6,7,8,9,10,11}, 65.0},
			// Add more data points as needed
		},
		CreatedAt: time.Now(),
		UpdatedAt: time.Now(),
		Metadata:  make(map[string]string),
	}

	err := dle.RegisterDataset(dataset)
	if err != nil {
		t.Fatalf("Failed to register dataset: %v", err)
	}

	// Create and train model
	model := &NeuralNetworkModel{
		ID:          "training-dl-model",
		Name:        "Training DL Model",
		Description: "A model for DL training tests",
		Framework:   "tensorflow",
		DatasetID:   "training-dl-dataset",
		Type:        "regression",
		Layers: []*Layer{
			{
				Type:       "dense",
				Parameters: map[string]interface{}{
					"units": 64,
					"activation": "relu",
				},
			},
			{
				Type:       "dense",
				Parameters: map[string]interface{}{
					"units": 1,
					"activation": "linear",
				},
			},
		},
		Config: map[string]interface{}{
			"optimizer": "adam",
			"loss": "mse",
			"metrics": []string{"mae"},
		},
		Status:    "untrained",
		CreatedAt: time.Now(),
		UpdatedAt: time.Now(),
		Metadata:  make(map[string]string),
	}

	err = dle.RegisterModel(model)
	if err != nil {
		t.Fatalf("Failed to register model: %v", err)
	}

	result, err := dle.TrainModel("training-dl-model", map[string]interface{}{
		"epochs": 10,
		"batch_size": 16,
		"validation_split": 0.2,
	})
	if err != nil {
		t.Fatalf("Failed to train model: %v", err)
	}

	if result.Status != "completed" {
		t.Errorf("Expected status 'completed', got '%s'", result.Status)
	}

	// Evaluate model
	evaluation, err := dle.EvaluateModel("training-dl-model", map[string]interface{}{
		"test_split": 0.2,
	})
	if err != nil {
		t.Fatalf("Failed to evaluate model: %v", err)
	}

	if evaluation.ModelID != "training-dl-model" {
		t.Errorf("Expected model ID 'training-dl-model', got '%s'", evaluation.ModelID)
	}

	if evaluation.Metrics == nil {
		t.Fatal("Evaluation metrics should not be nil")
	}
}

// TestDeepLearningEngineDistributedTraining tests distributed training functionality
func TestDeepLearningEngineDistributedTraining(t *testing.T) {
	config := DLConfig{
		EnableTraining:      true,
		EnableInference:     true,
		EnableAutoDL:        true,
		EnableMonitoring:    true,
		MonitorInterval:     30 * time.Second,
		EnablePersistence:   false,
		PersistencePath:     "",
		MaxModels:           50,
		RetentionPeriod:     365 * 24 * time.Hour,
		DefaultFramework:    "tensorflow",
		EnableDistributedTraining: true,
	}

	dle := NewDeepLearningEngine(config)

	// Create model for distributed training
	model := &NeuralNetworkModel{
		ID:          "distributed-model",
		Name:        "Distributed Training Model",
		Description: "A model for distributed training",
		Framework:   "tensorflow",
		DatasetID:   "test-dataset",
		Type:        "classification",
		Layers: []*Layer{
			{
				Type:       "dense",
				Parameters: map[string]interface{}{
					"units": 128,
					"activation": "relu",
				},
			},
		},
		Config: map[string]interface{}{
			"distributed": true,
			"nodes": 2,
		},
		Status:    "untrained",
		CreatedAt: time.Now(),
		UpdatedAt: time.Now(),
		Metadata:  make(map[string]string),
	}

	err := dle.RegisterModel(model)
	if err != nil {
		t.Fatalf("Failed to register model: %v", err)
	}

	// Train with distributed configuration
	result, err := dle.TrainModel("distributed-model", map[string]interface{}{
		"epochs": 5,
		"batch_size": 32,
		"distributed": true,
	})
	if err != nil {
		t.Fatalf("Failed to train distributed model: %v", err)
	}

	if result.Status != "completed" {
		t.Errorf("Expected status 'completed', got '%s'", result.Status)
	}

	// Verify distributed metrics
	if result.TrainingTime <= 0 {
		t.Error("Expected positive training time")
	}
}

// BenchmarkDeepLearningEngineTrainModel benchmarks model training
func BenchmarkDeepLearningEngineTrainModel(b *testing.B) {
	config := DLConfig{
		EnableTraining:      true,
		EnableInference:     true,
		EnableAutoDL:        false,
		EnableMonitoring:    false,
		MonitorInterval:     30 * time.Second,
		EnablePersistence:   false,
		PersistencePath:     "",
		MaxModels:           50,
		RetentionPeriod:     365 * 24 * time.Hour,
		DefaultFramework:    "tensorflow",
		EnableDistributedTraining: false,
	}

	dle := NewDeepLearningEngine(config)

	// Create model
	model := &NeuralNetworkModel{
		ID:          "benchmark-dl-model",
		Name:        "Benchmark DL Model",
		Description: "A model for benchmarking",
		Framework:   "tensorflow",
		DatasetID:   "test-dataset",
		Type:        "regression",
		Layers: []*Layer{
			{
				Type:       "dense",
				Parameters: map[string]interface{}{
					"units": 32,
					"activation": "relu",
				},
			},
		},
		Config: map[string]interface{}{
			"optimizer": "adam",
			"loss": "mse",
		},
		Status:    "untrained",
		CreatedAt: time.Now(),
		UpdatedAt: time.Now(),
		Metadata:  make(map[string]string),
	}

	err := dle.RegisterModel(model)
	if err != nil {
		b.Fatalf("Failed to register model: %v", err)
	}

	params := map[string]interface{}{
		"epochs": 1,
		"batch_size": 16,
		"validation_split": 0.2,
	}

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		_, err := dle.TrainModel("benchmark-dl-model", params)
		if err != nil {
			b.Fatalf("Model training failed: %v", err)
		}
	}
} 