package main

import (
	"fmt"
	"sync"
	"testing"
	"time"
)

// TestStreamProcessorBasic tests basic stream processor functionality
func TestStreamProcessorBasic(t *testing.T) {
	config := StreamConfig{
		DefaultBufferSize:     1000,
		MaxBufferSize:         10000,
		ProcessingTimeout:     30 * time.Second,
		EnableBackpressure:    true,
		BackpressureThreshold: 1000,
		EnableCheckpointing:   true,
		CheckpointInterval:    5 * time.Second,
		EnableMonitoring:      true,
		MonitorInterval:       5 * time.Second,
		EnableMetrics:         true,
	}

	sp := NewStreamProcessor(config)
	defer sp.Close()

	// Test stream creation
	stream, err := sp.CreateStream("test-stream", "test-source", map[string]string{
		"field1": "string",
		"field2": "int",
	}, 1, 1)
	if err != nil {
		t.Fatalf("Failed to create stream: %v", err)
	}

	if stream.Name != "test-stream" {
		t.Errorf("Expected stream name 'test-stream', got '%s'", stream.Name)
	}

	if stream.Source != "test-source" {
		t.Errorf("Expected stream source 'test-source', got '%s'", stream.Source)
	}

	// Test stream retrieval
	retrievedStream, err := sp.GetStream(stream.ID)
	if err != nil {
		t.Fatalf("Failed to get stream: %v", err)
	}

	if retrievedStream.ID != stream.ID {
		t.Errorf("Expected stream ID %s, got %s", stream.ID, retrievedStream.ID)
	}

	// Test stream listing
	streams := sp.ListStreams()
	if len(streams) != 1 {
		t.Errorf("Expected 1 stream, got %d", len(streams))
	}

	if streams[0].ID != stream.ID {
		t.Errorf("Expected stream ID %s, got %s", stream.ID, streams[0].ID)
	}
}

// TestStreamProcessorLifecycle tests stream lifecycle operations
func TestStreamProcessorLifecycle(t *testing.T) {
	config := StreamConfig{
		DefaultBufferSize:     1000,
		MaxBufferSize:         10000,
		ProcessingTimeout:     30 * time.Second,
		EnableBackpressure:    false,
		EnableCheckpointing:   false,
		EnableMonitoring:      false,
		EnableMetrics:         false,
	}

	sp := NewStreamProcessor(config)
	defer sp.Close()

	// Create stream
	stream, err := sp.CreateStream("lifecycle-test", "test-source", map[string]string{
		"field1": "string",
	}, 1, 1)
	if err != nil {
		t.Fatalf("Failed to create stream: %v", err)
	}

	// Test stream start
	err = sp.StartStream(stream.ID)
	if err != nil {
		t.Fatalf("Failed to start stream: %v", err)
	}

	retrievedStream, err := sp.GetStream(stream.ID)
	if err != nil {
		t.Fatalf("Failed to get stream: %v", err)
	}

	if retrievedStream.Status != "active" {
		t.Errorf("Expected stream status 'active', got '%s'", retrievedStream.Status)
	}

	// Test stream pause
	err = sp.PauseStream(stream.ID)
	if err != nil {
		t.Fatalf("Failed to pause stream: %v", err)
	}

	retrievedStream, err = sp.GetStream(stream.ID)
	if err != nil {
		t.Fatalf("Failed to get stream: %v", err)
	}

	if retrievedStream.Status != "paused" {
		t.Errorf("Expected stream status 'paused', got '%s'", retrievedStream.Status)
	}

	// Test stream stop
	err = sp.StopStream(stream.ID)
	if err != nil {
		t.Fatalf("Failed to stop stream: %v", err)
	}

	retrievedStream, err = sp.GetStream(stream.ID)
	if err != nil {
		t.Fatalf("Failed to get stream: %v", err)
	}

	if retrievedStream.Status != "stopped" {
		t.Errorf("Expected stream status 'stopped', got '%s'", retrievedStream.Status)
	}
}

// TestStreamProcessorRecordProcessing tests record processing
func TestStreamProcessorRecordProcessing(t *testing.T) {
	config := StreamConfig{
		DefaultBufferSize:     1000,
		MaxBufferSize:         10000,
		ProcessingTimeout:     30 * time.Second,
		EnableBackpressure:    false,
		EnableCheckpointing:   false,
		EnableMonitoring:      false,
		EnableMetrics:         false,
	}

	sp := NewStreamProcessor(config)
	defer sp.Close()

	// Create stream
	stream, err := sp.CreateStream("processing-test", "test-source", map[string]string{
		"field1": "string",
		"field2": "int",
	}, 1, 1)
	if err != nil {
		t.Fatalf("Failed to create stream: %v", err)
	}

	// Start stream
	err = sp.StartStream(stream.ID)
	if err != nil {
		t.Fatalf("Failed to start stream: %v", err)
	}

	// Test record processing
	testData := map[string]interface{}{
		"field1": "test value",
		"field2": 42,
	}
	testHeaders := map[string]string{"test": "header"}

	err = sp.ProcessRecord(stream.ID, testData, testHeaders)
	if err != nil {
		t.Fatalf("Failed to process record: %v", err)
	}

	// Wait for processing
	time.Sleep(100 * time.Millisecond)

	// Check stream stats
	retrievedStream, err := sp.GetStream(stream.ID)
	if err != nil {
		t.Fatalf("Failed to get stream: %v", err)
	}

	if retrievedStream.Stats.TotalRecords != 1 {
		t.Errorf("Expected 1 total record, got %d", retrievedStream.Stats.TotalRecords)
	}

	if retrievedStream.Stats.ProcessedRecords != 1 {
		t.Errorf("Expected 1 processed record, got %d", retrievedStream.Stats.ProcessedRecords)
	}
}

// TestStreamProcessorOperators tests stream operators
func TestStreamProcessorOperators(t *testing.T) {
	config := StreamConfig{
		DefaultBufferSize:     1000,
		MaxBufferSize:         10000,
		ProcessingTimeout:     30 * time.Second,
		EnableBackpressure:    false,
		EnableCheckpointing:   false,
		EnableMonitoring:      false,
		EnableMetrics:         false,
	}

	sp := NewStreamProcessor(config)
	defer sp.Close()

	// Create stream
	stream, err := sp.CreateStream("operators-test", "test-source", map[string]string{
		"field1": "string",
		"field2": "int",
	}, 1, 1)
	if err != nil {
		t.Fatalf("Failed to create stream: %v", err)
	}

	// Test filter operator
	filterOperator := &FilterOperator{
		name: "test-filter",
		config: map[string]interface{}{
			"field": "field2",
			"value": 42,
		},
	}

	err = sp.AddOperator("filter", filterOperator)
	if err != nil {
		t.Fatalf("Failed to add filter operator: %v", err)
	}

	// Test transform operator
	transformOperator := &TransformOperator{
		name: "test-transform",
		config: map[string]interface{}{
			"field": "field1",
			"operation": "uppercase",
		},
	}

	err = sp.AddOperator("transform", transformOperator)
	if err != nil {
		t.Fatalf("Failed to add transform operator: %v", err)
	}

	// Test aggregate operator
	aggregateOperator := &AggregateOperator{
		name: "test-aggregate",
		config: map[string]interface{}{
			"field": "field2",
			"operation": "sum",
		},
	}

	err = sp.AddOperator("aggregate", aggregateOperator)
	if err != nil {
		t.Fatalf("Failed to add aggregate operator: %v", err)
	}

	// Test window operator
	windowOperator := &WindowOperator{
		name: "test-window",
		config: map[string]interface{}{
			"size": "5",
			"slide": "1",
		},
	}

	err = sp.AddOperator("window", windowOperator)
	if err != nil {
		t.Fatalf("Failed to add window operator: %v", err)
	}

	// Get operators
	operators := sp.GetOperators()
	if len(operators) != 4 {
		t.Errorf("Expected 4 operators, got %d", len(operators))
	}

	// Test operator removal
	err = sp.RemoveOperator("filter")
	if err != nil {
		t.Fatalf("Failed to remove operator: %v", err)
	}

	operators = sp.GetOperators()
	if len(operators) != 3 {
		t.Errorf("Expected 3 operators after removal, got %d", len(operators))
	}
}

// TestStreamProcessorConcurrency tests concurrent record processing
func TestStreamProcessorConcurrency(t *testing.T) {
	config := StreamConfig{
		DefaultBufferSize:     1000,
		MaxBufferSize:         10000,
		ProcessingTimeout:     30 * time.Second,
		EnableBackpressure:    false,
		EnableCheckpointing:   false,
		EnableMonitoring:      false,
		EnableMetrics:         false,
	}

	sp := NewStreamProcessor(config)
	defer sp.Close()

	// Create stream
	stream, err := sp.CreateStream("concurrency-test", "test-source", map[string]string{
		"field1": "string",
		"field2": "int",
	}, 1, 1)
	if err != nil {
		t.Fatalf("Failed to create stream: %v", err)
	}

	// Start stream
	err = sp.StartStream(stream.ID)
	if err != nil {
		t.Fatalf("Failed to start stream: %v", err)
	}

	// Concurrent record processing
	var wg sync.WaitGroup
	recordCount := 100

	for i := 0; i < recordCount; i++ {
		wg.Add(1)
		go func(id int) {
			defer wg.Done()
			data := map[string]interface{}{
				"field1": fmt.Sprintf("value %d", id),
				"field2": id,
			}
			headers := map[string]string{"id": fmt.Sprintf("%d", id)}

			err := sp.ProcessRecord(stream.ID, data, headers)
			if err != nil {
				t.Errorf("Failed to process record %d: %v", id, err)
			}
		}(i)
	}

	// Wait for all records to be processed
	wg.Wait()

	// Wait for processing to complete
	time.Sleep(500 * time.Millisecond)

	// Check stream stats
	retrievedStream, err := sp.GetStream(stream.ID)
	if err != nil {
		t.Fatalf("Failed to get stream: %v", err)
	}

	if retrievedStream.Stats.TotalRecords != int64(recordCount) {
		t.Errorf("Expected %d total records, got %d", recordCount, retrievedStream.Stats.TotalRecords)
	}

	if retrievedStream.Stats.ProcessedRecords != int64(recordCount) {
		t.Errorf("Expected %d processed records, got %d", recordCount, retrievedStream.Stats.ProcessedRecords)
	}
}

// TestStreamProcessorMonitoring tests monitoring functionality
func TestStreamProcessorMonitoring(t *testing.T) {
	config := StreamConfig{
		DefaultBufferSize:     1000,
		MaxBufferSize:         10000,
		ProcessingTimeout:     30 * time.Second,
		EnableBackpressure:    false,
		EnableCheckpointing:   false,
		EnableMonitoring:      true,
		MonitorInterval:       100 * time.Millisecond,
		EnableMetrics:         true,
	}

	sp := NewStreamProcessor(config)
	defer sp.Close()

	// Create stream
	stream, err := sp.CreateStream("monitoring-test", "test-source", map[string]string{
		"field1": "string",
	}, 1, 1)
	if err != nil {
		t.Fatalf("Failed to create stream: %v", err)
	}

	// Start stream
	err = sp.StartStream(stream.ID)
	if err != nil {
		t.Fatalf("Failed to start stream: %v", err)
	}

	// Process some records
	for i := 0; i < 10; i++ {
		data := map[string]interface{}{
			"field1": fmt.Sprintf("value %d", i),
		}
		err := sp.ProcessRecord(stream.ID, data, nil)
		if err != nil {
			t.Fatalf("Failed to process record: %v", err)
		}
	}

	// Wait for monitoring to collect metrics
	time.Sleep(300 * time.Millisecond)

	// Test metrics
	metrics := sp.GetMetrics()
	if len(metrics) == 0 {
		t.Error("Expected metrics to be collected")
	}

	// Test alerts
	alerts := sp.GetAlerts()
	// Alerts might be empty depending on thresholds, but the method should work
	if alerts == nil {
		t.Error("Alerts should not be nil")
	}

	// Test stats
	stats := sp.GetStats()
	if stats == nil {
		t.Fatal("Stats should not be nil")
	}

	// Check that monitoring data is present
	if stats["monitoring"] == nil {
		t.Error("Monitoring data should be present in stats")
	}
}

// TestStreamProcessorBackpressure tests backpressure functionality
func TestStreamProcessorBackpressure(t *testing.T) {
	config := StreamConfig{
		DefaultBufferSize:     10,
		MaxBufferSize:         20,
		ProcessingTimeout:     30 * time.Second,
		EnableBackpressure:    true,
		BackpressureThreshold: 5,
		EnableCheckpointing:   false,
		EnableMonitoring:      false,
		EnableMetrics:         false,
	}

	sp := NewStreamProcessor(config)
	defer sp.Close()

	// Create stream
	stream, err := sp.CreateStream("backpressure-test", "test-source", map[string]string{
		"field1": "string",
	}, 1, 1)
	if err != nil {
		t.Fatalf("Failed to create stream: %v", err)
	}

	// Start stream
	err = sp.StartStream(stream.ID)
	if err != nil {
		t.Fatalf("Failed to start stream: %v", err)
	}

	// Add slow operator to create backpressure
	slowOperator := &FilterOperator{
		name: "slow-filter",
		config: map[string]interface{}{
			"delay": "100ms",
		},
	}

	err = sp.AddOperator("slow", slowOperator)
	if err != nil {
		t.Fatalf("Failed to add slow operator: %v", err)
	}

	// Process records rapidly to trigger backpressure
	for i := 0; i < 50; i++ {
		data := map[string]interface{}{
			"field1": fmt.Sprintf("value %d", i),
		}
		err := sp.ProcessRecord(stream.ID, data, nil)
		if err != nil {
			t.Fatalf("Failed to process record: %v", err)
		}
	}

	// Wait for processing to complete
	time.Sleep(2 * time.Second)

	// Check stream stats
	retrievedStream, err := sp.GetStream(stream.ID)
	if err != nil {
		t.Fatalf("Failed to get stream: %v", err)
	}

	// All records should eventually be processed
	if retrievedStream.Stats.TotalRecords != 50 {
		t.Errorf("Expected 50 total records, got %d", retrievedStream.Stats.TotalRecords)
	}
}

// TestStreamProcessorOperators tests individual operator functionality
func TestStreamProcessorOperatorFunctionality(t *testing.T) {
	// Test FilterOperator
	filterOp := &FilterOperator{
		name: "test-filter",
		config: map[string]interface{}{
			"field": "field2",
			"value": 42,
		},
	}

	if filterOp.GetName() != "test-filter" {
		t.Errorf("Expected filter operator name 'test-filter', got '%s'", filterOp.GetName())
	}

	config := filterOp.GetConfig()
	if config["field"] != "field2" {
		t.Errorf("Expected filter config field 'field2', got '%v'", config["field"])
	}

	// Test TransformOperator
	transformOp := &TransformOperator{
		name: "test-transform",
		config: map[string]interface{}{
			"field": "field1",
			"operation": "uppercase",
		},
	}

	if transformOp.GetName() != "test-transform" {
		t.Errorf("Expected transform operator name 'test-transform', got '%s'", transformOp.GetName())
	}

	config = transformOp.GetConfig()
	if config["operation"] != "uppercase" {
		t.Errorf("Expected transform config operation 'uppercase', got '%v'", config["operation"])
	}

	// Test AggregateOperator
	aggregateOp := &AggregateOperator{
		name: "test-aggregate",
		config: map[string]interface{}{
			"field": "field2",
			"operation": "sum",
		},
	}

	if aggregateOp.GetName() != "test-aggregate" {
		t.Errorf("Expected aggregate operator name 'test-aggregate', got '%s'", aggregateOp.GetName())
	}

	config = aggregateOp.GetConfig()
	if config["operation"] != "sum" {
		t.Errorf("Expected aggregate config operation 'sum', got '%v'", config["operation"])
	}

	// Test WindowOperator
	windowOp := &WindowOperator{
		name: "test-window",
		config: map[string]interface{}{
			"size": "5",
			"slide": "1",
		},
	}

	if windowOp.GetName() != "test-window" {
		t.Errorf("Expected window operator name 'test-window', got '%s'", windowOp.GetName())
	}

	config = windowOp.GetConfig()
	if config["size"] != "5" {
		t.Errorf("Expected window config size '5', got '%v'", config["size"])
	}
}

// BenchmarkStreamProcessorProcessRecord benchmarks record processing
func BenchmarkStreamProcessorProcessRecord(b *testing.B) {
	config := StreamConfig{
		DefaultBufferSize:     1000,
		MaxBufferSize:         10000,
		ProcessingTimeout:     30 * time.Second,
		EnableBackpressure:    false,
		EnableCheckpointing:   false,
		EnableMonitoring:      false,
		EnableMetrics:         false,
	}

	sp := NewStreamProcessor(config)
	defer sp.Close()

	// Create stream
	stream, err := sp.CreateStream("benchmark-test", "test-source", map[string]string{
		"field1": "string",
		"field2": "int",
	}, 1, 1)
	if err != nil {
		b.Fatalf("Failed to create stream: %v", err)
	}

	// Start stream
	err = sp.StartStream(stream.ID)
	if err != nil {
		b.Fatalf("Failed to start stream: %v", err)
	}

	testData := map[string]interface{}{
		"field1": "benchmark value",
		"field2": 42,
	}
	testHeaders := map[string]string{"benchmark": "true"}

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		err := sp.ProcessRecord(stream.ID, testData, testHeaders)
		if err != nil {
			b.Fatalf("Failed to process record: %v", err)
		}
	}
}

// BenchmarkStreamProcessorCreateStream benchmarks stream creation
func BenchmarkStreamProcessorCreateStream(b *testing.B) {
	config := StreamConfig{
		DefaultBufferSize:     1000,
		MaxBufferSize:         10000,
		ProcessingTimeout:     30 * time.Second,
		EnableBackpressure:    false,
		EnableCheckpointing:   false,
		EnableMonitoring:      false,
		EnableMetrics:         false,
	}

	sp := NewStreamProcessor(config)
	defer sp.Close()

	schema := map[string]string{
		"field1": "string",
		"field2": "int",
		"field3": "float",
	}

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		streamName := fmt.Sprintf("benchmark-stream-%d", i)
		_, err := sp.CreateStream(streamName, "test-source", schema, 1, 1)
		if err != nil {
			b.Fatalf("Failed to create stream: %v", err)
		}
	}
} 