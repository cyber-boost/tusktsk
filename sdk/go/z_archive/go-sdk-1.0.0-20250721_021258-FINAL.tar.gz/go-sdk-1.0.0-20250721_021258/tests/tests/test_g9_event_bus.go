package main

import (
	"fmt"
	"sync"
	"testing"
	"time"
)

// TestEventBusBasic tests basic event bus functionality
func TestEventBusBasic(t *testing.T) {
	config := EventBusConfig{
		EnableAsync:       true,
		AsyncWorkers:      5,
		EnableRetry:       true,
		MaxRetries:        3,
		RetryDelay:        100 * time.Millisecond,
		EnableDeadLetter:  true,
		DeadLetterTopic:   "dead-letter",
		EnableMonitoring:  true,
		MonitorInterval:   5 * time.Second,
		EnablePersistence: false,
		PersistencePath:   "",
	}

	eb := NewEventBus(config)
	defer eb.Close()

	// Test event publishing
	testData := map[string]interface{}{"message": "test event"}
	testHeaders := map[string]string{"test": "header"}

	receivedEvents := make(chan *Event, 1)
	handler := func(event *Event) error {
		receivedEvents <- event
		return nil
	}

	// Subscribe to event
	subscriber, err := eb.Subscribe("test.event", handler)
	if err != nil {
		t.Fatalf("Failed to subscribe: %v", err)
	}

	// Publish event
	err = eb.Publish("test.event", testData, testHeaders)
	if err != nil {
		t.Fatalf("Failed to publish event: %v", err)
	}

	// Wait for event
	select {
	case event := <-receivedEvents:
		if event.Type != "test.event" {
			t.Errorf("Expected event type 'test.event', got '%s'", event.Type)
		}
		if event.Data.(map[string]interface{})["message"] != "test event" {
			t.Errorf("Expected data message 'test event', got '%v'", event.Data.(map[string]interface{})["message"])
		}
		if event.Headers["test"] != "header" {
			t.Errorf("Expected header 'test'='header', got '%s'", event.Headers["test"])
		}
	case <-time.After(5 * time.Second):
		t.Fatal("Timeout waiting for event")
	}

	// Test unsubscribe
	err = eb.Unsubscribe(subscriber)
	if err != nil {
		t.Fatalf("Failed to unsubscribe: %v", err)
	}

	// Test stats
	stats := eb.GetStats()
	if stats == nil {
		t.Fatal("Stats should not be nil")
	}
}

// TestEventBusPatternMatching tests event pattern matching
func TestEventBusPatternMatching(t *testing.T) {
	config := EventBusConfig{
		EnableAsync:       true,
		AsyncWorkers:      5,
		EnableRetry:       false,
		EnableDeadLetter:  false,
		EnableMonitoring:  false,
		EnablePersistence: false,
	}

	eb := NewEventBus(config)
	defer eb.Close()

	// Test wildcard pattern matching
	receivedEvents := make(chan *Event, 3)
	handler := func(event *Event) error {
		receivedEvents <- event
		return nil
	}

	// Subscribe to wildcard pattern
	_, err := eb.Subscribe("user.*.created", handler)
	if err != nil {
		t.Fatalf("Failed to subscribe: %v", err)
	}

	// Publish events that should match
	events := []string{"user.admin.created", "user.guest.created", "user.test.created"}
	for _, eventType := range events {
		err = eb.Publish(eventType, map[string]interface{}{"user": "test"}, nil)
		if err != nil {
			t.Fatalf("Failed to publish event %s: %v", eventType, err)
		}
	}

	// Wait for all events
	for i := 0; i < 3; i++ {
		select {
		case event := <-receivedEvents:
			// Event should match pattern
			if event.Type != events[i] {
				t.Errorf("Expected event type %s, got %s", events[i], event.Type)
			}
		case <-time.After(5 * time.Second):
			t.Fatalf("Timeout waiting for event %d", i)
		}
	}

	// Test event that shouldn't match
	nonMatchingEvents := make(chan *Event, 1)
	nonMatchingHandler := func(event *Event) error {
		nonMatchingEvents <- event
		return nil
	}

	_, err = eb.Subscribe("user.created", nonMatchingHandler)
	if err != nil {
		t.Fatalf("Failed to subscribe: %v", err)
	}

	// Publish event that shouldn't match wildcard
	err = eb.Publish("user.admin.created", map[string]interface{}{"user": "test"}, nil)
	if err != nil {
		t.Fatalf("Failed to publish event: %v", err)
	}

	// Should not receive event on non-matching pattern
	select {
	case <-nonMatchingEvents:
		t.Error("Received event on non-matching pattern")
	case <-time.After(1 * time.Second):
		// Expected - no event should be received
	}
}

// TestEventBusRetry tests retry functionality
func TestEventBusRetry(t *testing.T) {
	config := EventBusConfig{
		EnableAsync:       true,
		AsyncWorkers:      5,
		EnableRetry:       true,
		MaxRetries:        3,
		RetryDelay:        100 * time.Millisecond,
		EnableDeadLetter:  true,
		DeadLetterTopic:   "dead-letter",
		EnableMonitoring:  false,
		EnablePersistence: false,
	}

	eb := NewEventBus(config)
	defer eb.Close()

	// Test retry with failing handler
	retryCount := 0
	handler := func(event *Event) error {
		retryCount++
		if retryCount < 3 {
			return fmt.Errorf("temporary error")
		}
		return nil
	}

	_, err := eb.Subscribe("retry.test", handler)
	if err != nil {
		t.Fatalf("Failed to subscribe: %v", err)
	}

	// Publish event
	err = eb.Publish("retry.test", map[string]interface{}{"test": "retry"}, nil)
	if err != nil {
		t.Fatalf("Failed to publish event: %v", err)
	}

	// Wait for retries
	time.Sleep(1 * time.Second)

	if retryCount != 3 {
		t.Errorf("Expected 3 retries, got %d", retryCount)
	}
}

// TestEventBusDeadLetter tests dead letter functionality
func TestEventBusDeadLetter(t *testing.T) {
	config := EventBusConfig{
		EnableAsync:       true,
		AsyncWorkers:      5,
		EnableRetry:       true,
		MaxRetries:        1,
		RetryDelay:        100 * time.Millisecond,
		EnableDeadLetter:  true,
		DeadLetterTopic:   "dead-letter",
		EnableMonitoring:  false,
		EnablePersistence: false,
	}

	eb := NewEventBus(config)
	defer eb.Close()

	// Handler that always fails
	handler := func(event *Event) error {
		return fmt.Errorf("permanent error")
	}

	_, err := eb.Subscribe("test.event", handler)
	if err != nil {
		t.Fatalf("Failed to subscribe: %v", err)
	}

	// Dead letter handler
	deadLetterEvents := make(chan *Event, 1)
	deadLetterHandler := func(event *Event) error {
		deadLetterEvents <- event
		return nil
	}

	_, err = eb.Subscribe("dead-letter", deadLetterHandler)
	if err != nil {
		t.Fatalf("Failed to subscribe to dead letter: %v", err)
	}

	// Publish event
	err = eb.Publish("test.event", map[string]interface{}{"test": "dead letter"}, nil)
	if err != nil {
		t.Fatalf("Failed to publish event: %v", err)
	}

	// Wait for dead letter
	select {
	case event := <-deadLetterEvents:
		if event.Type != "test.event" {
			t.Errorf("Expected event type 'test.event', got '%s'", event.Type)
		}
	case <-time.After(2 * time.Second):
		t.Fatal("Timeout waiting for dead letter event")
	}
}

// TestEventBusConcurrency tests concurrent event processing
func TestEventBusConcurrency(t *testing.T) {
	config := EventBusConfig{
		EnableAsync:       true,
		AsyncWorkers:      10,
		EnableRetry:       false,
		EnableDeadLetter:  false,
		EnableMonitoring:  false,
		EnablePersistence: false,
	}

	eb := NewEventBus(config)
	defer eb.Close()

	// Concurrent event processing
	var wg sync.WaitGroup
	eventCount := 100
	processedEvents := make(chan int, eventCount)

	handler := func(event *Event) error {
		processedEvents <- 1
		wg.Done()
		return nil
	}

	_, err := eb.Subscribe("concurrent.test", handler)
	if err != nil {
		t.Fatalf("Failed to subscribe: %v", err)
	}

	// Publish events concurrently
	for i := 0; i < eventCount; i++ {
		wg.Add(1)
		go func(id int) {
			data := map[string]interface{}{"id": id}
			err := eb.Publish("concurrent.test", data, nil)
			if err != nil {
				t.Errorf("Failed to publish event %d: %v", id, err)
			}
		}(i)
	}

	// Wait for all events to be processed
	wg.Wait()

	// Count processed events
	processed := 0
	for i := 0; i < eventCount; i++ {
		select {
		case <-processedEvents:
			processed++
		case <-time.After(1 * time.Second):
			break
		}
	}

	if processed != eventCount {
		t.Errorf("Expected %d processed events, got %d", eventCount, processed)
	}
}

// TestEventBusEventRegistry tests event registry functionality
func TestEventBusEventRegistry(t *testing.T) {
	config := EventBusConfig{
		EnableAsync:       false,
		EnableRetry:       false,
		EnableDeadLetter:  false,
		EnableMonitoring:  false,
		EnablePersistence: false,
	}

	eb := NewEventBus(config)
	defer eb.Close()

	// Register event type
	eventType := &EventType{
		Name:        "user.created",
		Description: "User creation event",
		Schema: map[string]string{
			"user_id": "string",
			"email":   "string",
		},
		Version:    "1.0",
		Deprecated: false,
		Metadata:   map[string]string{"category": "user"},
	}

	err := eb.RegisterEventType(eventType)
	if err != nil {
		t.Fatalf("Failed to register event type: %v", err)
	}

	// Get event type
	retrievedType, err := eb.GetEventType("user.created")
	if err != nil {
		t.Fatalf("Failed to get event type: %v", err)
	}

	if retrievedType.Name != "user.created" {
		t.Errorf("Expected event type name 'user.created', got '%s'", retrievedType.Name)
	}

	if retrievedType.Description != "User creation event" {
		t.Errorf("Expected description 'User creation event', got '%s'", retrievedType.Description)
	}

	// List event types
	eventTypes := eb.ListEventTypes()
	if len(eventTypes) != 1 {
		t.Errorf("Expected 1 event type, got %d", len(eventTypes))
	}

	if eventTypes[0].Name != "user.created" {
		t.Errorf("Expected event type name 'user.created', got '%s'", eventTypes[0].Name)
	}
}

// TestEventBusSubscriberManagement tests subscriber management
func TestEventBusSubscriberManagement(t *testing.T) {
	config := EventBusConfig{
		EnableAsync:       false,
		EnableRetry:       false,
		EnableDeadLetter:  false,
		EnableMonitoring:  false,
		EnablePersistence: false,
	}

	eb := NewEventBus(config)
	defer eb.Close()

	// Subscribe to multiple patterns
	handler := func(event *Event) error {
		return nil
	}

	subscriber1, err := eb.Subscribe("user.*", handler)
	if err != nil {
		t.Fatalf("Failed to subscribe: %v", err)
	}

	subscriber2, err := eb.Subscribe("order.*", handler)
	if err != nil {
		t.Fatalf("Failed to subscribe: %v", err)
	}

	// Get subscribers for pattern
	subscribers := eb.GetSubscribers("user.*")
	if len(subscribers) != 1 {
		t.Errorf("Expected 1 subscriber for 'user.*', got %d", len(subscribers))
	}

	if subscribers[0].ID != subscriber1.ID {
		t.Errorf("Expected subscriber ID %s, got %s", subscriber1.ID, subscribers[0].ID)
	}

	// Get all subscribers
	allSubscribers := eb.GetAllSubscribers()
	if len(allSubscribers) != 2 {
		t.Errorf("Expected 2 subscriber patterns, got %d", len(allSubscribers))
	}

	// Check that both patterns exist
	if allSubscribers["user.*"] == nil {
		t.Error("Expected 'user.*' pattern to exist")
	}

	if allSubscribers["order.*"] == nil {
		t.Error("Expected 'order.*' pattern to exist")
	}
}

// TestEventBusEventProperties tests event properties
func TestEventBusEventProperties(t *testing.T) {
	config := EventBusConfig{
		EnableAsync:       false,
		EnableRetry:       false,
		EnableDeadLetter:  false,
		EnableMonitoring:  false,
		EnablePersistence: false,
	}

	eb := NewEventBus(config)
	defer eb.Close()

	// Test event with properties
	testData := map[string]interface{}{"message": "test event"}
	testHeaders := map[string]string{"priority": "high", "type": "test"}
	expiresAt := time.Now().Add(1 * time.Hour)

	// Create event manually to test properties
	event := &Event{
		ID:        "test-event-id",
		Type:      "test.event",
		Source:    "test-source",
		Data:      testData,
		Headers:   testHeaders,
		Timestamp: time.Now(),
		Priority:  10,
		TTL:       1 * time.Hour,
		Metadata:  map[string]string{"test": "metadata"},
	}

	// Test event properties
	if event.ID != "test-event-id" {
		t.Errorf("Expected ID 'test-event-id', got '%s'", event.ID)
	}

	if event.Type != "test.event" {
		t.Errorf("Expected type 'test.event', got '%s'", event.Type)
	}

	if event.Source != "test-source" {
		t.Errorf("Expected source 'test-source', got '%s'", event.Source)
	}

	if event.Priority != 10 {
		t.Errorf("Expected priority 10, got %d", event.Priority)
	}

	if event.Headers["priority"] != "high" {
		t.Errorf("Expected header 'priority'='high', got '%s'", event.Headers["priority"])
	}

	// Test event publishing
	receivedEvents := make(chan *Event, 1)
	handler := func(evt *Event) error {
		receivedEvents <- evt
		return nil
	}

	_, err := eb.Subscribe("test.event", handler)
	if err != nil {
		t.Fatalf("Failed to subscribe: %v", err)
	}

	// Publish event
	err = eb.PublishEvent(event)
	if err != nil {
		t.Fatalf("Failed to publish event: %v", err)
	}

	// Wait for event
	select {
	case receivedEvent := <-receivedEvents:
		if receivedEvent.ID != event.ID {
			t.Errorf("Expected event ID %s, got %s", event.ID, receivedEvent.ID)
		}
	case <-time.After(5 * time.Second):
		t.Fatal("Timeout waiting for event")
	}
}

// BenchmarkEventBusPublish benchmarks event publishing
func BenchmarkEventBusPublish(b *testing.B) {
	config := EventBusConfig{
		EnableAsync:       true,
		AsyncWorkers:      10,
		EnableRetry:       false,
		EnableDeadLetter:  false,
		EnableMonitoring:  false,
		EnablePersistence: false,
	}

	eb := NewEventBus(config)
	defer eb.Close()

	handler := func(event *Event) error {
		return nil
	}

	_, err := eb.Subscribe("benchmark.test", handler)
	if err != nil {
		b.Fatalf("Failed to subscribe: %v", err)
	}

	testData := map[string]interface{}{"benchmark": "true"}
	testHeaders := map[string]string{"benchmark": "true"}

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		err := eb.Publish("benchmark.test", testData, testHeaders)
		if err != nil {
			b.Fatalf("Failed to publish event: %v", err)
		}
	}
}

// BenchmarkEventBusSubscribe benchmarks event subscription
func BenchmarkEventBusSubscribe(b *testing.B) {
	config := EventBusConfig{
		EnableAsync:       false,
		EnableRetry:       false,
		EnableDeadLetter:  false,
		EnableMonitoring:  false,
		EnablePersistence: false,
	}

	eb := NewEventBus(config)
	defer eb.Close()

	handler := func(event *Event) error {
		return nil
	}

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		pattern := fmt.Sprintf("benchmark.test.%d", i)
		_, err := eb.Subscribe(pattern, handler)
		if err != nil {
			b.Fatalf("Failed to subscribe: %v", err)
		}
	}
} 