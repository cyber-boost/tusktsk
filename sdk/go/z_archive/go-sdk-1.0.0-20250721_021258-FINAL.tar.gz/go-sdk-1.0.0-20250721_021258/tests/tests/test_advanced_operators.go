package main

import (
	"fmt"
	"log"

	"tusk-go-sdk/src/operators"
	"tusk-go-sdk/src/operators/communication"
)

func main() {
	fmt.Println("🚀 Testing TuskLang Go SDK Advanced Operators")
	fmt.Println("=============================================")

	// Test communication operators
	testCommunicationOperators()

	// Test monitoring operators
	testMonitoringOperators()

	// Test enterprise operators
	testEnterpriseOperators()

	// Test FUJSEN operators
	testFUJSENOperators()

	// Test operator registry with all operators
	testAdvancedOperatorRegistry()

	fmt.Println("\n✅ All advanced operator tests completed!")
}

func testCommunicationOperators() {
	fmt.Println("\n🌐 Testing Communication Operators...")

	// Test GraphQL
	testGraphQLOperator()

	// Test gRPC
	testGRPCOperator()

	// Test WebSocket
	testWebSocketOperator()
}

func testGraphQLOperator() {
	fmt.Println("  📊 Testing @graphql operator...")
	
	graphql := communication.NewGraphQLOperator("https://api.example.com/graphql")
	
	// Test basic execution
	result := graphql.Execute("query { users { id name } }")
	fmt.Printf("    - Execute result: %v\n", result)
	
	// Test introspection
	_, err := graphql.Introspect()
	if err != nil {
		log.Printf("    - Error during introspection: %v", err)
	} else {
		fmt.Printf("    - Introspection completed\n")
	}
	
	// Test query validation
	_, err = graphql.ValidateQuery("query { users { id name } }")
	if err != nil {
		log.Printf("    - Error during validation: %v", err)
	} else {
		fmt.Printf("    - Query validation completed\n")
	}
}

func testGRPCOperator() {
	fmt.Println("  🔗 Testing @grpc operator...")
	
	grpc := communication.NewGRPCOperator()
	
	// Test basic execution
	result := grpc.Execute("user.UserService,GetUser,{\"id\": \"123\"}")
	fmt.Printf("    - Execute result: %v\n", result)
	
	// Test connection management
	err := grpc.Connect("test", "localhost:50051")
	if err != nil {
		fmt.Printf("    - Connection test (expected error): %v\n", err)
	} else {
		fmt.Printf("    - Connection established\n")
	}
	
	// Test connection listing
	connections := grpc.ListConnections()
	fmt.Printf("    - Active connections: %v\n", connections)
}

func testWebSocketOperator() {
	fmt.Println("  🔌 Testing @websocket operator...")
	
	ws := communication.NewWebSocketOperator()
	
	// Test basic execution
	result := ws.Execute("connect,ws://localhost:8080/ws,hello")
	fmt.Printf("    - Execute result: %v\n", result)
	
	// Test connection management
	err := ws.Connect("test", "ws://localhost:8080/ws", map[string]string{})
	if err != nil {
		fmt.Printf("    - Connection test (expected error): %v\n", err)
	} else {
		fmt.Printf("    - Connection established\n")
	}
	
	// Test connection listing
	connections := ws.ListConnections()
	fmt.Printf("    - Active connections: %v\n", connections)
}

func testMonitoringOperators() {
	fmt.Println("\n📈 Testing Monitoring Operators...")

	// Test Prometheus
	testPrometheusOperator()
}

func testPrometheusOperator() {
	fmt.Println("  📊 Testing @prometheus operator...")
	
	prometheus := communication.NewPrometheusOperator("")
	
	// Test basic execution
	result := prometheus.Execute("counter,http_requests_total,1,{\"method\": \"GET\"}")
	fmt.Printf("    - Execute result: %v\n", result)
	
	// Test operator functionality
	fmt.Printf("    - Prometheus operator initialized\n")
}

func testEnterpriseOperators() {
	fmt.Println("\n🏢 Testing Enterprise Operators...")

	// Test OAuth2
	testOAuth2Operator()
}

func testOAuth2Operator() {
	fmt.Println("  🔐 Testing @oauth2 operator...")
	
	oauth2 := communication.NewOAuth2Operator()
	
	// Test basic execution
	result := oauth2.Execute("authorize,google,{\"client_id\": \"test\"}")
	fmt.Printf("    - Execute result: %v\n", result)
	
	// Test operator functionality
	fmt.Printf("    - OAuth2 operator initialized\n")
}

func testFUJSENOperators() {
	fmt.Println("\n⚡ Testing FUJSEN Operators...")

	// Test JavaScript
	testJavaScriptOperator()
}

func testJavaScriptOperator() {
	fmt.Println("  📜 Testing @fujsen operator...")
	
	fujsen := communication.NewFUJSENOperator()
	
	// Test basic execution
	result := fujsen.Execute("execute,add,[1, 2]")
	fmt.Printf("    - Execute result: %v\n", result)
	
	// Test operator functionality
	fmt.Printf("    - FUJSEN operator initialized\n")
}

func testAdvancedOperatorRegistry() {
	fmt.Println("\n🏪 Testing Advanced Operator Registry...")
	
	registry := operators.NewOperatorRegistry()
	
	// Test operator listing
	allOperators := registry.ListOperators()
	fmt.Printf("  - Total registered operators: %d\n", len(allOperators))
	
	// Test advanced operator execution
	advancedOperators := []string{
		"graphql", "grpc", "websocket", "prometheus", "oauth2", "fujsen",
		"sse", "nats", "amqp", "kafka",
	}
	
	for _, opName := range advancedOperators {
		result, _ := registry.ExecuteOperator(opName, "test_params")
		fmt.Printf("  - @%s result: %v\n", opName, result)
	}
	
	// Test operator categories
	fmt.Println("  - Core operators: date, env, query, cache, learn, optimize, metrics, feature, request, if, output, q")
	fmt.Println("  - Communication operators: graphql, grpc, websocket, sse, nats, amqp, kafka")
	fmt.Println("  - Monitoring operators: prometheus, jaeger, zipkin, grafana, elasticsearch")
	fmt.Println("  - Enterprise operators: oauth2, saml, rbac, audit, mfa, compliance")
	fmt.Println("  - FUJSEN operators: fujsen.js, fujsen.py, fujsen.bash, fujsen.go, fujsen.execute")
	
	// Test cleanup
	fmt.Println("  - Registry test completed")
} 