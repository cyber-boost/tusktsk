package main

import (
	"fmt"
	"testing"
	"time"
)

// TestBusinessIntelligenceBasic tests basic business intelligence functionality
func TestBusinessIntelligenceBasic(t *testing.T) {
	config := BIConfig{
		EnableDashboards:    true,
		EnableVisualizations: true,
		EnableKPIs:          true,
		EnableAlerts:        true,
		EnableMonitoring:    true,
		MonitorInterval:     30 * time.Second,
		EnablePersistence:   false,
		PersistencePath:     "",
		MaxDashboards:       100,
		MaxVisualizations:   1000,
		RetentionPeriod:     365 * 24 * time.Hour, // 1 year
	}

	bi := NewBusinessIntelligence(config)
	if bi == nil {
		t.Fatal("Failed to create BusinessIntelligence")
	}

	// Create a data source
	dataSource := &BIDataSource{
		ID:          "test-bi-source",
		Name:        "Test BI Data Source",
		Description: "A test data source for business intelligence",
		Type:        "database",
		Config: map[string]interface{}{
			"connection_string": "postgresql://localhost:5432/testdb",
			"query":            "SELECT * FROM sales_data",
		},
		Schema: []*BIField{
			{
				Name:     "date",
				Type:     "date",
				Required: true,
			},
			{
				Name:     "product",
				Type:     "string",
				Required: true,
			},
			{
				Name:     "sales",
				Type:     "number",
				Required: true,
			},
		},
		CreatedAt: time.Now(),
		UpdatedAt: time.Now(),
		Metadata:  make(map[string]string),
	}

	// Register data source
	err := bi.RegisterDataSource(dataSource)
	if err != nil {
		t.Fatalf("Failed to register data source: %v", err)
	}

	// Create a KPI
	kpi := &KPI{
		ID:          "test-kpi",
		Name:        "Test KPI",
		Description: "A test KPI for business intelligence",
		DataSource:  "test-bi-source",
		Type:        "metric",
		Formula:     "SUM(sales)",
		Unit:        "USD",
		Target:      1000000,
		Threshold:   800000,
		Direction:   "up",
		CreatedAt:   time.Now(),
		UpdatedAt:   time.Now(),
		Metadata:    make(map[string]string),
	}

	// Register KPI
	err = bi.RegisterKPI(kpi)
	if err != nil {
		t.Fatalf("Failed to register KPI: %v", err)
	}

	// Create a visualization
	visualization := &Visualization{
		ID:          "test-viz",
		Name:        "Test Visualization",
		Description: "A test visualization for business intelligence",
		Type:        "chart",
		ChartType:   "line",
		DataSource:  "test-bi-source",
		Config: map[string]interface{}{
			"x_axis": "date",
			"y_axis": "sales",
			"title":  "Sales Over Time",
		},
		CreatedAt: time.Now(),
		UpdatedAt: time.Now(),
		Metadata:  make(map[string]string),
	}

	// Register visualization
	err = bi.RegisterVisualization(visualization)
	if err != nil {
		t.Fatalf("Failed to register visualization: %v", err)
	}

	// Create a dashboard
	dashboard := &Dashboard{
		ID:          "test-dashboard",
		Name:        "Test Dashboard",
		Description: "A test dashboard for business intelligence",
		Layout:      "grid",
		Widgets: []*DashboardWidget{
			{
				ID:             "widget1",
				Type:           "kpi",
				KPIID:          "test-kpi",
				Position:       "top-left",
				Size:           "medium",
				Config:         make(map[string]interface{}),
				Metadata:       make(map[string]string),
			},
			{
				ID:             "widget2",
				Type:           "visualization",
				VisualizationID: "test-viz",
				Position:       "top-right",
				Size:           "large",
				Config:         make(map[string]interface{}),
				Metadata:       make(map[string]string),
			},
		},
		CreatedAt: time.Now(),
		UpdatedAt: time.Now(),
		Metadata:  make(map[string]string),
	}

	// Register dashboard
	err = bi.RegisterDashboard(dashboard)
	if err != nil {
		t.Fatalf("Failed to register dashboard: %v", err)
	}

	// Generate dashboard
	result, err := bi.GenerateDashboard("test-dashboard", map[string]interface{}{
		"start_date": time.Now().Add(-30 * 24 * time.Hour),
		"end_date":   time.Now(),
	})
	if err != nil {
		t.Fatalf("Failed to generate dashboard: %v", err)
	}

	if result.DashboardID != "test-dashboard" {
		t.Errorf("Expected dashboard ID 'test-dashboard', got '%s'", result.DashboardID)
	}

	if result.Status != "completed" {
		t.Errorf("Expected status 'completed', got '%s'", result.Status)
	}
}

// TestBusinessIntelligenceKPIManagement tests KPI management functionality
func TestBusinessIntelligenceKPIManagement(t *testing.T) {
	config := BIConfig{
		EnableDashboards:    true,
		EnableVisualizations: true,
		EnableKPIs:          true,
		EnableAlerts:        true,
		EnableMonitoring:    true,
		MonitorInterval:     30 * time.Second,
		EnablePersistence:   false,
		PersistencePath:     "",
		MaxDashboards:       100,
		MaxVisualizations:   1000,
		RetentionPeriod:     365 * 24 * time.Hour,
	}

	bi := NewBusinessIntelligence(config)

	// Create multiple KPIs
	kpis := []*KPI{
		{
			ID:          "kpi1",
			Name:        "Revenue KPI",
			Description: "Total revenue KPI",
			DataSource:  "test-source",
			Type:        "metric",
			Formula:     "SUM(revenue)",
			Unit:        "USD",
			Target:      1000000,
			Threshold:   800000,
			Direction:   "up",
			CreatedAt:   time.Now(),
			UpdatedAt:   time.Now(),
			Metadata:    make(map[string]string),
		},
		{
			ID:          "kpi2",
			Name:        "Customer KPI",
			Description: "Customer count KPI",
			DataSource:  "test-source",
			Type:        "metric",
			Formula:     "COUNT(DISTINCT customer_id)",
			Unit:        "customers",
			Target:      10000,
			Threshold:   8000,
			Direction:   "up",
			CreatedAt:   time.Now(),
			UpdatedAt:   time.Now(),
			Metadata:    make(map[string]string),
		},
		{
			ID:          "kpi3",
			Name:        "Conversion KPI",
			Description: "Conversion rate KPI",
			DataSource:  "test-source",
			Type:        "ratio",
			Formula:     "conversions / visits * 100",
			Unit:        "%",
			Target:      5.0,
			Threshold:   4.0,
			Direction:   "up",
			CreatedAt:   time.Now(),
			UpdatedAt:   time.Now(),
			Metadata:    make(map[string]string),
		},
	}

	// Register KPIs
	for _, kpi := range kpis {
		err := bi.RegisterKPI(kpi)
		if err != nil {
			t.Fatalf("Failed to register KPI %s: %v", kpi.ID, err)
		}
	}

	// Get KPI
	retrievedKPI, err := bi.GetKPI("kpi1")
	if err != nil {
		t.Fatalf("Failed to get KPI: %v", err)
	}

	if retrievedKPI.ID != "kpi1" {
		t.Errorf("Expected KPI ID 'kpi1', got '%s'", retrievedKPI.ID)
	}

	// List KPIs
	allKPIs := bi.ListKPIs()
	if len(allKPIs) < 3 {
		t.Fatalf("Expected at least 3 KPIs, got %d", len(allKPIs))
	}

	found := make(map[string]bool)
	for _, kpi := range allKPIs {
		found[kpi.ID] = true
	}

	if !found["kpi1"] {
		t.Fatal("KPI1 should be in KPI list")
	}

	if !found["kpi2"] {
		t.Fatal("KPI2 should be in KPI list")
	}

	if !found["kpi3"] {
		t.Fatal("KPI3 should be in KPI list")
	}

	// Calculate KPI values
	for _, kpi := range kpis {
		value, err := bi.CalculateKPI(kpi.ID, map[string]interface{}{
			"start_date": time.Now().Add(-30 * 24 * time.Hour),
			"end_date":   time.Now(),
		})
		if err != nil {
			t.Fatalf("Failed to calculate KPI %s: %v", kpi.ID, err)
		}

		if value.KPIID != kpi.ID {
			t.Errorf("Expected KPI ID %s, got %s", kpi.ID, value.KPIID)
		}

		// Value should be a number
		if value.Value == nil {
			t.Errorf("KPI value should not be nil for %s", kpi.ID)
		}
	}
}

// TestBusinessIntelligenceVisualizationManagement tests visualization management
func TestBusinessIntelligenceVisualizationManagement(t *testing.T) {
	config := BIConfig{
		EnableDashboards:    true,
		EnableVisualizations: true,
		EnableKPIs:          true,
		EnableAlerts:        true,
		EnableMonitoring:    true,
		MonitorInterval:     30 * time.Second,
		EnablePersistence:   false,
		PersistencePath:     "",
		MaxDashboards:       100,
		MaxVisualizations:   1000,
		RetentionPeriod:     365 * 24 * time.Hour,
	}

	bi := NewBusinessIntelligence(config)

	// Create multiple visualizations
	visualizations := []*Visualization{
		{
			ID:          "viz1",
			Name:        "Sales Chart",
			Description: "Sales over time chart",
			Type:        "chart",
			ChartType:   "line",
			DataSource:  "test-source",
			Config: map[string]interface{}{
				"x_axis": "date",
				"y_axis": "sales",
				"title":  "Sales Over Time",
			},
			CreatedAt: time.Now(),
			UpdatedAt: time.Now(),
			Metadata:  make(map[string]string),
		},
		{
			ID:          "viz2",
			Name:        "Product Distribution",
			Description: "Product sales distribution",
			Type:        "chart",
			ChartType:   "pie",
			DataSource:  "test-source",
			Config: map[string]interface{}{
				"category": "product",
				"value":    "sales",
				"title":    "Product Sales Distribution",
			},
			CreatedAt: time.Now(),
			UpdatedAt: time.Now(),
			Metadata:  make(map[string]string),
		},
		{
			ID:          "viz3",
			Name:        "Regional Performance",
			Description: "Regional performance comparison",
			Type:        "chart",
			ChartType:   "bar",
			DataSource:  "test-source",
			Config: map[string]interface{}{
				"x_axis": "region",
				"y_axis": "sales",
				"title":  "Regional Sales Performance",
			},
			CreatedAt: time.Now(),
			UpdatedAt: time.Now(),
			Metadata:  make(map[string]string),
		},
	}

	// Register visualizations
	for _, viz := range visualizations {
		err := bi.RegisterVisualization(viz)
		if err != nil {
			t.Fatalf("Failed to register visualization %s: %v", viz.ID, err)
		}
	}

	// Get visualization
	retrievedViz, err := bi.GetVisualization("viz1")
	if err != nil {
		t.Fatalf("Failed to get visualization: %v", err)
	}

	if retrievedViz.ID != "viz1" {
		t.Errorf("Expected visualization ID 'viz1', got '%s'", retrievedViz.ID)
	}

	// List visualizations
	allVizs := bi.ListVisualizations()
	if len(allVizs) < 3 {
		t.Fatalf("Expected at least 3 visualizations, got %d", len(allVizs))
	}

	found := make(map[string]bool)
	for _, viz := range allVizs {
		found[viz.ID] = true
	}

	if !found["viz1"] {
		t.Fatal("Viz1 should be in visualization list")
	}

	if !found["viz2"] {
		t.Fatal("Viz2 should be in visualization list")
	}

	if !found["viz3"] {
		t.Fatal("Viz3 should be in visualization list")
	}

	// Generate visualization data
	for _, viz := range visualizations {
		data, err := bi.GenerateVisualization(viz.ID, map[string]interface{}{
			"start_date": time.Now().Add(-30 * 24 * time.Hour),
			"end_date":   time.Now(),
		})
		if err != nil {
			t.Fatalf("Failed to generate visualization %s: %v", viz.ID, err)
		}

		if data.VisualizationID != viz.ID {
			t.Errorf("Expected visualization ID %s, got %s", viz.ID, data.VisualizationID)
		}

		if data.Data == nil {
			t.Errorf("Visualization data should not be nil for %s", viz.ID)
		}
	}
}

// TestBusinessIntelligenceDashboardManagement tests dashboard management
func TestBusinessIntelligenceDashboardManagement(t *testing.T) {
	config := BIConfig{
		EnableDashboards:    true,
		EnableVisualizations: true,
		EnableKPIs:          true,
		EnableAlerts:        true,
		EnableMonitoring:    true,
		MonitorInterval:     30 * time.Second,
		EnablePersistence:   false,
		PersistencePath:     "",
		MaxDashboards:       100,
		MaxVisualizations:   1000,
		RetentionPeriod:     365 * 24 * time.Hour,
	}

	bi := NewBusinessIntelligence(config)

	// Create multiple dashboards
	dashboards := []*Dashboard{
		{
			ID:          "dashboard1",
			Name:        "Sales Dashboard",
			Description: "Sales performance dashboard",
			Layout:      "grid",
			Widgets: []*DashboardWidget{
				{
					ID:       "widget1",
					Type:     "kpi",
					KPIID:    "kpi1",
					Position: "top-left",
					Size:     "medium",
					Config:   make(map[string]interface{}),
					Metadata: make(map[string]string),
				},
				{
					ID:             "widget2",
					Type:           "visualization",
					VisualizationID: "viz1",
					Position:       "top-right",
					Size:           "large",
					Config:         make(map[string]interface{}),
					Metadata:       make(map[string]string),
				},
			},
			CreatedAt: time.Now(),
			UpdatedAt: time.Now(),
			Metadata:  make(map[string]string),
		},
		{
			ID:          "dashboard2",
			Name:        "Marketing Dashboard",
			Description: "Marketing performance dashboard",
			Layout:      "flexible",
			Widgets: []*DashboardWidget{
				{
					ID:       "widget3",
					Type:     "kpi",
					KPIID:    "kpi2",
					Position: "top",
					Size:     "full",
					Config:   make(map[string]interface{}),
					Metadata: make(map[string]string),
				},
			},
			CreatedAt: time.Now(),
			UpdatedAt: time.Now(),
			Metadata:  make(map[string]string),
		},
	}

	// Register dashboards
	for _, dashboard := range dashboards {
		err := bi.RegisterDashboard(dashboard)
		if err != nil {
			t.Fatalf("Failed to register dashboard %s: %v", dashboard.ID, err)
		}
	}

	// Get dashboard
	retrievedDashboard, err := bi.GetDashboard("dashboard1")
	if err != nil {
		t.Fatalf("Failed to get dashboard: %v", err)
	}

	if retrievedDashboard.ID != "dashboard1" {
		t.Errorf("Expected dashboard ID 'dashboard1', got '%s'", retrievedDashboard.ID)
	}

	// List dashboards
	allDashboards := bi.ListDashboards()
	if len(allDashboards) < 2 {
		t.Fatalf("Expected at least 2 dashboards, got %d", len(allDashboards))
	}

	found := make(map[string]bool)
	for _, dashboard := range allDashboards {
		found[dashboard.ID] = true
	}

	if !found["dashboard1"] {
		t.Fatal("Dashboard1 should be in dashboard list")
	}

	if !found["dashboard2"] {
		t.Fatal("Dashboard2 should be in dashboard list")
	}

	// Generate dashboard
	for _, dashboard := range dashboards {
		result, err := bi.GenerateDashboard(dashboard.ID, map[string]interface{}{
			"start_date": time.Now().Add(-30 * 24 * time.Hour),
			"end_date":   time.Now(),
		})
		if err != nil {
			t.Fatalf("Failed to generate dashboard %s: %v", dashboard.ID, err)
		}

		if result.DashboardID != dashboard.ID {
			t.Errorf("Expected dashboard ID %s, got %s", dashboard.ID, result.DashboardID)
		}

		if result.Status != "completed" {
			t.Errorf("Expected status 'completed' for dashboard %s, got '%s'", dashboard.ID, result.Status)
		}
	}
}

// TestBusinessIntelligenceAlerting tests alerting functionality
func TestBusinessIntelligenceAlerting(t *testing.T) {
	config := BIConfig{
		EnableDashboards:    true,
		EnableVisualizations: true,
		EnableKPIs:          true,
		EnableAlerts:        true,
		EnableMonitoring:    true,
		MonitorInterval:     30 * time.Second,
		EnablePersistence:   false,
		PersistencePath:     "",
		MaxDashboards:       100,
		MaxVisualizations:   1000,
		RetentionPeriod:     365 * 24 * time.Hour,
	}

	bi := NewBusinessIntelligence(config)

	// Create alert rule
	alertRule := &AlertRule{
		ID:          "test-alert",
		Name:        "Test Alert",
		Description: "A test alert rule",
		KPIID:       "test-kpi",
		Condition:   "below_threshold",
		Threshold:   800000,
		Severity:    "warning",
		Recipients:  []string{"alert@example.com"},
		Enabled:     true,
		CreatedAt:   time.Now(),
		UpdatedAt:   time.Now(),
		Metadata:    make(map[string]string),
	}

	// Register alert rule
	err := bi.RegisterAlertRule(alertRule)
	if err != nil {
		t.Fatalf("Failed to register alert rule: %v", err)
	}

	// Get alert rule
	retrievedAlert, err := bi.GetAlertRule("test-alert")
	if err != nil {
		t.Fatalf("Failed to get alert rule: %v", err)
	}

	if retrievedAlert.ID != "test-alert" {
		t.Errorf("Expected alert rule ID 'test-alert', got '%s'", retrievedAlert.ID)
	}

	// List alert rules
	allAlerts := bi.ListAlertRules()
	if len(allAlerts) == 0 {
		t.Fatal("Should have at least one alert rule")
	}

	found := false
	for _, alert := range allAlerts {
		if alert.ID == "test-alert" {
			found = true
			break
		}
	}

	if !found {
		t.Fatal("Created alert rule should be in alert list")
	}

	// Check alerts
	alerts := bi.CheckAlerts()
	if len(alerts) >= 0 {
		// Alerts might be triggered based on KPI values
		t.Logf("Found %d alerts", len(alerts))
	}
}

// TestBusinessIntelligenceMonitoring tests monitoring functionality
func TestBusinessIntelligenceMonitoring(t *testing.T) {
	config := BIConfig{
		EnableDashboards:    true,
		EnableVisualizations: true,
		EnableKPIs:          true,
		EnableAlerts:        true,
		EnableMonitoring:    true,
		MonitorInterval:     30 * time.Second,
		EnablePersistence:   false,
		PersistencePath:     "",
		MaxDashboards:       100,
		MaxVisualizations:   1000,
		RetentionPeriod:     365 * 24 * time.Hour,
	}

	bi := NewBusinessIntelligence(config)

	// Create and register multiple components to generate metrics
	for i := 0; i < 3; i++ {
		// Create KPI
		kpi := &KPI{
			ID:          fmt.Sprintf("monitor-kpi-%d", i),
			Name:        fmt.Sprintf("Monitor KPI %d", i),
			Description: fmt.Sprintf("A KPI for monitoring tests %d", i),
			DataSource:  "test-source",
			Type:        "metric",
			Formula:     fmt.Sprintf("SUM(value_%d)", i),
			Unit:        "units",
			Target:      1000,
			Threshold:   800,
			Direction:   "up",
			CreatedAt:   time.Now(),
			UpdatedAt:   time.Now(),
			Metadata:    make(map[string]string),
		}

		err := bi.RegisterKPI(kpi)
		if err != nil {
			t.Fatalf("Failed to register KPI %d: %v", i, err)
		}

		// Create visualization
		viz := &Visualization{
			ID:          fmt.Sprintf("monitor-viz-%d", i),
			Name:        fmt.Sprintf("Monitor Visualization %d", i),
			Description: fmt.Sprintf("A visualization for monitoring tests %d", i),
			Type:        "chart",
			ChartType:   "line",
			DataSource:  "test-source",
			Config:      make(map[string]interface{}),
			CreatedAt:   time.Now(),
			UpdatedAt:   time.Now(),
			Metadata:    make(map[string]string),
		}

		err = bi.RegisterVisualization(viz)
		if err != nil {
			t.Fatalf("Failed to register visualization %d: %v", i, err)
		}

		// Create dashboard
		dashboard := &Dashboard{
			ID:          fmt.Sprintf("monitor-dashboard-%d", i),
			Name:        fmt.Sprintf("Monitor Dashboard %d", i),
			Description: fmt.Sprintf("A dashboard for monitoring tests %d", i),
			Layout:      "grid",
			Widgets:     []*DashboardWidget{},
			CreatedAt:   time.Now(),
			UpdatedAt:   time.Now(),
			Metadata:    make(map[string]string),
		}

		err = bi.RegisterDashboard(dashboard)
		if err != nil {
			t.Fatalf("Failed to register dashboard %d: %v", i, err)
		}
	}

	// Wait for monitoring to collect metrics
	time.Sleep(1 * time.Minute)

	// Get statistics
	stats := bi.GetStats()
	if stats == nil {
		t.Fatal("Statistics should not be nil")
	}

	// Verify statistics contain expected data
	if stats["total_kpis"] == nil {
		t.Error("Statistics should contain total_kpis")
	}

	if stats["total_visualizations"] == nil {
		t.Error("Statistics should contain total_visualizations")
	}

	if stats["total_dashboards"] == nil {
		t.Error("Statistics should contain total_dashboards")
	}

	if stats["total_alert_rules"] == nil {
		t.Error("Statistics should contain total_alert_rules")
	}
}

// BenchmarkBusinessIntelligenceGenerateDashboard benchmarks dashboard generation
func BenchmarkBusinessIntelligenceGenerateDashboard(b *testing.B) {
	config := BIConfig{
		EnableDashboards:    true,
		EnableVisualizations: true,
		EnableKPIs:          true,
		EnableAlerts:        false,
		EnableMonitoring:    false,
		MonitorInterval:     30 * time.Second,
		EnablePersistence:   false,
		PersistencePath:     "",
		MaxDashboards:       100,
		MaxVisualizations:   1000,
		RetentionPeriod:     365 * 24 * time.Hour,
	}

	bi := NewBusinessIntelligence(config)

	// Create dashboard
	dashboard := &Dashboard{
		ID:          "benchmark-dashboard",
		Name:        "Benchmark Dashboard",
		Description: "A dashboard for benchmarking",
		Layout:      "grid",
		Widgets:     []*DashboardWidget{},
		CreatedAt:   time.Now(),
		UpdatedAt:   time.Now(),
		Metadata:    make(map[string]string),
	}

	err := bi.RegisterDashboard(dashboard)
	if err != nil {
		b.Fatalf("Failed to register dashboard: %v", err)
	}

	params := map[string]interface{}{
		"start_date": time.Now().Add(-30 * 24 * time.Hour),
		"end_date":   time.Now(),
	}

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		_, err := bi.GenerateDashboard("benchmark-dashboard", params)
		if err != nil {
			b.Fatalf("Dashboard generation failed: %v", err)
		}
	}
} 