package main

import (
	"fmt"
	"testing"
	"time"
)

// TestReportingEngineBasic tests basic reporting functionality
func TestReportingEngineBasic(t *testing.T) {
	config := ReportingConfig{
		EnableScheduling:    true,
		EnableTemplates:     true,
		EnableExport:        true,
		EnableDistribution:  true,
		EnableMonitoring:    true,
		MonitorInterval:     30 * time.Second,
		EnablePersistence:   false,
		PersistencePath:     "",
		MaxReports:          1000,
		RetentionPeriod:     90 * 24 * time.Hour, // 90 days
		DefaultFormat:       "pdf",
		EnableCompression:   true,
	}

	re := NewReportingEngine(config)
	if re == nil {
		t.Fatal("Failed to create ReportingEngine")
	}

	// Create a report template
	template := &ReportTemplate{
		ID:          "test-template",
		Name:        "Test Template",
		Description: "A test report template",
		Type:        "html",
		Content:     "<html><body><h1>{{.title}}</h1><p>{{.content}}</p></body></html>",
		Variables: []*TemplateVariable{
			{
				Name:        "title",
				Type:        "string",
				Required:    true,
				Default:     "Default Title",
				Description: "Report title",
			},
			{
				Name:        "content",
				Type:        "string",
				Required:    true,
				Default:     "Default content",
				Description: "Report content",
			},
		},
		CreatedAt: time.Now(),
		UpdatedAt: time.Now(),
		Metadata:  make(map[string]string),
	}

	// Register template
	err := re.RegisterTemplate(template)
	if err != nil {
		t.Fatalf("Failed to register template: %v", err)
	}

	// Create a report
	report := &Report{
		ID:          "test-report",
		Name:        "Test Report",
		Description: "A test report",
		TemplateID:  "test-template",
		Type:        "scheduled",
		Format:      "pdf",
		Schedule: &ReportSchedule{
			Type:     "daily",
			Time:     "09:00",
			Timezone: "UTC",
			Enabled:  true,
		},
		Parameters: map[string]interface{}{
			"title":   "Test Report Title",
			"content": "This is test report content",
		},
		Recipients: []string{"test@example.com"},
		CreatedAt:  time.Now(),
		UpdatedAt:  time.Now(),
		Metadata:   make(map[string]string),
	}

	// Register report
	err = re.RegisterReport(report)
	if err != nil {
		t.Fatalf("Failed to register report: %v", err)
	}

	// Generate report
	result, err := re.GenerateReport("test-report", map[string]interface{}{
		"title":   "Generated Report Title",
		"content": "This is generated report content",
	})
	if err != nil {
		t.Fatalf("Failed to generate report: %v", err)
	}

	if result.ReportID != "test-report" {
		t.Errorf("Expected report ID 'test-report', got '%s'", result.ReportID)
	}

	if result.Status != "completed" {
		t.Errorf("Expected status 'completed', got '%s'", result.Status)
	}

	if result.Content == nil {
		t.Fatal("Report should have content")
	}
}

// TestReportingEngineTemplateManagement tests template management
func TestReportingEngineTemplateManagement(t *testing.T) {
	config := ReportingConfig{
		EnableScheduling:    true,
		EnableTemplates:     true,
		EnableExport:        true,
		EnableDistribution:  true,
		EnableMonitoring:    true,
		MonitorInterval:     30 * time.Second,
		EnablePersistence:   false,
		PersistencePath:     "",
		MaxReports:          1000,
		RetentionPeriod:     90 * 24 * time.Hour,
		DefaultFormat:       "pdf",
		EnableCompression:   true,
	}

	re := NewReportingEngine(config)

	// Create multiple templates
	templates := []*ReportTemplate{
		{
			ID:          "template1",
			Name:        "Template 1",
			Description: "First test template",
			Type:        "html",
			Content:     "<html><body><h1>{{.title}}</h1></body></html>",
			Variables: []*TemplateVariable{
				{
					Name:        "title",
					Type:        "string",
					Required:    true,
					Default:     "Default Title",
					Description: "Report title",
				},
			},
			CreatedAt: time.Now(),
			UpdatedAt: time.Now(),
			Metadata:  make(map[string]string),
		},
		{
			ID:          "template2",
			Name:        "Template 2",
			Description: "Second test template",
			Type:        "markdown",
			Content:     "# {{.title}}\n\n{{.content}}",
			Variables: []*TemplateVariable{
				{
					Name:        "title",
					Type:        "string",
					Required:    true,
					Default:     "Default Title",
					Description: "Report title",
				},
				{
					Name:        "content",
					Type:        "string",
					Required:    true,
					Default:     "Default content",
					Description: "Report content",
				},
			},
			CreatedAt: time.Now(),
			UpdatedAt: time.Now(),
			Metadata:  make(map[string]string),
		},
	}

	// Register templates
	for _, template := range templates {
		err := re.RegisterTemplate(template)
		if err != nil {
			t.Fatalf("Failed to register template %s: %v", template.ID, err)
		}
	}

	// Get template
	retrievedTemplate, err := re.GetTemplate("template1")
	if err != nil {
		t.Fatalf("Failed to get template: %v", err)
	}

	if retrievedTemplate.ID != "template1" {
		t.Errorf("Expected template ID 'template1', got '%s'", retrievedTemplate.ID)
	}

	// List templates
	allTemplates := re.ListTemplates()
	if len(allTemplates) < 2 {
		t.Fatalf("Expected at least 2 templates, got %d", len(allTemplates))
	}

	found := make(map[string]bool)
	for _, template := range allTemplates {
		found[template.ID] = true
	}

	if !found["template1"] {
		t.Fatal("Template1 should be in template list")
	}

	if !found["template2"] {
		t.Fatal("Template2 should be in template list")
	}
}

// TestReportingEngineReportScheduling tests report scheduling
func TestReportingEngineReportScheduling(t *testing.T) {
	config := ReportingConfig{
		EnableScheduling:    true,
		EnableTemplates:     true,
		EnableExport:        true,
		EnableDistribution:  true,
		EnableMonitoring:    true,
		MonitorInterval:     30 * time.Second,
		EnablePersistence:   false,
		PersistencePath:     "",
		MaxReports:          1000,
		RetentionPeriod:     90 * 24 * time.Hour,
		DefaultFormat:       "pdf",
		EnableCompression:   true,
	}

	re := NewReportingEngine(config)

	// Create template
	template := &ReportTemplate{
		ID:          "scheduled-template",
		Name:        "Scheduled Template",
		Description: "A template for scheduling tests",
		Type:        "html",
		Content:     "<html><body><h1>{{.title}}</h1><p>{{.content}}</p></body></html>",
		Variables: []*TemplateVariable{
			{
				Name:        "title",
				Type:        "string",
				Required:    true,
				Default:     "Scheduled Report",
				Description: "Report title",
			},
			{
				Name:        "content",
				Type:        "string",
				Required:    true,
				Default:     "This is a scheduled report",
				Description: "Report content",
			},
		},
		CreatedAt: time.Now(),
		UpdatedAt: time.Now(),
		Metadata:  make(map[string]string),
	}

	// Register template
	err := re.RegisterTemplate(template)
	if err != nil {
		t.Fatalf("Failed to register template: %v", err)
	}

	// Create scheduled report
	report := &Report{
		ID:          "scheduled-report",
		Name:        "Scheduled Report",
		Description: "A report for scheduling tests",
		TemplateID:  "scheduled-template",
		Type:        "scheduled",
		Format:      "pdf",
		Schedule: &ReportSchedule{
			Type:     "hourly",
			Time:     "00:00",
			Timezone: "UTC",
			Enabled:  true,
		},
		Parameters: map[string]interface{}{
			"title":   "Scheduled Report Title",
			"content": "This is scheduled report content",
		},
		Recipients: []string{"scheduled@example.com"},
		CreatedAt:  time.Now(),
		UpdatedAt:  time.Now(),
		Metadata:   make(map[string]string),
	}

	// Register report
	err = re.RegisterReport(report)
	if err != nil {
		t.Fatalf("Failed to register report: %v", err)
	}

	// Get report
	retrievedReport, err := re.GetReport("scheduled-report")
	if err != nil {
		t.Fatalf("Failed to get report: %v", err)
	}

	if retrievedReport.ID != "scheduled-report" {
		t.Errorf("Expected report ID 'scheduled-report', got '%s'", retrievedReport.ID)
	}

	// List reports
	allReports := re.ListReports()
	if len(allReports) == 0 {
		t.Fatal("Should have at least one report")
	}

	found := false
	for _, r := range allReports {
		if r.ID == "scheduled-report" {
			found = true
			break
		}
	}

	if !found {
		t.Fatal("Created report should be in report list")
	}

	// Wait for scheduled execution
	time.Sleep(2 * time.Minute)

	// Check that report was generated
	generations := re.ListGenerations()
	found = false
	for _, generation := range generations {
		if generation.ReportID == "scheduled-report" {
			found = true
			break
		}
	}

	if !found {
		t.Fatal("Scheduled report should have been generated")
	}
}

// TestReportingEngineExportFormats tests export format functionality
func TestReportingEngineExportFormats(t *testing.T) {
	config := ReportingConfig{
		EnableScheduling:    true,
		EnableTemplates:     true,
		EnableExport:        true,
		EnableDistribution:  true,
		EnableMonitoring:    true,
		MonitorInterval:     30 * time.Second,
		EnablePersistence:   false,
		PersistencePath:     "",
		MaxReports:          1000,
		RetentionPeriod:     90 * 24 * time.Hour,
		DefaultFormat:       "pdf",
		EnableCompression:   true,
	}

	re := NewReportingEngine(config)

	// Create template
	template := &ReportTemplate{
		ID:          "export-template",
		Name:        "Export Template",
		Description: "A template for export format tests",
		Type:        "html",
		Content:     "<html><body><h1>{{.title}}</h1><p>{{.content}}</p></body></html>",
		Variables: []*TemplateVariable{
			{
				Name:        "title",
				Type:        "string",
				Required:    true,
				Default:     "Export Report",
				Description: "Report title",
			},
			{
				Name:        "content",
				Type:        "string",
				Required:    true,
				Default:     "This is an export report",
				Description: "Report content",
			},
		},
		CreatedAt: time.Now(),
		UpdatedAt: time.Now(),
		Metadata:  make(map[string]string),
	}

	// Register template
	err := re.RegisterTemplate(template)
	if err != nil {
		t.Fatalf("Failed to register template: %v", err)
	}

	// Test different export formats
	formats := []string{"pdf", "html", "csv", "json", "xml"}

	for _, format := range formats {
		report := &Report{
			ID:          fmt.Sprintf("export-report-%s", format),
			Name:        fmt.Sprintf("Export Report %s", format),
			Description: fmt.Sprintf("A report for %s export tests", format),
			TemplateID:  "export-template",
			Type:        "manual",
			Format:      format,
			Parameters: map[string]interface{}{
				"title":   fmt.Sprintf("Export Report %s", format),
				"content": fmt.Sprintf("This is %s export content", format),
			},
			CreatedAt: time.Now(),
			UpdatedAt: time.Now(),
			Metadata:  make(map[string]string),
		}

		// Register report
		err := re.RegisterReport(report)
		if err != nil {
			t.Fatalf("Failed to register report for format %s: %v", format, err)
		}

		// Generate report
		result, err := re.GenerateReport(report.ID, map[string]interface{}{
			"title":   fmt.Sprintf("Generated %s Report", format),
			"content": fmt.Sprintf("This is generated %s content", format),
		})
		if err != nil {
			t.Fatalf("Failed to generate report for format %s: %v", format, err)
		}

		if result.Status != "completed" {
			t.Errorf("Expected status 'completed' for format %s, got '%s'", format, result.Status)
		}

		if result.Content == nil {
			t.Errorf("Report should have content for format %s", format)
		}

		if result.Format != format {
			t.Errorf("Expected format %s, got %s", format, result.Format)
		}
	}
}

// TestReportingEngineDistribution tests report distribution
func TestReportingEngineDistribution(t *testing.T) {
	config := ReportingConfig{
		EnableScheduling:    true,
		EnableTemplates:     true,
		EnableExport:        true,
		EnableDistribution:  true,
		EnableMonitoring:    true,
		MonitorInterval:     30 * time.Second,
		EnablePersistence:   false,
		PersistencePath:     "",
		MaxReports:          1000,
		RetentionPeriod:     90 * 24 * time.Hour,
		DefaultFormat:       "pdf",
		EnableCompression:   true,
	}

	re := NewReportingEngine(config)

	// Create template
	template := &ReportTemplate{
		ID:          "distribution-template",
		Name:        "Distribution Template",
		Description: "A template for distribution tests",
		Type:        "html",
		Content:     "<html><body><h1>{{.title}}</h1><p>{{.content}}</p></body></html>",
		Variables: []*TemplateVariable{
			{
				Name:        "title",
				Type:        "string",
				Required:    true,
				Default:     "Distribution Report",
				Description: "Report title",
			},
			{
				Name:        "content",
				Type:        "string",
				Required:    true,
				Default:     "This is a distribution report",
				Description: "Report content",
			},
		},
		CreatedAt: time.Now(),
		UpdatedAt: time.Now(),
		Metadata:  make(map[string]string),
	}

	// Register template
	err := re.RegisterTemplate(template)
	if err != nil {
		t.Fatalf("Failed to register template: %v", err)
	}

	// Create report with distribution
	report := &Report{
		ID:          "distribution-report",
		Name:        "Distribution Report",
		Description: "A report for distribution tests",
		TemplateID:  "distribution-template",
		Type:        "manual",
		Format:      "pdf",
		Parameters: map[string]interface{}{
			"title":   "Distribution Report Title",
			"content": "This is distribution report content",
		},
		Recipients: []string{"recipient1@example.com", "recipient2@example.com"},
		Distribution: &DistributionConfig{
			Method:     "email",
			Subject:    "Test Report",
			Body:       "Please find the attached report",
			AttachFile: true,
		},
		CreatedAt: time.Now(),
		UpdatedAt: time.Now(),
		Metadata:  make(map[string]string),
	}

	// Register report
	err = re.RegisterReport(report)
	if err != nil {
		t.Fatalf("Failed to register report: %v", err)
	}

	// Generate and distribute report
	result, err := re.GenerateReport("distribution-report", map[string]interface{}{
		"title":   "Distributed Report Title",
		"content": "This is distributed report content",
	})
	if err != nil {
		t.Fatalf("Failed to generate report: %v", err)
	}

	if result.Status != "completed" {
		t.Errorf("Expected status 'completed', got '%s'", result.Status)
	}

	// Verify distribution
	distributions := re.ListDistributions()
	found := false
	for _, distribution := range distributions {
		if distribution.ReportID == "distribution-report" {
			found = true
			break
		}
	}

	if !found {
		t.Fatal("Report distribution should have been created")
	}
}

// TestReportingEngineMonitoring tests monitoring functionality
func TestReportingEngineMonitoring(t *testing.T) {
	config := ReportingConfig{
		EnableScheduling:    true,
		EnableTemplates:     true,
		EnableExport:        true,
		EnableDistribution:  true,
		EnableMonitoring:    true,
		MonitorInterval:     30 * time.Second,
		EnablePersistence:   false,
		PersistencePath:     "",
		MaxReports:          1000,
		RetentionPeriod:     90 * 24 * time.Hour,
		DefaultFormat:       "pdf",
		EnableCompression:   true,
	}

	re := NewReportingEngine(config)

	// Create and generate multiple reports to generate metrics
	for i := 0; i < 5; i++ {
		template := &ReportTemplate{
			ID:          fmt.Sprintf("monitor-template-%d", i),
			Name:        fmt.Sprintf("Monitor Template %d", i),
			Description: fmt.Sprintf("A template for monitoring tests %d", i),
			Type:        "html",
			Content:     fmt.Sprintf("<html><body><h1>Report %d</h1></body></html>", i),
			Variables:   []*TemplateVariable{},
			CreatedAt:   time.Now(),
			UpdatedAt:   time.Now(),
			Metadata:    make(map[string]string),
		}

		err := re.RegisterTemplate(template)
		if err != nil {
			t.Fatalf("Failed to register template %d: %v", i, err)
		}

		report := &Report{
			ID:          fmt.Sprintf("monitor-report-%d", i),
			Name:        fmt.Sprintf("Monitor Report %d", i),
			Description: fmt.Sprintf("A report for monitoring tests %d", i),
			TemplateID:  template.ID,
			Type:        "manual",
			Format:      "pdf",
			Parameters:  make(map[string]interface{}),
			CreatedAt:   time.Now(),
			UpdatedAt:   time.Now(),
			Metadata:    make(map[string]string),
		}

		err = re.RegisterReport(report)
		if err != nil {
			t.Fatalf("Failed to register report %d: %v", i, err)
		}

		_, err = re.GenerateReport(report.ID, make(map[string]interface{}))
		if err != nil {
			t.Fatalf("Failed to generate report %d: %v", i, err)
		}
	}

	// Wait for monitoring to collect metrics
	time.Sleep(1 * time.Minute)

	// Get statistics
	stats := re.GetStats()
	if stats == nil {
		t.Fatal("Statistics should not be nil")
	}

	// Verify statistics contain expected data
	if stats["total_reports"] == nil {
		t.Error("Statistics should contain total_reports")
	}

	if stats["total_templates"] == nil {
		t.Error("Statistics should contain total_templates")
	}

	if stats["total_generations"] == nil {
		t.Error("Statistics should contain total_generations")
	}

	if stats["successful_generations"] == nil {
		t.Error("Statistics should contain successful_generations")
	}
}

// BenchmarkReportingEngineGenerateReport benchmarks report generation
func BenchmarkReportingEngineGenerateReport(b *testing.B) {
	config := ReportingConfig{
		EnableScheduling:    false,
		EnableTemplates:     true,
		EnableExport:        true,
		EnableDistribution:  false,
		EnableMonitoring:    false,
		MonitorInterval:     30 * time.Second,
		EnablePersistence:   false,
		PersistencePath:     "",
		MaxReports:          1000,
		RetentionPeriod:     90 * 24 * time.Hour,
		DefaultFormat:       "pdf",
		EnableCompression:   false,
	}

	re := NewReportingEngine(config)

	// Create template
	template := &ReportTemplate{
		ID:          "benchmark-template",
		Name:        "Benchmark Template",
		Description: "A template for benchmarking",
		Type:        "html",
		Content:     "<html><body><h1>{{.title}}</h1><p>{{.content}}</p></body></html>",
		Variables: []*TemplateVariable{
			{
				Name:        "title",
				Type:        "string",
				Required:    true,
				Default:     "Benchmark Report",
				Description: "Report title",
			},
			{
				Name:        "content",
				Type:        "string",
				Required:    true,
				Default:     "This is benchmark content",
				Description: "Report content",
			},
		},
		CreatedAt: time.Now(),
		UpdatedAt: time.Now(),
		Metadata:  make(map[string]string),
	}

	err := re.RegisterTemplate(template)
	if err != nil {
		b.Fatalf("Failed to register template: %v", err)
	}

	// Create report
	report := &Report{
		ID:          "benchmark-report",
		Name:        "Benchmark Report",
		Description: "A report for benchmarking",
		TemplateID:  "benchmark-template",
		Type:        "manual",
		Format:      "html",
		Parameters: map[string]interface{}{
			"title":   "Benchmark Report Title",
			"content": "This is benchmark report content",
		},
		CreatedAt: time.Now(),
		UpdatedAt: time.Now(),
		Metadata:  make(map[string]string),
	}

	err = re.RegisterReport(report)
	if err != nil {
		b.Fatalf("Failed to register report: %v", err)
	}

	params := map[string]interface{}{
		"title":   "Generated Benchmark Report",
		"content": "This is generated benchmark content",
	}

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		_, err := re.GenerateReport("benchmark-report", params)
		if err != nil {
			b.Fatalf("Report generation failed: %v", err)
		}
	}
} 