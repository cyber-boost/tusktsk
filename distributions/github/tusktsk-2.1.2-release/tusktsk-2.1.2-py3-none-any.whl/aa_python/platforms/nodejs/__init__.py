"""
TuskLang Python SDK - Node.js Platform Integration
Enables TuskLang to integrate with Node.js applications via N-API
"""

from .nodejs_integration import NodeJSIntegration
from .napi_bridge import NApiBridge
from .async_bridge import AsyncBridge
from .npm_package import NPMPackageManager

__all__ = [
    'NodeJSIntegration',
    'NApiBridge',
    'AsyncBridge', 
    'NPMPackageManager'
]

__version__ = "1.0.0"
__platform__ = "Node.js" 