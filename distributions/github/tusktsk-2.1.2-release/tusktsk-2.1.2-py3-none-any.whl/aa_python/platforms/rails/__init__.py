"""
TuskLang Python SDK - Ruby on Rails Integration
Enables TuskLang to integrate with Rails applications via Ruby FFI
"""

from .rails_integration import RailsIntegration
from .ruby_ffi import RubyFFIBridge
from .activerecord_orm import ActiveRecordORM
from .rails_generators import RailsGeneratorManager

__all__ = [
    'RailsIntegration',
    'RubyFFIBridge',
    'ActiveRecordORM',
    'RailsGeneratorManager'
]

__version__ = "1.0.0"
__platform__ = "Ruby on Rails" 