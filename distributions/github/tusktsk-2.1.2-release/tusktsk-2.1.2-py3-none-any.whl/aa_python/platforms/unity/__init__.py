"""
TuskLang Python SDK - Unity Game Engine Integration
Enables TuskLang to integrate with Unity projects via native plugins
"""

from .unity_integration import UnityIntegration
from .unity_plugin import UnityNativePlugin
from .csharp_bridge import CSharpBridge
from .asset_pipeline import AssetPipelineManager

__all__ = [
    'UnityIntegration',
    'UnityNativePlugin',
    'CSharpBridge',
    'AssetPipelineManager'
]

__version__ = "1.0.0"
__platform__ = "Unity" 