"""
TuskLang Python SDK - Azure Functions Integration
Enables TuskLang to run as serverless Azure Functions
"""

from .azure_integration import AzureFunctionsIntegration
from .function_app import FunctionAppManager
from .triggers import TriggerManager
from .deployment import AzureDeploymentManager

__all__ = [
    'AzureFunctionsIntegration',
    'FunctionAppManager',
    'TriggerManager',
    'AzureDeploymentManager'
]

__version__ = "1.0.0"
__platform__ = "Azure Functions" 