"""
TuskLang Python SDK - Jekyll Static Site Generator Integration
Enables TuskLang to process content at build time with Jekyll
"""

from .jekyll_integration import JekyllIntegration
from .liquid_templates import LiquidTemplateManager
from .build_processor import BuildTimeProcessor
from .github_pages import GitHubPagesManager

__all__ = [
    'JekyllIntegration',
    'LiquidTemplateManager',
    'BuildTimeProcessor',
    'GitHubPagesManager'
]

__version__ = "1.0.0"
__platform__ = "Jekyll" 